package com.cobblemonislands.emotive.command;

import com.cobblemonislands.emotive.config.Animations;
import com.cobblemonislands.emotive.config.ConfiguredAnimation;
import com.cobblemonislands.emotive.config.ModConfig;
import com.cobblemonislands.emotive.gui.EmoteSelectionGui;
import com.cobblemonislands.emotive.impl.GestureController;
import com.cobblemonislands.emotive.util.TextUtil;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.datafixers.util.Pair;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Predicate;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class EmotiveCommand {
    private EmotiveCommand() {}

    public static void register(com.mojang.brigadier.CommandDispatcher<class_2168> dispatcher) {
        final ModConfig config = ModConfig.getInstance();

        SuggestionProvider<class_2168> animationSuggestions =  (context, builder) -> {
            final String rem = builder.getRemaining().toLowerCase(Locale.ROOT);

            for (Map.Entry<class_2960, ConfiguredAnimation> entry : Animations.all().entrySet()) {
                final class_2960 id = entry.getKey();
                final ConfiguredAnimation animation = entry.getValue();

                final class_3222 sourcePlayer = context.getSource().method_44023();
                final boolean hasAccess = (sourcePlayer == null)
                        || sourcePlayer.method_5687(4)
                        || ModConfig.getInstance().getStorage().owns(sourcePlayer, id);

                if (!hasAccess) continue;

                final String nameLower = animation.animationName().toLowerCase(Locale.ROOT);
                final String idPath = id.method_12832().toLowerCase(Locale.ROOT);

                if (nameLower.startsWith(rem) || idPath.startsWith(rem)) {
                    builder.suggest(id.method_12832());
                }
            }

            return builder.buildFuture();
        };

        final Function<String, Predicate<class_2168>> requirePerm = (permKey) ->
                Permissions.require(permKey, config.permissions.getOrDefault(permKey, 2));

        var root = method_9247(config.command)
                .requires(requirePerm.apply("emotive.command"))
                .executes(EmotiveCommand::openGui);

        // /<cmd> reload
        root = root.then(method_9247("reload")
                .requires(requirePerm.apply("emotive.reload"))
                .executes(ctx -> {
                    ModConfig.load();
                    ctx.getSource().method_9226(() -> TextUtil.parse(ModConfig.getInstance().messages.configReloaded), false);
                    return Command.SINGLE_SUCCESS;
                }));

        // /<cmd> give <player> <emote>
        root = root.then(method_9247("give")
                .requires(requirePerm.apply("emotive.give"))
                .then(method_9244("player", class_2186.method_9305())
                        .then(method_9247("*").executes(EmotiveCommand::handleAddAll))
                        .then(method_9244("emote", StringArgumentType.word()).suggests(animationSuggestions)
                                .executes(EmotiveCommand::handleAdd))));

        // /<cmd> remove <player> <emote>
        root = root.then(method_9247("remove")
                .requires(requirePerm.apply("emotive.remove"))
                .then(method_9244("player", class_2186.method_9305())
                        .then(method_9247("*").executes(EmotiveCommand::handleRemoveAll))
                        .then(method_9244("emote", StringArgumentType.word()).suggests(animationSuggestions)
                                .executes(EmotiveCommand::handleRemove))));

        // /<cmd> list <player>
        root = root.then(method_9247("list")
                .requires(requirePerm.apply("emotive.list"))
                .then(method_9244("player", class_2186.method_9305())
                        .executes(EmotiveCommand::handleList)));

        // run emote directly: /<cmd> <emote>
        dispatcher.register(root.then(method_9244("emote", StringArgumentType.word())
                .requires(requirePerm.apply("emotive.direct"))
                .suggests(animationSuggestions)
                .executes(EmotiveCommand::executeEmote)));
    }

    private static int openGui(CommandContext<class_2168> ctx) {
        final class_3222 player = ctx.getSource().method_44023();
        if (player == null) return 0;

        final EmoteSelectionGui gui = new EmoteSelectionGui(player, false);
        gui.open();
        return Command.SINGLE_SUCCESS;
    }

    private static int handleAddAll(CommandContext<class_2168> ctx) {
        try {
            final class_3222 player = class_2186.method_9315(ctx, "player");
            int added = (int) Animations.all().keySet().stream().filter(name -> ModConfig.getInstance().getStorage().add(player, name)).count();
            ctx.getSource().method_9226(() -> class_2561.method_43470(String.format("Successfully added %d emotes to %s", added, player.method_5820())), false);
        } catch (CommandSyntaxException e) {
            ctx.getSource().method_9213(TextUtil.parse(ModConfig.getInstance().messages.playerNotFound));
            return 0;
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("An unexpected error occurred while adding all emote"));
            return 0;
        }

        return Command.SINGLE_SUCCESS;
    }

    private static int handleRemoveAll(CommandContext<class_2168> ctx) {
        try {
            final class_3222 player = class_2186.method_9315(ctx, "player");
            int added = (int) Animations.all().keySet().stream().filter(name -> ModConfig.getInstance().getStorage().remove(player, name)).count();
            ctx.getSource().method_9226(() -> class_2561.method_43470(String.format("Successfully removed %d emotes from %s", added, player.method_5820())), false);
        } catch (CommandSyntaxException e) {
            ctx.getSource().method_9213(TextUtil.parse(ModConfig.getInstance().messages.playerNotFound));
            return 0;
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("An unexpected error occurred while removing all emote"));
            return 0;
        }

        return Command.SINGLE_SUCCESS;
    }

    private static int handleAdd(CommandContext<class_2168> ctx) {
        try {
            final class_3222 player = class_2186.method_9315(ctx, "player");
            final String emoteName = StringArgumentType.getString(ctx, "emote");
            final var emote = ModConfig.getInstance().getAnimation(emoteName);

            final boolean success = emote != null && ModConfig.getInstance().getStorage().add(player, emote.getFirst());
            if (success) {
                ctx.getSource().method_9226(() -> class_2561.method_43470(String.format("Successfully added '%s' to %s", emote, player.method_5820())), false);
                return Command.SINGLE_SUCCESS;
            } else {
                ctx.getSource().method_9213(class_2561.method_43470(String.format("%s already owns '%s'", player.method_5820(), emote)));
                return 0;
            }
        } catch (CommandSyntaxException e) {
            ctx.getSource().method_9213(TextUtil.parse(ModConfig.getInstance().messages.playerNotFound));
            return 0;
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("An unexpected error occurred while adding emote"));
            return 0;
        }
    }

    private static int handleRemove(CommandContext<class_2168> ctx) {
        try {
            final class_3222 player = class_2186.method_9315(ctx, "player");
            final String emote = StringArgumentType.getString(ctx, "emote");
            final Pair<class_2960, ConfiguredAnimation> res = ModConfig.getInstance().getAnimation(emote);
            final boolean success = res != null && ModConfig.getInstance().getStorage().remove(player, res.getFirst());
            if (success) {
                ctx.getSource().method_9226(() -> class_2561.method_43470(String.format("Successfully removed '%s' from %s", emote, player.method_5820())), false);
                return Command.SINGLE_SUCCESS;
            } else {
                ctx.getSource().method_9213(class_2561.method_43470(String.format("%s does not own '%s'", player.method_5820(), emote)));
                return 0;
            }
        } catch (CommandSyntaxException e) {
            ctx.getSource().method_9213(TextUtil.parse(ModConfig.getInstance().messages.playerNotFound));
            return 0;
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("An unexpected error occurred while removing emote"));
            return 0;
        }
    }

    private static int handleList(CommandContext<class_2168> ctx) {
        try {
            final class_3222 player = class_2186.method_9315(ctx, "player");

            CompletableFuture.runAsync(() -> {
                final List<String> list = ModConfig.getInstance().getStorage().list(player);
                if (list.isEmpty()) {
                    ctx.getSource().method_9213(class_2561.method_43470(String.format("No entries for player %s!", player.method_5820())));
                    return;
                }

                for (String s : list) {
                    ctx.getSource().method_9226(() -> class_2561.method_43470(s), false);
                }
            });

            return Command.SINGLE_SUCCESS;
        } catch (CommandSyntaxException e) {
            ctx.getSource().method_9213(TextUtil.parse(ModConfig.getInstance().messages.playerNotFound));
            return 0;
        }
    }

    private static int executeEmote(CommandContext<class_2168> ctx) {
        final class_2168 source = ctx.getSource();

        if (!source.method_43737()) {
            source.method_9213(TextUtil.parse(ModConfig.getInstance().messages.onlyPlayer));
            return 0;
        }

        final class_3222 player = source.method_44023();
        if (player == null) return 0;

        final String animation = StringArgumentType.getString(ctx, "emote");
        final var anim = ModConfig.getInstance().getAnimation(animation);
        CompletableFuture.runAsync(() -> {
            if (anim == null || !ModConfig.getInstance().getStorage().owns(player, anim.getFirst())) {
                source.method_9213(TextUtil.parse(ModConfig.getInstance().messages.noPermission));
                return;
            }

            final ConfiguredAnimation found = Animations.all().values().stream()
                    .filter(a -> a.animationName().equals(animation))
                    .findFirst().orElse(null);

            if (found == null) {
                if (ModConfig.getInstance().messages.unknownEmote != null) source.method_9213(TextUtil.parse(String.format(ModConfig.getInstance().messages.unknownEmote, animation)));
                return;
            }

            ctx.getSource().method_9211().execute(() -> GestureController.onStart(player, found));
        });

        return Command.SINGLE_SUCCESS;
    }
}

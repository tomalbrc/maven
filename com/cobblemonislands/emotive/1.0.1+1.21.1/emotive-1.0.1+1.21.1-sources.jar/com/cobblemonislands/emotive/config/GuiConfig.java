package com.cobblemonislands.emotive.config;

import com.cobblemonislands.emotive.util.TextUtil;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import org.joml.Vector2i;

public class GuiConfig {
    public boolean addBackButton = true;
    public class_2960 backButtonItem = class_1802.field_8107.method_40131().method_40237().method_29177();
    public Vector2i backButtonLocation = new Vector2i(1, 1);
    public class_1799 backItem() {
        var item = class_7923.field_41178.method_10223(backButtonItem).method_7854();
        item.method_57379(class_9334.field_50239, TextUtil.parse(ModConfig.getInstance().messages.back));
        return item;
    }

    public int selectionMenuHeight = 6;
    public String selectionMenuTitle = "Select Emote";

    public class_2960 prevButtonItem = class_1802.field_8107.method_40131().method_40237().method_29177();
    public class_2960 nextButtonItem = class_1802.field_8107.method_40131().method_40237().method_29177();
    // default to bottom-right area (1-based coords as used elsewhere)
    public Vector2i prevButtonLocation = new Vector2i(8, 6);
    public Vector2i nextButtonLocation = new Vector2i(9, 6);

    public class_1799 prevItem() {
        var item = class_7923.field_41178.method_10223(prevButtonItem).method_7854();
        item.method_57379(class_9334.field_50239, TextUtil.parse(ModConfig.getInstance().messages.prev));
        return item;
    }

    public class_1799 nextItem() {
        var item = class_7923.field_41178.method_10223(nextButtonItem).method_7854();
        item.method_57379(class_9334.field_50239, TextUtil.parse(ModConfig.getInstance().messages.next));
        return item;
    }

    public int browseMenuHeight = 6;
    public String browseMenuTitle = "Browse Emotes";

    public boolean enableConfirmationMenu = true;
    public int confirmationMenuHeight = 1;
    public String confirmationMenuTitle = "Confirm";

    public boolean addBrowseButton = true;
    public class_2960 browseButtonItem = class_1802.field_8106.method_40131().method_40237().method_29177();
    public Vector2i browseButtonLocation = new Vector2i(1, 6);
    public class_1799 browseItem() {
        var item = class_7923.field_41178.method_10223(browseButtonItem).method_7854();
        item.method_57379(class_9334.field_50239, TextUtil.parse(ModConfig.getInstance().messages.browse));
        return item;
    }

    public class_2960 confirmButtonItem = class_1802.field_8687.method_40131().method_40237().method_29177();
    public Vector2i confirmButtonLocation = new Vector2i(7, 1);
    public Vector2i cancelButtonLocation = new Vector2i(3, 1);
    public class_1799 confirmItem() {
        var item = class_7923.field_41178.method_10223(confirmButtonItem).method_7854();
        item.method_57379(class_9334.field_50239, TextUtil.parse(ModConfig.getInstance().messages.confirm));
        return item;
    }
}

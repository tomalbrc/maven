package com.cobblemonislands.emotive.storage;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Generic interface for storing and retrieving player emote data.
 */
public interface EmoteStorage {
    enum Type {
        MARIADB,
        POSTGRESQL,
        SQLITE,
        MONGODB,
        LPMETA
    }

    /**
     * Adds a new emote to a player’s storage.
     * @return true if successfully added, false otherwise.
     */
    boolean add(class_3222 player, class_2960 emote);

    /**
     * Removes an emote from the player’s storage.
     * @return true if successfully removed, false otherwise.
     */
    boolean remove(class_3222 player, class_2960 emote);

    /**
     * Checks if the player owns the specified emote.
     */
    boolean owns(class_3222 player, class_2960 emote);

    /**
     * Gets the timestamp (in seconds) when the emote was added.
     * Returns 0 if not found.
     */
    int timestamp(class_3222 player, class_2960 emote);

    /**
     * Lists all stored emote keys for the player.
     */
    List<String> list(class_3222 player);

    default void close() {}
}

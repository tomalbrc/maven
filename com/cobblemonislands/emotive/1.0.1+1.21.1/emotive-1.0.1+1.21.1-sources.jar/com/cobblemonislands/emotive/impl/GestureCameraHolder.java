package com.cobblemonislands.emotive.impl;

import com.cobblemon.mod.common.entity.npc.NPCEntity;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.elements.BlockDisplayElement;
import it.unimi.dsi.fastutil.ints.IntList;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.function.Consumer;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2668;
import net.minecraft.class_2718;
import net.minecraft.class_2783;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_7833;

public class GestureCameraHolder extends ElementHolder {
    private final BlockDisplayElement cameraElement = new BlockDisplayElement() {
        @Override
        public void notifyMove(class_243 oldPos, class_243 newPos, class_243 delta) {
            if (this.getHolder() != null) {
                var packet = VirtualEntityUtils.createMovePacket(this.getEntityId(), class_243.field_1353, getCurrentPos(), true, this.getYaw(), this.getPitch());
                this.getHolder().sendPacket(packet);
            }
        }
    };

    private final class_3222 player;
    private final class_243 origin;
    private final NPCEntity playerModel;

    private float pitch;
    private float yaw;
    private boolean dirtyRot = true;

    public GestureCameraHolder(class_3222 player, NPCEntity playerModel) {
        super();

        this.playerModel = playerModel;
        this.origin = player.method_19538();
        this.player = player;
        this.updatePos();
        this.cameraElement.setTeleportDuration(2);
        this.cameraElement.ignorePositionUpdates();
        this.addElement(cameraElement);
    }

    public void setPitch(float pitch) {
        if (pitch != this.pitch) {
            this.pitch = pitch;
            this.dirtyRot = true;
        }
    }

    public void setYaw(float yaw) {
        if (yaw != this.yaw) {
            this.yaw = yaw;
            this.dirtyRot = true;
        }
    }

    @Override
    public boolean startWatching(class_3244 player) {
        player.method_14364(new class_2783(this.player.method_5628(), new class_1293(class_1294.field_5905, 72000, 0, true, false), false));
        return super.startWatching(player);
    }

    @Override
    public boolean stopWatching(class_3244 player) {
        class_1293 effect = this.player.method_6112(class_1294.field_5905);
        if (effect == null)
            player.method_14364(new class_2718(this.player.method_5628(), class_1294.field_5905));
        else
            player.method_14364(new class_2783(this.player.method_5628(), effect, false));

        return super.stopWatching(player);
    }

    @Override
    protected void startWatchingExtraPackets(class_3244 player, Consumer<class_2596<class_2602>> packetConsumer) {
        super.startWatchingExtraPackets(player, packetConsumer);
        if (this.player.field_13987 == player) {
            packetConsumer.accept(VirtualEntityUtils.createRidePacket(cameraElement.getEntityId(), IntList.of(player.field_14140.method_5628())));
            packetConsumer.accept(VirtualEntityUtils.createSetCameraEntityPacket(cameraElement.getEntityId()));
            packetConsumer.accept(new class_2668(class_2668.field_25648, class_1934.field_9219.method_8379()));
        }
    }

    @Override
    public void onTick() {
        super.onTick();

        if (this.player == null || this.player.method_31481() || !GestureController.GESTURE_CAMS.containsKey(player.method_5667())) {
            this.destroy();
        } else {
            this.updatePos();
        }
    }

    @Override
    public void destroy() {
        super.destroy();

        this.playerModel.method_31472();
    }

    private void updatePos() {
        Vector3f rotatedPoint = currentPoint(-4);

        if (this.getAttachment() != null && dirtyRot) {
            var level = this.getAttachment().getWorld();

            var eyePos = this.origin.method_1031(0, this.player.method_5751()/2.f, 0);
            var blockHitResult = level.method_17742(new class_3959(eyePos, new class_243(rotatedPoint), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, class_3726.method_16194()));
            var adjustedPos = currentPoint(-(Math.max(class_3532.method_15379((float) blockHitResult.method_17784().method_1022(eyePos)) - 0.5f, 0.1f)));

            var packet = VirtualEntityUtils.createMovePacket(this.cameraElement.getEntityId(), class_243.field_1353, new class_243(adjustedPos), true, this.yaw-180, this.pitch);
            this.player.field_13987.method_14364(packet);

            this.dirtyRot = false;
        }
    }

    private Vector3f currentPoint(float dist) {
        Quaternionf xr = class_7833.field_40714.rotationDegrees(this.pitch).normalize();
        Quaternionf yr = class_7833.field_40715.rotationDegrees(this.yaw + 180).normalize();

        Vector3f off = this.origin.method_46409().add(0, this.player.method_5751()/2.f, 0);
        return new Vector3f(0, 0, dist).rotate(yr.mul(xr)).add(off);
    }

    public NPCEntity getPlayerModel() {
        return playerModel;
    }

    public class_3222 getPlayer() {
        return player;
    }

    public class_243 getOrigin() {
        return origin;
    }

    public int getCameraId() {
        return this.cameraElement.getEntityId();
    }
}

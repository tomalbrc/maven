package com.cobblemonislands.emotive.mixin;

import com.cobblemonislands.emotive.impl.GestureController;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class LivingEntityMixin {
    @Inject(method = "equipmentHasChanged", at = @At("RETURN"), cancellable = true)
    private void emotive$onEquipmentChanged(class_1799 itemStack, class_1799 itemStack2, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof class_3222 serverPlayer && GestureController.GESTURE_CAMS.containsKey(serverPlayer.method_5667())) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "hurt", at = @At("HEAD"))
    private void emotive$handleDamage(class_1282 damageSource, float f, CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof class_3222 serverPlayer) {
            GestureController.onStop(serverPlayer);
        }
    }
}

package com.cobblemonislands.emotive.component;

import com.cobblemonislands.emotive.config.Animations;
import com.cobblemonislands.emotive.config.ModConfig;
import com.cobblemonislands.emotive.util.TextUtil;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_1792;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_9299;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public record EmotiveToken(
        @NotNull class_2960 id,
        @Nullable String permission,
        @Nullable Integer permissionLevel
) implements class_9299 {
    public static final Codec<EmotiveToken> CODEC = RecordCodecBuilder.create(instance -> instance.group(class_2960.field_25139.fieldOf("id").forGetter(EmotiveToken::id), Codec.STRING.optionalFieldOf("permission").forGetter(token -> java.util.Optional.ofNullable(token.permission())), Codec.INT.optionalFieldOf("permission_level").forGetter(token -> java.util.Optional.ofNullable(token.permissionLevel()))).apply(instance, (id, permissionOpt, levelOpt) -> new EmotiveToken(id, permissionOpt.orElse(null), levelOpt.orElse(null))));

    public boolean canUse(class_3222 player) {
        if (permission == null) return permissionLevel == null || player.method_5687(permissionLevel);
        return Permissions.check(player, permission, permissionLevel == null ? 0 : permissionLevel);
    }

    @Override
    public void method_57409(class_1792.class_9635 tooltipContext, Consumer<class_2561> consumer, class_1836 tooltipFlag) {
        consumer.accept(TextUtil.parse(String.format(ModConfig.getInstance().messages.componentTooltip, Animations.all().get(this.id).title())));
    }
}

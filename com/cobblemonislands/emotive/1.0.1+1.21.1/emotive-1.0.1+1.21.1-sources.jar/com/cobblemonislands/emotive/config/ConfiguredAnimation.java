package com.cobblemonislands.emotive.config;

import com.cobblemonislands.emotive.util.TextUtil;
import eu.pb4.sgui.api.elements.GuiElementBuilder;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

public record ConfiguredAnimation(String title, class_2960 npcClass, String animationName, int duration, class_2960 item, Integer customModelData, boolean glint, String permission, Integer permissionLevel) {
    public static class_2583 EMPTY = class_2583.field_24360.method_10977(class_124.field_1068).method_30938(false).method_10978(false).method_36141(false).method_36140(false);

    public class_1799 itemStack() {
        class_1799 itemStack;

        if (item == null)
            itemStack = class_1802.field_8511.method_7854();
        else
            itemStack = class_7923.field_41178.method_10223(item).method_7854();

        itemStack.method_57379(class_9334.field_50239, class_2561.method_43473().method_10852(class_2561.method_43473().method_27696(EMPTY).method_10852(TextUtil.parse(title))));
        if (customModelData != null)
            itemStack.method_57379(class_9334.field_49637, new class_9280(customModelData));

        return itemStack;
    }

    public GuiElementBuilder guiElementBuilder() {
        return guiElementBuilder(true);
    }

    public GuiElementBuilder guiElementBuilder(boolean playable) {
        var builder = GuiElementBuilder.from(itemStack());
        builder.addLoreLine(class_2561.method_43473());
        builder.addLoreLine(class_2561.method_43473().method_10852(class_2561.method_43473().method_27696(EMPTY).method_10852(TextUtil.parse(String.format(ModConfig.getInstance().messages.emoteDurationTooltip, duration(duration))))));
        if (playable) {
            builder.addLoreLine(class_2561.method_43473());
            builder.addLoreLine(class_2561.method_43473().method_10852(class_2561.method_43473().method_27696(EMPTY).method_10852(TextUtil.parse(ModConfig.getInstance().messages.emotePlayTooltip))));

            builder.addLoreLine(class_2561.method_43473());
            builder.addLoreLine(class_2561.method_43473().method_10852(class_2561.method_43473().method_27696(EMPTY).method_10852(TextUtil.parse(ModConfig.getInstance().messages.emoteGetItemTooltip))));
        }
        builder.glow(glint());
        return builder;
    }

    private String duration(int duration) {
        String formatted;
        if (duration == -1) {
            formatted = ModConfig.getInstance().messages.untilStopped;
        } else {
            formatted = duration + "s";
        }

        return formatted;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private String title;
        private class_2960 npcClass = class_2960.method_60655("cobblemon", "standard");
        private String animationName;
        private int duration = 6;
        private class_2960 item = class_2960.method_60656("diamond");
        private Integer customModelData = null;
        private boolean glint;
        private int permissionLevel;
        private String permission;

        private Builder() {}

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder npcClass(class_2960 npcClass) {
            this.npcClass = npcClass;
            return this;
        }

        public Builder animationName(String animationName) {
            this.animationName = animationName;
            return this;
        }

        public Builder duration(int duration) {
            this.duration = duration;
            return this;
        }

        public Builder item(class_2960 item) {
            this.item = item;
            return this;
        }

        public Builder glint(boolean glint) {
            this.glint = glint;
            return this;
        }

        public Builder permission(String permission) {
            this.permission = permission;
            return this;
        }

        public Builder permissionLevel(int level) {
            this.permissionLevel = level;
            return this;
        }

        public Builder customModelData(int customModelData) {
            this.customModelData = customModelData;
            return this;
        }

        public ConfiguredAnimation build() {
            return new ConfiguredAnimation(title, npcClass, animationName, duration, item, customModelData, glint, permission, permissionLevel);
        }
    }
}

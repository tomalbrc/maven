package com.cobblemonislands.emotive.component;

import eu.pb4.polymer.core.api.other.PolymerComponent;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ModComponents {
    public static final class_9331<EmotiveToken> EMOTIVE_TOKEN = new class_9331.class_9332<EmotiveToken>().method_57881(EmotiveToken.CODEC).method_57880();

    public static void register() {
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("emotive", "token"), EMOTIVE_TOKEN);
        PolymerComponent.registerDataComponent(EMOTIVE_TOKEN);
    }
}

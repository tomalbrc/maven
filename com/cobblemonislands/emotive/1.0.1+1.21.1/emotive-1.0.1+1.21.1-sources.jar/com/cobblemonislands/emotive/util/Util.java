package com.cobblemonislands.emotive.util;

import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;

public class Util {
    public static List<Pair<class_1304, class_1799>> getEquipment(class_1309 entity, boolean empty) {
        List<Pair<class_1304, class_1799>> equipment = new ObjectArrayList<>();

        for (class_1304 slot : class_1304.values()) {
            if (empty) {
                equipment.add(Pair.of(slot, class_1799.field_8037));
            } else {
                class_1799 stack = entity.method_6118(slot);
                if (!stack.method_7960()) {
                    equipment.add(Pair.of(slot, stack.method_7972()));
                }
            }
        }

        return equipment;
    }

    public static class_3917<?> menuTypeForHeight(int height) {
        return switch (height) {
            case 1 -> class_3917.field_18664;
            case 2 -> class_3917.field_18665;
            case 3 -> class_3917.field_17326;
            case 4 -> class_3917.field_18666;
            case 5 -> class_3917.field_18667;
            case 6 -> class_3917.field_17327;
            default -> class_3917.field_17328;
        };
    }

    public static void clickSound(class_3222 player) {
        player.method_17356(class_3417.field_15015.comp_349(), class_3419.field_15250, 0.5f, 1F);
    }
}

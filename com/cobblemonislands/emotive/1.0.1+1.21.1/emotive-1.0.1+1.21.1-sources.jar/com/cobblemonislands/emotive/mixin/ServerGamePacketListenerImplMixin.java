package com.cobblemonislands.emotive.mixin;

import com.cobblemonislands.emotive.component.ModComponents;
import com.cobblemonislands.emotive.config.Animations;
import com.cobblemonislands.emotive.config.ModConfig;
import com.cobblemonislands.emotive.impl.GestureController;
import com.cobblemonislands.emotive.util.TextUtil;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1799;
import net.minecraft.class_2709;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2851;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.network.protocol.game.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;

@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow
    public class_3222 player;

    @Inject(method = "handlePlayerInput", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;setPlayerInput(FFZZ)V"), cancellable = true)
    private void emotive$handleInput(class_2851 serverboundPlayerInputPacket, CallbackInfo ci) {
        var camera = GestureController.GESTURE_CAMS.get(player.method_5667());
        if (camera != null) {
            if (serverboundPlayerInputPacket.method_12370()) {
                GestureController.onStop(camera);
            }

            ci.cancel();
        }
    }

    @Inject(method = "handleMovePlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerGamePacketListenerImpl;containsInvalidValues(DDDFF)Z"), cancellable = true)
    private void emotive$handleMove(class_2828 serverboundMovePlayerPacket, CallbackInfo ci) {
        var camera = GestureController.GESTURE_CAMS.get(player.method_5667());
        if (camera != null) {
            if (serverboundMovePlayerPacket instanceof class_2828.class_2831 rot) {
                camera.setYaw(rot.method_12271(this.player.method_36454()));
                camera.setPitch(rot.method_12270(this.player.method_36455()));
            }
            ci.cancel();
        }
    }

    @Inject(method = "handleInteract", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;serverLevel()Lnet/minecraft/server/level/ServerLevel;", ordinal = 0), cancellable = true)
    private void emotive$preventInteract(class_2824 serverboundInteractPacket, CallbackInfo ci) {
        if (GestureController.GESTURE_CAMS.containsKey(player.method_5667())) {
            ci.cancel();
        }
    }

    @Inject(method = "teleport(DDDFFLjava/util/Set;)V", at = @At("HEAD"))
    private void emotive$preventTeleport(double d, double e, double f, float g, float h, Set<class_2709> set, CallbackInfo ci) {
        if (GestureController.GESTURE_CAMS.containsKey(player.method_5667())) {
            GestureController.onStop(player);
        }
    }

    @Inject(method = "handleUseItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItem(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;"), cancellable = true)
    private void emotive$backpackInteraction(class_2886 serverboundUseItemPacket, CallbackInfo ci, @Local class_1799 itemStack) {
        if (itemStack.method_57826(ModComponents.EMOTIVE_TOKEN)) {
            var tokenId = itemStack.method_57824(ModComponents.EMOTIVE_TOKEN);
            if (tokenId != null && tokenId.canUse(player) && ModConfig.getInstance().getStorage().add(player, tokenId.id())) {
                player.method_43496(TextUtil.parse(String.format(ModConfig.getInstance().messages.added, Animations.all().get(tokenId.id()).title())));
                itemStack.method_57008(1, player);
            }
            ci.cancel();
        }
    }

    @Inject(method = "handleUseItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItemOn(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;"), cancellable = true)
    private void emotive$backpackInteraction(class_2885 serverboundUseItemOnPacket, CallbackInfo ci, @Local class_1799 itemStack) {
        if (itemStack.method_57826(ModComponents.EMOTIVE_TOKEN)) {
            var tokenId = itemStack.method_57824(ModComponents.EMOTIVE_TOKEN);
            if (tokenId != null && tokenId.canUse(player) && ModConfig.getInstance().getStorage().add(player, tokenId.id())) {
                player.method_43496(TextUtil.parse(String.format(ModConfig.getInstance().messages.added, Animations.all().get(tokenId.id()).title())));
                itemStack.method_57008(1, player);
            }
            ci.cancel();
        }
    }
}
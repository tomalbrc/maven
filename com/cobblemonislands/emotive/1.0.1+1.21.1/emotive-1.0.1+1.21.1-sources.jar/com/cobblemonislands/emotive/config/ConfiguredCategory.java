package com.cobblemonislands.emotive.config;

import com.cobblemonislands.emotive.util.TextUtil;
import com.google.common.collect.ImmutableMap;
import eu.pb4.sgui.api.elements.GuiElementBuilder;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

public record ConfiguredCategory(
        String id,
        String title,
        class_2960 item,
        List<String> lore,
        Integer customModelData,
        boolean glint,
        Map<class_2960, ConfiguredAnimation> animations
) {
    public class_1799 itemStack() {
        class_1799 itemStack;

        if (item == null)
            itemStack = class_1802.field_8511.method_7854();
        else
            itemStack = class_7923.field_41178.method_10223(item).method_7854();

        itemStack.method_57379(class_9334.field_50239, class_2561.method_43473().method_10852(class_2561.method_43473().method_27696(ConfiguredAnimation.EMPTY).method_10852(TextUtil.parse(title))));
        if (customModelData != null)
            itemStack.method_57379(class_9334.field_49637, new class_9280(customModelData));

        return itemStack;
    }

    public GuiElementBuilder guiElementBuilder() {
        var builder = GuiElementBuilder.from(itemStack());
        if (lore != null) for (String string : lore) {
            builder.addLoreLine(class_2561.method_43473().method_10852(class_2561.method_43473().method_27696(ConfiguredAnimation.EMPTY).method_10852(TextUtil.parse(string))));
        }
        builder.glow(glint());
        return builder;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String id;
        private String title;
        private class_2960 item;
        private final List<String> lore = new ObjectArrayList<>();
        private Integer customModelData;
        private boolean glint;
        private final Map<class_2960, ConfiguredAnimation> animations = new Object2ObjectOpenHashMap<>();

        private Builder() {}

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder setItem(class_2960 item) {
            this.item = item;
            return this;
        }

        public Builder setCustomModelData(Integer customModelData) {
            this.customModelData = customModelData;
            return this;
        }

        public Builder setGlint(boolean glint) {
            this.glint = glint;
            return this;
        }

        public Builder addAnimation(class_2960 id, ConfiguredAnimation animation) {
            this.animations.put(id, animation);
            return this;
        }

        public Builder addAnimations(Map<class_2960, ConfiguredAnimation> animations) {
            this.animations.putAll(animations);
            return this;
        }

        public Builder addLore(String lore) {
            this.lore.add(lore);
            return this;
        }

        public Builder addLore(List<String> lore) {
            this.lore.addAll(lore);
            return this;
        }

        public ConfiguredCategory build() {
            return new ConfiguredCategory(
                    id,
                    title,
                    item,
                    lore,
                    customModelData,
                    glint,
                    ImmutableMap.copyOf(animations) // immutable copy
            );
        }
    }
}
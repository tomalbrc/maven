package com.cobblemonislands.emotive.impl;

import com.bedrockk.molang.runtime.value.StringValue;
import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.CobblemonEntities;
import com.cobblemon.mod.common.api.npc.NPCClasses;
import com.cobblemon.mod.common.entity.npc.NPCEntity;
import com.cobblemon.mod.common.entity.npc.NPCPlayerModelType;
import com.cobblemon.mod.common.entity.npc.NPCPlayerTexture;
import com.cobblemonislands.emotive.api.EmoteEvents;
import com.cobblemonislands.emotive.config.ConfiguredAnimation;
import com.cobblemonislands.emotive.config.ModConfig;
import com.cobblemonislands.emotive.mixin.EntityAccessor;
import com.cobblemonislands.emotive.util.Util;
import com.google.common.collect.ImmutableList;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.ProfileLookupCallback;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTextures;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.attachment.ChunkAttachment;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_2668;
import net.minecraft.class_2708;
import net.minecraft.class_2734;
import net.minecraft.class_2739;
import net.minecraft.class_2744;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_8042;
import net.minecraft.network.protocol.game.*;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class GestureController {
    public static final Map<UUID, GestureCameraHolder> GESTURE_CAMS = new ConcurrentHashMap<>();
    public static final Map<UUID, ModelData> TEXTURE_CACHE = new ConcurrentHashMap<>();

    public static void onConnect(class_3222 serverPlayer) {
        // to have a cached model/texture of players
        MinecraftServer server = Cobblemon.implementation.server();
        if (server == null) return;

        String username = serverPlayer.method_5820();
        server.method_3719().findProfilesByNames(new String[]{username}, new ProfileLookupCallback() {
            @Override
            public void onProfileLookupSucceeded(GameProfile profile) {
                GameProfile deepProfile = server.method_3844().fetchProfile(profile.getId(), false) != null
                        ? Objects.requireNonNull(server.method_3844().fetchProfile(profile.getId(), false)).profile()
                        : null;

                if (deepProfile == null) {
                    Cobblemon.LOGGER.error("Failed to fetch profile for game profile name: {}", username);
                    return;
                }

                MinecraftProfileTextures textures = server.method_3844().getTextures(deepProfile);
                MinecraftProfileTexture skin = textures.skin();
                if (skin == null) return;

                String url = skin.getUrl();
                String modelMeta = skin.getMetadata("model") != null ? skin.getMetadata("model") : "default";
                NPCPlayerModelType model = NPCPlayerModelType.valueOf(Objects.requireNonNull(modelMeta).toUpperCase());

                try {
                    var tex = new NPCPlayerTexture(new URI(url).toURL().openStream().readAllBytes(), model);
                    var aspect = "model-" + model.name().toLowerCase();
                    TEXTURE_CACHE.put(serverPlayer.method_5667(), new ModelData(tex, aspect));
                } catch (IOException | URISyntaxException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public void onProfileLookupFailed(String profileName, Exception exception) {
                Cobblemon.LOGGER.error("Unable to load texture for game profile name: {}", username, exception);
            }
        });
    }

    public static void onDisconnect(class_3222 serverPlayer) {
        var cam = GESTURE_CAMS.get(serverPlayer.method_5667());
        if (cam != null) {
            onStop(cam);
        }
    }

    public static void onStop(class_3222 player) {
        var cam = GestureController.GESTURE_CAMS.get(player.method_5667());
        if (cam != null) {
            GestureController.onStop(cam);
        }
    }

    public static void onStop(GestureCameraHolder camera) {
        var player = camera.getPlayer();
        if (!player.method_14239()) {
            PolymerUtils.reloadInventory(player);
            for (class_3244 watchingPlayer : camera.getWatchingPlayers()) {
                watchingPlayer.method_14364(new class_2744(player.method_5628(), Util.getEquipment(player, false)));
            }

            List<class_2945.class_7834<?>> data = new ObjectArrayList<>();
            data.add(class_2945.class_7834.method_46360(EntityTrackedData.FLAGS, player.method_5841().method_12789(EntityTrackedData.FLAGS)));
            camera.getWatchingPlayers().forEach(p -> camera.sendPacket(new class_2739(player.method_5628(), data)));

            var packet = new class_2708(camera.getOrigin().field_1352, camera.getOrigin().field_1351, camera.getOrigin().field_1350, player.method_36454(), player.method_36455(), Set.of(), player.method_5628());
            player.field_13987.method_14364(
                    new class_8042(ImmutableList.of(
                            new class_2734(player),
                            VirtualEntityUtils.createRidePacket(camera.getCameraId(), IntList.of()),
                            new class_2668(class_2668.field_25648, player.field_13974.method_14257().method_8379()),
                            packet
                    ))
            );
        }

        EmoteEvents.STOP_EMOTE.invoker().onStopEmote(player);

        camera.destroy();
        GestureController.GESTURE_CAMS.remove(player.method_5667());
    }

    public static void onStart(class_3222 player, ConfiguredAnimation animation) {
        if (GestureController.GESTURE_CAMS.containsKey(player.method_5667())) // prevent spamming gestures
            return;

        // destroy any previous gestures
        GestureCameraHolder camera = GestureController.GESTURE_CAMS.get(player.method_5667());
        if (camera != null) {
            camera.destroy();
        }

        NPCEntity playerModel = CobblemonEntities.NPC.method_5883(player.method_37908());
        assert playerModel != null;
        ((EntityAccessor)(class_1297)playerModel).invokeUnsetRemoved();
        playerModel.field_5960 = true;
        playerModel.method_5875(true);
        playerModel.setMovable(false);
        playerModel.setLeashable(false);
        playerModel.setAllowProjectileHits(false);
        playerModel.method_5684(true);
        playerModel.setNpc(Objects.requireNonNull(NPCClasses.INSTANCE.getByIdentifier(animation.npcClass())));
        playerModel.method_60949(player.method_19538(), player.field_6241, player.method_36455());
        playerModel.setHideNameTag(!ModConfig.getInstance().showPlayerName);
        playerModel.method_5665(player.method_5476());
        playerModel.method_5880(ModConfig.getInstance().showPlayerName);
        //playerModel.getVariationAspects().add("");

        for (class_1304 slot : class_1304.values()) {
            var item = player.method_6118(slot);
            playerModel.method_5673(slot, item);
        }

        playerModel.method_6122(class_1268.field_5808, player.method_6047());
        playerModel.method_6122(class_1268.field_5810, player.method_6079());

        playerModel.method_36457(player.method_36455());
        playerModel.method_5847(player.field_6241);
        playerModel.method_5636(player.field_6241);

        var data = TEXTURE_CACHE.get(player.method_5667());
        if (data != null) {
            playerModel.method_5841().method_12778(NPCEntity.Companion.getNPC_PLAYER_TEXTURE(), data.texture());
            playerModel.getData().setDirectly("player_texture_username", new StringValue(player.method_5820()));
            playerModel.getAppliedAspects().add(data.modelAspect());
            playerModel.updateAspects();
        }

        EmoteEvents.START_EMOTE.invoker().onStartEmote(player);

        GestureCameraHolder gestureCameraHolder = new GestureCameraHolder(player, playerModel);
        GestureController.GESTURE_CAMS.put(player.method_5667(), gestureCameraHolder);
        ChunkAttachment.ofTicking(gestureCameraHolder, player.method_51469(), player.method_19538());

        player.method_51469().method_8649(playerModel);

        CompletableFuture.runAsync(() -> playerModel.playAnimation(animation.animationName(), List.of()), CompletableFuture.delayedExecutor(50, TimeUnit.MILLISECONDS, player.field_13995));

        CompletableFuture.runAsync(() -> {
            if (GestureController.GESTURE_CAMS.containsValue(gestureCameraHolder))
                onStop(player);
        }, CompletableFuture.delayedExecutor(animation.duration(), TimeUnit.SECONDS, player.field_13995));
    }
}

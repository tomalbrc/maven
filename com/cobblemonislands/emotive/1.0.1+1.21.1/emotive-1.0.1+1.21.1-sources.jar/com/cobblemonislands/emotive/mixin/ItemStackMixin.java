package com.cobblemonislands.emotive.mixin;

import com.cobblemonislands.emotive.component.ModComponents;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_9299;
import net.minecraft.class_9331;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow protected abstract <T extends class_9299> void addToTooltip(class_9331<T> dataComponentType, class_1792.class_9635 tooltipContext, Consumer<class_2561> consumer, class_1836 tooltipFlag);

    @Inject(method = "getTooltipLines", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;addAttributeTooltips(Ljava/util/function/Consumer;Lnet/minecraft/world/entity/player/Player;)V"))
    private void emotive$addTooltip(class_1792.class_9635 tooltipContext, class_1657 player, class_1836 tooltipFlag, CallbackInfoReturnable<List<class_2561>> cir, @Local List<class_2561> components) {
        if (((class_1799)(Object)this).method_57826(ModComponents.EMOTIVE_TOKEN)) {
            this.addToTooltip(ModComponents.EMOTIVE_TOKEN, tooltipContext, components::add, tooltipFlag);

        }
    }
}

package xyz.nucleoid.disguiselib.impl.mixin;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2703;
import net.minecraft.class_2716;
import net.minecraft.class_2724;
import net.minecraft.class_2748;
import net.minecraft.class_2749;
import net.minecraft.class_2777;
import net.minecraft.class_2783;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_3898;
import net.minecraft.class_4050;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_5629;
import net.minecraft.class_5900;
import net.minecraft.class_7828;
import net.minecraft.class_7923;
import net.minecraft.class_8791;
import net.minecraft.entity.*;
import net.minecraft.network.packet.s2c.play.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.nucleoid.disguiselib.api.DisguiseUtils;
import xyz.nucleoid.disguiselib.api.EntityDisguise;
import xyz.nucleoid.disguiselib.impl.mixin.accessor.EntityTrackerEntryAccessor;
import xyz.nucleoid.disguiselib.impl.mixin.accessor.ServerChunkLoadingManagerAccessor;

import java.util.*;
import java.util.stream.Collectors;

import static net.minecraft.class_1299.field_6097;
import static net.minecraft.class_2703.class_5893.field_29136;
import static xyz.nucleoid.disguiselib.impl.DisguiseLib.DISGUISE_TEAM;
import static xyz.nucleoid.disguiselib.impl.mixin.accessor.PlayerEntityAccessor.getPLAYER_MODEL_PARTS;

@Mixin(class_1297.class)
public abstract class EntityMixin_Disguise implements EntityDisguise, DisguiseUtils {

    @Unique
    private final class_1297 disguiselib$entity = (class_1297) (Object) this;
    @Shadow
    public class_1937 world;
    @Shadow
    protected UUID uuid;
    @Unique
    private class_1297 disguiselib$disguiseEntity;
    @Unique
    private int disguiselib$ticks;
    @Unique
    private class_1299<?> disguiselib$disguiseType;
    @Unique
    private GameProfile disguiselib$profile;
    @Unique
    private boolean disguiselib$trueSight = false;

    @Shadow
    public abstract class_1299<?> getType();

    @Shadow
    public abstract float getHeadYaw();

    @Shadow
    public abstract class_2561 getName();

    @Shadow
    public abstract class_2945 getDataTracker();

    @Shadow
    @Nullable
    public abstract class_2561 getCustomName();

    @Shadow
    public abstract boolean isCustomNameVisible();

    @Shadow public abstract boolean isSprinting();

    @Shadow public abstract boolean isSneaking();

    @Shadow public abstract boolean isSwimming();

    @Shadow public abstract boolean isGlowing();

    @Shadow public abstract boolean isSilent();

    @Shadow
    private int id;

    @Shadow
    public abstract class_4050 getPose();

    @Shadow
    public abstract int getId();

    @Shadow
    public abstract boolean isOnFire();

    @Shadow
    public abstract class_2561 getDisplayName();

    @Shadow
    protected abstract void addPassenger(class_1297 passenger);

    @Shadow private boolean onGround;

    /**
     * Tells you the disguised status.
     *
     * @return true if entity is disguised, otherwise false.
     */
    @Override
    public boolean isDisguised() {
        return this.disguiselib$disguiseEntity != null;
    }

    /**
     * Sets entity's disguise from {@link class_1299}
     *
     * @param entityType the type to disguise this entity into
     */
    @Override
    public void disguiseAs(class_1299<?> entityType) {
        this.disguiselib$disguiseType = entityType;

        class_3324 manager = this.world.method_8503().method_3760();

        if(this.disguiselib$disguiseEntity != null && this.disguiselib$disguiseEntity.method_5864() != entityType && this.disguiselib$entity instanceof class_3222) {
            this.disguiselib$hideSelfView();
        }

        if(entityType == field_6097) {
            if(this.disguiselib$profile == null)
                this.setGameProfile(new GameProfile(this.uuid, this.getDisplayName().getString()));
            this.disguiselib$constructFakePlayer(this.disguiselib$profile);
        } else {
            // Why null check? Well, if entity was disguised via EntityDisguise#disguiseAs(Entity), this field is already set
            if (this.disguiselib$disguiseEntity == null || this.disguiselib$disguiseEntity.method_5864() != entityType)
                this.disguiselib$disguiseEntity = entityType.method_5883(world);

            if (this.disguiselib$profile != null) {
                // Previous type was player, we have to send a player remove packet
                class_7828 listPacket = new class_7828(new ArrayList(Collections.singletonList(this.disguiselib$profile.getId())));
                manager.method_14581(listPacket);
            }

            // We don't need gameprofile anymore
            this.disguiselib$profile = null;
        }


        // Fix some client predictions
        if(this.disguiselib$disguiseEntity instanceof class_1308)
            ((class_1308) this.disguiselib$disguiseEntity).method_5977(true);

        class_5321<class_1937> worldRegistryKey = this.world.method_27983();

        // Minor datatracker thingies
        this.updateTrackedData();

        //noinspection ReferenceToMixin
        var tracker = ((ServerChunkLoadingManagerAccessor) ((class_3218) this.world).method_14178().field_17254).getEntityTrackers().get(this.getId());

        for (var listener : tracker.getListeners()) {
            tracker.getEntry().method_14302(listener.method_32311());
            tracker.getEntry().method_18760(listener.method_32311());
        }
    }

    /**
     * Sets entity's disguise from {@link class_1297}
     *
     * @param entity the entity to disguise into
     */
    @Override
    public void disguiseAs(class_1297 entity) {
        if(this.disguiselib$disguiseEntity != null && this.disguiselib$entity instanceof class_3222) {
            // Removing previous disguise if this is player
            // (we have it saved under a separate id)
            this.disguiselib$hideSelfView();
        }

        this.disguiselib$disguiseEntity = entity;
        if(entity instanceof class_1657) {
            this.setGameProfile(((class_1657) entity).method_7334());
        }
        this.disguiseAs(entity.method_5864());
    }

    /**
     * Clears the disguise - sets the {@link EntityMixin_Disguise#disguiselib$disguiseType} back to original.
     */
    @Override
    public void removeDisguise() {
        if(this.disguiselib$disguiseEntity != null && this.disguiselib$entity instanceof class_3222) {
            // Removing previous disguise if this is player
            // (we have it saved under a separate id)
            this.disguiselib$hideSelfView();
        }
        // Disguising entity as itself
        this.disguiselib$disguiseEntity = this.disguiselib$entity;
        this.disguiselib$disguiseType = this.getType();

        this.disguiseAs(this.getType());

        // Setting as not-disguised
        this.disguiselib$disguiseEntity = null;
    }

    /**
     * Gets the disguise entity type
     *
     * @return disguise entity type or real type if there's no disguise
     */
    @Override
    public class_1299<?> getDisguiseType() {
        return this.disguiselib$disguiseType;
    }

    /**
     * Gets the disguise entity.
     *
     * @return disguise entity or null if there's no disguise
     */
    @Nullable
    @Override
    public class_1297 getDisguiseEntity() {
        return this.disguiselib$disguiseEntity;
    }

    /**
     * Whether disguise type entity is an instance of {@link class_1309}.
     *
     * @return true if the disguise type is an instance of {@link class_1309}, otherwise false.
     */
    @Override
    public boolean disguiseAlive() {
        return this.disguiselib$disguiseEntity instanceof class_1309;
    }

    /**
     * Whether this entity can bypass the
     * "disguises" and see entities normally
     * Intended more for admins (to not get trolled themselves).
     *
     * @return if entity can be "fooled" by disguise
     */
    @Override
    public boolean hasTrueSight() {
        return this.disguiselib$trueSight;
    }

    /**
     * Toggles true sight - whether entity
     * can see disguises or not.
     * Intended more for admins (to not get trolled themselves).
     *
     * @param trueSight if entity should not see disguises
     */
    @Override
    public void setTrueSight(boolean trueSight) {
        this.disguiselib$trueSight = trueSight;
    }

    /**
     * Gets the {@link GameProfile} for disguised entity,
     * used when disguising as player.
     *
     * @return GameProfile of the entity.
     */
    @Override
    public @Nullable GameProfile getGameProfile() {
        return this.disguiselib$profile;
    }

    /**
     * Sets the GameProfile
     *
     * @param gameProfile a new profile for the entity.
     */
    @Override
    public void setGameProfile(@Nullable GameProfile gameProfile) {
        this.disguiselib$profile = gameProfile;
        if(gameProfile != null) {
            String name = gameProfile.getName();
            if(name.length() > 16) {
                // Minecraft kicks players on such profile name received
                name = name.substring(0, 16);
                PropertyMap properties = gameProfile.getProperties();
                this.disguiselib$profile = new GameProfile(gameProfile.getId(), name);
                Collection<Property> textures = properties.get("textures");
                if(!textures.isEmpty())
                    this.disguiselib$profile.getProperties().put("textures", textures.stream().findFirst().get());
            }
        }

        this.disguiselib$sendProfileUpdates();
    }

    /**
     * Hides player's self-disguise-entity
     */
    @Unique
    private void disguiselib$hideSelfView() {
        // Removing previous disguise if this is player
        // (we have it saved under a separate id)
        class_3222 player = (class_3222) this.disguiselib$entity;
        player.field_13987.method_14364(new class_2716(this.disguiselib$disguiseEntity.method_5628()));

        class_5900 removeTeamPacket = class_5900.method_34171(DISGUISE_TEAM, player.method_7334().getName(), class_5900.class_5901.field_29156);
        player.field_13987.method_14364(removeTeamPacket);
    }

    /**
     * Constructs fake player entity for use
     * when entities are disguised as players.
     *
     * @param profile gameprofile to use for new player.
     */
    @Unique
    private void disguiselib$constructFakePlayer(@NotNull GameProfile profile) {
        this.disguiselib$disguiseEntity = new class_3222(world.method_8503(), (class_3218) world, profile, class_8791.method_53821());
        this.disguiselib$disguiseEntity.method_5841().method_12778(getPLAYER_MODEL_PARTS(), (byte) 0x7f);
    }

    /**
     * Gets equipment as list of {@link Pair Pairs}.
     * Requires entity to be an instanceof {@link class_1309}.
     *
     * @return equipment list of pairs.
     */
    @Unique
    private List<Pair<class_1304, class_1799>> disguiselib$getEquipment() {
        if(disguiselib$entity instanceof class_1309)
            return Arrays.stream(class_1304.values()).map(slot -> new Pair<>(slot, ((class_1309) disguiselib$entity).method_6118(slot))).collect(Collectors.toList());
        return Collections.emptyList();
    }

    /**
     * Updates the entity's GameProfile for other clients
     */
    @Unique
    private void disguiselib$sendProfileUpdates() {
        class_7828 packet = new class_7828(new ArrayList(Collections.singletonList(this.disguiselib$profile.getId())));

        class_3324 playerManager = this.world.method_8503().method_3760();
        playerManager.method_14581(packet);

        class_2703 addPacket = new class_2703(field_29136, (class_3222) this.disguiselib$disguiseEntity);
        /*((PlayerListS2CPacketAccessor) addPacket).getEntries().forEach(entry -> {

        });*/
        playerManager.method_14581(addPacket);

        class_3215 manager = (class_3215) this.world.method_8398();
        var storage = manager.field_17254;
        EntityTrackerEntryAccessor trackerEntry = ((ServerChunkLoadingManagerAccessor) storage).getEntityTrackers().get(this.getId());
        if (trackerEntry != null)
            trackerEntry.getListeners().forEach(tracking -> trackerEntry.getEntry().method_18760(tracking.method_32311()));

        // Changing entity on client
        if (this.disguiselib$entity instanceof class_3222 player) {
            class_3218 targetWorld = (class_3218) player.method_37908();

            player.field_13987.method_14364(new class_2724(player.method_52374(targetWorld), class_2724.field_41732));
            player.field_13987.method_14363(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455());

            player.field_13995.method_3760().method_14576(player);

            player.field_13987.method_14364(new class_2748(player.field_7510, player.field_7495, player.field_7520));
            player.field_13987.method_14364(new class_2749(player.method_6032(), player.method_7344().method_7586(), player.method_7344().method_7589()));

            for (class_1293 statusEffect : player.method_6026()) {
                player.field_13987.method_14364(new class_2783(player.method_5628(), statusEffect, false));
            }

            player.method_7355();
            playerManager.method_14606(player, targetWorld);
            playerManager.method_14594(player);
        }
    }

    /**
     * Updates custom name and its visibility.
     * Also sets no-gravity to true in order
     * to prevent the client from predicting
     * the entity position and velocity.
     */
    @Override
    public void updateTrackedData() {
        // Minor datatracker thingies
        this.disguiselib$disguiseEntity.method_5875(true);
        this.disguiselib$disguiseEntity.method_5665(this.getCustomName());
        this.disguiselib$disguiseEntity.method_5880(this.isCustomNameVisible());
        this.disguiselib$disguiseEntity.method_5728(this.isSprinting());
        this.disguiselib$disguiseEntity.method_5660(this.isSneaking());
        this.disguiselib$disguiseEntity.method_5796(this.isSwimming());
        this.disguiselib$disguiseEntity.method_5834(this.isGlowing());
        this.disguiselib$disguiseEntity.method_33572(this.isOnFire());
        this.disguiselib$disguiseEntity.method_5803(this.isSilent());
        this.disguiselib$disguiseEntity.method_18380(this.getPose());
        //noinspection ConstantValue
        if (this.disguiselib$disguiseEntity instanceof class_1309 disguise && ((Object) this) instanceof class_1309 self) {
            disguise.method_6127().method_26846(self.method_6127());
        }
    }

    /**
     * Sends additional move packets to the client if
     * entity is disguised.
     * Prevents client desync and fixes "blocky" movement.
     */
    @Inject(method = "tick()V", at = @At("TAIL"))
    private void postTick(CallbackInfo ci) {
        // Fixes #2, also makes non-living entities update their pos
        // more than once per second -> movement isn't as "blocky"
        if(this.isDisguised()) {
            if(this.world.method_8503() != null && !(this.disguiselib$disguiseEntity instanceof class_1309) && !(this.disguiselib$entity instanceof class_1657))
                this.world.method_8503().method_3760().method_14589(new class_2777(this.disguiselib$entity), this.world.method_27983());
            else if(this.disguiselib$entity instanceof class_3222 && ++this.disguiselib$ticks % 40 == 0 && this.disguiselib$disguiseEntity != null) {
                // "Disguised as" message
                class_5250 msg = class_2561.method_43470("You are disguised as ")
                        .method_10852(class_2561.method_43471(this.disguiselib$disguiseEntity.method_5864().method_5882()))
                        .method_27692(class_124.field_1060);

                ((class_3222) this.disguiselib$entity).method_7353(msg, true);
                this.disguiselib$ticks = 0;
            }
        }

    }

    /**
     * If entity is disguised as player, we need to send a player
     * remove packet on death as well, otherwise tablist still contains
     * it.
     */
    @Inject(
            method = "discard()V",
            at = @At("TAIL")
    )
    private void onRemove(CallbackInfo ci) {
        if(this.isDisguised() && this.disguiselib$profile != null) {
            // If entity was killed, we should also send a remove player action packet
            class_7828 packet = new class_7828(new ArrayList<>(Collections.singletonList(this.disguiselib$profile.getId())));
            class_3324 manager = this.world.method_8503().method_3760();
            manager.method_14581(packet);
        }
    }

    /**
     * Takes care of loading the fake entity data from tag.
     *
     * @param tag tag to load data from.
     */
    @Inject(
            method = "readNbt(Lnet/minecraft/nbt/NbtCompound;)V",
            at = @At("TAIL")
    )
    private void fromTag(class_2487 tag, CallbackInfo ci) {
        class_2487 disguiseTag = (class_2487) tag.method_10580("DisguiseLib");

        if(disguiseTag != null) {
            class_2960 disguiseTypeId = class_2960.method_12829(disguiseTag.method_10558("DisguiseType"));
            this.disguiselib$disguiseType = class_7923.field_41177.method_10223(disguiseTypeId);

            if(this.disguiselib$disguiseType == field_6097) {
                this.setGameProfile(new GameProfile(this.uuid, this.getName().getString()));
                this.disguiselib$constructFakePlayer(this.disguiselib$profile);
            } else {
                class_2487 disguiseEntityTag = disguiseTag.method_10562("DisguiseEntity");
                if(!disguiseEntityTag.method_33133())
                    this.disguiselib$disguiseEntity = class_1299.method_17842(disguiseEntityTag, this.world, (entityx) -> entityx);
            }
        }
    }

    /**
     * Takes care of saving the fake entity data to tag.
     *
     * @param tag tag to save data to.
     */
    @Inject(
            method = "writeNbt(Lnet/minecraft/nbt/NbtCompound;)Lnet/minecraft/nbt/NbtCompound;",
            at = @At("TAIL")
    )
    private void toTag(class_2487 tag, CallbackInfoReturnable<class_2487> cir) {
        if(this.isDisguised()) {
            class_2487 disguiseTag = new class_2487();

            disguiseTag.method_10582("DisguiseType", class_7923.field_41177.method_10221(this.disguiselib$disguiseType).toString());

            if(this.disguiselib$disguiseEntity != null && !this.disguiselib$entity.equals(this.disguiselib$disguiseEntity)) {
                class_2487 disguiseEntityTag = new class_2487();
                this.disguiselib$disguiseEntity.method_5647(disguiseEntityTag);

                class_2960 identifier = class_7923.field_41177.method_10221(this.disguiselib$disguiseEntity.method_5864());
                disguiseEntityTag.method_10582("id", identifier.toString());

                disguiseTag.method_10566("DisguiseEntity", disguiseEntityTag);
            }

            tag.method_10566("DisguiseLib", disguiseTag);
        }
    }
}

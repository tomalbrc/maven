package xyz.nucleoid.disguiselib.impl.packets;

import java.util.function.Consumer;
import net.minecraft.class_2596;
import net.minecraft.class_2602;

public interface ExtendedHandler {
    void disguiselib$transformPacket(class_2596<? super class_2602> packet, Runnable remove, Consumer<class_2596<? super class_2602>> add);
    void disguiselib$onClientBrand();
}

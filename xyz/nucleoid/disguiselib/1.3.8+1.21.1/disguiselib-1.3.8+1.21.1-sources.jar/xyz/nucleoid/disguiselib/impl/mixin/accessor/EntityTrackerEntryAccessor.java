package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_3231;
import net.minecraft.class_5629;

@Mixin(targets = "net.minecraft.server.world.ServerChunkLoadingManager$EntityTracker")
public interface EntityTrackerEntryAccessor {
    @Accessor("entry")
    class_3231 getEntry();
    @Accessor("listeners")
    Set<class_5629> getListeners();
}

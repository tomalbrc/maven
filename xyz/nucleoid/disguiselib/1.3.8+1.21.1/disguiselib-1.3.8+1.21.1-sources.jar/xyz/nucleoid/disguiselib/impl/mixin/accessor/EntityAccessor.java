package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import net.minecraft.class_1297;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1297.class)
public interface EntityAccessor {
    @Accessor("FLAGS")
    static class_2940<Byte> getFLAGS() {
        throw new AssertionError();
    }
}

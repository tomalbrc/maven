package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_2716;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2716.class)
public interface EntitiesDestroyS2CPacketAccessor {
    @Accessor("entityIds")
    IntList getEntityIds();
}

package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_2739;
import net.minecraft.class_2945;

@Mixin(class_2739.class)
public interface EntityTrackerUpdateS2CPacketAccessor {
    @Accessor("id")
    int getEntityId();

    @Mutable
    @Accessor("trackedValues")
    void setTrackedValues(List<class_2945.class_7834<?>> trackedValues);
}

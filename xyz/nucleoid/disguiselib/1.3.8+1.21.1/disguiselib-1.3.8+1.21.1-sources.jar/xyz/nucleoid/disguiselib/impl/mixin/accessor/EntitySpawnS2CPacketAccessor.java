package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_2604;

@Mixin(class_2604.class)
public interface EntitySpawnS2CPacketAccessor {
    @Mutable
    @Accessor("entityType")
    void setEntityType(class_1299<?> entityType);
    @Mutable
    @Accessor("entityData")
    void setEntityData(int entityData);

    @Accessor("entityId")
    int getEntityId();

    @Mutable
    @Accessor("entityId")
    void setEntityId(int id);

    @Mutable
    @Accessor("uuid")
    void setUuid(UUID uuid);

    @Mutable
    @Accessor("x")
    void setX(double x);
    @Mutable
    @Accessor("y")
    void setY(double y);
    @Mutable
    @Accessor("z")
    void setZ(double z);
    @Mutable
    @Accessor("velocityX")
    void setVelocityX(int velocityX);
    @Mutable
    @Accessor("velocityY")
    void setVelocityY(int velocityY);
    @Mutable
    @Accessor("velocityZ")
    void setVelocityZ(int velocityZ);
    @Mutable
    @Accessor("yaw")
    void setYaw(byte yaw);
    @Mutable
    @Accessor("pitch")
    void setPitch(byte pitch);
    @Mutable
    @Accessor("headYaw")
    void setHeadYaw(byte headYaw);
}

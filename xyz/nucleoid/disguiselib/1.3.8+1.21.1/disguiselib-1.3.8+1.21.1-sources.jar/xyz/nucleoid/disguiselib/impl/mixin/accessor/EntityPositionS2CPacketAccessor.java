package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import net.minecraft.class_2777;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2777.class)
public interface EntityPositionS2CPacketAccessor {
    @Mutable
    @Accessor("entityId")
    void setEntityId(int id);
}

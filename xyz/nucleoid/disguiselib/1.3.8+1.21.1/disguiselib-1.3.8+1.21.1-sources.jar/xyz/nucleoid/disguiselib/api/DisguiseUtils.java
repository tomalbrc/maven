package xyz.nucleoid.disguiselib.api;

import net.minecraft.class_1309;

/**
 * Internal methods for managing entity disguises.
 */
public interface DisguiseUtils {
    /**
     * Updates custom name and its visibility.
     * Also sets no-gravity to true in order
     * to prevent the client from predicting
     * the entity position and velocity.
     */
    void updateTrackedData();

    /**
     * Whether disguise type entity is an instance of {@link class_1309}.
     *
     * @return true whether the disguise type is an instance of {@link class_1309}, otherwise false.
     */
    boolean disguiseAlive();
}

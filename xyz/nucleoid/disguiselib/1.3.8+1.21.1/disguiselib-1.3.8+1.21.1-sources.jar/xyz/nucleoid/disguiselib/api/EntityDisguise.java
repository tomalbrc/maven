package xyz.nucleoid.disguiselib.api;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

/**
 * Util for disguising entities.
 */
public interface EntityDisguise {

    /**
     * Tells you the disguised status.
     *
     * @return true if entity is disguised, otherwise false.
     */
    boolean isDisguised();

    /**
     * Sets entity's disguise from {@link class_1299}
     *
     * @param entityType the type to disguise this entity into
     */
    void disguiseAs(class_1299<?> entityType);

    /**
     * Sets entity's disguise from {@link class_1299}
     *
     * @param entity the entity to disguise into
     */
    void disguiseAs(class_1297 entity);

    /**
     * Clears the disguise - sets the disguiseType back to original.
     */
    void removeDisguise();

    /**
     * Gets the disguise entity type
     *
     * @return disguise entity type or real type if there's no disguise
     */
    class_1299<?> getDisguiseType();

    /**
     * Gets the disguise entity.
     *
     * @return disguise entity or null if there's no disguise
     */
    class_1297 getDisguiseEntity();

    /**
     * Whether this entity can bypass the
     * "disguises" and see entities normally
     * Intended more for admins (to not get trolled themselves).
     *
     * @return if entity can be "fooled" by disguise
     */
    boolean hasTrueSight();

    /**
     * Toggles true sight - whether entity
     * can see disguises or not.
     * Intended more for admins (to not get trolled themselves).
     *
     * @param trueSight if entity should not see disguises
     */
    void setTrueSight(boolean trueSight);

    /**
     * Gets the {@link GameProfile} for disguised entity,
     * used when disguising as player.
     *
     * @return GameProfile of the entity if set, otherwise null.
     */
    GameProfile getGameProfile();

    /**
     * Sets the GameProfile.
     *
     * @param gameProfile a new profile for the entity.
     */
    void setGameProfile(GameProfile gameProfile);
}

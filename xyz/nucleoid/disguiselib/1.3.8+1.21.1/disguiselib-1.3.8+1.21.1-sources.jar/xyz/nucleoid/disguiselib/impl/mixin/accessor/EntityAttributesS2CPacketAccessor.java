package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import net.minecraft.class_2781;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2781.class)
public interface EntityAttributesS2CPacketAccessor {
    @Accessor("entityId")
    int getEntityId();
}

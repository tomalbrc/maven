package xyz.nucleoid.disguiselib.impl.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2817;
import net.minecraft.class_7648;
import net.minecraft.class_8042;
import net.minecraft.class_8609;
import net.minecraft.class_8709;
import net.minecraft.network.packet.s2c.play.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.nucleoid.disguiselib.api.DisguiseUtils;
import xyz.nucleoid.disguiselib.api.EntityDisguise;
import xyz.nucleoid.disguiselib.impl.mixin.accessor.*;
import xyz.nucleoid.disguiselib.impl.packets.ExtendedHandler;
import xyz.nucleoid.disguiselib.impl.packets.FakePackets;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

import static xyz.nucleoid.disguiselib.impl.DisguiseLib.DISGUISE_TEAM;

@Mixin(class_8609.class)
public abstract class ServerCommonNetworkHandlerMixin_Disguiser {
    @Shadow
    public abstract void sendPacket(class_2596<?> packet);

    @Unique
    private boolean disguiselib$skipCheck;

    /**
     * Checks the packet that was sent. If the entity in the packet is disguised, the
     * entity type / id in the packet will be changed.
     *
     * As minecraft client doesn't allow moving if you send it an entity with the same
     * id as player, we send the disguised player another entity, so they will see their
     * own disguise.
     *
     * @param packet packet being sent
     */
    @Inject(
            method = "send",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/ClientConnection;send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V"
            ),
            cancellable = true
    )
    private void disguiseEntity(class_2596<class_2602> packet, class_7648 callbacks, CallbackInfo ci) {
        if (!this.disguiselib$skipCheck) {
            if (!(this instanceof ExtendedHandler self)) {
                return;
            }
            if (packet instanceof class_8042 bundleS2CPacket) {
                if (bundleS2CPacket.method_48324() instanceof ArrayList<class_2596<? super class_2602>> list) {
                    var list2 = new ArrayList<class_2596<? super class_2602>>();
                    var adder = new ArrayList<class_2596<? super class_2602>>();
                    var atomic = new AtomicBoolean(true);
                    for (var packet2 : list) {
                        atomic.set(true);
                        adder.clear();
                        self.disguiselib$transformPacket(packet2, () -> atomic.set(false), list2::add);

                        if (atomic.get()) {
                            list2.add(packet2);
                        }

                        list2.addAll(adder);
                    }

                    list.clear();
                    list.addAll(list2);
                }
            } else {
                this.disguiselib$skipCheck = true;
                self.disguiselib$transformPacket(packet, ci::cancel, this::sendPacket);
                this.disguiselib$skipCheck = false;
            }
        }
    }

    @Inject(method = "onCustomPayload", at = @At("TAIL"))
    private void onClientBrand(class_2817 packet, CallbackInfo ci) {
        if (packet.comp_1647() instanceof class_8709 && this instanceof ExtendedHandler self) {
            self.disguiselib$onClientBrand();
        }
    }
}

package xyz.nucleoid.disguiselib.impl.mixin.accessor;

import net.minecraft.class_1657;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1657.class)
public interface PlayerEntityAccessor {
    @Accessor("PLAYER_MODEL_PARTS")
    static class_2940<Byte> getPLAYER_MODEL_PARTS() {
        throw new AssertionError();
    }
}

package xyz.nucleoid.disguiselib.impl.packets;

import I;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3231;
import xyz.nucleoid.disguiselib.api.EntityDisguise;

public class FakePackets {
    /**
     * Creates a fake spawn packet for entity.
     * Make sure entity is disguised, otherwise packet will stay the same.
     *
     * @param entity entity that requires fake spawn packet
     * @param entry
     * @param b
     * @return fake entity spawn packet (Either player)
     */
    public static class_2596<? super class_2602> universalSpawnPacket(class_1297 entity, class_3231 entry, boolean replace) {
        // fixme - disguising non-living kicks you (just upon disguise)
        class_1297 disguise = ((EntityDisguise) entity).getDisguiseEntity();
        if(disguise == null) {
            disguise = entity;
        }

        try {
            if (replace) {
                var x = disguise.method_5628();
                var y = disguise.method_5667();
                disguise.method_5838(entity.method_5628());
                disguise.method_5826(entity.method_5667());
                class_2596<? super class_2602> packet = disguise.method_18002(entry);
                disguise.method_5838(x);
                disguise.method_5826(y);
                return packet;
            } else {
                return disguise.method_18002(entry);
            }
        } catch (Throwable e) {
            return entity.method_18002(entry);
        }
    }
}

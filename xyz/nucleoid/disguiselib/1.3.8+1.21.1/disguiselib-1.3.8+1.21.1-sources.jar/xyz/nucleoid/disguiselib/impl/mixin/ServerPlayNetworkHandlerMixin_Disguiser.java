package xyz.nucleoid.disguiselib.impl.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2703;
import net.minecraft.class_2716;
import net.minecraft.class_2726;
import net.minecraft.class_2739;
import net.minecraft.class_2743;
import net.minecraft.class_2777;
import net.minecraft.class_2781;
import net.minecraft.class_2828;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import net.minecraft.class_3244;
import net.minecraft.class_5900;
import net.minecraft.class_7828;
import net.minecraft.class_8609;
import net.minecraft.class_8792;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.nucleoid.disguiselib.api.DisguiseUtils;
import xyz.nucleoid.disguiselib.api.EntityDisguise;
import xyz.nucleoid.disguiselib.impl.mixin.accessor.*;
import xyz.nucleoid.disguiselib.impl.packets.ExtendedHandler;
import xyz.nucleoid.disguiselib.impl.packets.FakePackets;

import java.util.*;
import java.util.function.Consumer;

import static xyz.nucleoid.disguiselib.impl.DisguiseLib.DISGUISE_TEAM;

@Mixin(class_3244.class)
public abstract class ServerPlayNetworkHandlerMixin_Disguiser extends class_8609 implements ExtendedHandler {
    @Shadow public class_3222 player;

    @Unique
    private final Set<class_2596<?>> disguiselib$q = new HashSet<>();
    @Unique
    private int disguiselib$qTimer;
    @Unique
    private boolean disguiselib$sentTeamPacket;

    public ServerPlayNetworkHandlerMixin_Disguiser(MinecraftServer server, class_2535 connection, class_8792 clientData) {
        super(server, connection, clientData);
    }

    public void disguiselib$transformPacket(class_2596<? super class_2602> packet, Runnable remove, Consumer<class_2596<? super class_2602>> add) {
        class_1937 world = this.player.method_5770();
        class_1297 entity = null;
        if (packet instanceof class_2604) {
            entity = world.method_8469(((EntitySpawnS2CPacketAccessor) packet).getEntityId());

            if(entity != null) {
                disguiselib$sendFakePacket(entity, remove, add);
            }
        } else if (packet instanceof class_2716 && !((EntitiesDestroyS2CPacketAccessor) packet).getEntityIds().isEmpty() && ((EntitiesDestroyS2CPacketAccessor) packet).getEntityIds().getInt(0) == this.player.method_5628()) {
            remove.run();
            return;
        } else if(packet instanceof class_2739) {
            // an ugly fix for #6
            int entityId = ((EntityTrackerUpdateS2CPacketAccessor) packet).getEntityId();
            if(entityId == this.player.method_5628() && ((EntityDisguise) this.player).isDisguised()) {
                List<class_2945.class_7834<?>> trackedValues = this.player.method_5841().method_46357();
                if(((EntityDisguise) this.player).getDisguiseType() != class_1299.field_6097) {
                    Byte flags = this.player.method_5841().method_12789(EntityAccessor.getFLAGS());

                    boolean removed = trackedValues.removeIf(entry -> entry.comp_1117().equals(flags));
                    if(removed) {
                        class_2945.class_7834<Byte> fakeInvisibleFlag = class_2945.class_7834.method_46360(EntityAccessor.getFLAGS(), (byte) (flags | 1 << 5));
                        trackedValues.add(fakeInvisibleFlag);
                    }
                }
                ((EntityTrackerUpdateS2CPacketAccessor) packet).setTrackedValues(trackedValues);
            } else if(!((EntityDisguise) this.player).hasTrueSight()) {
                // Fixing "wrong data" client issue (#1)
                // Just prevents the client from spamming the log
                class_1297 original = world.method_8469(entityId);

                // Only change the content if entity is disguised
                if(original != null && ((EntityDisguise) original).isDisguised()) {
                    class_1297 disguised = ((EntityDisguise) original).getDisguiseEntity();
                    if(disguised != null) {
                        ((DisguiseUtils) original).updateTrackedData();
                        List<class_2945.class_7834<?>> trackedValues = disguised.method_5841().method_46357();
                        ((EntityTrackerUpdateS2CPacketAccessor) packet).setTrackedValues(trackedValues);
                    }
                }
            }
            return;
        } else if(packet instanceof class_2781 && !((EntityDisguise) this.player).hasTrueSight()) {
            // Fixing #2
            // Another client spam
            // Entity attributes "cannot" be sent for non-living entities
            class_1297 original = world.method_8469(((EntityAttributesS2CPacketAccessor) packet).getEntityId());
            EntityDisguise entityDisguise = (EntityDisguise) original;

            if(original != null && entityDisguise.isDisguised() && !((DisguiseUtils) original).disguiseAlive()) {
                remove.run();
                return;
            }
        } else if(packet instanceof class_2743 velocityPacket) {
            int id = velocityPacket.method_11818();
            if(id != this.player.method_5628()) {

                class_1297 entity1 = world.method_8469(id);
                if(entity1 != null && ((EntityDisguise) entity1).isDisguised()) {
                    // Cancels some client predictions
                    remove.run();
                }
            }
        }

        if(entity != null) {
            disguiselib$sendFakePacket(entity, remove, add);
        }
    }

    /**
     * Sends fake packet instead of the real one.
     *
     * @param entity the entity that is disguised and needs to have a custom packet sent.
     */
    @Unique
    private void disguiselib$sendFakePacket(class_1297 entity, Runnable remove, Consumer<class_2596<? super class_2602>> add) {
        EntityDisguise disguise = (EntityDisguise) entity;
        GameProfile profile = disguise.getGameProfile();
        class_1297 disguiseEntity = disguise.getDisguiseEntity();

        class_2596<? super class_2602> spawnPacket;
        var entry = new class_3231((class_3218) entity.method_37908(), entity, 1, true, (c) -> {});

        if(((EntityDisguise) this.player).hasTrueSight() || !disguise.isDisguised())
            spawnPacket = entity.method_18002(entry);
        else
            spawnPacket = FakePackets.universalSpawnPacket(entity, entry, true);

        if (disguise.getDisguiseType() == class_1299.field_6097) {
            class_2703 packet = new class_2703(class_2703.class_5893.field_29136, (class_3222) disguiseEntity);
            add.accept(packet);

            if (!(entity instanceof class_1657)) {
                var playerRemovePacket = new class_7828(new ArrayList<>(Collections.singletonList(profile.getId())));
                this.disguiselib$q.add(playerRemovePacket);
                this.disguiselib$qTimer = 50;
            }
        }
        if (entity.method_5628() == this.player.method_5628()) {
            // We must treat disguised player differently
            // Why, I hear you ask ..?
            // Well, sending spawn packet of the new entity makes the player not being able to move :(
            if (disguise.getDisguiseType() != class_1299.field_6097 && disguise.isDisguised()) {
                if (disguiseEntity != null) {
                    if (spawnPacket instanceof class_2604) {
                        ((EntitySpawnS2CPacketAccessor) spawnPacket).setEntityId(disguiseEntity.method_5628());
                        ((EntitySpawnS2CPacketAccessor) spawnPacket).setUuid(disguiseEntity.method_5667());
                    }
                    disguiseEntity.method_5873(this.player, true);
                    add.accept(spawnPacket);

                    class_5900 joinTeamPacket = class_5900.method_34171(DISGUISE_TEAM, this.player.method_7334().getName(), class_5900.class_5901.field_29155); // join team
                    add.accept(joinTeamPacket);
                }
            }
            remove.run();
        } else if(disguise.isDisguised()) {
            //this.player.getX()
            //ArmorStandEntity fakeStand = new ArmorStandEntity(this.player.world, );
            //fakeStand.startRiding(fakeStand, true);
            //new EntitySpawnS2CPacket(fakeStand);
            add.accept(spawnPacket);
            remove.run();
        }
    }


    @Inject(
            method = "onPlayerMove(Lnet/minecraft/network/packet/c2s/play/PlayerMoveC2SPacket;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/server/world/ServerWorld;)V",
                    shift = At.Shift.AFTER
            )
    )
    private void disguiselib$moveDisguiseEntity(class_2828 packet, CallbackInfo ci) {
        if(((EntityDisguise) this.player).isDisguised() && ((EntityDisguise) this.player).getDisguiseType() != class_1299.field_6097) {
            // Moving disguise for the disguised player
            class_2777 s2CPacket = new class_2777(this.player);
            class_2726 headYawS2CPacket = new class_2726(this.player, (byte)((int)(this.player.method_5791() * 256.0F / 360.0F)));

            //noinspection ConstantConditions
            ((EntityPositionS2CPacketAccessor) s2CPacket).setEntityId(((EntityDisguise) this.player).getDisguiseEntity().method_5628());
            //noinspection ConstantConditions
            ((EntitySetHeadYawS2CPacketAccessor) headYawS2CPacket).setEntityId(((EntityDisguise) this.player).getDisguiseEntity().method_5628());
            this.method_14364(s2CPacket);
            this.method_14364(headYawS2CPacket);
        }
    }


    @Inject(method = "onPlayerMove(Lnet/minecraft/network/packet/c2s/play/PlayerMoveC2SPacket;)V", at = @At("RETURN"))
    private void removeFromTablist(class_2828 packet, CallbackInfo ci) {
        if(!this.disguiselib$q.isEmpty() && --this.disguiselib$qTimer <= 0) {
            // fixme - non-living disguised as player still not showing up
            // fixme - player sometimes gets removed from tablist :(
            this.disguiselib$q.forEach(this::method_14364);
            this.disguiselib$q.clear();}
    }

    public void disguiselib$onClientBrand() {
        if (!this.disguiselib$sentTeamPacket) {
            // Disabling collisions with the disguised entity itself
            class_5900 addTeamPacket = class_5900.method_34172(DISGUISE_TEAM, true); // create team
            this.disguiselib$sentTeamPacket = true;
            this.method_14364(addTeamPacket);

            if (((EntityDisguise) this.player).isDisguised()) {
                // Send join team packet to prevent "sliding"
                class_5900 joinTeamPacket = class_5900.method_34171(DISGUISE_TEAM, this.player.method_7334().getName(), class_5900.class_5901.field_29155); // join team
                this.method_14364(joinTeamPacket);
            }
        }
    }
}

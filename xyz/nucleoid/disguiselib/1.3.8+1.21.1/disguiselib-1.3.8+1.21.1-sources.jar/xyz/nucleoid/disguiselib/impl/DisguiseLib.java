package xyz.nucleoid.disguiselib.impl;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_270;

import static org.apache.logging.log4j.LogManager.getLogger;

public class DisguiseLib {

	/**
	 * Disables collisions with disguised entities.
	 * (Client predictions are horrible sometimes ... )
	 */
	public static final class_268 DISGUISE_TEAM = new class_268(new class_269(), "");

	public static void init() {
		DISGUISE_TEAM.method_1145(class_270.class_271.field_1434);
		getLogger("DisguiseLib").info("DisguiseLib loaded.");

		CommandRegistrationCallback.EVENT.register(DisguiseCommand::register);
	}

	public static void setPlayerClientVisibility(boolean clientVisibility) {
		DISGUISE_TEAM.method_1143(clientVisibility);
	}
}

package xyz.nucleoid.disguiselib.impl;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import xyz.nucleoid.disguiselib.api.EntityDisguise;

import java.util.Collection;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2179;
import net.minecraft.class_2186;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_7157;
import net.minecraft.class_7733;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.class_2186.method_9306;
import static net.minecraft.class_2321.field_10935;
import static net.minecraft.class_1299.field_6097;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class DisguiseCommand {

    private static final class_2561 NO_PERMISSION_ERROR = class_2561.method_43471("commands.help.failed");

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandRegistryAccess, class_2170.class_5364 registrationEnvironment) {
        dispatcher.register(method_9247("disguise")
                .requires(src -> src.method_9259(2))
                .then(method_9244("target", method_9306())
                        .then(method_9247("as")
                            .then(method_9244("disguise", new class_7733<>(commandRegistryAccess, class_7924.field_41266))
                                .suggests(field_10935)
                                .executes(DisguiseCommand::setDisguise)
                                    .then(method_9244("nbt", class_2179.method_9284())
                                        .executes(DisguiseCommand::setDisguise)
                                    )
                            )
                            .then(method_9247("minecraft:player")
                                    .then(method_9244("playername", word())
                                            .executes(DisguiseCommand::disguiseAsPlayer)
                                    )
                                    .executes(DisguiseCommand::disguiseAsPlayer)
                            )
                            .then(method_9247("player")
                                    .then(method_9244("playername", word())
                                            .executes(DisguiseCommand::disguiseAsPlayer)
                                    )
                                    .executes(DisguiseCommand::disguiseAsPlayer)
                            )
                        )
                        .then(method_9247("clear").executes(DisguiseCommand::clearDisguise))
                )
        );
    }

    private static int disguiseAsPlayer(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        Collection<? extends class_1297> entities = class_2186.method_9317(ctx, "target");
        class_2168 src = ctx.getSource();
        GameProfile profile;
        class_3222 player = src.method_9207();
        String playername;
        try {
            playername = StringArgumentType.getString(ctx, "playername");
        } catch(IllegalArgumentException ignored) {
            playername = player.method_7334().getName();
        }

        profile = new GameProfile(null, playername);  //fixme profile doesn't contain skin data; migrate to fabrictailor
        /*SkullBlockEntity.loadProperties(profile, gameProfile -> {
            // Minecraft doesn't allow "summoning" players, that's why we make an exception
            GameProfile finalProfile = gameProfile == null ? player.getGameProfile() : gameProfile;
            entities.forEach(entity -> {
                if(entity == src.getEntity()) {
                    if(src.hasPermissionLevel(2)) {
                        ((EntityDisguise) entity).disguiseAs(PLAYER);
                        if(finalProfile != null) {
                            ((EntityDisguise) entity).setGameProfile(finalProfile);
                        }
                    }
                    else
                        src.sendError(NO_PERMISSION_ERROR);
                } else {
                    if(src.hasPermissionLevel(2)) {
                        ((EntityDisguise) entity).disguiseAs(PLAYER);
                        if(finalProfile != null) {
                            ((EntityDisguise) entity).setGameProfile(finalProfile);
                        }
                    }
                    else
                        src.sendError(NO_PERMISSION_ERROR);
                }
            });
        });*/
        return 0;
    }

    private static int clearDisguise(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        Collection<? extends class_1297> entities = class_2186.method_9317(ctx, "target");
        class_2168 src = ctx.getSource();
        // Minecraft doesn't allow "summoning" players, that's why we make an exception
        entities.forEach(entity -> {
            if(entity == src.method_9228()) {
                if(src.method_9259(2))
                    ((EntityDisguise) entity).removeDisguise();
                else
                    src.method_9213(NO_PERMISSION_ERROR);
            } else {
                if(src.method_9259(2)) {
                    ((EntityDisguise) entity).removeDisguise();
                } else
                    src.method_9213(NO_PERMISSION_ERROR);
            }
        });
        return 0;
    }

    private static int setDisguise(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        Collection<? extends class_1297> entities = class_2186.method_9317(ctx, "target");
        class_2168 src = ctx.getSource();
        var type = class_7733.method_45602(ctx, "disguise", class_7924.field_41266);
        var disguise = class_7923.field_41177.method_10221(type.comp_349());

        class_2487 nbt;
        try {
            nbt = class_2179.method_9285(ctx, "nbt").method_10553();
        } catch(IllegalArgumentException ignored) {
            nbt = new class_2487();
        }
        nbt.method_10582("id", disguise.toString());

        class_2487 finalNbt = nbt;
        entities.forEach(entity -> class_1299.method_17842(finalNbt, ctx.getSource().method_9225(), (entityx) -> {
            if(entity == src.method_9228()) {
                if(src.method_9259(2))
                    ((EntityDisguise) entity).disguiseAs(entityx);
                else
                    src.method_9213(NO_PERMISSION_ERROR);
            } else {
                if(src.method_9259(2)) {
                    ((EntityDisguise) entity).disguiseAs(entityx);
                } else
                    src.method_9213(NO_PERMISSION_ERROR);
            }
            return entityx;
        }));
        return 0;
    }
}
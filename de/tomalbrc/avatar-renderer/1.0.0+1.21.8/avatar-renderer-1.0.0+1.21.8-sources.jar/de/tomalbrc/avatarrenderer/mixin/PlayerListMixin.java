package de.tomalbrc.avatarrenderer.mixin;

import de.tomalbrc.avatarrenderer.AvatarRendererMod;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class PlayerListMixin {
    @Inject(method = "placeNewPlayer", at = @At("HEAD"))
    private void ar$onPlacePlayer(class_2535 connection, class_3222 serverPlayer, class_8792 commonListenerCookie, CallbackInfo ci) {
        for (int i = 0; i < 256; i++) {
            // hm we technically dont need to cache every offset
            AvatarRendererMod.get(serverPlayer.method_5820(), i, false, AvatarRendererMod.NOOP);
            AvatarRendererMod.get(serverPlayer.method_5820(), i, true, AvatarRendererMod.NOOP);
        }
    }
}

package de.tomalbrc.dialogutils.util;

import com.mojang.brigadier.CommandDispatcher;
import de.tomalbrc.dialogutils.DialogUtils;
import net.minecraft.class_11406;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9247;

public class CloseCommand {
    public static void register(CommandDispatcher<class_2168> commandDispatcher, class_7157 context, class_2170.class_5364 selection) {
        commandDispatcher.register(
                method_9247(DialogUtils.MODID).then(method_9247("close").executes(commandContext -> {
                            var player = commandContext.getSource().method_44023();
                            if (player != null) {
                                player.field_13987.method_14364(class_11406.field_60602);
                            }
                            return com.mojang.brigadier.Command.SINGLE_SUCCESS;
                        })
                ));
    }
}

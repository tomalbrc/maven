package de.tomalbrc.dialogutils.util;

import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3532;
import net.minecraft.class_5250;

public class ComponentAligner {
    public static class_5250 align(class_2561 component, TextUtil.Alignment alignment, int width) {
        int w = getWidth(component);
        int remainingSpace = width - w;

        if (alignment == TextUtil.Alignment.LEFT) {
            var space = spacer(remainingSpace);
            return class_2561.method_43473().method_10852(component).method_10852(space);
        }
        else if (alignment == TextUtil.Alignment.RIGHT) {
            var space = spacer(remainingSpace);
            return class_2561.method_43473().method_10852(space).method_10852(component);
        } else {
            var space = spacer(remainingSpace / 2);
            return class_2561.method_43473().method_10852(space).method_10852(component).method_10852(space);
        }
    }

    public static int getWidth(class_2561 component) {
        return component.method_27658((style, content) -> {

            int w = TextUtil.getTextWidth(content, style.method_27708());

            System.out.printf("W: %d, content: %s - font: %s%n", w, content, style.method_27708());

            if (style.method_10984()) {
                w += content.length();
            }
            return Optional.of(w);
        }, class_2583.field_24360).orElse(0);
    }

    public static class_2561 defaultFont(class_2561 component) {
        return class_2561.method_43473().method_10852(component).method_27696(class_2583.field_24360.method_27704(FontUtil.FONT));
    }

    public static class_2561 spacer(int width) {
        return class_2561.method_43470((width < 0 ? " " : ".").repeat(class_3532.method_15382(width))).method_27696(class_2583.field_24360.method_27704(FontUtil.ALIGN_FONT));
    }
}

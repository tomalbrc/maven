package de.tomalbrc.dialogutils.util;

import eu.pb4.mapcanvas.impl.font.BitmapFont;
import eu.pb4.placeholders.api.TextParserUtils;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class TextUtil {
    public enum Alignment {
        LEFT, CENTER, RIGHT
    }

    public static int getGlyphWidth(int character, int offset, class_2960 font) {
        var fr = FontUtil.fontReader(font);
        if (fr == null)
            return 5;

        BitmapFont.Glyph glyph = fr.characters.getOrDefault(character, fr.defaultGlyph);

        if (glyph.logicalHeight() != 0 && glyph.height() != 0) {
            return glyph.width() + offset;
        } else {
            return (int) ((double) glyph.fontWidth());
        }
    }

    public static int getTextWidth(String text, class_2960 font) {
        if (text.isEmpty()) {
            return 0;
        } else {
            int posX = 0;
            int[] array = text.codePoints().toArray();
            for (int j : array) {
                posX += getGlyphWidth(j, 1, font);
            }
            return posX;
        }
    }

    public static class_2561 parse(String s) {
        return TextParserUtils.formatText(s);
    }

}

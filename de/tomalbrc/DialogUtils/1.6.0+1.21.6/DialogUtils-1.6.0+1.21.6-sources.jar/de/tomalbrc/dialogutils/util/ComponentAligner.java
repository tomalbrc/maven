package de.tomalbrc.dialogutils.util;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3532;
import net.minecraft.class_5250;

public class ComponentAligner {
    public static class_5250 align(class_2561 component, TextUtil.Alignment alignment, int width) {
        int w = getWidth(component);
        int remainingSpace = width - w;

        if (alignment == TextUtil.Alignment.LEFT) {
            var space = spacer(remainingSpace);
            return class_2561.method_43473().method_10852(component).method_10852(space);
        } else if (alignment == TextUtil.Alignment.RIGHT) {
            var space = spacer(remainingSpace);
            return class_2561.method_43473().method_10852(space).method_10852(component);
        } else {
            int half = remainingSpace / 2;
            var space = spacer(half);
            if (remainingSpace % 2 == 1) {
                var space2 = spacer(half+1);
                return class_2561.method_43473().method_10852(space).method_10852(component).method_10852(space2);
            }

            return class_2561.method_43473().method_10852(space).method_10852(component).method_10852(space);
        }
    }

    public static int getWidth(class_2561 component) {
        AtomicInteger w = new AtomicInteger(0);
        for (class_2561 part : component.method_44746()) {
            int val = part.method_27658((style, content) -> {
                int textWidth = TextUtil.getTextWidth(content, style.method_27708());

                if (style.method_10984()) {
                    textWidth += content.length();
                }
                return Optional.of(textWidth);
            }, class_2583.field_24360).orElse(0);
            w.addAndGet(val);
        }

        return w.get();
    }

    public static class_2561 defaultFont(class_2561 component) {
        return class_2561.method_43473().method_10852(component).method_27696(class_2583.field_24360.method_27704(FontUtil.FONT));
    }

    public static class_2561 spacer(int width) {
        return class_2561.method_43470((width < 0 ? " " : ".").repeat(class_3532.method_15382(width))).method_27696(class_2583.field_24360.method_27704(FontUtil.ALIGN_FONT));
    }
}

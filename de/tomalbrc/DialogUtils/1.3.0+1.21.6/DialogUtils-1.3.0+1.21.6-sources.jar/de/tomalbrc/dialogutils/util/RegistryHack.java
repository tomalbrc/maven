package de.tomalbrc.dialogutils.util;

import net.minecraft.class_2960;

public interface RegistryHack {
    void du$unfreeze();

    void du$remove(class_2960 key);
}

package de.tomalbrc.dialogutils.mixin;

import de.tomalbrc.dialogutils.util.RegistryHack;
import it.unimi.dsi.fastutil.objects.ObjectList;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9248;

@Mixin(class_2370.class)
public abstract class MappedRegistryMixin<T> implements RegistryHack {
    @Shadow
    @Nullable
    private Map<T, class_6880.class_6883<T>> unregisteredIntrusiveHolders;

    @Shadow
    private boolean frozen;

    @Shadow class_2370.class_10105<T> allTags;

    @Shadow public abstract class_6880.class_6883<T> register(class_5321<T> resourceKey, T object, class_9248 registrationInfo);

    @Shadow @Final private ObjectList<class_6880.class_6883<T>> byId;

    @Shadow @Final private Map<class_2960, class_6880.class_6883<T>> byLocation;

    @Shadow @Final private Map<class_5321<T>, class_6880.class_6883<T>> byKey;

    @Override
    public void du$unfreeze() {
        this.unregisteredIntrusiveHolders = new IdentityHashMap<>();
        this.allTags = class_2370.class_10105.method_62697();
        this.frozen = false;
    }

    @Override
    public void du$remove(class_2960 key) {
        var o = byLocation.remove(key);
        if (o != null) {
            this.byId.remove(o);
            this.byKey.remove(o.method_40237());
        }
    }
}

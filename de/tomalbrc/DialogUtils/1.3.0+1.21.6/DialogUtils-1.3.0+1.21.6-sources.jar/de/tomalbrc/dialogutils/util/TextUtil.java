package de.tomalbrc.dialogutils.util;

import eu.pb4.placeholders.api.TextParserUtils;
import net.minecraft.class_2561;

public class TextUtil {
    public static class_2561 parse(String s) {
        return TextParserUtils.formatText(s);
    }
}

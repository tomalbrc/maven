package de.tomalbrc.dialogutils.util;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import de.tomalbrc.dialogutils.DialogUtils;
import de.tomalbrc.dialogutils.mixin.DefaultRPBuilderAccessor;
import eu.pb4.mapcanvas.api.font.CanvasFont;
import eu.pb4.mapcanvas.impl.font.BitmapFont;
import eu.pb4.mapcanvas.impl.font.serialization.VanillaFontReader;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import eu.pb4.polymer.resourcepack.impl.generation.DefaultRPBuilder;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11719;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

public class FontUtil {
    public final static class_11719.class_11721 FONT = new class_11719.class_11721(class_2960.method_60655(DialogUtils.MODID, "default"));
    public static final class_11719.class_11721 ALIGN_FONT = new class_11719.class_11721(class_2960.method_60655(DialogUtils.MODID, "align"));
    public static Map<class_2960, BitmapFont> FONTS = new Object2ObjectOpenHashMap<>();

    public static BitmapFont loadFont(ResourcePackBuilder resourcePackBuilder, class_2960 id) {
        try {
            var fr = VanillaFontReader.build((x) -> new ByteArrayInputStream(Objects.requireNonNull(resourcePackBuilder.getDataOrSource(x))), CanvasFont.Metadata.create("Resource Pack Font", List.of("Unknown"), "Generated"),id);
            FONTS.put(id, fr);

            return fr;
        } catch (Exception ignored) {
            return null;
        }
    }

    @Nullable
    public static BitmapFont fontReader(ResourcePackBuilder builder) {
        if (!FONTS.containsKey(class_11719.field_61972.comp_4590())) {
            try {
                if (builder == null) builder = PolymerResourcePackUtils.createBuilder(FabricLoader.getInstance().getGameDir().resolve("polymer/dialog"));
                var fr = loadFont(builder, class_11719.field_61972.comp_4590());
                FONTS.put(class_11719.field_61972.comp_4590(), fr);
                FONTS.put(FontUtil.FONT.comp_4590(), fr);
            } catch (Exception ignored) {}
        }

        return FONTS.get(class_11719.field_61972.comp_4590());
    }

    @Nullable
    public static BitmapFont fontReader(class_2960 font) {
        return FONTS.get(font);
    }

    public static void copyVanillaFont(ResourcePackBuilder resourcePackBuilder) {
        copyVanillaFont(resourcePackBuilder, DialogUtils.MODID);
    }

    public static void registerDefaultFonts(ResourcePackBuilder resourcePackBuilder) {
        var def = loadFont(resourcePackBuilder, class_11719.field_61972.comp_4590());
        FONTS.put(FontUtil.FONT.comp_4590(), def);
        loadFont(resourcePackBuilder, FontUtil.ALIGN_FONT.comp_4590());
    }

    public static void copyVanillaFont(ResourcePackBuilder resourcePackBuilder, String namespace) {
        List<String> fontTextures = ImmutableList.of(
                "assets/minecraft/textures/font/nonlatin_european.png",
                "assets/minecraft/textures/font/accented.png",
                "assets/minecraft/textures/font/ascii.png"
        );

        Function<String, byte[]> getter = null;
        try {
            if (resourcePackBuilder instanceof DefaultRPBuilder x) {
                getter = path -> ((DefaultRPBuilderAccessor)x).getFileMap().get(path).readAllBytes();
            }
        } catch (Exception e) {
            LogUtils.getLogger().error("Error copying vanilla font: ", e);
        }

        if (getter == null) {
            getter = resourcePackBuilder::getDataOrSource;
        }

        for (String path : fontTextures) {
            resourcePackBuilder.addData(path.replace("minecraft", namespace), getter.apply(path));
        }

        var defaultFont = getter.apply("assets/minecraft/font/include/default.json");
        var spaceFont = getter.apply("assets/minecraft/font/include/space.json");

        assert defaultFont != null;
        JsonElement def = JsonParser.parseReader(new InputStreamReader(new ByteArrayInputStream(defaultFont)));

        assert spaceFont != null;
        JsonElement space = JsonParser.parseReader(new InputStreamReader(new ByteArrayInputStream(spaceFont)));

        space.getAsJsonObject().getAsJsonArray("providers").addAll(def.getAsJsonObject().getAsJsonArray("providers"));
        var combined = space.toString().replace("minecraft:", namespace + ":");

        resourcePackBuilder.addData("assets/" + namespace + "/font/default.json", combined.getBytes(StandardCharsets.UTF_8));
    }
}

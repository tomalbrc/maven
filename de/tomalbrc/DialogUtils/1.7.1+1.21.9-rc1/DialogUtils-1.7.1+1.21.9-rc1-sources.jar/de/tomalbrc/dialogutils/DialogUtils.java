package de.tomalbrc.dialogutils;

import de.tomalbrc.dialogutils.util.CloseCommand;
import de.tomalbrc.dialogutils.util.FontUtil;
import de.tomalbrc.dialogutils.util.RegistryHack;
import eu.pb4.polymer.autohost.impl.AutoHost;
import eu.pb4.polymer.common.impl.CommonNetworkHandlerExt;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.class_11419;
import net.minecraft.class_2378;
import net.minecraft.class_2720;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class DialogUtils implements ModInitializer {
    public final static String MODID = "dialogutils";

    private static final Map<class_2960, class_11419> DIALOGS = new Object2ObjectArrayMap<>();
    private static final List<class_2960> QUICK_ACTIONS = new ObjectArrayList<>();

    public static MinecraftServer SERVER;

    public static void registerQuickDialog(class_2960 id) {
        DialogUtils.QUICK_ACTIONS.add(id);
    }

    public static void registerDialog(class_2960 id, class_11419 dialog) {
        DialogUtils.DIALOGS.put(id, dialog);

        var dialogRegistry = SERVER.method_30611().method_46759(class_7924.field_60818).orElseThrow();
        ((RegistryHack) dialogRegistry).du$unfreeze();
        dialogRegistry.method_40269(dialog);
        ((RegistryHack) dialogRegistry).du$remove(id);
        class_2378.method_10230(dialogRegistry, id, dialog);
        SERVER.method_30611().method_40316();
    }

    public static Map<class_2960, class_11419> getDialogs() {
        return DIALOGS;
    }

    public static List<class_2960> getQuickActions() {
        return QUICK_ACTIONS;
    }

    @Override
    public void onInitialize() {
        PolymerResourcePackUtils.addModAssets(DialogUtils.MODID);
        PolymerResourcePackUtils.markAsRequired();

        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(FontUtil::copyVanillaFont);

        ServerLifecycleEvents.SERVER_STARTING.register(minecraftServer -> {
            SERVER = minecraftServer;
        });
    }

    public static void addCloseCommand() {
        CommandRegistrationCallback.EVENT.register(CloseCommand::register);
    }

    @SuppressWarnings("all")
    public static void reloadRebuildResourcePack(MinecraftServer server) {
        PolymerResourcePackUtils.buildMain();

        if (AutoHost.config != null && AutoHost.config.enabled) {
            var provider = AutoHost.provider;
            if (provider.isReady()) {
                for (class_3222 player : server.method_3760().method_14571()) {
                    for (var x : provider.getProperties(((CommonNetworkHandlerExt) player.field_13987).polymerCommon$getConnection())) {
                        player.field_13987.method_14364(new class_2720(x.comp_2156(), x.comp_784(), x.comp_785(), AutoHost.config.require || PolymerResourcePackUtils.isRequired(), Optional.ofNullable(AutoHost.message)));
                    }
                }
            }
        }
    }
}

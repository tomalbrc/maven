package de.tomalbrc.dialogutils;

import de.tomalbrc.dialogutils.impl.Book;
import de.tomalbrc.dialogutils.util.Command;
import de.tomalbrc.dialogutils.util.Globals;
import de.tomalbrc.dialogutils.util.RegistryHack;
import de.tomalbrc.dialogutils.util.TextAligner;
import eu.pb4.polymer.autohost.impl.AutoHost;
import eu.pb4.polymer.common.impl.CommonNetworkHandlerExt;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import eu.pb4.polymer.resourcepack.extras.api.format.font.FontAsset;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11419;
import net.minecraft.class_2378;
import net.minecraft.class_2720;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.FilenameUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class DialogUtils implements ModInitializer {
    public static String MODID = "dialogutils";
    public static MinecraftServer SERVER;
    public static final Map<String, Book> BOOKS = new Object2ObjectArrayMap<>();

    private static final Map<class_2960, class_11419> DIALOGS = new Object2ObjectArrayMap<>();
    private static final List<class_2960> QUICK_ACTIONS = new ObjectArrayList<>();

    public static void registerQuickDialog(class_2960 id) {
        DialogUtils.QUICK_ACTIONS.add(id);
    }

    public static void registerDialog(class_2960 id, class_11419 dialog) {
        DialogUtils.DIALOGS.put(id, dialog);
    }

    public static Map<class_2960, class_11419> getDialogs() {
        return DIALOGS;
    }

    public static List<class_2960> getQuickActions() {
        return QUICK_ACTIONS;
    }

    @Override
    public void onInitialize() {
        PolymerResourcePackUtils.addModAssets(DialogUtils.MODID);
        PolymerResourcePackUtils.markAsRequired();

        ServerLifecycleEvents.SERVER_STARTING.register(minecraftServer -> SERVER = minecraftServer);
        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(TextAligner::init);
        ServerLifecycleEvents.SERVER_STARTED.register(DialogUtils::onStarted);

        bookSupport();
    }

    public static void bookSupport() {
        ServerTickEvents.END_SERVER_TICK.register(Ticker::tick);
        ServerPlayerEvents.LEAVE.register((serverPlayer -> {
            Ticker.remove(serverPlayer.method_5667());
        }));

        PolymerResourcePackUtils.RESOURCE_PACK_FINISHED_EVENT.register(() -> Globals.FONT_INDEX = 0xF000);
        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(DialogUtils::loadOrReloadBooks);

        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((minecraftServer, closeableResourceManager, b) -> {
            loadWithReload(minecraftServer);
        });

        CommandRegistrationCallback.EVENT.register(Command::register);
    }

    private static void onStarted(MinecraftServer server) {
        var dialogRegistry = SERVER.method_30611().method_46759(class_7924.field_60818).orElseThrow();
        ((RegistryHack) dialogRegistry).du$unfreeze();
        for (Map.Entry<class_2960, class_11419> entry : DIALOGS.entrySet()) {
            class_11419 dialog = entry.getValue();
            dialogRegistry.method_40269(dialog);
            ((RegistryHack) dialogRegistry).du$remove(entry.getKey());
            class_2378.method_10230(dialogRegistry, entry.getKey(), dialog);
        }
        SERVER.method_30611().method_40316();
    }

    private static void loadOrReloadBooks(ResourcePackBuilder builder) {
        var bookPath = FabricLoader.getInstance().getConfigDir().resolve("books");
        if (!bookPath.toFile().exists())
            return;

        try (var x = Files.walk(bookPath, FileVisitOption.FOLLOW_LINKS)) {
            var fontAssetBuilder = FontAsset.builder();

            for (Object object : x.toArray()) {
                Path path = (Path) object;
                if (path.toString().endsWith(".txt") && !path.toFile().isDirectory()) {
                    try (var f = new FileInputStream(path.toFile())) {
                        String name = FilenameUtils.getBaseName(path.toString());
                        BOOKS.put(name, Book.from(name, f, fontAssetBuilder));
                    } catch (IOException ignored) {}
                }
            }

            var fontAsset = fontAssetBuilder.build();
            builder.addData("assets/" + DialogUtils.MODID + "/font/generated.json", fontAsset.toJson().replace("minecraft:bitmap", "bitmap").getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {

        }

        for (Map.Entry<String, Book> entry : BOOKS.entrySet()) {
            class_11419 dialog = entry.getValue().createDialog(0, 0);
            class_2960 id = class_2960.method_60655(DialogUtils.MODID, entry.getKey());
            DIALOGS.put(id, dialog);
            QUICK_ACTIONS.add(id);
        }
    }

    public static void loadWithReload(MinecraftServer server) {
        PolymerResourcePackUtils.buildMain();

        if (AutoHost.config != null && AutoHost.config.enabled) {
            var provider =  AutoHost.provider;
            if (provider.isReady()) {
                for (class_3222 player : server.method_3760().method_14571()) {
                    for (var x : provider.getProperties(((CommonNetworkHandlerExt) player.field_13987).polymerCommon$getConnection())) {
                        player.field_13987.method_14364(new class_2720(x.comp_2156(), x.comp_784(), x.comp_785(), AutoHost.config.require || PolymerResourcePackUtils.isRequired(), Optional.ofNullable(AutoHost.message)));
                    }
                }
            }
        }
    }
}

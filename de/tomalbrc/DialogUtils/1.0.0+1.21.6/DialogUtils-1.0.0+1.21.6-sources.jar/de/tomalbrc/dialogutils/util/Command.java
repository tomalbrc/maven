package de.tomalbrc.dialogutils.util;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import de.tomalbrc.dialogutils.DialogUtils;
import de.tomalbrc.dialogutils.Ticker;
import net.minecraft.class_11406;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3532;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class Command {
    public static void register(CommandDispatcher<class_2168> commandDispatcher, class_7157 context, class_2170.class_5364 selection) {
        commandDispatcher.register(
                method_9247(DialogUtils.MODID).then(method_9244("book", StringArgumentType.word()).suggests((commandContext, suggestionsBuilder) -> {
                    DialogUtils.BOOKS.keySet().forEach(suggestionsBuilder::suggest);
                    return suggestionsBuilder.buildFuture();
                }).then(method_9244("page", IntegerArgumentType.integer()).executes(commandContext -> {
                    var player = commandContext.getSource().method_44023();
                    if (player == null)
                        return 0;

                    Ticker.remove(player.method_5667());

                    var bookId = StringArgumentType.getString(commandContext, "book");
                    var book = DialogUtils.BOOKS.get(bookId);

                    var pageNum = IntegerArgumentType.getInteger(commandContext, "page");
                    pageNum = class_3532.method_15340(0, book.pages().size() - 1, pageNum);

                    book.openBookAtPage(player, pageNum);

                    return com.mojang.brigadier.Command.SINGLE_SUCCESS;
                }))).then(method_9247("close").executes(commandContext -> {
                            var player = commandContext.getSource().method_44023();
                            if (player != null) {
                                player.field_13987.method_14364(class_11406.field_60602);
                                Ticker.remove(player.method_5667());
                            }
                            return com.mojang.brigadier.Command.SINGLE_SUCCESS;
                        })
                ));
    }
}

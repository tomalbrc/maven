package de.tomalbrc.dialogutils;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import de.tomalbrc.dialogutils.mixin.DefaultRPBuilderAccessor;
import de.tomalbrc.dialogutils.util.CloseCommand;
import de.tomalbrc.dialogutils.util.Globals;
import de.tomalbrc.dialogutils.util.RegistryHack;
import de.tomalbrc.dialogutils.util.TextAligner;
import eu.pb4.mapcanvas.api.font.CanvasFont;
import eu.pb4.mapcanvas.impl.font.serialization.VanillaFontReader;
import eu.pb4.polymer.autohost.impl.AutoHost;
import eu.pb4.polymer.common.impl.CommonNetworkHandlerExt;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import eu.pb4.polymer.resourcepack.impl.generation.DefaultRPBuilder;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11419;
import net.minecraft.class_2378;
import net.minecraft.class_2720;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class DialogUtils implements ModInitializer {
    public static String MODID = "dialogutils";
    public static String FONT = MODID + ":default";
    public static MinecraftServer SERVER;

    private static final Map<class_2960, class_11419> DIALOGS = new Object2ObjectArrayMap<>();
    private static final List<class_2960> QUICK_ACTIONS = new ObjectArrayList<>();

    public static void registerQuickDialog(class_2960 id) {
        DialogUtils.QUICK_ACTIONS.add(id);
    }

    public static void registerDialog(class_2960 id, class_11419 dialog) {
        DialogUtils.DIALOGS.put(id, dialog);
    }

    public static Map<class_2960, class_11419> getDialogs() {
        return DIALOGS;
    }

    public static List<class_2960> getQuickActions() {
        return QUICK_ACTIONS;
    }

    public static ResourcePackBuilder resourcePackBuilder() {
        if (Globals.RP_BUILDER == null) {
            var path = FabricLoader.getInstance().getGameDir().resolve("polymer/a");
            Globals.RP_BUILDER = PolymerResourcePackUtils.createBuilder(FabricLoader.getInstance().getGameDir().resolve("polymer/a"));
            path.toFile().delete();
        }
        return Globals.RP_BUILDER;
    }

    @Override
    public void onInitialize() {
        PolymerResourcePackUtils.addModAssets(DialogUtils.MODID);
        PolymerResourcePackUtils.markAsRequired();

        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(DialogUtils::copyVanillaFont);

        Globals.FONT_READER = VanillaFontReader.build((x) -> new ByteArrayInputStream(Objects.requireNonNull(Globals.RP_BUILDER.getDataOrSource(x))), CanvasFont.Metadata.create("Resource Pack Font", List.of("Unknown"), "Generated"), class_2960.method_60655(DialogUtils.MODID, "default"));

        ServerLifecycleEvents.SERVER_STARTING.register(minecraftServer -> {
            SERVER = minecraftServer;
            DialogUtils.onStarted(resourcePackBuilder());
        });
    }

    public static void addCloseCommand() {
        CommandRegistrationCallback.EVENT.register(CloseCommand::register);
    }

    private static void onStarted(ResourcePackBuilder builder) {
        var dialogRegistry = SERVER.method_30611().method_46759(class_7924.field_60818).orElseThrow();
        ((RegistryHack) dialogRegistry).du$unfreeze();
        for (Map.Entry<class_2960, class_11419> entry : DIALOGS.entrySet()) {
            class_11419 dialog = entry.getValue();
            dialogRegistry.method_40269(dialog);
            ((RegistryHack) dialogRegistry).du$remove(entry.getKey());
            class_2378.method_10230(dialogRegistry, entry.getKey(), dialog);
        }
        SERVER.method_30611().method_40316();
    }

    @SuppressWarnings("all")
    public static void reloadRebuildResourcePack(MinecraftServer server) {
        PolymerResourcePackUtils.buildMain();

        if (AutoHost.config != null && AutoHost.config.enabled) {
            var provider = AutoHost.provider;
            if (provider.isReady()) {
                for (class_3222 player : server.method_3760().method_14571()) {
                    for (var x : provider.getProperties(((CommonNetworkHandlerExt) player.field_13987).polymerCommon$getConnection())) {
                        player.field_13987.method_14364(new class_2720(x.comp_2156(), x.comp_784(), x.comp_785(), AutoHost.config.require || PolymerResourcePackUtils.isRequired(), Optional.ofNullable(AutoHost.message)));
                    }
                }
            }
        }
    }

    public static void copyVanillaFont(ResourcePackBuilder resourcePackBuilder) {
        copyVanillaFont(resourcePackBuilder, MODID);
    }

    public static void copyVanillaFont(ResourcePackBuilder resourcePackBuilder, String namespace) {
        if (resourcePackBuilder instanceof DefaultRPBuilder defaultRPBuilder) {
            List<String> fontTextures = ImmutableList.of(
                    "assets/minecraft/textures/font/nonlatin_european.png",
                    "assets/minecraft/textures/font/accented.png",
                    "assets/minecraft/textures/font/ascii.png"
            );
            for (String path : fontTextures) {
                try {
                    resourcePackBuilder.addData(path.replace("minecraft", namespace), ((DefaultRPBuilderAccessor) defaultRPBuilder).inkvokeGetSourceStream(path).readAllBytes());
                } catch (IOException ignored) {}
            }

            var defaultFont = ((DefaultRPBuilderAccessor) defaultRPBuilder).inkvokeGetSourceStream("assets/minecraft/font/include/default.json");
            var spaceFont = ((DefaultRPBuilderAccessor) defaultRPBuilder).inkvokeGetSourceStream("assets/minecraft/font/include/space.json");

            JsonElement def = JsonParser.parseReader(new InputStreamReader(defaultFont));
            JsonElement space = JsonParser.parseReader(new InputStreamReader(spaceFont));

            space.getAsJsonObject().getAsJsonArray("providers").addAll(def.getAsJsonObject().getAsJsonArray("providers"));
            var combined = space.toString().replace("minecraft:", namespace + ":");

            resourcePackBuilder.addData("assets/" + namespace + "/font/default.json", combined.getBytes(StandardCharsets.UTF_8));
        }
    }
}

package de.tomalbrc.dialogutils.mixin;

import de.tomalbrc.dialogutils.DialogUtils;
import de.tomalbrc.dialogutils.util.Globals;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.class_11455;
import net.minecraft.class_2378;
import net.minecraft.class_2790;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6864;
import net.minecraft.class_7924;

@Mixin(class_2790.class)
public class ClientboundUpdateTagsPacketMixin {
    @Inject(method = "<init>(Ljava/util/Map;)V", at = @At("RETURN"))
    private void du$hackQuickActions(Map<class_5321<? extends class_2378<?>>, class_6864.class_5748> map, CallbackInfo ci) {
        var payload = map.get(class_7924.field_60818);

        var reg = DialogUtils.SERVER.method_30611().method_46759(class_7924.field_60818);
        reg.ifPresent(registry -> {
            var list = new IntArrayList(payload.field_28304.get(class_11455.field_60978.comp_327()));
            for (class_2960 id : DialogUtils.getQuickActions()) {
                var obj = registry.method_63535(id);
                var rawid = registry.method_10206(obj);
                list.add(rawid);
            }

            payload.field_28304.put(class_11455.field_60978.comp_327(), list);
        });
    }
}

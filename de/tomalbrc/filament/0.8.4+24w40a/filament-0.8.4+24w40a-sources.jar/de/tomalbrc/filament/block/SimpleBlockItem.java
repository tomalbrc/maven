package de.tomalbrc.filament.block;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.item.SimpleItem;
import eu.pb4.polymer.core.api.item.PolymerItem;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class SimpleBlockItem extends SimpleItem implements PolymerItem, BehaviourHolder {

    private final BlockData blockData;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties, data.properties(), data.vanillaItem());
        this.blockData = data;
        this.initBehaviours(data.behaviourConfig());
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, class_3222 player) {
        return this.vanillaItem;
    }

    @Override
    protected Map<String, class_2960> getModelMap() {
        return this.blockData.itemResource() == null ? Map.of() : this.blockData.itemResource().models();
    }

    @Override
    protected class_2960 getModel() {
        boolean hasItemModels = this.blockData.itemResource() != null && this.blockData.itemResource().models() != null;
        return hasItemModels ? this.blockData.itemResource().models().get("default") : this.blockData.blockResource().models().entrySet().iterator().next().getValue();
    }
}
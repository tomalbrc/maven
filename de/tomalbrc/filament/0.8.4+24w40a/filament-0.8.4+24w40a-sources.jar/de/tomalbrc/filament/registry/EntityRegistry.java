package de.tomalbrc.filament.registry;

import de.tomalbrc.filament.decoration.util.SeatEntity;
import de.tomalbrc.filament.item.BaseProjectileEntity;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class EntityRegistry {
    public static final class_1299<BaseProjectileEntity> BASE_PROJECTILE = registerEntity("projectile", class_1299.class_1300.method_5903(BaseProjectileEntity::new, class_1311.field_17715).method_17687(2.f, 3.3f));

    public static final class_1299<SeatEntity> SEAT_ENTITY =  registerEntity("decoration_seat", class_1299.class_1300.method_5903(SeatEntity::new, class_1311.field_17715).method_5901());

    public static void register() {
    }

    private static <T extends class_1297> class_1299<T> registerEntity(String str, class_1299.class_1300<T> type) {
        var id = class_2960.method_60655(Constants.MOD_ID, str);
        var res = class_2378.method_10230(class_7923.field_41177, id, type.method_5905(class_5321.method_29179(class_7924.field_41266, id)));
        PolymerEntityUtils.registerType(res);
        return res;
    }

    public static class_5321<class_2591<?>> key(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41255, id);
    }

    public static void registerBlockEntity(class_5321<class_2591<?>> id, class_2591<?> type) {
        class_2378.method_39197(class_7923.field_41181, id, type);
        PolymerBlockUtils.registerBlockEntity(type);
    }
}

package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class CanSurvive implements BlockBehaviour<CanSurvive.Config> {
    private final Config config;

    public CanSurvive(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public CanSurvive.Config getConfig() {
        return this.config;
    }

    public boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        var belowState = levelReader.method_8320(blockPos.method_10074());
        if (config.blocks != null && config.blocks.contains(belowState.method_26204()))
            return true;
        if (config.tags != null) {
            for (class_2960 tag : config.tags) {
                var tagKey = class_6862.method_40092(class_7924.field_41254, tag);
                if (belowState.method_26164(tagKey))
                    return true;
            }
        }
        return false;
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        return !blockState.method_26184(levelReader, blockPos) ? class_2246.field_10124.method_9564() : blockState;
    }

    public static class Config {
        public List<class_2248> blocks;
        public List<class_2960> tags;
    }
}

package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.item.BaseProjectileEntity;
import de.tomalbrc.filament.registry.EntityRegistry;
import de.tomalbrc.filament.util.Util;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3730;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

/**
 * Item behaviour for projectile shooting
 */
public class Shoot implements ItemBehaviour<Shoot.ShootConfig> {
    private final ShootConfig config;

    public Shoot(ShootConfig config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ShootConfig getConfig() {
        return this.config;
    }

    @Override
    public class_1269 use(class_1792 item, class_1937 level, class_1657 user, class_1268 hand) {
        user.method_7357().method_62835(user.method_5998(hand), 8);
        class_1799 itemStack = user.method_5998(hand);

        if (!level.field_9236) {
            BaseProjectileEntity projectile = EntityRegistry.BASE_PROJECTILE.method_5883(level, class_3730.field_16461);
            if (projectile != null) {
                projectile.method_33574(user.method_19538().method_1031(0, user.method_5751(), 0));
                Util.damageAndBreak(1, itemStack, user, class_1657.method_56079(hand));

                float pitch = user.method_36455();
                float yaw = user.method_36454();
                double speed = this.config.speed; // Adjust the speed as needed

                Vector3f deltaMovement = new Vector3f(
                        -(float) Math.sin(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch)),
                        -(float) Math.sin(Math.toRadians(pitch)),
                        (float) Math.cos(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch))
                ).mul((float) speed);

                projectile.method_36456(user.method_36454());
                projectile.method_36457(user.method_36455());
                projectile.method_18800(deltaMovement.x, deltaMovement.y, deltaMovement.z);

                var projItem = this.config.projectile != null ? class_7923.field_41178.method_10223(this.config.projectile).orElseThrow().comp_349().method_7854() : itemStack.method_46651(1);
                projectile.setProjectileStack(projItem);
                projectile.setPickupStack(projItem);
                projectile.method_7432(user);
                projectile.method_7438(this.config.baseDamage);

                if (user.method_7337()) {
                    projectile.field_7572 = class_1665.class_1666.field_7594;
                }
            }

            level.method_8649(projectile);
            level.method_43129(null, projectile, this.config.sound != null ? class_7923.field_41172.method_10223(this.config.sound).orElseThrow().comp_349() : class_3417.field_15001.comp_349(), class_3419.field_15254, 1.0F, 1.0F);
            if (!user.method_7337() && this.config.consumes) {
                itemStack.method_7934(1);
            }
        }

        user.method_7259(class_3468.field_15372.method_14956(item));

        return class_1269.field_21466;
    }

    public static class ShootConfig {
        /**
         * Indicates whether the shooting action consumes the item
         */
        public boolean consumes;

        /**
         * The base damage of the projectile.
         */
        public double baseDamage = 2.0;

        /**
         * The speed at which the projectile is fired.
         */
        public double speed = 1.0;

        /**
         * The identifier for the projectile item
         */
        public class_2960 projectile;

        /**
         * Sound effect to play when shooting
         */
        public class_2960 sound;
    }
}

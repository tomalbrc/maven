package de.tomalbrc.filament.decoration.block.entity;

import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.behaviours.decoration.*;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.holder.AnimatedHolder;
import de.tomalbrc.filament.decoration.holder.DecorationHolder;
import de.tomalbrc.filament.decoration.util.BlockEntityWithElementHolder;
import de.tomalbrc.filament.decoration.util.FunctionalDecoration;
import de.tomalbrc.filament.decoration.util.impl.ContainerImpl;
import de.tomalbrc.filament.decoration.util.impl.LockImpl;
import de.tomalbrc.filament.registry.filament.ModelRegistry;
import de.tomalbrc.filament.registry.filament.DecorationRegistry;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.BlockBoundAttachment;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1722;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_7225;
import net.minecraft.class_747;

public class DecorationBlockEntity extends AbstractDecorationBlockEntity implements BlockEntityWithElementHolder, FunctionalDecoration {
    public static final String DECORATION_KEY = "Decoration";
    public static final String ITEM_KEY = "Item";

    public static final String SHOWCASE_KEY = "Showcase";

    @Nullable
    public AnimatedHolder animatedHolder;

    @Nullable
    private DecorationHolder decorationHolder;


    public ContainerImpl containerImpl;

    LockImpl lockImpl;

    private class_2960 decorationId;

    public DecorationBlockEntity(class_2338 pos, class_2680 state) {
        super(pos, state);
    }

    @Override
    protected void method_11014(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11014(compoundTag, provider);

        this.decorationId = new class_2960(compoundTag.method_10558(DECORATION_KEY));

        if (this.isMain()) this.loadMain(compoundTag, provider);
    }

    public void loadMain(class_2487 compoundTag, class_7225.class_7874 provider) {
        DecorationData decorationData = this.getDecorationData();
        if (decorationData == null) {
            Filament.LOGGER.error("No decoration formats for " + (this.decorationId == null ? "(null)" : this.decorationId.toString()) + "!");
        } else if (this.decorationHolder == null) {
            this.makeHolder();
            this.setupBehaviour(decorationData);
        }


        if (this.containerImpl != null) {
            this.containerImpl.read(compoundTag, provider);
        }

        if (compoundTag.method_10545(SHOWCASE_KEY) && this.decorationHolder != null) {
            class_2487 showcaseTag = compoundTag.method_10562(SHOWCASE_KEY);

            for (int i = 0; i < this.decorationHolder.getShowcaseData().size(); i++) {
                Showcase showcase = this.decorationHolder.getShowcaseData().get(i);
                String key = ITEM_KEY + i;
                if (showcase != null && showcaseTag.method_10545(key)) {
                    this.decorationHolder.setShowcaseItemStack(showcase, class_1799.method_57359(provider, showcaseTag.method_10562(key)));
                }
            }
        }

        if (this.lockImpl != null) {
            this.lockImpl.read(compoundTag);
        }
    }

    @Override
    protected void method_11007(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11007(compoundTag, provider);

        if (decorationId != null) {
            compoundTag.method_10582(DECORATION_KEY, decorationId.toString());
        }

        if (this.containerImpl != null) {
            this.containerImpl.write(compoundTag, provider);
        }

        if (this.lockImpl != null) {
            this.lockImpl.write(compoundTag);
        }

        if (decorationHolder != null && decorationHolder.isShowcase()) {
            class_2487 showcaseTag = new class_2487();

            for (int i = 0; i < decorationHolder.getShowcaseData().size(); i++) {
                Showcase showcase = decorationHolder.getShowcaseData().get(i);
                if (showcase != null && !decorationHolder.getShowcaseItemStack(showcase).method_7960())
                    showcaseTag.method_10566(ITEM_KEY + i, decorationHolder.getShowcaseItemStack(showcase).method_57358(provider));
            }

            compoundTag.method_10566(SHOWCASE_KEY, showcaseTag);
        }
    }

    @Override
    public ElementHolder makeHolder() {
        if (this.field_11863 != null && this.getDecorationData() != null && this.getDecorationData().hasAnimation() && this.animatedHolder == null) {
            Model model = ModelRegistry.getModel(this.getDecorationData().behaviour().animation.model);
            if (model == null) {
                Filament.LOGGER.error("No Animated-Java model named '" + this.getDecorationData().behaviour().animation.model + "' was found!");
            } else {
                this.animatedHolder = new AnimatedHolder(this, model);
            }
        }
        else if (this.decorationHolder == null && this.animatedHolder == null) {
            this.decorationHolder = new DecorationHolder();
            this.decorationHolder.setBlockEntity(this);
            if (this.decorationHolder.getElements().get(0) instanceof ItemDisplayElement itemDisplayElement) {
                itemDisplayElement.setItem(this.itemStack);
            }
        }

        return this.animatedHolder != null ? this.animatedHolder : this.decorationHolder;
    }


    @Override
    public void attach(class_2818 chunk) {
        if (this.isMain()) {
            ElementHolder elementHolder = this.makeHolder();
            if (elementHolder.getAttachment() == null) {
                new BlockBoundAttachment(elementHolder, chunk, this.method_11010(), this.method_11016(), this.method_11016().method_46558(), this.animatedHolder != null);
            }
        }

        if (this.animatedHolder != null)
            this.animatedHolder.setRotation(this.getVisualRotationYInDegrees());
    }

    @Override
    public void attach(class_3218 level) {
        this.attach((class_2818)level.method_22350(this.method_11016()));
    }

    @Override
    public void setupBehaviour(DecorationData decorationData) {
        this.decorationId = decorationData.id();

        // When placed, decorationId is not yet set?
        if (this.isMain()) {
            assert decorationData.behaviour() != null;

            if (decorationData.isContainer()) {
                this.setContainerData(decorationData.behaviour().container);
            }

            if (decorationData.isLock()) {
                this.setLockData(decorationData.behaviour().lock);
            }

            if (this.decorationHolder == null && this.animatedHolder == null) {
                this.makeHolder();
            }

            if (decorationData.isSeat()) {
                this.setSeatData(decorationData.behaviour().seat);
            }

            if (decorationData.isShowcase()) {
                this.setShowcaseData(decorationData.behaviour().showcase);
            }

            if (decorationData.hasAnimation()) {
                this.setAnimationData(decorationData.behaviour().animation);
            }
        }
    }

    @Override
    public void setAnimationData(@NotNull Animation animationData) {
        if (animationData.model != null) {
            Model model = ModelRegistry.getModel(animationData.model);
            if (model == null) {
                Filament.LOGGER.error("No AnimatedJava model named '" + animationData.model + "' was found!");
            }
        }
    }

    @Override
    public void setSeatData(@NotNull List<Seat> seatData) {
        this.decorationHolder.setSeatData(seatData);
    }

    @Override
    public void setShowcaseData(@NotNull List<Showcase> showcaseData) {
        this.decorationHolder.setShowcaseData(showcaseData);
    }

    @Override
    public void setLockData(Lock lockData) {
        // dont recreate lock formats!
        if (this.lockImpl != null)
            return;

        this.lockImpl = new LockImpl(lockData);
    }

    @Override
    public void setContainerData(@NotNull Container containerData) {
        // dont recreate container formats!
        if (this.containerImpl != null) {
            return;
        }

        class_3917<?> menuType = ContainerImpl.getMenuType(containerData);

        // internal container formats with minecraft container
        this.containerImpl = new ContainerImpl(containerData.name, new FilamentContainer(containerData.size, containerData.purge), menuType, containerData.purge);
    }


    public class_1269 interact(class_1657 player, class_1268 interactionHand, class_243 location) {
        return this.decorationInteract((class_3222) player, interactionHand, location);
    }

    public class_1269 decorationInteract(class_3222 player, class_1268 interactionHand, class_243 location) {
        if (!this.isMain()) {
            return this.getMainBlockEntity().decorationInteract(player, interactionHand, location);
        }

        DecorationData decorationData = this.getDecorationData();
        if (decorationData == null) {
            Filament.LOGGER.warn("Can't interact with decoration: Missing decoration formats! Location: " + location.toString());
            return class_1269.field_5814;
        }

        if (this.lockImpl != null && lockImpl.interact(player, this)) {
            return class_1269.field_21466;
        }

        if (this.containerImpl != null && !player.method_21823()) {
            class_2561 containerName = class_2561.method_43470(containerImpl.name() == null ? "filament container" : containerImpl.name());
            if (this.containerImpl.container().method_5439() % 9 == 0) {
                player.method_17355(new class_747((i, playerInventory, playerEntity) -> new class_1707(containerImpl.menuType(), i, playerInventory, containerImpl.container(), containerImpl.container().method_5439() / 9), containerName));
            } else if (this.containerImpl.container().method_5439() == 5) {
                player.method_17355(new class_747((i, playerInventory, playerEntity) -> new class_1722(i, playerInventory, containerImpl.container()), containerName));
            }

            return class_1269.field_21466;
        }

        if (this.decorationHolder != null) {
            if (this.decorationHolder.isSeat() && player.method_5998(interactionHand).method_7960() && !this.decorationHolder.isShowcase()) {
                Seat seat = this.decorationHolder.getClosestSeat(location);

                if (seat != null && !this.decorationHolder.hasSeatedPlayer(seat)) {
                    this.decorationHolder.seatPlayer(seat, player);
                }

                return class_1269.field_21466;
            }

            if (this.decorationHolder.isShowcase() && !player.method_21823()) {
                Showcase showcase = this.decorationHolder.getClosestShowcase(location);
                class_1799 itemStack = player.method_5998(interactionHand);

                if (this.decorationHolder.canUseShowcaseItem(showcase, itemStack)) {
                    if (!player.method_5998(interactionHand).method_7960()) {

                        if (this.decorationHolder.getShowcaseItemStack(showcase) != null) {
                            Util.spawnAtLocation(this.field_11863, this.method_11016().method_46558(), this.decorationHolder.getShowcaseItemStack(showcase));
                        }

                        this.decorationHolder.setShowcaseItemStack(showcase, itemStack.method_46651(1));
                        itemStack.method_7934(1);
                    } else if (this.decorationHolder.getShowcaseItemStack(showcase) != null) {
                        player.method_6122(interactionHand, this.decorationHolder.getShowcaseItemStack(showcase));
                        this.decorationHolder.setShowcaseItemStack(showcase, class_1799.field_8037);
                    }

                    return class_1269.field_21466;
                }
            }
        }

        return class_1269.field_5811;
    }

    @Override
    protected void destroyBlocks() {
        class_2680 decorationBlockState = this.method_10997().method_8320(this.method_11016());
        if (DecorationRegistry.isDecoration(decorationBlockState) && this.getDecorationData() != null) {
            if (this.getDecorationData().hasBlocks()) {
                Util.forEachRotated(this.getDecorationData().blocks(), this.main, this.getVisualRotationYInDegrees(), blockPos -> {
                    if (DecorationRegistry.isDecoration(this.method_10997().method_8320(blockPos))) {
                        this.method_10997().method_22352(blockPos, false);
                        this.method_10997().method_8544(blockPos);
                    }
                });
            } else {
                this.method_10997().method_22352(this.method_11016(), true);
            }
        }
    }

    @Override
    public void destroyStructure(boolean dropItem) {
        if (!this.isMain()) {
            if (this.main != null && this.method_10997().method_8321(this.main) instanceof DecorationBlockEntity mainBlockEntity) {
                mainBlockEntity.destroyStructure(dropItem);
            }
            return;
        }

        if (dropItem) {
            Util.spawnAtLocation(this.method_10997(), this.method_11016().method_46558(), this.getItem());
        }

        if (this.containerImpl != null) {
            this.containerImpl.container().setValid(false);
            for (class_1799 itemStack : this.containerImpl.container().field_5828) {
                if (itemStack.method_7960()) continue;

                Util.spawnAtLocation(this.method_10997(), this.method_11016().method_46558(), itemStack);
            }
        }

        if (this.decorationHolder != null && this.decorationHolder.isShowcase()) {
            this.decorationHolder.getShowcaseData().forEach(showcase -> {
                class_1799 itemStack = this.decorationHolder.getShowcaseItemStack(showcase);
                if (itemStack != null && !itemStack.method_7960()) {
                    Util.spawnAtLocation(this.method_10997(), this.method_11016().method_46558(), this.decorationHolder.getShowcaseItemStack(showcase));
                }
            });
        }

        this.removeHolder(this.decorationHolder);
        this.removeHolder(this.animatedHolder);

        this.destroyBlocks();
    }

    private void removeHolder(ElementHolder holder) {
        if (holder != null && holder.getAttachment() != null)
            holder.getAttachment().destroy();
    }

    @Override
    protected void setCollisionStructure(boolean collisionStructure) {
        if (this.getDecorationData() != null && this.getDecorationData().blocks() != null) {
            Util.forEachRotated(this.getDecorationData().blocks(), this.method_11016(), this.getVisualRotationYInDegrees(), blockPos -> {
                class_2680 blockState = this.method_10997().method_8320(blockPos);

                if (DecorationRegistry.isDecoration(blockState)) {
                    blockState.method_11657(DecorationBlock.PASSTHROUGH, !collisionStructure);
                }
            });
        }
    }

    public DecorationData getDecorationData() {
        return DecorationRegistry.getDecorationDefinition(decorationId);
    }
}

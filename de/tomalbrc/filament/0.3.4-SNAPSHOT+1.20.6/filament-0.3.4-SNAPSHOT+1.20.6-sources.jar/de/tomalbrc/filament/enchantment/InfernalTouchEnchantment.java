package de.tomalbrc.filament.enchantment;

import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import java.util.Optional;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_3489;
import net.minecraft.class_7699;

public class InfernalTouchEnchantment extends class_1887 implements PolymerEnchantment {
    public InfernalTouchEnchantment() {
        super(new class_9427(class_3489.field_48307, Optional.empty(), 2, 1, class_1887.method_58441(0, 40), class_1887.method_58441(20, 40), 3, class_7699.method_45397(), new class_1304[]{class_1304.field_6173}));
    }

    @Override
    protected boolean method_8180(class_1887 enchantment) {
        return super.method_8180(enchantment) && enchantment != class_1893.field_9099;
    }

    @Override
    public boolean method_8192(class_1799 itemStack) {
        return super.method_8192(itemStack) && itemStack.method_7909() instanceof class_1810;
    }
}

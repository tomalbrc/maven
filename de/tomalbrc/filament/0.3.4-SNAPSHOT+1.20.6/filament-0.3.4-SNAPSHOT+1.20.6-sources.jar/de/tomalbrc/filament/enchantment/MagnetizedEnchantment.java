package de.tomalbrc.filament.enchantment;

import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import java.util.Optional;
import net.minecraft.class_1304;
import net.minecraft.class_1887;
import net.minecraft.class_3222;
import net.minecraft.class_3489;
import net.minecraft.class_7699;

/*
        COMMON(10),
        UNCOMMON(5),
        RARE(2),
        VERY_RARE(1);
 */

public class MagnetizedEnchantment extends class_1887 implements PolymerEnchantment {
    public MagnetizedEnchantment() {
        super(new class_9427(class_3489.field_48307, Optional.empty(), 5, 1, class_1887.method_58441(5, 19), class_1887.method_58441(56, 19), 3, class_7699.method_45397(), new class_1304[]{class_1304.field_6173}));
    }

    @Override
    protected boolean method_8180(class_1887 enchantment) {
        return super.method_8180(enchantment);
    }

    @Override
    public class_1887 getPolymerReplacement(class_3222 player) {
        return null;
    }
}

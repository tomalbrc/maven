package de.tomalbrc.filament.enchantment;

import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1887;
import net.minecraft.class_3222;
import net.minecraft.class_3489;
import net.minecraft.class_7699;

public class LuminousBladeEnchantment extends class_1887 implements PolymerEnchantment {
    public LuminousBladeEnchantment() {
        super(new class_9427(class_3489.field_48305, Optional.empty(), 5, 5, class_1887.method_58441(4, 12), class_1887.method_58441(4, 12), 3, class_7699.method_45397(), new class_1304[]{class_1304.field_6173}));
    }

    @Override
    public void method_8189(class_1309 user, class_1297 target, int level) {
        if (target instanceof class_1309 livingEntity) {
            livingEntity.method_6092(new class_1293(class_1294.field_5912, 20 * 5 * level, 0));
        }

        super.method_8189(user, target, level);
    }

    @Override
    public class_1887 getPolymerReplacement(class_3222 player) {
        return null;
    }
}
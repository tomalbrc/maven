package de.tomalbrc.filament.enchantment;

import de.tomalbrc.filament.registry.filament.EnchantmentRegistry;
import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_3222;
import net.minecraft.class_3489;
import net.minecraft.class_7699;

public class WintersGraspEnchantment extends class_1887 implements PolymerEnchantment {
    public WintersGraspEnchantment() {
        super(new class_9427(class_3489.field_48305, Optional.empty(), 2, 3, class_1887.method_58441(8, 20), class_1887.method_58441(58, 20), 3, class_7699.method_45397(), new class_1304[]{class_1304.field_6173}));
    }

    @Override
    protected boolean method_8180(class_1887 enchantment) {
        return super.method_8180(enchantment) && enchantment != class_1893.field_9124 && enchantment != EnchantmentRegistry.BLACKENED_EDGE && enchantment != EnchantmentRegistry.LETHARGY;
    }

    @Override
    public void method_8189(class_1309 user, class_1297 target, int level) {
        if (target instanceof class_1309 livingEntity) {
            livingEntity.method_6092(new class_1293(class_1294.field_5909, 20 * 2 * level, level - 1));
            livingEntity.method_32317(220 * level);
        }

        super.method_8189(user, target, level);
    }

    @Override
    public class_1887 getPolymerReplacement(class_3222 player) {
        return null;
    }
}
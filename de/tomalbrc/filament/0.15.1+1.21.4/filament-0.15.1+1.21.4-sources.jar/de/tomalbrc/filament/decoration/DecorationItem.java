package de.tomalbrc.filament.decoration;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.block.SimpleBlockItem;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.util.DecorationUtil;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_7923;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

public class DecorationItem extends SimpleBlockItem implements PolymerItem, BehaviourHolder {
    final private DecorationData decorationData;

    public DecorationItem(class_2248 block, DecorationData decorationData, class_1792.class_1793 properties) {
        super(properties, block, decorationData);
        this.initBehaviours(decorationData.behaviour());
        this.decorationData = decorationData;
    }

    public DecorationData getDecorationData() {
        return this.decorationData;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        if (this.decorationData.vanillaItem().method_57347().method_57832(class_9334.field_49644) || this.decorationData.components().method_57832(class_9334.field_49644)) {
            list.add(class_2561.method_43470("§9Dyeable"));
        }

        if (itemStack.method_57826(class_9334.field_49622)) {
            Iterator<class_1799> itemStackIterator = itemStack.method_57825(class_9334.field_49622, class_9288.field_49334).method_59714().iterator();
            int i = 0;
            int j = 0;
            while(itemStackIterator.hasNext()) {
                class_1799 itemStack2 = itemStackIterator.next();
                j++;
                if (i <= 4) {
                    i++;
                    list.add(class_2561.method_43469("container.shulkerBox.itemCount", itemStack2.method_7964(), itemStack2.method_7947()));
                }
            }
            if (j - i > 0) {
                list.add(class_2561.method_43469("container.shulkerBox.more", j - i).method_27692(class_124.field_1056));
            }
        }

        super.method_7851(itemStack, tooltipContext, list, tooltipFlag);
    }

    public static float getVisualRotationYInDegrees(class_2350 direction, int rotation) {
        int i = direction.method_10166().method_10178() ? 90 * direction.method_10171().method_10181() : 0;
        return (float) class_3532.method_15392(180 + direction.method_10161() * 90 + rotation * 45 + i);
    }

    @Override
    @NotNull
    public class_1269 method_7884(class_1838 useOnContext) {
        var res = super.method_7884(useOnContext);
        if (res.method_23665())
            return res;

        if (decorationData == null) {
            Filament.LOGGER.warn("Can't use decoration Item: Missing decoration data!");
            return class_1269.field_5814;
        }

        var replaceable = useOnContext.method_8045().method_8320(useOnContext.method_8037()).method_45474();

        class_2338 blockPos = useOnContext.method_8037();
        class_2350 direction = replaceable ? class_2350.field_11036 : useOnContext.method_8038();
        class_2338 relativeBlockPos = replaceable ? blockPos : blockPos.method_10093(direction);
        class_1657 player = useOnContext.method_8036();
        class_1799 itemStack = useOnContext.method_8041();
        class_1937 level = useOnContext.method_8045();

        int rotation = 0;
        if (decorationData.properties().rotate) {
            if (decorationData.properties().rotateSmooth) {
                rotation = Util.SEGMENTED_ANGLE8.method_48125(useOnContext.method_8044()-180);
            } else {
                rotation = Util.SEGMENTED_ANGLE8.method_48124(useOnContext.method_8042().method_10153());
            }
        }

        boolean propertyPlaceCheck = decorationData.properties().placement.canPlace(direction);
        if (!propertyPlaceCheck && decorationData.properties().placement.floor() && !level.method_8320(relativeBlockPos.method_10093(class_2350.field_11033)).method_26215()) {
            direction = class_2350.field_11036;
            propertyPlaceCheck = decorationData.properties().placement.canPlace(direction);
        }

        if (!propertyPlaceCheck && decorationData.properties().placement.ceiling() && !level.method_8320(relativeBlockPos.method_10093(class_2350.field_11036)).method_26215()) {
            direction = class_2350.field_11033;
            propertyPlaceCheck = decorationData.properties().placement.canPlace(direction);
        }

        float angle = DecorationItem.getVisualRotationYInDegrees(direction, rotation);

        if (player == null || !this.mayPlace(player, direction, itemStack, relativeBlockPos) || !propertyPlaceCheck) {
            return class_1269.field_5814;
        } else if (this.canPlaceAt(level, relativeBlockPos, angle) && itemStack.method_7909() instanceof DecorationItem) {
            DecorationItem.place(itemStack, level, relativeBlockPos, direction, rotation);

            player.method_6019(useOnContext.method_20287());
            itemStack.method_7934(1);

            class_3414 placeSound = this.getDecorationData().properties().blockBase.method_9564().method_26231().method_10598();
            level.method_8396(null, blockPos,  placeSound, class_3419.field_15245, 1.0F, 1.0F);

            return class_1269.field_52422;
        }

        return class_1269.field_5814;
    }

    protected boolean mayPlace(class_1657 player, class_2350 direction, class_1799 itemStack, class_2338 blockPos) {
        return !player.method_37908().method_31606(blockPos) && player.method_7343(blockPos, direction, itemStack);
    }

    /**
     * Check if multi-block structure can be placed
     */
    private boolean canPlaceAt(class_1937 level, class_2338 blockPos, float angle) {
        if (!level.method_8320(blockPos).method_45474()) {
            return false;
        }

        if (decorationData.hasBlocks()) {
            boolean[] canPlace = new boolean[]{true};
            DecorationUtil.forEachRotated(decorationData.blocks(), blockPos, angle, blockPos2 -> {
                if (!level.method_8320(blockPos2).method_45474()) {
                    canPlace[0] = false;
                }
            });
            return canPlace[0];
        }

        return true;
    }

    public static void place(class_1799 itemStack, class_1937 level, class_2338 blockPos, class_2350 direction, int rotation) {
        float angle = DecorationItem.getVisualRotationYInDegrees(direction, rotation);

        if (!(itemStack.method_7909() instanceof  DecorationItem)) {
            Filament.LOGGER.error("Tried to place non-decoration item as decoration! Item: {}", class_7923.field_41178.method_10221(itemStack.method_7909()));
        }

        DecorationData decorationData = ((DecorationItem)itemStack.method_7909()).decorationData;
        if (decorationData.hasBlocks() && decorationData.countBlocks() == 0)
            Filament.LOGGER.warn("Found block data with potentially invalid blocks for {} while trying tof", decorationData.id());

        if (decorationData.hasBlocks()) {
            DecorationUtil.forEachRotated(decorationData.blocks(), blockPos, angle, blockPos2 -> {
                level.method_22352(blockPos2, false);

                class_2680 blockState = DecorationRegistry.getDecorationBlock(decorationData.id()).method_9564();

                if (decorationData.properties().mayBeLightSource()) {
                    blockState = blockState.method_11657(DecorationBlock.LIGHT_LEVEL, decorationData.properties().lightEmission.getValue(blockState));
                }

                if (!decorationData.properties().waterloggable)
                    blockState = blockState.method_11657(DecorationBlock.WATERLOGGED, false);

                if (decorationData.isSimple()) {
                    blockState = blockState.method_11657(SimpleDecorationBlock.ROTATION, (rotation + 4) % 8);
                }

                level.method_8501(blockPos2, blockState);

                if (!decorationData.isSimple() && level.method_8321(blockPos2) instanceof DecorationBlockEntity decorationBlockEntity) {
                    decorationBlockEntity.setMain(new class_2338(blockPos2).method_10059(blockPos));
                    decorationBlockEntity.setItem(itemStack.method_46651(1));
                    decorationBlockEntity.setRotation(rotation);
                    decorationBlockEntity.setDirection(direction);
                    decorationBlockEntity.setupBehaviour(decorationData);
                    decorationBlockEntity.attach((class_3218) level);
                }
            });
        } else {
            class_2680 blockState = DecorationRegistry.getDecorationBlock(decorationData.id()).method_9564();

            if (!decorationData.properties().waterloggable) {
                blockState = blockState.method_11657(DecorationBlock.WATERLOGGED, false);
            }

            if (decorationData.properties().mayBeLightSource()) {
                blockState = blockState.method_11657(DecorationBlock.LIGHT_LEVEL, decorationData.properties().lightEmission.getValue(blockState));
            }

            if (decorationData.isSimple()) {
                blockState = blockState.method_11657(SimpleDecorationBlock.ROTATION, (rotation + 4) % 8);
            }

            level.method_8501(blockPos, blockState);
            if (!decorationData.isSimple() && level.method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                decorationBlockEntity.setMain(class_2338.field_10980);
                decorationBlockEntity.setItem(itemStack.method_46651(1));
                decorationBlockEntity.setRotation(rotation);
                decorationBlockEntity.setDirection(direction);
                decorationBlockEntity.setupBehaviour(decorationData);
                decorationBlockEntity.attach((class_3218) level);
            }
        }
    }
}

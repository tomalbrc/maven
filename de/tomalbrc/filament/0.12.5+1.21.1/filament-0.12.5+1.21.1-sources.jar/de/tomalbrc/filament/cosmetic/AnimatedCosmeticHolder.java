package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.bil.core.holder.entity.EntityHolder;
import de.tomalbrc.bil.core.holder.wrapper.DisplayWrapper;
import de.tomalbrc.bil.core.model.Model;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

public class AnimatedCosmeticHolder extends EntityHolder {
    private final class_1309 entity;

    private final Consumer<class_3244> startWatchingCallback;

    public AnimatedCosmeticHolder(class_1309 entity, Model model, Consumer<class_3244> startWatchingCallback) {
        super(entity, model);
        this.startWatchingCallback = startWatchingCallback;
        this.entity = entity;
    }

    @Override
    public int getVehicleId() {
        return -1;
    }

    @Override
    public boolean addAdditionalDisplay(DisplayElement element) {
        if (this.additionalDisplays.add(element)) {
            this.addElement(element);
            return true;
        } else {
            return false;
        }
    }

    private CosmeticInterface access() {
        return (CosmeticInterface) this.entity;
    }

    @Override
    protected void updateElement(DisplayWrapper<?> display) {
        display.element().ignorePositionUpdates();
        display.element().setYaw(access().filament$bodyYaw());
        super.updateElement(display);
    }

    @Override
    public class_2168 createCommandSourceStack() {
        return this.entity.method_5671().method_9230(4);
    }

    @Override
    public boolean startWatching(class_3244 player) {
        var ret = super.startWatching(player);

        this.startWatchingCallback.accept(player);

        return ret;
    }

    public class_243 getPos() {
        return this.entity instanceof class_3222 ? this.entity.method_19538() : this.entity.method_33571();
    }
}

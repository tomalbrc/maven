package de.tomalbrc.filament.data;

import com.google.gson.annotations.SerializedName;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.data.properties.ItemProperties;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.util.RPUtil;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_9323;

@SuppressWarnings("unused")
public record ItemData(
        @NotNull class_2960 id,
        @Nullable class_1792 vanillaItem,
        @Nullable Map<String, String> translations,
        @Nullable ItemResource itemResource,
        @SerializedName("behaviour")
        @Nullable BehaviourConfigMap behaviourConfig,
        @Nullable ItemProperties properties,
        @Nullable class_9323 components,
        @SerializedName("group")
        @Nullable class_2960 itemGroup
) {
    @Override
    @NotNull
    public ItemProperties properties() {
        if (properties == null) {
            return ItemProperties.EMPTY;
        }
        return properties;
    }

    @Override
    @NotNull
    public class_9323 components() {
        if (components == null) {
            return class_9323.field_49584;
        }
        return components;
    }

    @Override
    @NotNull
    public class_1792 vanillaItem() {
        if (vanillaItem == null) {
            return class_1802.field_8407;
        }
        return vanillaItem;
    }

    public Object2ObjectOpenHashMap<String, PolymerModelData> requestModels(BehaviourMap behaviourMap) {
        if (itemResource != null && itemResource.couldGenerate()) {
            RPUtil.createItemModels(id(), Objects.requireNonNull(itemResource));
        }

        Object2ObjectOpenHashMap<String, PolymerModelData> map = new Object2ObjectOpenHashMap<>();
        if (itemResource != null) {
            if (itemResource.models().size() > 1 && RPUtil.useGeneratedModel(behaviourMap)) {
                map.put("default", PolymerResourcePackUtils.requestModel(this.vanillaItem == null ? class_1802.field_8407 : this.vanillaItem, id().method_45138("item/")));
            } else {
                itemResource.models().forEach((key, value) -> map.put(key, PolymerResourcePackUtils.requestModel(this.vanillaItem == null ? class_1802.field_8407 : this.vanillaItem, value)));
            }
        }
        return map.isEmpty() ? null : map;
    }
}

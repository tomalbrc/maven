package de.tomalbrc.filament.mixin.behaviour.fire;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.Fire;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2358;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2358.class)
public abstract class FireBlockMixin {
    @Invoker
    protected static int invokeGetFireTickDelay(class_5819 randomSource) {
        throw new AssertionError();
    }

    @Inject(method = "onPlace", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;scheduleTick(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;I)V"), cancellable = true)
    private void filament$onFirePlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl, CallbackInfo ci) {
        Fire f = null;
        if (blockState.method_26204() instanceof SimpleBlock simpleBlock && (f = simpleBlock.get(Behaviours.FIRE)) != null && f.getConfig().tick) {
            level.method_64310(blockPos, simpleBlock, invokeGetFireTickDelay(level.field_9229));
            ci.cancel();
        }
    }

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;scheduleTick(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;I)V"))
    private void filament$onTick(class_2680 blockState, class_3218 level, class_2338 blockPos, class_5819 randomSource, CallbackInfo ci) {
        Fire f = null;
        if (blockState.method_26204() instanceof SimpleBlock simpleBlock && (f = simpleBlock.get(Behaviours.FIRE)) != null && f.getConfig().tick) {
            level.method_64310(blockPos, simpleBlock, invokeGetFireTickDelay(level.field_9229));
        }
    }
}

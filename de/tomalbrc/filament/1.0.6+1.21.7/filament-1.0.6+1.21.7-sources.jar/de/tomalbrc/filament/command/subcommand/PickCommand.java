package de.tomalbrc.filament.command.subcommand;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import de.tomalbrc.bil.util.Permissions;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class PickCommand {
    public static LiteralCommandNode<class_2168> register() {
        return class_2170
                .method_9247("pick").requires(Permissions.require("filament.command.pick", 3))
                .executes(PickCommand::execute)
                .build();
    }

    private static int execute(CommandContext<class_2168> context) {
        if (context.getSource() != null && context.getSource().method_44023() != null) {
            class_3222 player = context.getSource().method_44023();

            for (int i = 1; i <= 8; i++) {
                class_243 pos = player.method_33571().method_1019(player.method_5828(1).method_1029().method_1021(i*0.5f));
                class_2338 blockPos = class_2338.method_49638(pos);

                class_2680 state = player.method_51469().method_8320(blockPos);
                if (state.method_26204() instanceof DecorationBlock) {
                    if (player.method_51469().method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                        class_1799 item = decorationBlockEntity.getItem().method_7972();

                        if (player.method_68878()) {
                            player.method_6122(class_1268.field_5808, item);
                        } else {
                            int slot = player.method_31548().method_7395(item);
                            if (slot != -1) {
                                player.method_31548().method_7365(slot);
                            }
                        }

                        // eh, may actually not be successful, but it's not like this return value changes anything..?
                        return Command.SINGLE_SUCCESS;
                    }
                } else if (!state.method_26215() && !state.method_51176()) {
                    player.method_6122(class_1268.field_5808, state.method_26204().method_8389().method_7854());
                    return Command.SINGLE_SUCCESS;
                }
            }
        }
        return 0;
    }
}

package de.tomalbrc.filament.mixin.behaviour.container;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2614;
import net.minecraft.class_2680;

@Mixin(class_2614.class)
public class HopperBlockEntityMixin {
    @Inject(method = "getBlockContainer", at = @At(value = "HEAD"), cancellable = true)
    private static void filament$customContainerSupport(class_1937 level, class_2338 blockPos, class_2680 blockState, CallbackInfoReturnable<class_1263> cir) {
        if (blockState.method_26204() instanceof ComplexDecorationBlock complexDecorationBlock && complexDecorationBlock.has(Behaviours.CONTAINER) && Objects.requireNonNull(complexDecorationBlock.get(Behaviours.CONTAINER)).getConfig().hopperDropperSupport) {
            DecorationBlockEntity blockEntity = (DecorationBlockEntity) level.method_8321(blockPos);
            assert blockEntity != null;
            cir.setReturnValue(Objects.requireNonNull(blockEntity.getMainBlockEntity().get(Behaviours.CONTAINER)).container);
        }
    }
}

package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3866;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.entity.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class Furnace implements BlockBehaviourWithEntity<Furnace.Config> {
    private final Config config;

    public Furnace(Config config) {
        this.config = config;
    }

    @Override
    public @Nullable class_2586 newBlockEntity(class_2338 blockPos, class_2680 blockState) {
        return new class_3866(blockPos, blockState);
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(class_2741.field_12548, false);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12548);
    }

    @Override
    @Nullable
    public <A extends class_2586> class_5558<A> getTicker(class_1937 level, class_2680 blockState1, class_2591<A> blockEntityType) {
        class_5558<A> ticker;
        if (level instanceof class_3218 serverLevel) {
            ticker = BlockBehaviourWithEntity.createTickerHelper(blockEntityType, class_2591.field_11903, (levelx, blockPos, blockState, abstractFurnaceBlockEntity) -> class_2609.method_31651(serverLevel, blockPos, blockState, abstractFurnaceBlockEntity));
        } else {
            ticker = null;
        }
        return ticker;
    }

    @Override
    public class_2591<?> blockEntityType() {
        return class_2591.field_11903;
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (!level.method_8608()) {
            class_2586 blockEntity = level.method_8321(blockPos);
            if (blockEntity instanceof class_3866) {
                player.method_17355((class_3908)blockEntity);
                player.method_7281(class_3468.field_15379);
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public void affectNeighborsAfterRemoval(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, boolean movedByPiston) {
        class_1264.method_66221(blockState, serverLevel, blockPos);
    }

    @Override
    public Optional<Boolean> hasAnalogOutputSignal(class_2680 blockState) {
        return Optional.of(true);
    }

    @Override
    public int getAnalogOutputSignal(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return class_1703.method_7608(level.method_8321(blockPos));
    }

    @Override
    @NotNull
    public Furnace.Config getConfig() {
        return this.config;
    }
    public static class Config {

    }
}
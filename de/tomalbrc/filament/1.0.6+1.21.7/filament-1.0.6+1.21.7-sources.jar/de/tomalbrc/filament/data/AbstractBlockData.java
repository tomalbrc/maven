package de.tomalbrc.filament.data;

import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_9323;

@SuppressWarnings("unused")
public abstract class AbstractBlockData<BlockPropertyLike extends BlockProperties> extends Data<BlockPropertyLike> {
    private final @Nullable Set<class_2960> blockTags;

    public AbstractBlockData(
            @NotNull class_2960 id,
            @Nullable class_1792 vanillaItem,
            @Nullable Map<String, String> translations,
            @Nullable class_2561 displayName,
            @Nullable ItemResource itemResource,
            @Nullable class_2960 itemModel,
            @Nullable BehaviourConfigMap behaviourConfig,
            @Nullable class_9323 components,
            @Nullable class_2960 itemGroup,
            @Nullable BlockPropertyLike properties,
            @Nullable Set<class_2960> itemTags,
            @Nullable Set<class_2960> blockTags
    ) {
        super(id, vanillaItem, translations, displayName, itemResource, itemModel, properties, behaviourConfig, components, itemGroup, itemTags);
        this.blockTags = blockTags;
    }

    public boolean requiresEntityBlock() {
        return behaviour().test((behaviourType)-> BlockBehaviourWithEntity.class.isAssignableFrom(behaviourType.type()));
    }

    @Override
    public abstract @NotNull BlockPropertyLike properties();

    // TODO: those should be part of BlockData, but needs abstract SimpleBlock first
    public abstract boolean virtual();

    public abstract Map<class_2680, BlockData.BlockStateMeta> createStandardStateMap();

    public abstract BlockResource blockResource();

    public @Nullable Set<class_2960> blockTags() {
        return this.blockTags;
    }

    @Override
    public String toString() {
        return "AbstractBlockData[" +
                "id=" + id + ", " +
                "vanillaItem=" + vanillaItem + ", " +
                "itemResource=" + itemResource + ", " +
                "properties=" + properties + ", " +
                "behaviourConfig=" + behaviour + ", " +
                "components=" + components + ", " +
                "itemGroup=" + group + ']';
    }
}

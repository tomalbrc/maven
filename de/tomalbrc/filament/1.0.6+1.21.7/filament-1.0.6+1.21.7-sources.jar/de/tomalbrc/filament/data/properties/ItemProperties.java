package de.tomalbrc.filament.data.properties;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_2561;

// For shared properties that make sense for items, blocks *and* decorations
public class ItemProperties {
    public int durability = Integer.MIN_VALUE;
    public int stackSize = 64;
    public List<class_2561> lore;
    public boolean fireResistant;
    public boolean copyComponents;

    public void appendHoverText(Consumer<class_2561> tooltip) {
        if (this.lore != null)
            this.lore.forEach(tooltip);
    }

    public class_1792.class_1793 toItemProperties() {
        class_1792.class_1793 props = new class_1792.class_1793();
        props.method_7889(stackSize);

        if (durability != Integer.MIN_VALUE)
            props.method_7895(durability);

        if (fireResistant)
            props.method_24359();

        return props;
    }
}

package de.tomalbrc.filament.util;

import eu.pb4.placeholders.api.ParserContext;
import eu.pb4.placeholders.api.parsers.TagParser;
import net.minecraft.class_2561;

public class TextUtil {
    public static class_2561 formatText(String text) {
        return TagParser.SIMPLIFIED_TEXT_FORMAT.parseText(text, ParserContext.of());
    }
}

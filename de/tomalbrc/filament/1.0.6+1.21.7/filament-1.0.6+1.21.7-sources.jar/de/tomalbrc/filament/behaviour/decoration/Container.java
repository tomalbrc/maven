package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.Util;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1707;
import net.minecraft.class_1722;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

/**
 * Decoration containers, such as chests, or just drawers etc.
 */
public class Container implements DecorationBehaviour<Container.Config> {
    public final FilamentContainer container;

    private final Config config;

    public Container(Config config) {
        this.config = config;
        this.container = new FilamentContainer(config.size, config.purge);
    }

    @Override
    @NotNull
    public Container.Config getConfig() {
        return config;
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        if (this.config.canPickup)
            Objects.requireNonNull(blockEntity.getItem().method_58694(class_9334.field_49622)).method_57492(container.field_5828);
    }

    @Override
    public void write(class_11372 output, DecorationBlockEntity decorationBlockEntity) {
        class_1262.method_5426(output.method_71461("Container"), this.container.field_5828);
    }

    @Override
    public void read(class_11368 input, DecorationBlockEntity decorationBlockEntity) {
        input.method_71420("Container").ifPresent(x -> class_1262.method_5429(input, container.field_5828));
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (!player.method_21823()) {
            class_2561 containerName = class_2561.method_43470(config.name == null ? "filament container" : config.name);
            if (this.container.method_5439() % 9 == 0) {
                player.method_17355(new class_747((i, playerInventory, playerEntity) -> new class_1707(getMenuType(), i, playerInventory, container, container.method_5439() / 9), containerName));
            } else if (this.container.method_5439() == 5) {
                player.method_17355(new class_747((i, playerInventory, playerEntity) -> new class_1722(i, playerInventory, container), containerName));
            }

            decorationBlockEntity.method_5431();

            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        container.setValid(false);
        if (!config.canPickup) {
            for (class_1799 itemStack : container.field_5828) {
                if (itemStack.method_7960()) continue;
                Util.spawnAtLocation(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016().method_46558(), itemStack);
            }
        }
    }

    @Override
    public void modifyDrop(DecorationBlockEntity blockEntity, class_1799 itemStack) {
        if (config.canPickup) {
            itemStack.method_57379(class_9334.field_49622, class_9288.method_57493(container.method_54454()));
        }
    }

    public class_3917<?> getMenuType() {
        return switch (config.size) {
            case 9 -> class_3917.field_18664;
            case 2 * 9 -> class_3917.field_18665;
            case 3 * 9 -> class_3917.field_17326;
            case 4 * 9 -> class_3917.field_18666;
            case 5 * 9 -> class_3917.field_18667;
            case 6 * 9 -> class_3917.field_17327;
            case 5 -> class_3917.field_17337;
            default ->
                    throw new IllegalStateException("Unexpected container size: " + config.name + " " + config.size);
        };
    }

    public static class Config {
        /**
         * The name displayed in the container UI
         */
        public String name;

        /**
         * The size of the container, has to be 5 slots or a multiple of 9, up to 6 rows of 9 slots.
         */
        public int size = 9;

        /**
         * Indicates whether the container's contents should be cleared when no player is viewing the inventory.
         */
        public boolean purge = false;

        /**
         * The name of the animation to play when the container is opened (if applicable).
         */
        public String openAnimation = null;

        /**
         * The name of the animation to play when the container is closed (if applicable).
         */
        public String closeAnimation = null;

        /**
         * Flag to indicate whether the container can be picked up like shulker boxes.
         */
        public boolean canPickup = false;

        /**
         * Support hopper and dropper block support
         */
        public boolean hopperDropperSupport = true;
    }
}

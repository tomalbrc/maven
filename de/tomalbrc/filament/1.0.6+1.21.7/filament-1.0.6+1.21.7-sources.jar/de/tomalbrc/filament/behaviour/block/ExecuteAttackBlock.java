package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_7923;

public class ExecuteAttackBlock implements BlockBehaviour<ExecuteAttackBlock.Config> {
    private final Config config;

    public ExecuteAttackBlock(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ExecuteAttackBlock.Config getConfig() {
        return config;
    }

    @Override
    public void attack(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player) {
        if (player instanceof class_3222 serverPlayer) runCommandBlock(serverPlayer, blockPos);
    }

    public void runCommandBlock(class_3222 user, class_2338 blockPos) {
        var cmds = commands();
        if (cmds != null && user.method_5682() != null) {
            for (String cmd : cmds) {
                var css = user.method_64396().method_36321(user.method_5682()).method_9230(4);
                if (config.atBlock)
                    css = css.method_9208(blockPos.method_46558());

                user.method_5682().method_3734().method_44252(css, cmd);
            }

            if (this.config.sound != null) {
                var sound = this.config.sound;
                user.method_51469().method_43129(null, user, class_7923.field_41172.method_63535(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                user.method_51469().method_8651(blockPos, config.dropBlock, user);
            }
        }
    }

    private List<String> commands() {
        return config.commands == null ? this.config.command == null ? null : List.of(this.config.command) : config.commands;
    }

    public static class Config {
        public boolean consumes;

        public String command;
        public List<String> commands;

        public boolean atBlock = false;

        public boolean dropBlock = false;

        public class_2960 sound;
    }
}

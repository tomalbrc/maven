package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_9362;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_9362.class)
public interface MaceItemAccessor {
    @Invoker
    static void invokeKnockback(class_1937 level, class_1297 entity, class_1297 entity2) {
        throw new AssertionError();
    }
}

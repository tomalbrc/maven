package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1541;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1541.class)
public interface PrimedTntAccessor {
    @Accessor
    void setExplosionPower(float p);
}

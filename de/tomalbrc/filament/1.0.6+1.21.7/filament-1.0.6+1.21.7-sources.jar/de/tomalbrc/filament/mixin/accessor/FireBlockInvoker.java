package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_10225;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2358;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2358.class)
public interface FireBlockInvoker {
    @Invoker
    class_2680 invokeUpdateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource);

    @Invoker
    class_2680 invokeGetStateForPlacement(class_1922 blockGetter, class_2338 blockPos);

    @Invoker
    boolean invokeCanSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos);

    @Invoker
    void invokeTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource);

    @Invoker
    void invokeOnPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl);

    @Invoker
    void invokeCreateBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder);
}

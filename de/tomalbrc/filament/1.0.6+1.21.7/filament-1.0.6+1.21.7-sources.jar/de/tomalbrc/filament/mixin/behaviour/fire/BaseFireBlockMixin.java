package de.tomalbrc.filament.mixin.behaviour.fire;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.block.Fire;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4770;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4770.class)
public abstract class BaseFireBlockMixin {
    @Inject(method = "getState", at = @At(value = "RETURN"), cancellable = true)
    private static void filament$getState(class_1922 blockGetter, class_2338 blockPos, CallbackInfoReturnable<class_2680> cir, @Local class_2680 blockState) {
        class_2248 block = Fire.getMaterialFire(blockState);
        if (block != null) {
            cir.setReturnValue(block.method_9564());
        }
    }
}

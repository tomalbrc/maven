package de.tomalbrc.filament.registry;

import com.google.gson.reflect.TypeToken;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.ItemGroupData;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.FilamentSynchronousResourceReloadListener;
import de.tomalbrc.filament.util.Json;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_7923;

public class ItemGroupRegistry {
    public static final Object2ObjectLinkedOpenHashMap<class_2960, List<class_1792>> TAB_GROUP_ITEMS = new Object2ObjectLinkedOpenHashMap<>();
    public static final Object2ObjectLinkedOpenHashMap<class_2960, class_1761> TAB_GROUPS = new Object2ObjectLinkedOpenHashMap<>();

    public static void register(InputStream inputStream) throws IOException {
        List<ItemGroupData> data = Json.GSON.fromJson(new InputStreamReader(inputStream), TypeToken.getParameterized(List.class, ItemGroupData.class).getType());
        for (ItemGroupData datum : data) {
            register(datum);
        }
    }

    static public void register(ItemGroupData data) {
        if (TAB_GROUPS.containsKey(data.id())) return;

        class_1761 group = new class_1761.class_7913(null, -1)
                .method_47321(data.literal() == null ? class_2561.method_43471(data.id().method_12836()+".itemGroup."+data.id().method_12832()) : data.literal())
                .method_47320(() -> class_7923.field_41178.method_63535(data.item()).method_7854())
                .method_47317((parameters, output) -> TAB_GROUP_ITEMS.get(data.id()).forEach(output::method_45421))
                .method_47324();

        TAB_GROUPS.put(data.id(), group);
        TAB_GROUP_ITEMS.putIfAbsent(data.id(), new ObjectArrayList<>());

        if (!PolymerItemGroupUtils.contains(data.id()) && !TAB_GROUP_ITEMS.get(data.id()).isEmpty()) {
            PolymerItemGroupUtils.registerPolymerItemGroup(data.id(), group);
        }
    }

    public static void addItem(class_2960 identifier, class_1792 item) {
        TAB_GROUP_ITEMS.putIfAbsent(identifier, new ObjectArrayList<>());
        TAB_GROUP_ITEMS.get(identifier).add(item);

        if (!PolymerItemGroupUtils.contains(identifier) && TAB_GROUPS.containsKey(identifier)) {
            PolymerItemGroupUtils.registerPolymerItemGroup(identifier, TAB_GROUPS.get(identifier));
        }
    }

    public static class ItemGroupDataReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "item_groups");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            load(Constants.MOD_ID, "item-groups", resourceManager, (id, inputStream) -> {
                try {
                    ItemGroupRegistry.register(inputStream);
                } catch (IOException e) {
                    Filament.LOGGER.error("Failed to load item group config \"{}\".", id);
                }
            });
        }
    }
}

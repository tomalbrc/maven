package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import de.tomalbrc.filament.item.TridentEntity;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_9334;
import net.minecraft.class_9701;

/**
 * Trident behaviour
 */
public class Trident implements ItemBehaviour<Trident.Config>, ItemPredicateModelProvider {
    private final Config config;

    public Trident(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Trident.Config getConfig() {
        return this.config;
    }

    @Override
    public Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.of(72000);
    }

    @Override
    public class_1839 getUseAnimation(class_1799 itemStack) {
        return class_1839.field_8951;
    }

    @Override
    public boolean releaseUsing(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int i) {
        if (livingEntity instanceof class_1657 player) {
            var item = itemStack.method_7909();
            int j = this.getUseDuration(itemStack, livingEntity).orElseThrow() - i;
            if (j < 10) {
                return false;
            } else {
                float f = class_1890.method_60123(itemStack, player);
                if (f > 0.0f && !player.method_5721()) {
                    return false;
                } else if (itemStack.method_63692()) {
                    return false;
                } else {
                    class_6880<class_3414> holder = class_1890.method_60165(itemStack, class_9701.field_51654).orElse(class_3417.field_15001);
                    player.method_7259(class_3468.field_15372.method_14956(item));
                    if (level instanceof class_3218 serverLevel) {
                        itemStack.method_61653(1, player);
                        if (f == 0.0f) {
                            TridentEntity tridentEntity = class_1676.method_61549(TridentEntity::new, serverLevel, itemStack, player, 0.0f, 2.5f, 1.0f);

                            if (player.method_56992()) {
                                tridentEntity.field_7572 = class_1665.class_1666.field_7594;
                            } else {
                                player.method_31548().method_7378(itemStack);
                            }

                            level.method_43129(null, tridentEntity, holder.comp_349(), class_3419.field_15248, 1.0f, 1.0f);
                            return true;
                        }
                    }

                    if (f > 0.0F) {
                        float g = player.method_36454();
                        float h = player.method_36455();
                        float k = -class_3532.method_15374(g * class_3532.field_29847) * class_3532.method_15362(h * class_3532.field_29847);
                        float l = -class_3532.method_15374(h * class_3532.field_29847);
                        float m = class_3532.method_15362(g * class_3532.field_29847) * class_3532.method_15362(h * class_3532.field_29847);
                        float n = class_3532.method_15355(k * k + l * l + m * m);
                        k *= f / n;
                        l *= f / n;
                        m *= f / n;
                        player.method_5762(k, l, m);
                        player.method_40126(20, 8.0F, itemStack);
                        if (player.method_24828()) {
                            player.method_5784(class_1313.field_6308, new class_243(0.0, 1.2, 0.0));
                        }

                        level.method_43129(null, player, holder.comp_349(), class_3419.field_15248, 1.0F, 1.0F);
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
    }

    @Override
    public class_1269 use(class_1792 self, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        if (itemStack.method_63692()) {
            return class_1269.field_5814;
        } else if (class_1890.method_60123(itemStack, player) > 0.0F && !player.method_5721()) {
            return class_1269.field_5814;
        } else {
            player.method_6019(interactionHand);
            return class_1269.field_21466;
        }
    }

    @Override
    public void generate(Data<?> data) {
        PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(resourcePackBuilder ->
                ItemAssetGenerator.createTrident(
                        resourcePackBuilder, data.id(),
                        Objects.requireNonNull(data.itemResource()),
                        data.components().method_57832(class_9334.field_49644) || data.vanillaItem().method_57347().method_57832(class_9334.field_49644)
                )
        );
    }

    public static class Config {

    }
}
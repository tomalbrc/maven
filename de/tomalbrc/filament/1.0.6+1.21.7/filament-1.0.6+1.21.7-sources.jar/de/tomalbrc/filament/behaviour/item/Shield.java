package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;

/**
 * Shield behaviour
 */
public class Shield implements ItemBehaviour<Shield.Config>, ItemPredicateModelProvider {
    private final Config config;

    public Shield(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Shield.Config getConfig() {
        return this.config;
    }

    public Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.of(72000);
    }

    @Override
    public class_1269 use(class_1792 self, class_1937 level, class_1657 player, class_1268 interactionHand) {
        player.method_6019(interactionHand);
        return class_1269.field_21466;
    }

    @Override
    public class_1839 getUseAnimation(class_1799 itemStack) {
        return class_1839.field_8949;
    }

    @Override
    public void generate(Data<?> data) {
        PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(resourcePackBuilder ->
                ItemAssetGenerator.createShield(
                        resourcePackBuilder, data.id(),
                        Objects.requireNonNull(data.itemResource())
                )
        );
    }

    public static class Config {
    }
}
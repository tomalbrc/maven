package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

public class ExecuteInteractItem implements ItemBehaviour<ExecuteInteractItem.Config> {
    private final Config config;

    public ExecuteInteractItem(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ExecuteInteractItem.Config getConfig() {
        return config;
    }

    @Override
    public class_1269 use(class_1792 item, class_1937 level, class_1657 user, class_1268 hand) {
        var cmds = commands();

        if (cmds != null && user.method_5682() != null && user instanceof class_3222 serverPlayer) {
            runCommandItem(serverPlayer, item, hand);
            return class_1269.field_21466;
        }

        return ItemBehaviour.super.use(item, level, user, hand);
    }

    public void runCommandItem(class_3222 serverPlayer, class_1792 item, class_1268 hand) {
        if (serverPlayer.method_7357().method_7904(serverPlayer.method_5998(hand)))
            return;

        var cmds = commands();
        if (cmds != null && serverPlayer.method_5682() != null) {
            for (String cmd : cmds) {
                serverPlayer.method_5682().method_3734().method_44252(
                        serverPlayer.method_64396().method_36321(serverPlayer.method_5682()).method_9230(4), cmd);
            }

            serverPlayer.method_7259(class_3468.field_15372.method_14956(item));

            if (this.config.sound != null) {
                var sound = this.config.sound;
                serverPlayer.method_51469().method_43129(null, serverPlayer, class_7923.field_41172.method_63535(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                serverPlayer.method_5998(hand).method_7934(1);
            }
        }
    }

    private List<String> commands() {
        return config.commands == null ? this.config.command == null ? null : List.of(this.config.command) : config.commands;
    }

    public static class Config {
        public boolean consumes;

        public String command;
        public List<String> commands;

        public class_2960 sound;
    }
}

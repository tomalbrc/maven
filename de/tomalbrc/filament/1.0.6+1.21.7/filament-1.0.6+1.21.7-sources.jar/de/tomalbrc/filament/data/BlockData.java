package de.tomalbrc.filament.data;

import com.google.gson.JsonParseException;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.data.resource.ResourceProvider;
import de.tomalbrc.filament.util.FilamentBlockResourceUtils;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceArrayMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2259;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9323;

@SuppressWarnings("unused")
public class BlockData extends AbstractBlockData<BlockProperties> {
    private final @NotNull BlockResource blockResource;
    private final @Nullable BlockStateMappedProperty<BlockModelType> blockModelType;

    public BlockData(
            @NotNull class_2960 id,
            @Nullable class_1792 vanillaItem,
            @Nullable Map<String, String> translations,
            @Nullable class_2561 displayName,
            @Nullable ItemResource itemResource,
            @Nullable class_2960 itemModel,
            @Nullable BehaviourConfigMap behaviourConfig,
            @Nullable class_9323 components,
            @Nullable class_2960 itemGroup,
            @NotNull BlockResource blockResource,
            @Nullable BlockStateMappedProperty<BlockModelType> blockModelType,
            @Nullable BlockProperties properties,
            @Nullable Set<class_2960> itemTags,
            @Nullable Set<class_2960> blockTags
    ) {
        super(id, vanillaItem, translations, displayName, itemResource, itemModel, behaviourConfig, components, itemGroup, properties, itemTags, blockTags);
        this.blockResource = blockResource;
        this.blockModelType = blockModelType;
    }

    @Override
    @NotNull
    public BlockProperties properties() {
        if (properties == null) {
            properties = new BlockProperties();
        }
        return properties;
    }

    @Override
    public boolean virtual() {
        return this.properties().virtual;
    }

    @Override
    public Map<class_2680, BlockStateMeta> createStandardStateMap() {
        Reference2ReferenceArrayMap<class_2680, BlockStateMeta> val = new Reference2ReferenceArrayMap<>();

        if (blockResource.models() != null && this.blockModelType != null) {
            for (Map.Entry<String, PolymerBlockModel> entry : this.blockResource.models().entrySet()) {
                if (entry.getKey().equals("default")) {
                    var type = safeBlockModelType(this.blockModelType.getRawValue());
                    class_2680 requestedState = type == null ? null : FilamentBlockResourceUtils.requestBlock(type, entry.getValue(), this.virtual());
                    val.put(class_7923.field_41175.method_63535(id).method_9564(), BlockStateMeta.of(type == null ? class_2246.field_9987.method_9564() : requestedState, entry.getValue()));
                } else {
                    class_2680 state = blockState(String.format("%s[%s]", id, entry.getKey()));
                    BlockModelType type;
                    if (this.blockModelType.isMap()) {
                        type = safeBlockModelType(this.blockModelType.getOrDefault(state, BlockModelType.FULL_BLOCK));
                    } else {
                        type = safeBlockModelType(this.blockModelType.getRawValue());
                    }

                    class_2680 requestedState = type == null ? null : FilamentBlockResourceUtils.requestBlock(type, entry.getValue(), this.virtual());
                    val.put(state, BlockStateMeta.of(type == null ? class_2246.field_9987.method_9564() : requestedState, entry.getValue()));
                }
            }
        }

        return val;
    }

    private static class_2680 blockState(String str) {
        class_2259.class_7211 parsed;
        try {
            parsed = class_2259.method_41957(class_7923.field_41175, str, false);
        } catch (CommandSyntaxException e) {
            throw new JsonParseException("Invalid BlockState value: " + str);
        }
        return parsed.comp_622();
    }

    private BlockModelType safeBlockModelType(BlockModelType blockModelType) {
        if (PolymerBlockResourceUtils.getBlocksLeft(blockModelType) <= 0) {
            blockModelType = BlockModelType.FULL_BLOCK;
            if (PolymerBlockResourceUtils.getBlocksLeft(blockModelType) <= 0) {
                Filament.LOGGER.error("Filament: Ran out of blockModelTypes to use AND FULL_BLOCK ran out too! Using Bedrock block temporarily. Fix your Block-Config for {}!", this.id());
                return null;
            } else {
                Filament.LOGGER.error("Filament: Ran out of blockModelTypes to use! Using FULL_BLOCK for {}", this.id());
            }
        }

        return blockModelType;
    }

    @Override
    public BlockResource blockResource() {
        return blockResource;
    }

    @Override
    public @NotNull ResourceProvider preferredResource() {
        return blockResource();
    }

    public @Nullable BlockStateMappedProperty<BlockModelType> blockModelType() {
        return blockModelType;
    }

    @Override
    public String toString() {
        return "BlockData[" +
                "id=" + id + ", " +
                "vanillaItem=" + vanillaItem + ", " +
                "blockResource=" + blockResource + ", " +
                "itemResource=" + itemResource + ", " +
                "blockModelType=" + blockModelType + ", " +
                "properties=" + properties + ", " +
                "behaviourConfig=" + behaviour + ", " +
                "components=" + components + ", " +
                "itemGroup=" + group + ']';
    }

    public record BlockStateMeta(class_2680 blockState, PolymerBlockModel polymerBlockModel) {
        public static BlockStateMeta of(class_2680 blockState, PolymerBlockModel blockModel) {
            return new BlockStateMeta(blockState, blockModel);
        }
    }
}

package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class Waterloggable implements BlockBehaviour<Waterloggable.Config>, class_3737 {
    private final Config config;

    public Waterloggable(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Waterloggable.Config getConfig() {
        return this.config;
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(class_2741.field_12508, false);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12508);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 blockState, class_1750 blockPlaceContext) {
        class_2338 blockPos = blockPlaceContext.method_8037();
        class_3610 fluidState = blockPlaceContext.method_8045().method_8316(blockPos);
        return blockState.method_11657(class_2741.field_12508, fluidState.method_15772() == class_3612.field_15910);
    }

    @Override
    public class_3610 getFluidState(class_2680 blockState) {
        if (blockState.method_11654(class_2741.field_12508)) {
            return class_3612.field_15910.method_15729(false);
        }
        return null;
    }

    @Override
    public boolean method_10311(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_3610 fluidState) {
        return class_3737.super.method_10311(levelAccessor, blockPos, blockState, fluidState);
    }

    @Override
    public boolean method_10310(@Nullable class_1309 livingEntity, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3611 fluid) {
        return class_3737.super.method_10310(livingEntity, blockGetter, blockPos, blockState, fluid);
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        if (blockState.method_11654(class_2741.field_12508)) {
            scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
        }
        return blockState;
    }

    @Override
    public Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
        return switch (pathComputationType) {
            case field_50, field_51 -> Optional.of(false);
            case field_48 -> Optional.of(blockState.method_26227().method_15767(class_3486.field_15517));
        };
    }

    public static class Config {}
}
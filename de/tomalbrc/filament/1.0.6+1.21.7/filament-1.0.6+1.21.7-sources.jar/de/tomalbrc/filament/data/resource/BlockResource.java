package de.tomalbrc.filament.data.resource;

import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import net.minecraft.class_2960;

public class BlockResource implements ResourceProvider {
    private Map<String, PolymerBlockModel> models = new Object2ObjectArrayMap<>();
    private class_2960 parent;
    private Map<String, TextureBlockModel> textures;

    public BlockResource(Map<String, PolymerBlockModel> models) {
        this(models, null, null);
    }

    public BlockResource(Map<String, PolymerBlockModel> models, class_2960 parent, Map<String, TextureBlockModel> textures) {
        this.models = models;
        this.parent = parent;
        this.textures = textures;
    }

    public class_2960 parent() {
        if (parent == null)
            parent = class_2960.method_60656("block/cube_all");
        return parent;
    }

    public Map<String, TextureBlockModel> textures() {
        return textures;
    }

    public boolean couldGenerate() {
        return (models == null || models.isEmpty()) && textures != null;
    }

    @Override
    public Map<String, class_2960> getModels() {
        var map = new Object2ObjectOpenHashMap<String, class_2960>();
        if (this.models == null) {
            this.models = new Object2ObjectArrayMap<>();
            return map;
        }

        for (Map.Entry<String, PolymerBlockModel> entry : models.entrySet()) {
            var model = entry.getValue().model();
            map.put(entry.getKey(), model);
        }
        return map;
    }

    public Map<String, PolymerBlockModel> models() {
        return this.models;
    }

    public void addModel(String key, PolymerBlockModel blockModel) {
        if (this.models == null) this.models = new Object2ObjectArrayMap<>();
        this.models.put(key, blockModel);
    }


    public record TextureBlockModel(Map<String, class_2960> textures, int x, int y, boolean uvLock, int weight) {}
}
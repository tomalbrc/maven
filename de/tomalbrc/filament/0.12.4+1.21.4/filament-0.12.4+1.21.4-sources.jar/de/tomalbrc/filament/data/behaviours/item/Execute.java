package de.tomalbrc.filament.data.behaviours.item;

import net.minecraft.class_2960;

public class Execute {
    public boolean consumes;

    public String command;

    public class_2960 sound;
}

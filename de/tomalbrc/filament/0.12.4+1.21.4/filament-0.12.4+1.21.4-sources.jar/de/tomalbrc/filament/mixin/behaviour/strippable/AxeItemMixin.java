package de.tomalbrc.filament.mixin.behaviour.strippable;

import de.tomalbrc.filament.registry.StrippableRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_1743;
import net.minecraft.class_181;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8567;

@Mixin(class_1743.class)
public class AxeItemMixin {
    @Inject(method = "evaluateNewBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/AxeItem;getStripped(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/Optional;"), cancellable = true)
    private void filament$onGetStripped(class_1937 level, class_2338 blockPos, class_1657 player, class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (StrippableRegistry.has(blockState.method_26204())) {
            var newState = StrippableRegistry.get(blockState.method_26204()).method_34725(blockState);
            level.method_8396(player, blockPos, class_3417.field_14675, class_3419.field_15245, 1.0F, 1.0F);
            var lootId = StrippableRegistry.getLootTable(blockState.method_26204());
            if (lootId != null) {
                var tableReference = level.method_30349().method_58561(class_5321.method_29179(class_7924.field_50079, lootId));
                var table = tableReference.orElseThrow().comp_349();
                table.method_51882(new class_8567.class_8568((class_3218) level)
                        .method_51874(class_181.field_24424, class_243.method_24953(blockPos))
                        .method_51874(class_181.field_1229, player.method_6047())
                        .method_51874(class_181.field_1226, player)
                        .method_51874(class_181.field_1224, blockState)
                        .method_51871(player.method_7292())
                        .method_51875(class_173.field_1172), item -> class_2248.method_9577(level, blockPos, item));
            }
            cir.setReturnValue(Optional.of(newState));
        }
    }
}

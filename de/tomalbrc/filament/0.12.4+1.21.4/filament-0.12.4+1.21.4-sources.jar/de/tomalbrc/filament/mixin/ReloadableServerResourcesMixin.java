package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_2170;
import net.minecraft.class_2378;
import net.minecraft.class_3300;
import net.minecraft.class_5350;
import net.minecraft.class_7659;
import net.minecraft.class_7699;
import net.minecraft.class_7780;

@Mixin(class_5350.class)
public class ReloadableServerResourcesMixin {
    @Inject(at = @At("HEAD"), method = "loadResources")
    private static void filament$loadResources(class_3300 resourceManager, class_7780<class_7659> layeredRegistryAccess, List<class_2378.class_10106<?>> list, class_7699 featureFlagSet, class_2170.class_5364 commandSelection, int i, Executor executor, Executor executor2, CallbackInfoReturnable<CompletableFuture<class_5350>> cir) {
        Filament.REGISTRY_ACCESS = layeredRegistryAccess;
        Util.loadDatapackContents(resourceManager);
        PolymerItemGroupUtils.invalidateItemGroupCache();
    }
}
package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import org.jetbrains.annotations.NotNull;

public class Powerlevel implements BlockBehaviour<Powerlevel.PowerlevelConfig> {
    public static final class_2758[] POWERS = {
            class_2758.method_11867("powerlevel", 0,1),
            class_2758.method_11867("powerlevel", 0,2),
            class_2758.method_11867("powerlevel", 0,3),
            class_2758.method_11867("powerlevel", 0,4),
            class_2758.method_11867("powerlevel", 0,5),
            class_2758.method_11867("powerlevel", 0,6),
            class_2758.method_11867("powerlevel", 0,7),
            class_2758.method_11867("powerlevel", 0,8),
            class_2758.method_11867("powerlevel", 0,9),
            class_2758.method_11867("powerlevel", 0,10),
            class_2758.method_11867("powerlevel", 0,11),
            class_2758.method_11867("powerlevel", 0,12),
            class_2758.method_11867("powerlevel", 0,13),
            class_2758.method_11867("powerlevel", 0,14),
            class_2758.method_11867("powerlevel", 0,15),
    };

    private final PowerlevelConfig config;

    public Powerlevel(PowerlevelConfig config) {
        this.config = config;
    }

    @Override
    @NotNull
    public PowerlevelConfig getConfig() {
        return this.config;
    }

    @Override
    public boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(POWERS[Math.max(0, config.max-1)]);
        return true;
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 block, class_1750 blockPlaceContext) {
        int signal = blockPlaceContext.method_8045().method_49804(blockPlaceContext.method_8037());
        return block.method_11657(POWERS[Math.max(0, config.max-1)], Math.min(signal, this.config.max));
    }

    @Override
    public void neighborChanged(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_9904 orientation, boolean bl) {
        if (!level.field_9236) {
            int power = blockState.method_11654(POWERS[Math.max(0, config.max-1)]);
            int signal = level.method_49804(blockPos);
            if (signal > this.config.max)
                signal = this.config.max;

            if (signal != power) {
                level.method_64310(blockPos, blockState.method_26204(), 1);
            }
        }
    }

    @Override
    public void tick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        int signal = serverLevel.method_49804(blockPos);
        if (signal > this.config.max)
            signal = this.config.max;

        if (signal != blockState.method_11654(POWERS[Math.max(0, config.max-1)])) {
            serverLevel.method_8652(blockPos, blockState.method_11657(POWERS[Math.max(0, config.max-1)], signal), 2); // what does the 2 do..?
        }
    }

    public static class PowerlevelConfig {
        public int max = 15;
    }
}
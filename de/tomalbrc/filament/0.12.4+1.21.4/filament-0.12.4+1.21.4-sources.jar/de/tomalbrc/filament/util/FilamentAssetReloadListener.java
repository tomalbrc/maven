package de.tomalbrc.filament.util;

import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import java.io.IOException;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_3255;
import net.minecraft.class_3258;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

public class FilamentAssetReloadListener implements FilamentSynchronousResourceReloadListener {
    Consumer<ResourcePackBuilder> lastConsumer = null;

    @Override
    public class_2960 getFabricId() {
        return class_2960.method_60655(Constants.MOD_ID, "assets");
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        if (lastConsumer == null) {
            Consumer<ResourcePackBuilder> consumer = resourcePackBuilder -> resourceManager.method_29213().forEach(packResources -> {
                Set<String> clientResources = packResources.method_14406(class_3264.field_14188);
                if (packResources instanceof class_3255 abstractPackResources) {
                    // using cursed hack for FilePackResource in a mixin to remove double-slashes in the path when providing an empty second string
                    boolean isZip = packResources instanceof class_3258;
                    for (String namespace : clientResources) {
                        abstractPackResources.method_14408(class_3264.field_14188, isZip ? namespace : "", !isZip ? namespace : "", (resourceLocation,ioSupplier) -> {
                            try {
                                if (isZip)
                                    resourcePackBuilder.addData("assets/" + resourceLocation.method_12836() + "/" + resourceLocation.method_12832(), ioSupplier.get().readAllBytes());
                                else
                                    // and another hack, we don't provide a namespace for normals packs... so the namespace is part of the identifiers' path
                                    resourcePackBuilder.addData("assets/" + resourceLocation.method_12832(), ioSupplier.get().readAllBytes());
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                }
            });

            lastConsumer = consumer;
            PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(consumer);
        }
    }
}
package de.tomalbrc.filament.mixin.behaviour.cosmetic;

import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.cosmetic.CosmeticUtil;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_3222.class)
public abstract class ServerPlayerMixin implements CosmeticInterface {
    @Inject(method = "initInventoryMenu", at = @At(value = "TAIL"))
    private void filament$onInitInventoryMenu(CallbackInfo ci) {
        if ((Object)this instanceof class_3222 serverPlayer) {
            var slots = serverPlayer.method_5661();
            for (class_1799 item : slots) {
                if (serverPlayer.method_32326(item) == class_1304.field_6169) {
                    continue;
                }

                if (!item.method_7960() && CosmeticUtil.isCosmetic(item)) {
                    filament$destroyHolder(serverPlayer.method_32326(item).method_5923());
                    filament$addHolder(serverPlayer, item.method_7909(), item, serverPlayer.method_32326(item).method_5923());
                }
            }
        }
    }

    @Inject(method = "hasChangedDimension", at = @At("TAIL"))
    private void filament$onChangeDimension(CallbackInfo ci) {
        if ((Object)this instanceof class_3222 serverPlayer) {
            var slots = serverPlayer.method_5661();
            for (class_1799 item : slots) {
                if (serverPlayer.method_32326(item) == class_1304.field_6169) {
                    continue;
                }

                if (!item.method_7960() && CosmeticUtil.isCosmetic(item)) {
                    filament$destroyHolder(serverPlayer.method_32326(item).method_5923());
                    filament$addHolder(serverPlayer, item.method_7909(), item, serverPlayer.method_32326(item).method_5923());
                }
            }
        }
    }
}

package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.bil.core.holder.entity.EntityHolder;
import de.tomalbrc.bil.core.holder.wrapper.DisplayWrapper;
import de.tomalbrc.bil.core.model.Model;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2716;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_4050;
import net.minecraft.class_8042;

public class AnimatedCosmeticHolder extends EntityHolder {
    private final class_1309 entity;

    private final Consumer<class_3244> startWatchingCallback;

    boolean hidden = false;

    public AnimatedCosmeticHolder(class_1309 entity, Model model, Consumer<class_3244> startWatchingCallback) {
        super(entity, model);
        this.startWatchingCallback = startWatchingCallback;
        this.entity = entity;
    }

    @Override
    public int getVehicleId() {
        return -1;
    }

    @Override
    public boolean addAdditionalDisplay(DisplayElement element) {
        if (this.additionalDisplays.add(element)) {
            this.addElement(element);
            return true;
        } else {
            return false;
        }
    }

    private CosmeticInterface access() {
        return (CosmeticInterface) this.entity;
    }

    @Override
    protected void updateElement(DisplayWrapper<?> display) {
        display.element().ignorePositionUpdates();
        display.element().setYaw(access().filament$bodyYaw());
        super.updateElement(display);
    }

    @Override
    public class_2168 createCommandSourceStack() {
        return this.entity.method_5671(this.getLevel()).method_9230(4);
    }

    @Override
    public boolean startWatching(class_3244 player) {
        var ret = super.startWatching(player);

        this.startWatchingCallback.accept(player);

        return ret;
    }

    public class_243 getPos() {
        return this.entity instanceof class_3222 ? this.entity.method_19538() : this.entity.method_33571();
    }

    @Override
    public void onTick() {
        if (this.entity.method_18376() == class_4050.field_18079 || this.entity.method_18376() == class_4050.field_18078) {
            if (!hidden) {
                hideForAll(this);
                hidden = true;
            }
        } else {
            if (hidden) {
                showForAll(this);
                for (class_3244 player : this.getWatchingPlayers()) {
                    startWatchingCallback.accept(player);
                }
                hidden = false;
            }
        }

        super.onTick();
    }

    public static void hideForAll(ElementHolder elementHolder) {
        for (class_3244 player : elementHolder.getWatchingPlayers()) {
            player.method_14364(new class_2716(elementHolder.getEntityIds()));
        }
    }

    public static void showForAll(ElementHolder elementHolder) {
        for (class_3244 player : elementHolder.getWatchingPlayers()) {
            var packets = new ObjectArrayList<class_2596<? super class_2602>>();
            for (VirtualElement e : elementHolder.getElements()) {
                Objects.requireNonNull(packets);
                e.startWatching(player.field_14140, packets::add);
            }
            player.method_14364(new class_8042(packets));
        }
    }
}

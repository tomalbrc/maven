package de.tomalbrc.filament.data;

import com.google.gson.JsonObject;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.data.resource.ItemResource;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_9323;
import net.minecraft.class_9331;

public abstract class Data {
    protected final @NotNull class_2960 id;
    protected final @Nullable class_1792 vanillaItem;
    protected final @Nullable Map<String, String> translations;
    protected final @Nullable ItemResource itemResource;
    protected final @Nullable class_2960 itemModel;
    protected final @Nullable BehaviourConfigMap behaviour;
    protected final @Nullable class_9323 components;
    protected final @Nullable class_2960 group;
    transient protected Map<class_9331<?>, JsonObject> additionalComponents;

    protected Data(
            @NotNull class_2960 id,
            @Nullable class_1792 vanillaItem,
            @Nullable Map<String, String> translations,
            @Nullable ItemResource itemResource,
            @Nullable class_2960 itemModel,
            @Nullable BehaviourConfigMap behaviour,
            @Nullable class_9323 components,
            @Nullable class_2960 group
    ) {
        this.id = id;
        this.vanillaItem = vanillaItem;
        this.translations = translations;
        this.itemResource = itemResource;
        this.itemModel = itemModel;
        this.behaviour = behaviour;
        this.components = components;
        this.group = group;
    }

    public void putAdditional(class_9331<?> s, JsonObject jsonObject) {
        if (this.additionalComponents == null) this.additionalComponents = new Object2ObjectOpenHashMap<>();
        this.additionalComponents.put(s, jsonObject);
    }

    @NotNull
    public Map<class_9331<?>, JsonObject> getAdditionalComponents() {
        if (this.additionalComponents == null) this.additionalComponents = new Object2ObjectOpenHashMap<>();
        return additionalComponents;
    }

    public @NotNull class_2960 id() {
        return id;
    }

    public @NotNull class_1792 vanillaItem() {
        if (vanillaItem == null) {
            return class_1802.field_8407;
        }
        return vanillaItem;
    }

    public @Nullable Map<String, String> translations() {
        return translations;
    }

    public @Nullable ItemResource itemResource() {
        return itemResource;
    }

    public @Nullable class_2960 itemModel() {
        return itemModel;
    }

    public @NotNull BehaviourConfigMap behaviour() {
        return behaviour == null ? BehaviourConfigMap.EMPTY : behaviour;
    }

    public @NotNull class_9323 components() {
        return components == null ? class_9323.field_49584 : components;
    }

    public @Nullable class_2960 group() {
        return group;
    }
}

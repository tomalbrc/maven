package de.tomalbrc.filament.data.behaviours.item;

import net.minecraft.class_1304;
import net.minecraft.class_2960;
import org.joml.Vector3f;

/**
 * Cosmetics; either head or chestplate slot, can be Blockbenchmodel for chestplate slot or simple item model for either
 */
public class Cosmetic {
    /**
     * The equipment slot for the cosmetic (head, chest).
     */
    public class_1304 slot;

    /**
     * The resource location of the animated model for the cosmetic.
     */
    public class_2960 model;

    /**
     * The name of the animation to autoplay. The animation should be loopable
     */
    public String autoplay;

    /**
     * Scale of the chest cosmetic
     */
    public Vector3f scale = new Vector3f(1);

    /**
     * Translation of the chest cosmetic
     */
    public Vector3f translation = new Vector3f();
}

package de.tomalbrc.filament.data.resource;

import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import net.minecraft.class_2960;

public record BlockResource(Map<String, PolymerBlockModel> models) implements ResourceProvider {
    @Override
    public Map<String, class_2960> getModels() {
        var map = new Object2ObjectOpenHashMap<String, class_2960>();
        for (Map.Entry<String, PolymerBlockModel> entry : models.entrySet()) {
            var model = entry.getValue().model();
            map.put(entry.getKey(), model);
        }
        return map;
    }
}

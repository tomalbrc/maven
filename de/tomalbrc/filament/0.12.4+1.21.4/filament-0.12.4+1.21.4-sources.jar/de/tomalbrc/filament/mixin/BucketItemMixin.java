package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1755;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1755.class)
public abstract class BucketItemMixin {
    @Shadow public abstract class_1269 use(class_1937 level, class_1657 player, class_1268 interactionHand);

    @Inject(cancellable = true, method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;", ordinal = 0), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void filament$preventBucketInteraction(class_1937 level, class_1657 player, class_1268 interactionHand, CallbackInfoReturnable<class_1269> cir, @Local class_2680 blockState, @Local class_1799 itemStack) {
        if (blockState.method_26204() instanceof SimpleBlock && !blockState.method_28498(class_2741.field_12508))
            cir.setReturnValue(class_1269.field_5814);
    }
}

package de.tomalbrc.filament.data.resource;

import java.util.Map;
import net.minecraft.class_2960;

public interface ResourceProvider {
    Map<String, class_2960> getModels();
}

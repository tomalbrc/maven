package de.tomalbrc.filament.data.resource;

import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import java.util.Map;
import net.minecraft.class_2960;

public class ItemResource implements ResourceProvider {
    private final Map<String, class_2960> models = new Object2ObjectArrayMap<>();
    private class_2960 parent = class_2960.method_60656("item/generated");
    private Map<String, Map<String, class_2960>> textures;

    public class_2960 parent() {
        return parent;
    }

    public Map<String, Map<String, class_2960>> textures() {
        return textures;
    }

    public boolean couldGenerate() {
        return models.isEmpty() && textures != null && parent != null;
    }

    @Override
    public Map<String, class_2960> getModels() {
        return this.models;
    }
}

package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_5455;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class ItemMask implements ItemBehaviour<ItemMask.Config> {
    private final Config config;

    public ItemMask(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ItemMask.Config getConfig() {
        return this.config;
    }

    @Override
    public void appendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        class_9279 customData;
        if (itemStack.method_57826(class_9334.field_49628) && (customData = itemStack.method_57824(class_9334.field_49628)) != null) {
            var tag = customData.method_57461();
            var originalItem = class_1799.method_57359(tooltipContext.method_59527(), tag.method_10562("Item"));
            list.add(class_2561.method_43470("---"));
            list.add(class_2561.method_43470("Masked Item:"));
            list.add(class_2561.method_43470("---"));
            originalItem.method_7909().method_7851(originalItem, tooltipContext, list, tooltipFlag);
        }
    }

    public static class_1799 getMasked(class_5455 registryAccess, class_1799 original, class_1799 masker) {
        class_2520 tag = original.method_57358(registryAccess);
        class_2487 compoundTag = new class_2487();
        compoundTag.method_10566("Item", tag);
        masker.method_57379(class_9334.field_49628, class_9279.method_57456(compoundTag));

        return masker;
    }

    public static class_1799 getOriginal(class_5455 registryAccess, class_1799 masker) {
        class_9279 customData = masker.method_57824(class_9334.field_49628);
        if (customData != null) {
            var tag = customData.method_57461();
            return class_1799.method_57359(registryAccess, tag.method_10562("Item"));
        }

        return class_1799.field_8037;
    }

    public static class Config {

    }
}

package de.tomalbrc.filament.data;

import com.google.gson.annotations.SerializedName;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.data.properties.DecorationProperties;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_9323;

public record DecorationData(
        @NotNull class_2960 id,
        @NotNull class_2960 model,

        @Nullable class_1792 vanillaItem,

        @Nullable List<BlockConfig> blocks,

        @Nullable Vector2f size,

        @Nullable DecorationProperties properties,

        @SerializedName("behaviour")
        @Nullable BehaviourConfigMap behaviourConfig,
        @Nullable class_9323 components,
        @SerializedName("group")
        @Nullable class_2960 itemGroup
) {
    @Override
    @NotNull
    public DecorationProperties properties() {
        if (properties == null) {
            return DecorationProperties.EMPTY;
        }
        return properties;
    }

    @Override
    @NotNull
    public class_9323 components() {
        if (components == null) {
            return class_9323.field_49584;
        }
        return components;
    }

    @Override
    @NotNull
    public class_1792 vanillaItem() {
        if (vanillaItem == null) {
            return class_1802.field_8407;
        }
        return vanillaItem;
    }

    public PolymerModelData requestModel() {
        return PolymerResourcePackUtils.requestModel(vanillaItem != null ? vanillaItem : class_1802.field_8054, model);
    }

    public boolean isContainer() {
        return this.behaviourConfig != null && this.behaviourConfig.has(Behaviours.CONTAINER);
    }

    public boolean hasBlocks() {
        return this.blocks != null;
    }

    public int countBlocks() {
        if (!this.hasBlocks())
            return 0;

        int c = 0;
        for (BlockConfig block : this.blocks) {
            c += (int) (block.size().x() * block.size().y() * block.size().z());
        }
        return c;
    }

    public boolean isSimple() {
        boolean singleBlock = (!this.hasBlocks() || Util.barrierDimensions(Objects.requireNonNull(this.blocks()), 0).equals(1, 1));
        boolean hasBehaviour = this.behaviourConfig() != null;
        boolean canBeDyed = this.vanillaItem != null && (vanillaItem == class_1802.field_18138 || vanillaItem == class_1802.field_8450);
        boolean groundOnly = this.properties != null && !(this.properties.placement.wall() || this.properties.placement.ceiling());

        return groundOnly && !canBeDyed && !hasBehaviour && (singleBlock || this.size != null);
    }

    public boolean isCosmetic() {
        return this.behaviourConfig != null && this.behaviourConfig.has(Behaviours.COSMETIC);
    }

    public record BlockConfig(Vector3f origin,
                       Vector3f size,
                       class_2680 block) { }
}

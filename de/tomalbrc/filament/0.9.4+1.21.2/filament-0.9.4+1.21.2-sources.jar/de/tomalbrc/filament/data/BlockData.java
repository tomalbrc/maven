package de.tomalbrc.filament.data;

import com.google.gson.JsonParseException;
import com.google.gson.annotations.SerializedName;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceArrayMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2259;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9323;


public record BlockData(
        @NotNull class_2960 id,
        @Nullable class_1792 vanillaItem,
        @NotNull BlockResource blockResource,
        @Nullable ItemResource itemResource,
        @Nullable BlockStateMappedProperty<BlockModelType> blockModelType,
        @Nullable BlockProperties properties,
        @SerializedName("behaviour")
        @Nullable BehaviourConfigMap behaviourConfig,
        @Nullable class_9323 components,
        @SerializedName("group")
        @Nullable class_2960 itemGroup
) {
    @Override
    @NotNull
    public BlockProperties properties() {
        if (properties == null) {
            return BlockProperties.EMPTY;
        }
        return properties;
    }

    @Override
    @NotNull
    public class_9323 components() {
        if (components == null) {
            return class_9323.field_49584;
        }
        return components;
    }

    @Override
    @NotNull
    public class_1792 vanillaItem() {
        if (vanillaItem == null) {
            return class_1802.field_8407;
        }
        return vanillaItem;
    }

    public Map<class_2680, BlockStateMeta> createStandardStateMap() {
        Reference2ReferenceArrayMap<class_2680, BlockStateMeta> val = new Reference2ReferenceArrayMap<>();

        if (blockResource.couldGenerate()) {
            //val = BlockModelGenerator.generate(blockResource);
            throw new UnsupportedOperationException("Not implemented");
        } else if (blockResource.models() != null && this.blockModelType != null) {
            for (Map.Entry<String, PolymerBlockModel> entry : this.blockResource.models().entrySet()) {
                if (entry.getKey().equals("default")) {
                    var type = safeBlockModelType(this.blockModelType.getRawValue());
                    class_2680 requestedState = type == null ? null : PolymerBlockResourceUtils.requestBlock(type, entry.getValue());
                    val.put(class_7923.field_41175.method_10223(id).orElseThrow().comp_349().method_9564(), BlockStateMeta.of(type == null ? class_2246.field_9987.method_9564() : requestedState, entry.getValue()));
                }
                else {
                    var state = blockState(String.format("%s[%s]", id, entry.getKey()));
                    if (this.blockModelType.isMap()) {
                        var type = safeBlockModelType(this.blockModelType.getOrDefault(state, BlockModelType.FULL_BLOCK));
                        class_2680 requestedState = type == null ? null : PolymerBlockResourceUtils.requestBlock(type, entry.getValue());
                        val.put(state, BlockStateMeta.of(type == null ? class_2246.field_9987.method_9564() : requestedState, entry.getValue()));
                    } else {
                        var type = safeBlockModelType(this.blockModelType.getRawValue());
                        class_2680 requestedState = type == null ? null : PolymerBlockResourceUtils.requestBlock(type, entry.getValue());
                        val.put(state, BlockStateMeta.of(type == null ? class_2246.field_9987.method_9564() : requestedState, entry.getValue()));
                    }
                }
            }
        }

        return val;
    }

    private static class_2680 blockState(String str) {
        class_2259.class_7211 parsed;
        try {
            parsed = class_2259.method_41957(class_7923.field_41175, str, false);
        } catch (CommandSyntaxException e) {
            throw new JsonParseException("Invalid BlockState value: " + str);
        }
        return parsed.comp_622();
    }

    private BlockModelType safeBlockModelType(BlockModelType blockModelType) {
        if (PolymerBlockResourceUtils.getBlocksLeft(blockModelType) <= 0) {
            blockModelType = BlockModelType.FULL_BLOCK;
            if (PolymerBlockResourceUtils.getBlocksLeft(blockModelType) <= 0) {
                Filament.LOGGER.error("Filament: Ran out of blockModelTypes to use AND FULL_BLOCK ran out too! Using Bedrock block temporarily. Fix your Block-Config for {}!", this.id());
                return null;
            } else {
                Filament.LOGGER.error("Filament: Ran out of blockModelTypes to use! Using FULL_BLOCK");
            }
        }

        return blockModelType;
    }

    public record BlockStateMeta(class_2680 blockState, PolymerBlockModel polymerBlockModel) {
        public static BlockStateMeta of(class_2680 blockState, PolymerBlockModel blockModel) {
            return new BlockStateMeta(blockState, blockModel);
        }
    }
}

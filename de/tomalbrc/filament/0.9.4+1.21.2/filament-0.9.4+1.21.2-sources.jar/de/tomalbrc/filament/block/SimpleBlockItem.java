package de.tomalbrc.filament.block;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.item.SimpleItem;
import eu.pb4.polymer.core.api.item.PolymerItem;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

public class SimpleBlockItem extends SimpleItem implements PolymerItem, BehaviourHolder {
    private final BlockData blockData;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties, data.properties(), data.vanillaItem());
        this.blockData = data;
        this.initBehaviours(data.behaviourConfig());
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, PacketContext packetContext) {
        return this.vanillaItem;
    }

    @Override
    protected Map<String, class_2960> getModelMap() {
        return this.blockData.itemResource() == null ? Map.of() : this.blockData.itemResource().models();
    }

    @Override
    protected class_2960 getModel() {
        boolean hasItemModels = this.blockData.itemResource() != null && this.blockData.itemResource().models() != null;
        return hasItemModels ? this.blockData.itemResource().models().get("default") : removeItemPrefix(this.blockData.blockResource().models().entrySet().iterator().next().getValue().model());
    }

    private static class_2960 removeItemPrefix(class_2960 resourceLocation) {
        return class_2960.method_60655(resourceLocation.method_12836(), resourceLocation.method_12832().startsWith("item/") ? resourceLocation.method_12832().substring("item/".length()) : resourceLocation.method_12832());
    }
}
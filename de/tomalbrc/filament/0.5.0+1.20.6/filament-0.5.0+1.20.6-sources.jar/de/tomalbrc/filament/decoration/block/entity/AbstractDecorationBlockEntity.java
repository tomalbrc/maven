package de.tomalbrc.filament.decoration.block.entity;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.registry.filament.DecorationRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_7225;

public abstract class AbstractDecorationBlockEntity extends class_2586 {

    protected class_2338 main;

    protected int rotation;

    protected class_2350 direction = class_2350.field_11036;

    protected class_1799 itemStack;

    private boolean passthrough = false;

    public AbstractDecorationBlockEntity(class_2338 pos, class_2680 state) {
        super(DecorationRegistry.getBlockEntityType(state), pos, state);
    }

    public boolean isMain() {
        return this.main != null && this.main.equals(this.field_11867);
    }

    public void setMain(class_2338 main) {
        this.main = main;
    }

    public DecorationBlockEntity getMainBlockEntity() {
        assert this.field_11863 != null;
        return (DecorationBlockEntity)this.field_11863.method_8321(this.main);
    }

    @Override
    protected void method_11014(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11014(compoundTag, provider);

        // TODO: safely unwrap optional
        this.main = class_2512.method_10691(compoundTag, "Main").get();
        this.itemStack = class_1799.method_57360(provider, compoundTag.method_10562("Item")).get();

        if (compoundTag.method_10545("Passthrough")) {
            this.passthrough = compoundTag.method_10577("Passthrough");
            this.setCollision(!this.passthrough);
        }

        if (!this.isMain())
            return;

        this.rotation = compoundTag.method_10550("Rotation");
        this.direction = class_2350.method_10143(compoundTag.method_10550("Direction"));
    }

    @Override
    protected void method_11007(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11007(compoundTag, provider);

        if (this.itemStack == null) {
            Filament.LOGGER.error("No item for decoration! Removing decoration block entity at " + this.method_11016().method_23854());
            this.field_11863.method_22352(this.method_11016(), false);
            this.method_11012();
            return;
        }

        compoundTag.method_10566("Item", this.itemStack.method_57358(provider));

        compoundTag.method_10566("Main", class_2512.method_10692(this.main));
        if (this.passthrough) compoundTag.method_10556("Passthrough", this.passthrough);

        if (this.isMain()) {
            compoundTag.method_10569("Rotation", this.rotation);
            compoundTag.method_10569("Direction", this.direction.method_10146());
        }
    }

    abstract protected void destroyBlocks();
    abstract protected void destroyStructure(boolean dropItems);
    abstract protected void setCollisionStructure(boolean collisionStructure);

    protected void setCollision(boolean collision) {
        if (this.isMain()) {
            this.setCollisionStructure(collision);
        } else {
            this.getMainBlockEntity().setCollisionStructure(collision);
        }
    }

    public class_2350 getDirection() {
        return this.direction;
    }

    public void setDirection(class_2350 direction) {
        this.direction = direction;
    }

    public class_1799 getItem() {
        return this.itemStack;
    }

    public void setItem(class_1799 itemStack) {
        this.itemStack = itemStack;
    }

    public float getVisualRotationYInDegrees() {
        class_2350 direction = this.getDirection();
        int i = direction.method_10166().method_10178() ? 90 * direction.method_10171().method_10181() : 0;
        return (float) class_3532.method_15392(180 + direction.method_10161() * 90 + rotation * 45 + i);
    }

    public void setRotation(int rotation) {
        this.rotation = rotation;
    }

    public int getRotation() {
        return this.rotation;
    }
}
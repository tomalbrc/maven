package de.tomalbrc.filament.block;

import com.mojang.serialization.MapCodec;
import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import java.util.HashMap;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1953;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2457;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5819;

public class PoweredDirectionBlock extends class_2318 implements PolymerTexturedBlock {
    public static final class_2758 POWER = class_2758.method_11867("power", 0, 15);
    public static final class_2746 POWERED = class_2746.method_11825("powered");

    private final HashMap<String, class_2680> stateMap;
    private final class_2680 breakEventState;

    private final boolean isRelay;
    private int delay = 1;
    private int loss = 0;

    public MapCodec<DirectionBlock> method_53969() {
        return null;
    }

    public PoweredDirectionBlock(class_2251 properties, BlockData data) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(POWER, 0).method_11657(POWERED, false));

        this.isRelay = data.isRepeater();
        if (this.isRelay && data.behaviour().repeater != null) {
            this.delay = data.behaviour().repeater.delay;
            this.loss = data.behaviour().repeater.loss;
        }

        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_10927, POWERED, POWER);
    }

    @Override
    public class_2680 method_9605(class_1750 blockPlaceContext) {
        class_2350 dir = blockPlaceContext.method_7715().method_10153().method_10153();
        class_2680 state = this.method_9564().method_11657(field_10927, dir);
        int s = this.getInputSignal(blockPlaceContext.method_8045(), blockPlaceContext.method_8037(), state);
        state = state.method_11657(POWERED, s > 0).method_11657(POWER, s);
        this.updateNeighborsOnBack(blockPlaceContext.method_8045(), blockPlaceContext.method_8037(), state);
        return state;
    }

    @Override
    public int method_9603(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return blockState.method_26195(blockGetter, blockPos, direction);
    }

    @Override
    public int method_9524(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        if (!this.isRelay || !blockState.method_11654(POWERED)) {
            return 0;
        } else {
            return blockState.method_11654(field_10927) == direction ? blockState.method_11654(POWER)-this.loss : 0;
        }
    }

    @Override
    public void method_9612(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_2338 blockPos2, boolean bl) {
        if (this.isRelay)
            this.checkTickOnNeighbor(level, blockPos, blockState);
    }

    protected void checkTickOnNeighbor(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        boolean powered = blockState.method_11654(POWERED);
        int power = blockState.method_11654(POWER);
        int s = this.getInputSignal(level, blockPos, blockState);
        if ((s != power || powered != s > 0) && !level.method_8397().method_8677(blockPos, this)) {
            class_1953 tickPriority = class_1953.field_9310;
            if (this.shouldPrioritize(level, blockPos, blockState)) {
                tickPriority = class_1953.field_9315;
            } else if (powered) {
                tickPriority = class_1953.field_9313;
            }

            level.method_39280(blockPos, this, this.delay, tickPriority);
        }
    }

    protected void updateNeighborsOnBack(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        class_2350 direction = blockState.method_11654(field_10927);
        class_2338 blockPos2 = blockPos.method_10093(direction.method_10153());
        level.method_8492(blockPos2, this, blockPos);
        level.method_8508(blockPos2, this, direction);
    }

    public static boolean isRelay(class_2680 blockState) {
        return blockState.method_26204() instanceof PoweredDirectionBlock poweredDirectionBlock && poweredDirectionBlock.isRelay;
    }

    public boolean shouldPrioritize(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState) {
        class_2350 direction = blockState.method_11654(field_10927).method_10153();
        class_2680 blockState2 = blockGetter.method_8320(blockPos.method_10093(direction));
        return isRelay(blockState2) && blockState2.method_11654(field_10927) != direction;
    }

    @Override
    public void method_9588(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        if (this.isRelay) {
            boolean powered = blockState.method_11654(POWERED);
            int power = blockState.method_11654(POWER);
            int inputPower = this.getInputSignal(serverLevel, blockPos, blockState);
            if (powered && inputPower <= 0) {
                serverLevel.method_8652(blockPos, blockState.method_11657(POWERED, false).method_11657(POWER, 0), 3);
            } else if (!powered || power != inputPower) {
                serverLevel.method_8652(blockPos, blockState.method_11657(POWERED, true).method_11657(POWER, inputPower), 3);

                if (inputPower <= 0) {
                    serverLevel.method_39280(blockPos, this, this.delay, class_1953.field_9313);
                }
            }

            this.updateNeighborsOnBack(serverLevel, blockPos, blockState);
        }
    }

    protected int getInputSignal(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        class_2350 direction = blockState.method_11654(field_10927);
        class_2338 blockPos2 = blockPos.method_10093(direction);
        class_2680 state = level.method_8320(blockPos2);
        if (state.method_26204() instanceof PoweredDirectionBlock poweredDirectionBlock && poweredDirectionBlock.isRelay) {
            return state.method_11654(POWER);
        } else if (state.method_27852(class_2246.field_10091)) {
            return state.method_11654(class_2457.field_11432);
        }
        return level.method_49808(blockPos2, direction);
    }

    public void method_9615(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        this.updateNeighborsOnBack(level, blockPos, blockState);
    }

    public void method_9536(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        if (!bl && !blockState.method_27852(blockState2.method_26204())) {
            super.method_9536(blockState, level, blockPos, blockState2, bl);
            this.updateNeighborsOnBack(level, blockPos, blockState);
        }
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return stateMap.get(String.format("%s,powered=%b", state.method_11654(field_10927).method_15434(), state.method_11654(POWERED)));
    }
}

package de.tomalbrc.filament.data;

import de.tomalbrc.filament.data.behaviours.block.BlockBehaviourList;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_9323;


public record BlockData(
        @NotNull class_2960 id,
        @NotNull BlockResource blockResource,
        @NotNull ItemResource itemResource,
        @NotNull BlockModelType blockModelType,
        @NotNull BlockProperties properties,
        @Nullable BlockType type,
        @Nullable BlockBehaviourList behaviour,
        @Nullable class_9323 components
        ) {
    public HashMap<String, class_2680> createStateMap() {
        HashMap<String, class_2680> val = new HashMap<>();

        if (blockResource.couldGenerate()) {
            //val = BlockModelGenerator.generate(blockResource);
            throw new UnsupportedOperationException("Not implemented");
        }
        else if (blockResource.models() != null) {
            for (HashMap.Entry<String, class_2960> entry : this.blockResource.models().entrySet()) {
                PolymerBlockModel blockModel = PolymerBlockModel.of(entry.getValue());

                var requestedState = PolymerBlockResourceUtils.requestBlock(this.blockModelType, blockModel);
                val.put(entry.getKey(), requestedState);

                if (requestedState.method_28498(class_2482.field_11502) && requestedState.method_28498(class_2482.field_11501)) {
                    PolymerBlockResourceUtils.requestBlock(this.blockModelType, blockModel);
                }
            }
        }

        return val;
    }

    public boolean isPowersource() {
        return this.behaviour != null && this.behaviour.powersource != null;
    }

    public boolean isRepeater() {
        return this.behaviour != null && this.behaviour.repeater != null;
    }

    public boolean isFuel() {
        return this.behaviour != null && this.behaviour.fuel != null;
    }

    public boolean isCosmetic() {
        return this.behaviour != null && this.behaviour.cosmetic != null;
    }

    public enum BlockType {
        block,
        column,
        count,
        powerlevel,
        powered_directional,
        slab,
        directional, // not supported yet
        horizontal_directional // not supported yet
    }
}

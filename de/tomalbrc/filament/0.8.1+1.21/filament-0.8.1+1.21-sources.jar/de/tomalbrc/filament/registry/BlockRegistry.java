package de.tomalbrc.filament.registry;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.block.SimpleBlockItem;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Json;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.class_9336;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class BlockRegistry {
    public static int REGISTERED_BLOCKS = 0;

    public static void register(InputStream inputStream) throws IOException {
        register(Json.GSON.fromJson(new InputStreamReader(inputStream, StandardCharsets.UTF_8), BlockData.class));
    }

    public static void register(BlockData data) throws IOException {
        if (class_7923.field_41175.method_10250(data.id())) return;

        BlockProperties properties = data.properties();
        class_4970.class_2251 blockProperties = properties.toBlockProperties();

        SimpleBlock customBlock = new SimpleBlock(blockProperties, data);
        BehaviourUtil.postInitBlock(customBlock, customBlock, data.behaviourConfig());

        var itemProperties = data.properties().toItemProperties();
        if (data.components() != null) {
            for (class_9336 component : data.components()) {
                itemProperties.method_57349(component.comp_2443(), component.comp_2444());
            }
        }
        SimpleBlockItem item = new SimpleBlockItem(itemProperties, customBlock, data);
        BehaviourUtil.postInitItem(item, item, data.behaviourConfig());

        BlockRegistry.registerBlock(data.id(), customBlock);
        ItemRegistry.registerItem(data.id(), item, ItemRegistry.CUSTOM_BLOCK_ITEMS);

        customBlock.postRegister();

        REGISTERED_BLOCKS++;
    }

    public static void registerBlock(class_2960 identifier, class_2248 block) {
        class_2378.method_10230(class_7923.field_41175, identifier, block);
    }

    public static class BlockDataReloadListener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, Constants.MOD_ID);
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/block", path -> path.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {

                try (var reader = new InputStreamReader(entry.getValue().method_14482())) {
                    BlockData data = Json.GSON.fromJson(reader, BlockData.class);
                    BlockRegistry.register(data);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load block resource \"" + entry.getKey() + "\".");
                }
            }
        }
    }
}

package de.tomalbrc.filament.decoration;

import com.griefdefender.api.GriefDefender;
import com.griefdefender.api.claim.Claim;
import com.griefdefender.lib.flowpowered.math.vector.Vector3i;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class GriefDefenderSupport {
    public static boolean isAdminClaim(class_1937 level, class_2338 blockPos) {
        final Claim claim = GriefDefender.getCore().getClaimManager(GriefDefender.getCore().getWorldUniqueId(level)).getClaimAt(new Vector3i(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260()));
        return claim != null && claim.isAdminClaim();
    }
}

package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4538;
import net.minecraft.class_7225;

public interface DecorationBehaviour<T> extends Behaviour<T> {
    default void init(DecorationBlockEntity blockEntity) {
    }

    default ElementHolder createHolder(DecorationBlockEntity blockEntity) {
        return null;
    }

    default void onElementAttach(DecorationBlockEntity blockEntity, ElementHolder holder) {
    }

    default class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        return class_1269.field_5811;
    }

    default void read(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {
    }

    default void write(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {
    }

    default void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
    }

    default void modifyDrop(DecorationBlockEntity decorationBlockEntity, class_1799 itemStack) {
    }

    default class_1799 getCloneItemStack(class_1799 stack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return stack;
    }

    default void postBreak(DecorationBlockEntity decorationBlockEntity, class_2338 blockPos, class_1657 player) {

    }
}
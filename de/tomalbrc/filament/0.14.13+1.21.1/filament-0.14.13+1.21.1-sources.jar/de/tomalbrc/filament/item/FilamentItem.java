package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import net.minecraft.class_5151;

public interface FilamentItem extends BehaviourHolder, class_5151 {

}

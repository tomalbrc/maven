package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import net.minecraft.class_1540;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;

public class FallingBlock implements BlockBehaviour<FallingBlock.Config> {
    private final Config config;

    public FallingBlock(Config config) {
        this.config = config;
    }

    @Override
    public @NotNull FallingBlock.Config getConfig() {
        return config;
    }

    @Override
    public void onPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        level.method_39279(blockPos, blockState.method_26204(), config.delayAfterPlace.getValue(blockState));
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        levelAccessor.method_39279(blockPos, blockState.method_26204(), config.delayAfterPlace.getValue(blockState));
        return BlockBehaviour.super.updateShape(blockState, direction, blockState2, levelAccessor, blockPos, blockPos2);
    }

    @Override
    public void tick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        if (net.minecraft.class_2346.method_10128(serverLevel.method_8320(blockPos.method_10074())) && blockPos.method_10264() >= serverLevel.method_31607()) {
            class_1540 fallingBlockEntity = class_1540.method_40005(serverLevel, blockPos, blockState);

            if (config.disableDrops.getValue(blockState))
                fallingBlockEntity.method_49181();

            fallingBlockEntity.field_7193 = config.dropItem.getValue(blockState);

            fallingBlockEntity.method_5803(true);
            this.falling(fallingBlockEntity);
        }
    }

    private void falling(class_1540 fallingBlockEntity) {
        if (config.heavy.getValue(fallingBlockEntity.method_6962()))
            fallingBlockEntity.method_6965(config.damagePerDistance.getValue(fallingBlockEntity.method_6962()), config.maxDamage.getValue(fallingBlockEntity.method_6962()));
    }

    @Override
    public void onLand(class_1937 level, class_2338 blockPos, class_2680 blockState, class_2680 blockState2, class_1540 fallingBlockEntity) {
        if (!config.silent.getValue(blockState)) {
            level.method_45447(null, blockPos, class_3414.method_47908(config.landSound.getValue(blockState2)), class_3419.field_15245);
        }
    }

    @Override
    public void onBrokenAfterFall(class_1937 level, class_2338 blockPos, class_1540 fallingBlockEntity) {
        var bs = level.method_8320(blockPos);
        if (!config.silent.getValue(bs)) {
            level.method_45447(null, blockPos, class_3414.method_47908(config.breakSound.getValue(bs)), class_3419.field_15245);
        }
    }

    public static class Config {
        public BlockStateMappedProperty<Boolean> dropItem = BlockStateMappedProperty.of(true) ;
        BlockStateMappedProperty<Integer> delayAfterPlace = BlockStateMappedProperty.of(2);
        BlockStateMappedProperty<Boolean> heavy = BlockStateMappedProperty.of(false);
        public BlockStateMappedProperty<Float> damagePerDistance = BlockStateMappedProperty.of(2.f);
        public BlockStateMappedProperty<Integer> maxDamage = BlockStateMappedProperty.of(40);
        BlockStateMappedProperty<Boolean> disableDrops = BlockStateMappedProperty.of(false);
        BlockStateMappedProperty<Boolean> silent = BlockStateMappedProperty.of(false);
        BlockStateMappedProperty<class_2960> breakSound = BlockStateMappedProperty.of(class_3417.field_14542.method_14833());
        BlockStateMappedProperty<class_2960> landSound = BlockStateMappedProperty.of(class_3417.field_14833.method_14833());
        public BlockStateMappedProperty<Boolean> canBeDamaged = BlockStateMappedProperty.of(false);
        public BlockStateMappedProperty<class_2960> damagedBlock = null;
        public BlockStateMappedProperty<Float> baseBreakChance = BlockStateMappedProperty.of(0.05f);
        public BlockStateMappedProperty<Float> breakChancePerDistance = BlockStateMappedProperty.of(0.05f);
    }
}

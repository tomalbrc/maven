package de.tomalbrc.filament.mixin.behaviour.bow;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.FilamentItem;
import net.minecraft.class_1308;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public abstract class MobMixin {
    @Shadow public abstract boolean canReplaceEqualItem(class_1799 itemStack, class_1799 itemStack2);

    @Inject(method = "canReplaceCurrentItem", at = @At("HEAD"), cancellable = true)
    private void filament$onCanReplaceCurrentItem(class_1799 itemStack, class_1799 itemStack2, CallbackInfoReturnable<Boolean> cir) {
        if (filament$isBow(itemStack) && filament$isBow(itemStack2)) {
            cir.setReturnValue(this.canReplaceEqualItem(itemStack, itemStack2));
        }
    }

    @Unique
    private boolean filament$isBow(class_1799 itemStack) {
        return itemStack.method_7909() instanceof FilamentItem simpleItem && simpleItem.has(Behaviours.BOW) || itemStack.method_7909() instanceof class_1753;
    }
}

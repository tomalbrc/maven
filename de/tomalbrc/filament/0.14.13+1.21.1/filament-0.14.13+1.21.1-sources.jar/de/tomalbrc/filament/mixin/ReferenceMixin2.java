package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.registry.ItemRegistry;
import it.unimi.dsi.fastutil.objects.ReferenceArraySet;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7923;

@Mixin(class_6880.class_6883.class)
public abstract class ReferenceMixin2<T> implements class_6880<T> {
    @Shadow @Nullable private T value;

    @Shadow @Nullable private Set<class_6862<T>> tags;

    @Inject(method = "bindTags", at = @At("HEAD"), cancellable = true)
    private void filament$bind(Collection<class_6862<T>> collection, CallbackInfo ci) {
        class_1792 x = ItemRegistry.COPY_TAGS.get(value);
        if (x != null) {
            Map<class_6862<class_1792>, class_6885.class_6888<class_1792>> set = ((MappedRegistryAccessor)class_7923.field_41178).getTags();
            var newSet = new ReferenceArraySet<class_6862<T>>();
            set.forEach((tagKey,blockNamed) -> {
                for (class_6880<class_1792> holder : blockNamed) {
                    if (holder == x) {
                        newSet.add((class_6862<T>) tagKey);
                    }
                }
            });

            this.tags = Set.copyOf(newSet);
            ci.cancel();
        }
    }
}

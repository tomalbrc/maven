package de.tomalbrc.filament.mixin.behaviour.shield;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.FilamentItem;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1309.class)
public abstract class LivingEntityMixin {
    @Shadow public abstract class_1799 getUseItem();

    @Inject(method = "isBlocking", at = @At(value = "RETURN"), cancellable = true)
    private void filament$customShieldBlocking(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue() && this.getUseItem().method_7909() instanceof FilamentItem simpleItem && simpleItem.has(Behaviours.SHIELD)) {
            cir.setReturnValue(true);
        }
    }
}

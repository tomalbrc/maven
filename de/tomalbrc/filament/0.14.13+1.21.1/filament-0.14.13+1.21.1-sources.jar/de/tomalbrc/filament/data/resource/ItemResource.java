package de.tomalbrc.filament.data.resource;

import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import net.minecraft.class_2960;

public class ItemResource {
    private Map<String, class_2960> models = new Object2ObjectArrayMap<>();
    private class_2960 parent = class_2960.method_60656("item/generated");
    private Map<String, Map<String, class_2960>> textures;

    public static ItemResource of(Map<String, class_2960> models, class_2960 parent,  Map<String, Map<String, class_2960>> textures) {
        ItemResource resource = new ItemResource();
        if (models != null) resource.models = models;
        if (parent != null) resource.parent = parent;
        resource.textures = textures;
        return resource;
    }

    public boolean couldGenerate() {
        return models.isEmpty() && this.textures != null;
    }

    public Map<String, Map<String, class_2960>> textures() {
        return textures;
    }

    public class_2960 parent() {
        return parent;
    }

    public Map<String, class_2960> models() {
        return models;
    }
}

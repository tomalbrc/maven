package de.tomalbrc.filament.item;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.data.properties.ItemProperties;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_5151;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Universal item, base for all filament items, with behaviour support
 * I wish BlockItem was an interface...
 */
public class SimpleBlockItemBase extends class_1747 implements PolymerItem, FilamentItem, class_5151, BehaviourHolder {
    protected ItemData itemData;
    protected ItemProperties properties;
    protected Object2ObjectOpenHashMap<String, PolymerModelData> modelData;

    protected final class_1792 vanillaItem;

    protected final BehaviourMap behaviours = new BehaviourMap();

    public BehaviourMap getBehaviours() {
        return this.behaviours;
    }

    public SimpleBlockItemBase(class_2248 block, class_1793 properties, ItemData itemData, class_1792 vanillaItem) {
        super(block, properties);
        this.initBehaviours(itemData.behaviourConfig());

        this.vanillaItem = vanillaItem;
        this.itemData = itemData;
        this.properties = itemData.properties();
        this.modelData = this.itemData.requestModels(behaviours);
    }

    public SimpleBlockItemBase(class_2248 block, class_1793 itemProperties, ItemProperties props, class_1792 vanillaItem) {
        super(block, itemProperties);

        this.vanillaItem = vanillaItem;
        this.properties = props;
    }

    @Override
    @NotNull
    public String method_7876() {
        return this.method_7711() != null ? this.method_7711().method_9539() : this.method_7869();
    }

    @Override
    @Nullable
    public class_2248 method_7711() {
        return super.method_7711();
    }

    @Override
    @NotNull
    public class_7699 method_45322() {
        return this.method_7711() != null ? this.method_7711().method_45322() : this.vanillaItem.method_45322();
    }

    @Override
    public void method_7852(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.onUseTick(level, livingEntity, itemStack, i);
            }
        }
    }

    @Override
    public void method_7840(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.releaseUsing(itemStack, level, livingEntity, useDuration);
            }
        }
    }

    @Override
    public boolean method_7838(class_1799 itemStack) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                boolean didUse = itemBehaviour.useOnRelease(itemStack);
                if (didUse)
                    return true;
            }
        }
        return false;
    }

    @Override
    public int method_7837() {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var val = itemBehaviour.getEnchantmentValue();
                if (val.isPresent())
                    return val.get();
            }
        }
        return super.method_7837();
    }

    @Override
    public int method_7881(class_1799 itemStack, class_1309 livingEntity) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var val = itemBehaviour.getUseDuration(itemStack, livingEntity);
                if (val.isPresent())
                    return val.get();
            }
        }

        return super.method_7881(itemStack, livingEntity);
    }

    @Override
    public boolean method_7873(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var res = itemBehaviour.hurtEnemy(itemStack, livingEntity, livingEntity2);
                if (res.isPresent()) {
                    return res.orElseThrow();
                }
            }
        }

        return this.method_57347().method_57832(class_9334.field_50077);
    }

    @Override
    public void method_59978(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.postHurtEnemy(itemStack, livingEntity, livingEntity2);
            }
        }

        if (this.method_57347().method_57832(class_9334.field_50077))
            itemStack.method_7970(1, livingEntity2, class_1304.field_6173);
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.appendHoverText(itemStack, tooltipContext, list, tooltipFlag);
            }
        }
        this.properties.appendHoverText(list);
        super.method_7851(itemStack, tooltipContext, list, tooltipFlag);
    }

    @Override
    public boolean method_7878(class_1799 itemStack, class_1799 itemStack2) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var valid = itemBehaviour.isValidRepairItem(itemStack, itemStack2);
                if (valid)
                    return true;
            }
        }
        return super.method_7878(itemStack, itemStack2);
    }

    @Override
    @NotNull
    public class_6880<class_3414> method_31570() {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var sound = itemBehaviour.getEquipSound();
                if (sound != null)
                    return sound;
            }
        }
        return FilamentItem.super.method_31570();
    }

    @Override
    public class_1799 getPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, class_7225.class_7874 lookup, @Nullable class_3222 player) {
        class_1799 itemStack1 = PolymerItemUtils.createItemStack(itemStack, tooltipType, lookup, player);
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.modifyPolymerItemStack(itemStack, itemStack1, tooltipType, lookup, player);
            }
        }
        return itemStack1;
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, @Nullable class_3222 player) {
        return this.vanillaItem != null ? this.vanillaItem : class_1802.field_8407;
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var data = itemBehaviour.modifyPolymerCustomModelData(this.modelData, itemStack, player);
                if (data != -1) {
                    return data;
                }
            }
        }

        return this.modelData != null ?
                this.modelData.get("default").value() : itemData.components().method_57832(class_9334.field_49628) ?
                Objects.requireNonNull(itemData.components().method_57829(class_9334.field_49637)).comp_2382() : -1;
    }

    @Override
    public int getPolymerArmorColor(class_1799 itemStack, @Nullable class_3222 player) {
        int color = -1;
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                color = itemBehaviour.modifyPolymerArmorColor(itemStack, player, color);
            }
        }
        return color;
    }

    @Override
    @NotNull
    public class_1304 method_7685() {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var slot = itemBehaviour.getEquipmentSlot();
                if (slot != class_1304.field_6173) {
                    return slot;
                }
            }
        }
        return class_1304.field_6173;
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);
        if (res.method_5467().method_23665()) {
            return res;
        }

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                res = itemBehaviour.use(this, level, user, hand);
                if (res.method_5467().method_23665()) {
                    return res;
                }
            }
        }

        return res;
    }

    @Override
    @NotNull
    public class_1269 method_7884(class_1838 useOnContext) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var res = itemBehaviour.useOn(useOnContext);
                if (res.method_23665()) {
                    return res;
                }
            }
        }

        if (this.method_7711() instanceof SimpleBlock) {
            var res = super.method_7884(useOnContext);
            if (res.method_23665()) {
                return res;
            }
        }

        return class_1269.field_5814;
    }

    @Override
    protected boolean method_7708(class_1750 context, class_2680 state) {
        if (!super.method_7708(context, state)) {
            return false;
        }

        if (context.method_8036() instanceof class_3222 player) {
            Util.handleBlockPlaceEffects(player, context.method_20287(), context.method_8037(), state.method_26231());
        }

        return true;
    }

    @Override
    public boolean method_7879(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_1309 livingEntity) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var res = itemBehaviour.mineBlock(itemStack, level, blockState, blockPos, livingEntity);
                if (res) {
                    return true;
                }
            }
        }

        return super.method_7879(itemStack, level, blockState, blockPos, livingEntity);
    }

    public ItemData getItemData() {
        return this.itemData;
    }

    /// Entity Damaging behaviours
    @Override
    public float method_58403(class_1297 entity, float f, class_1282 damageSource) {
        float attackBonus = super.method_58403(entity, f, damageSource);
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                attackBonus += itemBehaviour.getAttackDamageBonus(entity, f, damageSource);
            }
        }

        return attackBonus;
    }
}

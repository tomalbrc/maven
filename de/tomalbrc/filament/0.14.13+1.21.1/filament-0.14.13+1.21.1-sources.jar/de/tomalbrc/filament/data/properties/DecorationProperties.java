package de.tomalbrc.filament.data.properties;

import de.tomalbrc.filament.decoration.block.DecorationBlock;
import net.minecraft.class_2350;
import net.minecraft.class_4970;
import net.minecraft.class_811;
import org.joml.Vector3f;

public class DecorationProperties extends BlockProperties {
    public static final DecorationProperties EMPTY = new DecorationProperties();

    public boolean rotate = false;
    public boolean rotateSmooth = false;

    public Placement placement = Placement.DEFAULT;
    public boolean glow = false;

    public boolean waterloggable = true;

    public class_811 display = class_811.field_4319;

    public boolean useItemParticles = true;

    public boolean showBreakParticles = true;

    public boolean drops = true;
    public Vector3f scale;
    public boolean allowAdventureMode;

    @Override
    public class_4970.class_2251 toBlockProperties() {
        class_4970.class_2251 props = super.toBlockProperties();
        props.method_9631((state) -> state.method_28498(DecorationBlock.LIGHT_LEVEL) ? state.method_11654(DecorationBlock.LIGHT_LEVEL) : 0);
        return props.method_9624().method_22488();
    }

    public record Placement(boolean wall, boolean floor, boolean ceiling) {
        public static Placement DEFAULT = new Placement(false, true, false);
        public boolean canPlace(class_2350 direction) {
            boolean upDown = direction == class_2350.field_11036 || direction == class_2350.field_11033;
            return (wall && !upDown) || (floor && direction == class_2350.field_11036) || (ceiling && direction == class_2350.field_11033);
        }
    }
}

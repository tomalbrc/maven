package de.tomalbrc.filament.util;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class BackpackMenu {
    public static class_1703 create(int id, class_1661 inventory, class_1263 container, int selectedSlot) {
        return new class_1733(id, inventory, container) {
            @Override
            protected void method_61622(class_1263 container, int x, int y) {
                for (int slot = 0; slot < 9; ++slot) {
                    this.method_7621(new BackpackHotbarSlot(container, selectedSlot, slot, x + slot * 18, y));
                }
            }

            public static class BackpackHotbarSlot extends class_1735 {
                final int selectedSlot;

                public BackpackHotbarSlot(class_1263 container, int selectedSlot, int slot, int x, int y) {
                    super(container, slot, x, y);
                    this.selectedSlot = selectedSlot;
                }

                @Override
                public boolean method_7674(class_1657 player) {
                    return this.selectedSlot != method_34266() && super.method_7674(player);
                }

                @Override
                public boolean method_7680(class_1799 itemStack) {
                    return this.selectedSlot != method_34266() && super.method_7680(itemStack);
                }

                @Override
                public boolean method_32754(class_1657 player) {
                    return this.selectedSlot != method_34266();
                }
            }
        };
    }

}

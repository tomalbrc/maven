package de.tomalbrc.filament.item;

import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.ContainerLike;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.data.properties.ItemProperties;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_6903;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import java.util.function.Consumer;

/**
 * Simple item, base for filament items without block (+ decorations), with behaviour support
 */
public class SimpleItem extends class_1792 implements PolymerItem, FilamentItem, BehaviourHolder {
    protected final Data<?> data;
    protected final ItemProperties properties;
    protected final class_1792 vanillaItem;

    protected final BehaviourMap behaviours = new BehaviourMap();
    protected final FilamentItemDelegate delegate;

    public SimpleItem(class_1793 properties, Data<?> data, class_1792 vanillaItem) {
        super(properties);
        this.initBehaviours(data.behaviour());

        this.vanillaItem = vanillaItem;
        this.data = data;
        this.properties = data.properties();
        this.delegate = new FilamentItemDelegate(this);
    }

    @Override
    public BehaviourMap getBehaviours() {
        return this.behaviours;
    }

    @Override
    public Data<?> getData() {
        return this.data;
    }

    @Override
    public FilamentItemDelegate getDelegate() {
        return this.delegate;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void verifyComponentsAfterLoad(class_1799 itemStack) {
        if (this.data != null) {
            for (Map.Entry<class_9331<?>, JsonElement> entry : this.data.getAdditionalComponents().entrySet()) {
                var codec = entry.getKey().method_57875();
                assert codec != null;

                class_6903.class_7863 registryInfoLookup = Json.DataComponentsDeserializer.createContext(Filament.REGISTRY_ACCESS.method_45926());
                var result = codec.decode(class_6903.method_40414(JsonOps.INSTANCE, registryInfoLookup), entry.getValue());
                if (result.hasResultOrPartial()) {
                    class_9331 type = entry.getKey();
                    itemStack.method_57379(type, result.getOrThrow().getFirst());
                }
            }
        }
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 itemStack) {
        var dataName = this.data.displayName();
        return dataName != null ? dataName : data.components().method_57832(class_9334.field_50239) ? data.components().method_58694(class_9334.field_50239) : super.method_7864(itemStack);
    }

    @Override
    public void method_7852(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
        this.delegate.onUseTick(level, livingEntity, itemStack, i);
    }

    @Override
    public boolean method_7840(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        return this.delegate.releaseUsing(itemStack, level, livingEntity, useDuration, () -> super.method_7840(itemStack, level, livingEntity, useDuration));
    }

    @Override
    public boolean method_7838(class_1799 itemStack) {
        return this.delegate.useOnRelease(itemStack, () -> super.method_7838(itemStack));
    }

    @Override
    public int method_7881(class_1799 itemStack, class_1309 livingEntity) {
        return this.delegate.getUseDuration(itemStack, livingEntity, () -> super.method_7881(itemStack, livingEntity));
    }

    @Override
    @NotNull
    public class_1839 method_7853(class_1799 itemStack) {
        return this.delegate.getUseAnimation(itemStack, () -> super.method_7853(itemStack));
    }

    @Override
    public void method_7873(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        this.delegate.hurtEnemy(itemStack, livingEntity, livingEntity2);
    }

    @Override
    public void method_59978(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        this.delegate.postHurtEnemy(itemStack, livingEntity, livingEntity2);
    }

    @Override
    public void method_67187(class_1799 itemStack, class_1792.class_9635 tooltipContext, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 tooltipFlag) {
        this.delegate.appendHoverText(itemStack, tooltipContext, tooltipDisplay, consumer, tooltipFlag);
        this.properties.appendHoverText(consumer);
        super.method_67187(itemStack, tooltipContext, tooltipDisplay, consumer, tooltipFlag);
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, PacketContext packetContext) {
        return this.vanillaItem != null ? this.vanillaItem : class_1802.field_8407;
    }

    @Override
    public final class_1799 getPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, PacketContext packetContext) {
        return Util.filamentItemStack(itemStack, tooltipType, packetContext, this);
    }

    @Override
    @NotNull
    public class_1269 method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        return this.delegate.use(this, level, user, hand, () -> super.method_7836(level, user, hand));
    }

    @Override
    @NotNull
    public class_1269 method_7884(class_1838 useOnContext) {
        return this.delegate.useOn(useOnContext, () -> useOnContext.method_8041().method_57826(class_9334.field_53964) ? super.method_7836(useOnContext.method_8045(), useOnContext.method_8036(), useOnContext.method_20287()) : class_1269.field_5814);
    }

    @Override
    public boolean method_7879(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_1309 livingEntity) {
        return this.delegate.mineBlock(itemStack, level, blockState, blockPos, livingEntity, () -> super.method_7879(itemStack, level, blockState, blockPos, livingEntity));
    }

    /// Entity Damaging behaviours
    @Override
    public float method_58403(class_1297 entity, float f, class_1282 damageSource) {
        return this.delegate.getAttackDamageBonus(entity, f, damageSource, () -> super.method_58403(entity, f, damageSource));
    }

    @Override
    @Nullable
    public class_1282 method_64193(class_1309 livingEntity) {
        return this.delegate.getDamageSource(livingEntity, () -> super.method_64193(livingEntity));
    }

    @Override
    public boolean method_31568() {
        var c = DecorationData.getFirstContainer(this);
        if (c != null && c.canPickUp())
            return false;

        return super.method_31568();
    }
}

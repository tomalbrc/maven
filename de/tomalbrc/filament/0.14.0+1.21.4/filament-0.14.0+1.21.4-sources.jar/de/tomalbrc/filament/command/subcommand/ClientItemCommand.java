package de.tomalbrc.filament.command.subcommand;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.mojang.serialization.JsonOps;
import eu.pb4.polymer.core.api.item.PolymerItem;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_6903;
import net.minecraft.class_9323;
import xyz.nucleoid.packettweaker.PacketContext;

public class ClientItemCommand {
    public static LiteralCommandNode<class_2168> register() {
        var node = class_2170
                .method_9247("client-item").requires(Permissions.require("filament.command.client-item", 2));

        return node.executes(ClientItemCommand::execute).build();
    }

    private static int execute(CommandContext<class_2168> context) {
        var player = context.getSource().method_44023();
        if (player != null) {
            var handItem = player.method_5998(class_1268.field_5808);
            var isPolymerItem = handItem.method_7909() instanceof PolymerItem;
            if (handItem.method_7909() instanceof PolymerItem polymerItem) {
                handItem = polymerItem.getPolymerItemStack(handItem, class_1836.field_41070, PacketContext.create(player));
            }
            class_1799.field_24671.encodeStart(class_6903.method_46632(JsonOps.INSTANCE, player.method_56673()), handItem).ifSuccess(jsonElement -> context.getSource().method_9226(() -> class_2561.method_43470("Client Item: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1077)).method_10852(class_2561.method_43470(jsonElement.toString()).method_27692(class_124.field_1068)), false));
            class_9323.field_50234.encodeStart(class_6903.method_46632(JsonOps.INSTANCE, player.method_56673()), handItem.method_57353()).ifSuccess(jsonElement -> context.getSource().method_9226(() -> class_2561.method_43470("Components: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1060)).method_10852(class_2561.method_43470(jsonElement.toString()).method_10862(class_2583.field_24360.method_10977(class_124.field_1068))), false));
            if (!isPolymerItem) context.getSource().method_9226(() -> class_2561.method_43470("Not a polymer item!").method_10862(class_2583.field_24360.method_10977(class_124.field_1065)), false);
        }
        return 0;
    }
}

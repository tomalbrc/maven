package de.tomalbrc.filament.mixin.component.skin;

import de.tomalbrc.filament.registry.FilamentComponents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

@Mixin(class_1799.class)
public class ItemStackMixin {
    @Inject(method = "applyDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isBroken()Z"))
    private void filament$dontDestroySkin(int i, class_3222 serverPlayer, Consumer<class_1792> consumer, CallbackInfo ci) {
        var self = class_1799.class.cast(this);
        if (self.method_61657() && self.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var skinItem = self.method_57824(FilamentComponents.SKIN_DATA_COMPONENT);
            if (skinItem != null && !skinItem.method_7960()) {
                if (!serverPlayer.method_7270(skinItem))
                    serverPlayer.method_5775(serverPlayer.method_51469(), skinItem);

                self.method_57381(FilamentComponents.SKIN_DATA_COMPONENT);
            }
        }
    }
}

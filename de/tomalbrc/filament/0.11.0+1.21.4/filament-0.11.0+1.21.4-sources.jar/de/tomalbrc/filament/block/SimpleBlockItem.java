package de.tomalbrc.filament.block;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.item.SimpleItem;
import eu.pb4.polymer.core.api.item.PolymerItem;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_9280;

public class SimpleBlockItem extends SimpleItem implements PolymerItem, BehaviourHolder {
    private final BlockData blockData;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties, data.properties(), data.vanillaItem());
        this.blockData = data;
        this.initBehaviours(data.behaviour());
    }

    @Override
    protected Map<String, class_2960> getModelMap() {
        return this.blockData.itemResource() == null ? Map.of() : Objects.requireNonNull(this.blockData.itemResource()).models();
    }

    @Override
    protected class_9280 getModel() {
        if (this.blockData.itemResource() != null)
            return null; // default model, not modified
        else
            return new class_9280(List.of(), List.of(), List.of(this.blockData.blockResource().models().entrySet().iterator().next().getKey()), List.of());
    }
}
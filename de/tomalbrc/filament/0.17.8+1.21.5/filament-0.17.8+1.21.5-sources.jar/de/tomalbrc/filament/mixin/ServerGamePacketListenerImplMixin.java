package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.util.DecorationUtil;
import de.tomalbrc.filament.util.VirtualDestroyStage;
import net.minecraft.class_10371;
import net.minecraft.class_1799;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerImplMixin implements VirtualDestroyStage.ServerGamePacketListenerExtF {
    @Shadow protected abstract void tryPickItem(class_1799 itemStack);

    @Unique
    private final VirtualDestroyStage filament$virtualDestroyStageF = new VirtualDestroyStage();

    @Override
    public VirtualDestroyStage filament$getVirtualDestroyStage() {
        return this.filament$virtualDestroyStageF;
    }

    @Inject(method = "handlePickItemFromEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;getEntityOrPart(I)Lnet/minecraft/world/entity/Entity;"), cancellable = true)
    private void filament$handleEntityPick(class_10371 serverboundPickItemFromEntityPacket, CallbackInfo ci) {
        var v = DecorationUtil.VIRTUAL_ENTITY_PICK_MAP.get(serverboundPickItemFromEntityPacket.comp_3328());
        if (v != null) {
            this.tryPickItem(v.get());
            ci.cancel();
        }
    }
}

package de.tomalbrc.filament.mixin.copper_golem;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_11568;
import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_11568.class_11572.class)
public class TransportItemsBetweenContainersMixin {
    @Inject(method = "getBlockEntityContainer", at = @At("RETURN"), cancellable = true)
    private static void filament$getContainer(class_2586 blockEntity, class_2680 blockState, class_1937 level, class_2338 blockPos, CallbackInfoReturnable<class_1263> cir) {
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            var res = decorationBlockEntity.getMainBlockEntity().getDecorationData().getFirstContainer(decorationBlockEntity);
            if (res != null) {
                cir.setReturnValue(res.container());
            }
        }
    }
}

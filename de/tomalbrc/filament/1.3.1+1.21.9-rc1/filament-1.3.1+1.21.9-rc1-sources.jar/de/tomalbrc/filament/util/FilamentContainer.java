package de.tomalbrc.filament.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_11565;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import net.minecraft.class_3222;

public class FilamentContainer extends class_1277 {
    List<class_11565> menus = new ObjectArrayList<>();

    private boolean valid = true;

    private final boolean purge;
    private final class_2586 blockEntity;

    private Runnable closeCallback;
    private Runnable openCallback;

    public FilamentContainer(class_2586 blockEntity, int size, boolean purge) {
        super(size);

        this.method_5489(x -> blockEntity.method_5431());
        this.blockEntity = blockEntity;
        this.purge = purge;
    }

    @Override
    public @NotNull List<class_11565> method_72379() {
        return menus;
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return this.valid && !blockEntity.method_11015();
    }

    @Override
    public boolean method_49104(class_1263 target, int slot, class_1799 stack) {
        return this.valid;
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return this.valid && !blockEntity.method_11015() && stack.method_7947() <= getMaxStackSize(slot) - method_5438(slot).method_7947();
    }

    public int getMaxStackSize(int slot) {
        return method_5444();
    }

    public void setValid(boolean valid) {
        if (!valid) {
            for (class_11565 entity : this.menus) {
                if (entity instanceof class_3222 player) player.method_7346();
            }
        }
        this.valid = valid;
    }

    public boolean hasViewers() {
        return !this.menus.isEmpty();
    }

    @Override
    public void method_5435(class_11565 containerUser) {
        super.method_5435(containerUser);

        if (!containerUser.method_72382().method_7325() && this.menus.isEmpty() && this.openCallback != null) {
            this.openCallback.run();
        }

        this.menus.add(containerUser);
    }

    @Override
    public void method_5432(class_11565 containerUser) {
        super.method_5432(containerUser);

        this.menus.remove(containerUser);

        if (this.menus.isEmpty() && this.closeCallback != null) {
            this.closeCallback.run();
        }

        if (this.purge && this.menus.isEmpty())
            this.method_5448();
    }

    public void setCloseCallback(Runnable closeCallback) {
        this.closeCallback = closeCallback;
    }

    public void setOpenCallback(Runnable openCallback) {
        this.openCallback = openCallback;
    }

    public class_2586 getBlockEntity() {
        return blockEntity;
    }
}

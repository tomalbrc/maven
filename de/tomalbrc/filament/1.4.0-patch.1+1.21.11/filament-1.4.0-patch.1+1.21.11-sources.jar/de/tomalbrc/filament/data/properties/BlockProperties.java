package de.tomalbrc.filament.data.properties;

import com.google.gson.annotations.SerializedName;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

@SuppressWarnings({"FieldCanBeLocal", "FieldMayBeFinal"})
public class BlockProperties extends ItemProperties {
    @NotNull
    private class_2248 blockBase = class_2246.field_10340;
    @Nullable private Boolean requiresTool = true;
    private Float explosionResistance = null;
    private Float destroyTime = null;

    private BlockStateMappedProperty<Boolean> isSuffocating = null;
    private BlockStateMappedProperty<Boolean> redstoneConductor = null;
    private BlockStateMappedProperty<Integer> lightEmission = null;

    private Boolean transparent = false;
    private Boolean allowsSpawning = false;
    private Boolean replaceable = false;
    private Boolean collision = true;

    private Boolean solid = true;

    private class_3619 pushReaction = class_3619.field_15974;

    private class_2960 lootTable = null;

    public Boolean virtual;
    private Boolean showBreakParticles = true;

    private Sounds sounds;

    public @NotNull class_2248 blockBase() {
        return blockBase;
    }

    public boolean requiresTool() {
        return requiresTool == null ? false : requiresTool;
    }

    public float explosionResistance() {
        return explosionResistance == null ? 0 : explosionResistance;
    }

    public float destroyTime() {
        return destroyTime == null ? 0 : destroyTime;
    }

    public BlockStateMappedProperty<Boolean> isSuffocating() {
        return isSuffocating;
    }

    public BlockStateMappedProperty<Boolean> redstoneConductor() {
        return redstoneConductor;
    }

    public BlockStateMappedProperty<Integer> lightEmission() {
        return lightEmission;
    }

    public boolean transparent() {
        return transparent == null ? false : transparent;
    }

    public boolean allowsSpawning() {
        return allowsSpawning == null ? false : allowsSpawning;
    }

    public boolean replaceable() {
        return replaceable == null ? false : replaceable;
    }

    public boolean collision() {
        return collision == null ? false : collision;
    }

    public boolean solid() {
        return solid  == null ? false : solid;
    }

    public class_3619 pushReaction() {
        return pushReaction;
    }

    public class_2960 lootTable() {
        return lootTable;
    }

    public boolean virtual() {
        return virtual == null ? false : virtual;
    }

    public boolean showBreakParticles() {
        return showBreakParticles == null ? false : showBreakParticles;
    }

    public Sounds sounds() {
        return sounds;
    }

    public class_4970.class_2251 toBlockProperties() {
        class_4970.class_2251 props = class_4970.class_2251.method_9637();
        props.method_9626(this.blockBase.method_9564().method_26231());
        if (this.sounds != null) {
            props.method_9626(this.sounds.asSoundType());
        }

        if (this.destroyTime != null) props.method_36557(this.destroyTime);
        if (this.explosionResistance != null) props.method_36558(this.explosionResistance);
        else if (this.destroyTime != null) props.method_36558(this.destroyTime);
        if (this.lightEmission != null) props.method_9631((state) -> this.lightEmission.getOrDefault(state, 0));
        if (this.redstoneConductor != null) props.method_26236((blockState, blockGetter, blockPos) -> this.redstoneConductor.getOrDefault(blockState, false));
        if (this.requiresTool == Boolean.TRUE) props.method_29292();
        if (this.replaceable == Boolean.TRUE) props.method_51371();
        if (this.transparent == Boolean.TRUE) props.method_22488();
        if (!this.collision == Boolean.TRUE) props.method_9634();

        if (this.lootTable != null)
            props.method_63502(Optional.of(class_5321.method_29179(class_7924.field_50079, this.lootTable)));

        if (this.isSuffocating != null)
            props.method_26243((blockState, blockGetter, blockPos) -> this.isSuffocating.getValue(blockState));

        props.method_31710(this.blockBase.method_26403());

        if (this.solid == Boolean.TRUE) props.method_51369();
        else props.method_51370();

        props.method_26235((blockState, blockGetter, blockPos, entityType) -> this.allowsSpawning);
        props.method_50012(this.pushReaction);

        return props;
    }

    public record Sounds(
            float volume,
            float pitch,
            @SerializedName("break") class_2960 breakSound,
            @SerializedName("step") class_2960 stepSound,
            @SerializedName("place") class_2960 placeSound,
            @SerializedName("hit") class_2960 hitSound,
            @SerializedName("fall") class_2960 fallSound
    ) {
        class_2498 asSoundType() {
            return new class_2498(
                    volume,
                    pitch,
                    class_3414.method_47908(breakSound),
                    class_3414.method_47908(stepSound),
                    class_3414.method_47908(placeSound),
                    class_3414.method_47908(hitSound),
                    class_3414.method_47908(fallSound)
            );
        }
    }
}

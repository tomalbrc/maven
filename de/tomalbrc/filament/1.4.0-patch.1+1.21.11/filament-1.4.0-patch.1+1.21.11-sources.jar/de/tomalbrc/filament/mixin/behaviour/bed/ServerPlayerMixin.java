package de.tomalbrc.filament.mixin.behaviour.bed;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_12195;
import net.minecraft.class_12206;
import net.minecraft.class_1299;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

@Mixin(class_3222.class)
public class ServerPlayerMixin {
    @Inject(method = "findRespawnAndUseSpawnBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;", ordinal = 0), cancellable = true)
    private static void filament$findRespawnAndUseSpawnBlock(class_3218 serverLevel, class_3222.class_10766 respawnConfig, boolean bl, CallbackInfoReturnable<Optional<class_3222.class_9773>> cir) {
        class_2338 blockPos = respawnConfig.comp_4913().method_74897();
        class_2680 blockState = serverLevel.method_8320(respawnConfig.comp_4913().method_74897());
        if (blockState.method_26204() instanceof DecorationBlock decorationBlock && decorationBlock.getDecorationData().behaviour().has(Behaviours.BED) && ((class_12195)serverLevel.method_75598().method_75697(class_12206.field_63756, blockPos)).method_75644(serverLevel)) {
            var v = class_2244.method_9484(class_1299.field_6097, serverLevel, respawnConfig.comp_4913().method_74897(), blockState.method_11654(class_2244.field_11177), respawnConfig.comp_4913().comp_4916()).map((vec3) -> class_3222.class_9773.method_60595(vec3, respawnConfig.comp_4913().method_74897(), respawnConfig.comp_4913().comp_4916()));
            cir.setReturnValue(v);
        }
    }
}

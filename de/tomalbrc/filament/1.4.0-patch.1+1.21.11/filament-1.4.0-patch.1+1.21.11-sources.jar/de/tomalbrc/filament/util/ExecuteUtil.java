package de.tomalbrc.filament.util;

import de.tomalbrc.filament.Filament;
import net.minecraft.class_12096;
import net.minecraft.class_2168;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class ExecuteUtil {
    public static void asPlayer(class_3222 user, class_243 at, String ...cmd) {
        var commandSourceStack = Filament.SERVER.method_3739().method_9232(user).method_9208(user.method_73189()).method_9230(class_12096.field_63208);
        if (at != null) {
            commandSourceStack = commandSourceStack.method_9208(at);
        }

        for (int i = 0; i < cmd.length; i++) {
            cmd[i] = cmd[i].replace("${player}", user.method_5820());
            cmd[i] = cmd[i].replace("%player%", user.method_5820());
        }

        as(Filament.SERVER, commandSourceStack, at, cmd);
    }

    public static void asConsole(class_3222 user, class_243 at, String ... cmd) {
        var commandSourceStack = Filament.SERVER.method_3739().method_9232(user).method_9208(user.method_73189()).method_9216(user.method_5802()).method_9230(class_12096.field_63208);
        if (at != null) {
            commandSourceStack = commandSourceStack.method_9208(at);
        }

        as(Filament.SERVER, commandSourceStack, at, cmd);
    }

    public static void as(MinecraftServer server, class_2168 commandSourceStack, class_243 at, String ... cmds) {
        if (at != null) {
            commandSourceStack = commandSourceStack.method_9208(at);
        }

        for (String cmd : cmds) {
            server.method_3734().method_44252(commandSourceStack.method_9217(), cmd);
        }
    }
}

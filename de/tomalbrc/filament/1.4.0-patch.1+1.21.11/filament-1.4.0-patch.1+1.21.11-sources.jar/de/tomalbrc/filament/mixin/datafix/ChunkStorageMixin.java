package de.tomalbrc.filament.mixin.datafix;

import de.tomalbrc.filament.datafixer.DataFix;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_2487;
import net.minecraft.class_3977;
import net.minecraft.class_4284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3977.class)
public class ChunkStorageMixin {
    @Inject(method = "upgradeChunkTag(Lnet/minecraft/nbt/CompoundTag;ILnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag;", at = @At(value = "RETURN"), cancellable = true)
    private void filament$addChunkFixer(class_2487 compoundTag, int i, class_2487 compoundTag2, CallbackInfoReturnable<class_2487> cir) {
        if (FilamentConfig.getInstance().version < DataFix.VERSION) {
            var res = class_4284.field_19214.method_48131(DataFix.getDataFixer(), compoundTag, 1, DataFix.VERSION);
            cir.setReturnValue(res);
        }
    }
}

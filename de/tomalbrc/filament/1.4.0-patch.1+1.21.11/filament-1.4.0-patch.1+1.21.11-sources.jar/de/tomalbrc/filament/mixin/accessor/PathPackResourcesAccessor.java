package de.tomalbrc.filament.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.nio.file.Path;
import net.minecraft.class_3259;

@Mixin(class_3259.class)
public interface PathPackResourcesAccessor {
    @Accessor
    Path getRoot();
}
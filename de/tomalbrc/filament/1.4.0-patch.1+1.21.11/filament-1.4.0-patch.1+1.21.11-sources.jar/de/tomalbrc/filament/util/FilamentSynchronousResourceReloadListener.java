package de.tomalbrc.filament.util;

import com.google.common.reflect.TypeToken;
import com.google.gson.*;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.mixin.accessor.PathPackResourcesAccessor;
import de.tomalbrc.filament.registry.Templates;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3259;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

public interface FilamentSynchronousResourceReloadListener extends SimpleSynchronousResourceReloadListener {
    default Path obtainPath(class_2960 id, class_3300 resourceManager) {
        Path path = null;
        var resource = resourceManager.method_14486(id);
        if (resource.isPresent() && resource.get().method_45304() instanceof class_3259 pathPackResources) {
            path = ((PathPackResourcesAccessor)pathPackResources).getRoot().resolve("data").resolve(id.method_12836()).resolve(id.method_12832());
        }

        return path;
    }

    default void loadJson(@NotNull String root, @Nullable String endsWith, @NotNull class_3300 resourceManager, @NotNull BiConsumer<class_2960, InputStream> onRead) {
        var resources = resourceManager.method_14488(root, path -> path.method_12832().endsWith((endsWith == null ? "" : endsWith) + ".json"));
        for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
            try (InputStream inputStream = entry.getValue().method_14482()) {
                Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
                var json = JsonParser.parseReader(new InputStreamReader(inputStream));
                InputStream stream;
                if (json.isJsonObject()) {
                    Type mapType = new TypeToken<Map<String, Object>>() {
                    }.getType();
                    Map<String, Object> document = gson.fromJson(json, mapType);
                    if (document != null) {
                        document = Json.camelToSnakeCase(document);
                    }
                    stream = new ByteArrayInputStream(gson.toJson(document).getBytes(StandardCharsets.UTF_8));
                }
                else {
                    stream = new ByteArrayInputStream(gson.toJson(json).getBytes(StandardCharsets.UTF_8));
                }

                onRead.accept(entry.getKey(), stream);
            } catch (IOException | IllegalStateException e) {
                error(entry.getKey(), e);
            }
        }
    }

    default void loadYaml(@NotNull String root, @Nullable String endsWith, @NotNull class_3300 resourceManager, @NotNull BiConsumer<class_2960, InputStream> onRead) {
        var resources = resourceManager.method_14488(root, path ->
                path.method_12832().endsWith((endsWith == null ? "" : endsWith) + ".yaml") ||
                        path.method_12832().endsWith((endsWith == null ? "" : endsWith) + ".yml"));

        for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
            try (InputStream inputStream = entry.getValue().method_14482()) {
                var list = Json.yamlToJson(inputStream);
                for (InputStream stream : list) {
                    onRead.accept(entry.getKey(), stream);
                }
            } catch (IOException | IllegalStateException e) {
                error(entry.getKey(), e);
            }
        }
    }

    default void load(@NotNull String root, @Nullable String endsWith, @NotNull class_3300 resourceManager, @NotNull BiConsumer<class_2960, InputStream> onRead) {
        loadYaml(root, endsWith, resourceManager, (id, input) -> {
            if (!loadAsTemplate(input))
                onRead.accept(id, template(input));
        });

        loadJson(root, endsWith, resourceManager, (id, input) -> {
            if (!loadAsTemplate(input))
                onRead.accept(id, template(input));
        });
    }

    static boolean loadAsTemplate(InputStream input) {
        JsonElement element = JsonParser.parseReader(new InputStreamReader(input));
        if (element != null && element.isJsonObject()) {
            try {
                if (element.getAsJsonObject().has("is_template") && element.getAsJsonObject().getAsJsonPrimitive("is_template").getAsBoolean()) {
                    Templates.add(input);
                    return true;
                }
            } catch (Exception ignored) {}
        }

        return false;
    }

    static void error(class_2960 Identifier, Exception e) {
        Filament.LOGGER.error("Failed to load resource \"{}\".", Identifier, e);
    }

    static InputStream template(InputStream inputStream) {
        var parsed = JsonParser.parseReader(new InputStreamReader(inputStream));
        try {
            inputStream.reset();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (!parsed.isJsonObject() || !parsed.getAsJsonObject().has("id"))
            return inputStream;

        var parsedObject = parsed.getAsJsonObject();
        var realId = class_2960.method_60654(parsedObject.getAsJsonPrimitive("id").getAsString());
        var multiTemp = parsedObject.has("templates");
        var singleTemp = parsedObject.has("template");
        if (multiTemp || singleTemp) {
            List<class_2960> templates = new ArrayList<>();
            if (multiTemp) {
                JsonElement templateEl = parsedObject.get("templates");
                if (templateEl.isJsonArray()) {
                    JsonArray array = templateEl.getAsJsonArray();
                    for (JsonElement element : array) {
                        if (element.isJsonPrimitive()) {
                            templates.add(class_2960.method_60654(element.getAsJsonPrimitive().getAsString()));
                        }
                    }
                }
            }
            else {
                JsonElement templateEl = parsedObject.get("template");
                if (templateEl.isJsonPrimitive()) {
                    templates.add(class_2960.method_60654(templateEl.getAsString()));
                }
            }

            for (class_2960 template : templates) {
                parsed = Templates.merge(template, realId, parsed.getAsJsonObject());
            }

            parsed.getAsJsonObject().remove("is_template");

            JsonElement res = Templates.handlePlaceholder(parsed, realId);

            String jsonString = new Gson().toJson(res);
            return new ByteArrayInputStream(jsonString.getBytes(StandardCharsets.UTF_8));
        }

        return inputStream;
    }
}

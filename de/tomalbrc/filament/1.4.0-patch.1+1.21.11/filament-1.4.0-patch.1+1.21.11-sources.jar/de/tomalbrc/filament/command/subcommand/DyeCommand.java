package de.tomalbrc.filament.command.subcommand;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import de.tomalbrc.bil.util.Permissions;
import net.minecraft.class_11199;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_9282;
import net.minecraft.class_9334;

public class DyeCommand {
    public static LiteralCommandNode<class_2168> register() {
        var dyeNode = class_2170.method_9247("dye").requires(Permissions.require("filament.command.dye", 2));
        var colorArg = class_2170.method_9244("color", class_11199.method_70758());
        return dyeNode.then(colorArg.executes(DyeCommand::execute)).build();
    }

    private static int execute(CommandContext<class_2168> context) {
        if (context.getSource().method_44023() != null) {
            class_1799 item = context.getSource().method_44023().method_6047();
            if (!item.method_7960()) {
                Integer hexColor = class_11199.method_70760(context, "color");
                item.method_57379(class_9334.field_49644, new class_9282(hexColor));
                return Command.SINGLE_SUCCESS;
            }
        }
        return 0;
    }
}

package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_3288;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;


@Mixin(class_3288.class)
public interface PackAccessor {
    @Accessor
    class_3288.class_7680 getResources();
}

package de.tomalbrc.filament.registry;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.block.*;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.datafixer.config.BlockDataFix;
import de.tomalbrc.filament.item.FilamentItem;
import de.tomalbrc.filament.util.*;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9336;

public class BlockRegistry {
    public static Map<class_2960, Collection<class_2960>> BLOCKS_TAGS = new Object2ReferenceOpenHashMap<>();

    public static void register(Path filepath, InputStream inputStream) throws IOException {
        JsonElement element = JsonParser.parseReader(new InputStreamReader(inputStream));
        try {
            BlockData data = Json.GSON.fromJson(element, BlockData.class);
            data.filepath = filepath;
            BlockDataFix.fixup(element, data);
            Util.handleComponentsCustom(element, data);

            register(data);
        } catch (Exception e) {
            Filament.LOGGER.error("Could not load file! Error: {}", String.valueOf(e.fillInStackTrace()));
            Filament.LOGGER.info("Path: {}", filepath);
            Filament.LOGGER.info("File: \n{}", element.toString());
        }
    }

    public static void register(InputStream inputStream) throws IOException {
        register(null, inputStream);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void register(BlockData data) {
        if (class_7923.field_41175.method_10250(data.id())) {
            var block = class_7923.field_41175.method_63535(data.id());
            if (block.isFilamentBlock() && block.method_8389().isFilamentItem()) {
                block.method_8389().asFilamentItem().initBehaviours(data.behaviour());
                block.asFilamentBlock().initBehaviours(data.behaviour());
                postRegistration(block.method_8389().asFilamentItem(), block.asFilamentBlock(), data);
            }
            return;
        }

        BlockProperties properties = data.properties();
        class_4970.class_2251 blockProperties = properties.toBlockProperties();

        SimpleBlock customBlock;
        // ok this is starting to get messy
        if (data.requiresEntityBlock()) {
            if (data.virtual()) {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleVirtualBlockWithEntity(props, data), blockProperties, data.blockTags());
            } else {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleBlockWithEntity(props, data), blockProperties, data.blockTags());
            }
        } else {
            if (data.virtual()) {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleVirtualBlock(props, data), blockProperties, data.blockTags());
            } else {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleBlock(props, data), blockProperties, data.blockTags());
            }
        }

        class_1792.class_1793 itemProperties = data.properties().toItemProperties();
        if (data.properties().copyComponents == Boolean.TRUE) {
            for (class_9336 component : data.vanillaItem().method_57347()) {
                itemProperties.method_57349(component.comp_2443(), component.comp_2444());
            }
        }

        for (class_9336 component : data.components()) {
            itemProperties.method_57349(component.comp_2443(), component.comp_2444());
        }

        SimpleBlockItem item = ItemRegistry.registerItem(ItemRegistry.key(data.id()), (newProps) -> new SimpleBlockItem(newProps, customBlock, data), itemProperties, data.group() != null ? data.group() : Constants.BLOCK_GROUP_ID, data.itemTags());
        postRegistration(item, customBlock, data);

        FilamentRegistrationEvents.BLOCK.invoker().registered(data, item, customBlock);
    }

    static void postRegistration(FilamentItem item, SimpleBlock customBlock, Data<?> data) {
        BehaviourUtil.postInitItem(item.asItem(), item, data.behaviour());
        BehaviourUtil.postInitBlock(customBlock, data.behaviour());
        Translations.add(item.asItem(), customBlock, data);

        // has to run before `postRegister` since it may add block models from textures
        RPUtil.create(item, data);

        customBlock.postRegister();
    }

    public static class_5321<class_2248> key(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41254, id);
    }

    public static <T extends class_2248> T registerBlock(class_5321<class_2248> resourceKey, Function<class_4970.class_2251, T> function, class_4970.class_2251 properties, @Nullable Set<class_2960> blockTags) {
        T block = function.apply(properties.method_63500(resourceKey));
        if (blockTags != null) for (class_2960 tag : blockTags) {
            var list = BLOCKS_TAGS.computeIfAbsent(tag, x -> new ArrayList<>());
            list.add(resourceKey.method_29177());
        }
        return class_2378.method_39197(class_7923.field_41175, resourceKey, block);
    }

    public static class BlockDataReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, Constants.MOD_ID);
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            load("filament/block", null, resourceManager, (id, inputStream) -> {
                try {
                    BlockRegistry.register(obtainPath(id, resourceManager), inputStream);
                } catch (Exception e) {
                    Filament.LOGGER.error("Failed to load block resource \"{}\".", id);
                }
            });
        }
    }
}

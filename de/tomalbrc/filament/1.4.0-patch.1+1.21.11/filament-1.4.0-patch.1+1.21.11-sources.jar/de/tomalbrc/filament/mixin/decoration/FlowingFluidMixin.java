package de.tomalbrc.filament.mixin.decoration;

import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.DecorationRegistry;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3609.class)
public abstract class FlowingFluidMixin {
    @Shadow protected abstract void beforeDestroyingBlock(class_1936 level, class_2338 pos, class_2680 state);

    @Inject(method = "canPassThroughWall(Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z", at = @At("HEAD"), cancellable = true)
    private static void filament$customCanPassThroughWall(class_2350 direction, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2338 blockPos2, class_2680 blockState2, CallbackInfoReturnable<Boolean> cir) {
        if (DecorationRegistry.isDecoration(blockState2) || DecorationRegistry.isDecoration(blockState)) {
            cir.setReturnValue(true);
        }
    }

    @Unique
    private boolean filament$passes(class_2680 blockState) {
        if (DecorationRegistry.isDecoration(blockState) && (!filament$isSolid((DecorationBlock) blockState.method_26204()) || filament$isWaterloggable(blockState)))
            return this.filament$canFlowThrough(blockState);
        return false;
    }

    @Inject(method = "canMaybePassThrough", at = @At("RETURN"), cancellable = true)
    private void filament$canMaybePassThrough(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_3610 fluidState, CallbackInfoReturnable<Boolean> cir) {
        // pass-thu but only non-waterloggable blocks and non-solid
        if (filament$passes(blockState2)) cir.setReturnValue(true);
    }

    @Inject(method = "canPassThrough", at = @At("RETURN"), cancellable = true)
    private void filament$canPassThrough(class_1922 blockGetter, class_3611 fluid, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_3610 fluidState, CallbackInfoReturnable<Boolean> cir) {
        if (filament$passes(blockState)) cir.setReturnValue(true);
        if (filament$passes(blockState2)) cir.setReturnValue(true);
    }

    @Inject(method = "spreadTo", at = @At(value = "HEAD"))
    protected void filament$spreadTo(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_3610 fluidState, CallbackInfo ci) {
        if (DecorationRegistry.isDecoration(blockState) && !filament$isSolid((DecorationBlock) blockState.method_26204())) {
            if (levelAccessor.method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                decorationBlockEntity.destroyStructure(true);
            }
        }
    }

    @Unique
    private boolean filament$canFlowThrough(class_2680 blockState) {
        DecorationBlock decorationBlock = (DecorationBlock) blockState.method_26204();
        if (decorationBlock.getDecorationData() != null) {
            return !decorationBlock.getDecorationData().hasBlocks();
        }

        return false;
    }

    @Unique
    private static boolean filament$isWaterloggable(class_2680 decorationBlock) {
        return decorationBlock.method_28498(class_2741.field_12508);
    }

    @Unique
    private static boolean filament$isSolid(DecorationBlock decorationBlock) {
        if (decorationBlock.getDecorationData() != null) {
            return decorationBlock.getDecorationData().properties().solid();
        }

        return false;
    }
}

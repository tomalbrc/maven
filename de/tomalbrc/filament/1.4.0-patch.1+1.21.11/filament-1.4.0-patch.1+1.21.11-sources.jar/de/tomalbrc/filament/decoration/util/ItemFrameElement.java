package de.tomalbrc.filament.decoration.util;

import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.mixin.accessor.ItemFrameAccessor;
import de.tomalbrc.filament.util.DecorationUtil;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.elements.GenericEntityElement;
import eu.pb4.polymer.virtualentity.api.tracker.DataTrackerLike;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import eu.pb4.polymer.virtualentity.api.tracker.SimpleDataTracker;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ItemFrameElement extends GenericEntityElement {
    int rotation;
    boolean glow;
    class_2350 direction;

    public ItemFrameElement(DecorationData decorationData, class_2350 direction, int rotation, class_1799 itemStack, DecorationUtil.OnInteract onInteract) {
        super();

        this.direction = direction;
        this.rotation = rotation;
        this.glow = decorationData.properties().glow;

        this.dataTracker.set(EntityTrackedData.FLAGS, (byte) 0);
        this.dataTracker.set(ItemFrameAccessor.getDATA_ITEM(), itemStack);
        this.dataTracker.set(ItemFrameAccessor.getDATA_ROTATION(), rotation);
        this.setInvisible(true);

        this.setInteractionHandler(new InteractionHandler() {
            @Override
            public void interactAt(class_3222 player, class_1268 hand, class_243 pos) {
                class_3218 serverLevel = player.method_51469();
                class_2338 blockPos = class_2338.method_49638(getHolder().getAttachment().getPos());
                class_1269 result = class_1269.field_5811;
                if (onInteract != null && serverLevel.method_8505(player, blockPos)) {
                    result = onInteract.interact(player, hand, blockPos.method_61082().method_1019(pos));
                }

                if (!result.method_23665()) DecorationUtil.defaultVirtualInteraction(player, hand, blockPos, pos, 1/16f);
            }

            @Override
            public void attack(class_3222 player) {
                class_3218 serverLevel = player.method_51469();
                class_2338 blockPos = class_2338.method_49638(getHolder().getAttachment().getPos());
                player.field_13974.method_14263(blockPos, class_2846.class_2847.field_12968, class_2350.field_11036, serverLevel.method_31600(), 0);
            }
        });
    }

    @Override
    protected class_1299<? extends class_1297> getEntityType() {
        return this.glow ? class_1299.field_28401 : class_1299.field_6043;
    }

    @Override
    protected class_2596<class_2602> createSpawnPacket(class_3222 player) {
        var pos = Objects.requireNonNull(this.getHolder()).getPos().method_1019(this.getOffset());
        return new class_2604(this.getEntityId(), this.getUuid(), pos.field_1352, pos.field_1351, pos.field_1350, this.getPitch(), this.getYaw(), this.getEntityType(), this.direction.method_10146(), class_243.field_1353, this.getYaw());
    }

    @Override
    protected DataTrackerLike createDataTracker() {
        return new SimpleDataTracker(class_1299.field_6043);
    }

    @Override
    public void setYaw(float yaw) {
        this.dataTracker.set(ItemFrameAccessor.getDATA_ROTATION(), Util.SEGMENTED_ANGLE8.method_48125(yaw-180));
    }

    public void setItem(class_1799 item) {
        this.dataTracker.set(ItemFrameAccessor.getDATA_ITEM(), item.method_7972());
    }
}
package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.AsyncTickingBlockBehaviour;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.util.AsyncBlockTicker;
import de.tomalbrc.filament.util.ExecuteUtil;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class AreaExecute implements BlockBehaviour<AreaExecute.Config>, AsyncTickingBlockBehaviour {
    public static AsyncBlockTicker.DataKey PLAYERS = new AsyncBlockTicker.DataKey("players");

    private Config config;

    public AreaExecute(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Config getConfig() {
        return this.config;
    }

    @Override
    public void tickAsync(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        if (!config.enabled.getValue(blockState)) return;

        int interval = config.interval.getValue(blockState);
        if (interval <= 0) return; // or treat 0 as "every tick" if that's what you want

        if (serverLevel.method_75260() % interval != 0) return;

        class_238 aABB = (new class_238(blockPos))
                .method_1014(config.radius.getValue(blockState))
                .method_1012(0.0, config.ignoreHeight ? serverLevel.method_31605() : 0, 0.0);

        ReferenceOpenHashSet<class_3222> playersInArea = new ReferenceOpenHashSet<>(
                serverLevel.method_18467(class_3222.class, aABB)
        );

        var tickData = AsyncBlockTicker.get(blockPos);

        @SuppressWarnings("unchecked")
        Set<class_3222> set = (Set<class_3222>) tickData.userData().computeIfAbsent(PLAYERS, x -> ConcurrentHashMap.newKeySet());

        // ENTER + REPEAT
        for (class_3222 user : playersInArea) {
            // ENTER: only when not already tracked
            if (!set.contains(user)) {
                var cmds = enterCommands();
                if (cmds != null && (config.permission == null || Permissions.check(user, config.permission))) {
                    var pos = config.atBlock ? blockPos.method_46558() : null;
                    if (getConfig().console) {
                        ExecuteUtil.asConsole(user, pos, cmds.toArray(new String[0]));
                    } else {
                        ExecuteUtil.asPlayer(user, pos, cmds.toArray(new String[0]));
                    }
                }
                // mark inside after enter
                set.add(user);
            }

            var repeat = repeatCommands();
            if (repeat != null && (config.permission == null || Permissions.check(user, config.permission))) {
                var pos = config.atBlock ? blockPos.method_46558() : null;
                if (getConfig().console) {
                    ExecuteUtil.asConsole(user, pos, repeat.toArray(new String[0]));
                } else {
                    ExecuteUtil.asPlayer(user, pos, repeat.toArray(new String[0]));
                }
            }
        }

        // EXIT: if player no longer in playersInArea -> exit
        for (class_3222 user : new ReferenceOpenHashSet<>(set)) {
            if (!playersInArea.contains(user) || user.method_14239() || user.method_29504()) {
                var cmds = exitCommands();
                if (cmds != null && (config.permission == null || Permissions.check(user, config.permission))) {
                    var pos = config.atBlock ? blockPos.method_46558() : null;
                    if (getConfig().console) {
                        ExecuteUtil.asConsole(user, pos, cmds.toArray(new String[0]));
                    } else {
                        ExecuteUtil.asPlayer(user, pos, cmds.toArray(new String[0]));
                    }
                }
                set.remove(user);
            }
        }
    }

    private List<String> enterCommands() {
        return config.enterCommands == null ? this.config.enterCommand == null ? null : List.of(this.config.enterCommand) : config.enterCommands;
    }

    private List<String> exitCommands() {
        return config.exitCommands == null ? this.config.exitCommand == null ? null : List.of(this.config.exitCommand) : config.exitCommands;
    }

    private List<String> repeatCommands() {
        return config.repeatCommands == null ? this.config.repeatCommand == null ? null : List.of(this.config.repeatCommand) : config.repeatCommands;
    }

    public static class Config {
        public BlockStateMappedProperty<Integer> radius = BlockStateMappedProperty.of(16);
        public BlockStateMappedProperty<Boolean> enabled = BlockStateMappedProperty.of(true);
        public BlockStateMappedProperty<Integer> interval = BlockStateMappedProperty.of(40);
        public String repeatCommand;
        public List<String> repeatCommands;
        public String enterCommand;
        public List<String> enterCommands;
        public String exitCommand;
        public List<String> exitCommands;
        public boolean atBlock;
        public boolean ignoreHeight;
        public boolean console;
        public String permission;
    }
}
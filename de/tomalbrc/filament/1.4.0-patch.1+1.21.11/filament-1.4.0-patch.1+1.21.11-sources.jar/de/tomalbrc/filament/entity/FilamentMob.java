package de.tomalbrc.filament.entity;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.data.EntityData;
import de.tomalbrc.filament.registry.EntityRegistry;
import eu.pb4.polymer.core.api.entity.PolymerEntity;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1334;
import net.minecraft.class_1335;
import net.minecraft.class_1355;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2781;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3730;
import net.minecraft.class_4538;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;

public class FilamentMob extends class_1429 implements PolymerEntity {
    EntityData data;

    @SuppressWarnings("unchecked")
    public FilamentMob(class_1299<? extends class_1297> entityType, class_1937 level) {
        super((class_1299<? extends class_1429>) entityType, level);
        this.data = getData();
        this.field_6194 = data.properties().xpReward;
        method_5959();

        this.method_5684(data.properties().invulnerable);
        this.field_5960 = data.properties().noPhysics;

        //this.setPathfindingMalus(PathType.BLOCKED);

        this.field_6207 = new class_1335(this);
        this.field_6204 = new class_1334(this);
    }


    public EntityData getData() {
        return EntityRegistry.getData(class_7923.field_41177.method_10221(this.method_5864()));
    }

    @Override
    protected void method_5959() {
        super.method_5959();

        if (data != null) {
            for (var behaviour : data.goals()) {
                if (behaviour instanceof EntityBehaviour<?> entityBehaviour) {
                    entityBehaviour.registerGoals(this);
                }
            }
        }
    }

    public class_1355 getGoalSelector() {
        return this.field_6201;
    }

    public class_1355 getTargetSelector() {
        return this.field_6185;
    }

    @Override
    public class_1299<?> getPolymerEntityType(PacketContext packetContext) {
        return class_7923.field_41177.method_63535(getData().entityType());
    }

    protected void updateNoActionTime() {
        float f = this.method_5718();
        if (f > 0.5F) {
            this.field_6278 += 2;
        }
    }

    @Override
    public float method_6144(class_2338 blockPos, class_4538 levelReader) {
        if (data.properties().category == class_1311.field_6302) return -levelReader.method_42309(blockPos);
        return super.method_6144(blockPos, levelReader);
    }

    @Override
    public @Nullable class_1296 method_5613(class_3218 serverLevel, class_1296 ageableMob) {
        var id = data.properties().offspring;
        return (class_1296) class_7923.field_41177.method_63535(id).method_5883(serverLevel, class_3730.field_16466);
    }

    @Override
    public void method_6007() {
        if (data.properties().category == class_1311.field_6302) this.updateNoActionTime();

        if (this.method_5805()) {
            boolean burn = data.properties().isSunSensitive && this.method_5972();
            if (burn) {
                class_1799 itemStack = this.method_6118(class_1304.field_6169);
                if (!itemStack.method_7960()) {
                    if (itemStack.method_7963()) {
                        class_1792 item = itemStack.method_7909();
                        itemStack.method_7974(itemStack.method_7919() + this.field_5974.method_43048(2));
                        if (itemStack.method_7919() >= itemStack.method_7936()) {
                            this.method_20235(item, class_1304.field_6169);
                            this.method_5673(class_1304.field_6169, class_1799.field_8037);
                        }
                    }

                    burn = false;
                }

                if (burn) {
                    this.method_5639(8.0F);
                }
            }
        }

        super.method_6007();
    }

    @Override
    public void method_5958(class_3218 serverLevel) {
        super.method_5958(serverLevel);

        if (this.field_5947 > 0) {
            if (this.field_5947 % 4 == 0) {
                serverLevel.method_65096(class_2398.field_11211, this.method_23322(1.0), this.method_23319() + 0.5, this.method_23325(1.0), 0, 0.0, 0.0, 0.0, 0.0);
            }

            --this.field_5947;
        }
    }

    @Override
    public boolean method_5936() {
        return this.data.properties().canPickupLoot;
    }

    @Override
    public boolean method_6121(class_3218 serverLevel, class_1297 entity) {
        serverLevel.method_8421(this, (byte)4);

        return super.method_6121(serverLevel, entity);
    }

    @Override
    @NotNull
    protected class_3414 method_5737() {
        if (data.properties().sounds != null && data.properties().sounds.swim() != null)
            return class_3414.method_47908(data.properties().sounds.swim());
        return super.method_5737();
    }

    @Override
    @NotNull
    protected class_3414 method_5625() {
        if (data.properties().sounds != null && data.properties().sounds.swimSplash() != null)
            return class_3414.method_47908(data.properties().sounds.swimSplash());
        return super.method_5625();
    }

    @Override
    protected class_3414 method_6011(class_1282 damageSource) {
        if (data.properties().sounds != null && data.properties().sounds.hurt() != null)
            return class_3414.method_47908(data.properties().sounds.hurt());
        return super.method_6011(damageSource);
    }

    @Override
    protected class_3414 method_6002() {
        if (data.properties().sounds != null && data.properties().sounds.death() != null)
            return class_3414.method_47908(data.properties().sounds.death());
        return super.method_6002();
    }

    @Override
    @NotNull
    public class_1309.class_6823 method_39760() {
        if (data.properties().sounds != null && data.properties().sounds.fall() != null)
            return new class_1309.class_6823(class_3414.method_47908(data.properties().sounds.fall().small()), class_3414.method_47908(data.properties().sounds.fall().big()));
        return super.method_39760();
    }

    @Nullable
    protected class_3414 method_5994() {
        if (data.properties().sounds != null && data.properties().sounds.ambient() != null)
            return class_3414.method_47908(data.properties().sounds.ambient());
        return super.method_5994();
    }

    @Override
    public int method_5970() {
        return data.properties().ambientSoundInterval;
    }

    @Override
    public boolean method_6481(class_1799 itemStack) {
        var food = data.properties().food;
        if (food != null) {
            for (class_2960 Identifier : food) {
                if (itemStack.method_31574(class_7923.field_41178.method_63535(Identifier)))
                    return true;
            }
        }
        return false;
    }

    @Override
    public void method_6480(@Nullable class_1657 player) {
        if (this.method_73183() instanceof class_3218 level) {
            for (int i = 0; i < 7; ++i) {
                double xOffset = this.field_5974.method_43059() * 0.02;
                double yOffset = this.field_5974.method_43059() * 0.02;
                double zOffset = this.field_5974.method_43059() * 0.02;
                level.method_65096(class_2398.field_11201, this.method_23322(1.0), this.method_23319() + 0.5, this.method_23325(1.0), 0, xOffset, yOffset, zOffset, 0);
            }
        }

        super.method_6480(player);
    }

    @Override
    public boolean method_5822(boolean bl) {
        if (!data.properties().canUsePortal) {
            return false;
        }

        return super.method_5822(bl);
    }

    @Override
    public void modifyRawEntityAttributeData(List<class_2781.class_2782> data, class_3222 player, boolean initial) {

        data.add(new class_2781.class_2782(class_5134.field_23716, 1.0, List.of()));
    }

    //@Override
    //public void modifyRawTrackedData(List<SynchedEntityData.DataValue<?>> data, ServerPlayer player, boolean initial) {
        //BuiltInRegistries.ENTITY_TYPE.getValue(this.data.entityType());
    //}


    @Override
    public boolean method_5931() {
        return data.properties().canBeLeashed;
    }

    @Override
    public boolean method_5974(double d) {
        return data.properties().despawnWhenFarAway && !this.method_60953() && !this.method_16914();
    }

    @Override
    public boolean method_6474(class_1429 animal) {
        if (animal == this) {
            return false;
        } else if (animal.method_5864() != this.method_5864()) {
            return false;
        } else {
            return this.method_6479() && animal.method_6479();
        }
    }
}

package de.tomalbrc.filament.mixin.behaviour.shears;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import de.tomalbrc.filament.behaviour.item.Shears;
import de.tomalbrc.filament.util.mixin.ItemPredicateCustomCheck;
import net.minecraft.class_5341;
import net.minecraft.class_7788;
import net.minecraft.class_7791;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_7788.class)
public abstract class BlockLootSubProviderMixin implements class_7791 {
    @ModifyReturnValue(method = "hasShears", at = @At(value = "RETURN", target = "Lnet/minecraft/advancements/criterion/ItemPredicate$Builder;of(Lnet/minecraft/core/HolderGetter;[Lnet/minecraft/world/level/ItemLike;)Lnet/minecraft/advancements/criterion/ItemPredicate$Builder;"))
    private class_5341.class_210 filament$customShears(class_5341.class_210 original) {
        if (original instanceof ItemPredicateCustomCheck customCheck) {
            customCheck.setCustomCheck(Shears::is);
        }
        return original;
    }
}

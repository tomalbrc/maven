package de.tomalbrc.filament.mixin.behaviour.crop;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import de.tomalbrc.filament.behaviour.Behaviours;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// For crops
@Mixin(targets = "net/minecraft/world/entity/animal/bee/Bee$BeeGrowCropGoal")
public abstract class BeeMixin {
    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z", ordinal = 0))
    void filament$beeAddCustom(CallbackInfo ci, @Local(ordinal = 0) class_2680 blockState, @Local(ordinal=1) LocalRef<class_2680> blockState2Ref) {
        if (blockState.method_26204().isFilamentBlock() && blockState.method_26204().has(Behaviours.CROP) && blockState.method_26204().getOrThrow(Behaviours.CROP).getConfig().beeInteraction) {
            blockState2Ref.set(blockState.method_26204().getOrThrow(Behaviours.CROP).incrementedAge(blockState));
        }
    }
}

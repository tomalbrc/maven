package de.tomalbrc.filament.mixin.behaviour.container;

import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.class_11568;
import net.minecraft.class_11574;
import net.minecraft.class_1263;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_11574.class)
public class CopperGolemAiMixin {
    @Inject(method = "method_72486", at = @At("RETURN"), cancellable = true)
    private static void filament$customContainerSupportWooden(class_2680 blockState, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue() && blockState.method_26204() instanceof DecorationBlock decorationBlock && DecorationData.getFirstContainer(decorationBlock) != null)
            cir.setReturnValue(blockState.method_26164(ConventionalBlockTags.WOODEN_CHESTS));
    }

    @Inject(method = "method_72482", at = @At("RETURN"), cancellable = true)
    private static void filament$shouldQueue(class_11568.class_11572 target, CallbackInfoReturnable<Boolean> cir) {
        if (target.comp_4429() instanceof DecorationBlockEntity decorationBlockEntity) {
            var containerLike = DecorationData.getFirstContainer(decorationBlockEntity.getMainBlockEntity());
            class_1263 container;
            if (containerLike != null && (container = containerLike.container()) != null) {
                cir.setReturnValue(!container.method_72379().isEmpty());
            }
        }
    }
}

package de.tomalbrc.filamentweb.util;

import com.google.common.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.*;
import net.minecraft.class_1767;
import net.minecraft.class_2960;
import net.minecraft.class_9323;

public class PojoComponents {
    // TODO: add to schema gen
    public static final class ContainerEntry {
        public ItemStack item = new ItemStack();
        public int slot = 0;

        public ContainerEntry() {}
    }

    public static final class ItemStack {
        public String id = "minecraft:paper";
        public int count = 1;
        public class_9323 components = class_9323.method_57827().method_57838();

        public ItemStack() {}
    }

    public record ConsumeEffect(class_2960 id, int duration, int amplifier, boolean ambient, boolean showParticles) {}

    public record AttributeModifier(class_2960 attribute, double amount, String operation, String slot) {}

    public record FireworkExplosion(
            String shape,
            List<Integer> colors,
            List<Integer> fadeColors,
            boolean trail,
            boolean twinkle
    ) {
        public FireworkExplosion() {
            this("small_ball", new ArrayList<>(), new ArrayList<>(), false, false);
        }
    }

    public record MapDecoration(String type, int x, int z, boolean tracked) {}

    public static final class ToolRule {
        private final class_2960 block = class_2960.method_60654("minecraft:stone");
        private final float speed= 1;
        private final boolean correctForDrops = true;
    }

    public record KineticCondition(int maxDurationTicks, Optional<Float> minSpeed, Optional<Float> minRelativeSpeed) {
        public KineticCondition() {
            this(0, Optional.empty(), Optional.empty());
        }
    }

    public record AttackRangeComponent(
            float minReach,
            float maxReach,
            float minCreativeReach,
            float maxCreativeReach,
            float hitboxMargin,
            float mobFactor
    ) {
        public AttackRangeComponent() {
            this(0.0f, 3.0f, 0.0f, 5.0f, 0.3f, 1.0f);
        }
    }

    public record FireResistantComponent() {}

    public record DeathProtectionComponent(List<ConsumeEffect> effects) {
        public DeathProtectionComponent() { this(new ArrayList<>()); }
    }

    public record UseRemainderComponent(class_2960 convertInto) {
        public UseRemainderComponent() { this(class_2960.method_60654("minecraft:air")); }
    }

    public record UseCooldownComponent(float seconds, Optional<class_2960> cooldownGroup) {
        public UseCooldownComponent() { this(0.0f, Optional.empty()); }
    }

    public record RepairableComponent(class_2960 items) {
        public RepairableComponent() { this(class_2960.method_60654("minecraft:iron_ingot")); }
    }

    public record EnchantmentGlintOverrideComponent(boolean hasGlint) {
        public EnchantmentGlintOverrideComponent() { this(true); }
    }

    @Deprecated
    public record GlintOverrideComponent(boolean hasGlint) {
        public GlintOverrideComponent() { this(true); }
    }

    public record ItemModelComponent(class_2960 model) {
        public ItemModelComponent() { this(class_2960.method_60654("minecraft:stick")); }
    }

    public record TooltipStyleComponent(class_2960 sprite) {
        public TooltipStyleComponent() { this(class_2960.method_60654("minecraft:default")); }
    }

    public record TooltipDisplayComponent(boolean hideTooltip, List<class_2960> hiddenComponents) {
        public TooltipDisplayComponent() { this(false, new ArrayList<>()); }
    }

    public record UseEffectsComponent(boolean canSprint, boolean interactVibrations, float speedMultiplier) {
        public UseEffectsComponent() { this(false, true, 0.2f); }
    }

    public record MinimumAttackChargeComponent(float charge) {
        public MinimumAttackChargeComponent() { this(0.0f); }
    }

    public record DamageTypeComponent(class_2960 type) {
        public DamageTypeComponent() { this(class_2960.method_60654("minecraft:spear")); }
    }

    public record KineticWeaponComponent(
            int contactCooldownTicks,
            int delayTicks,
            KineticCondition dismountConditions,
            KineticCondition knockbackConditions,
            KineticCondition damageConditions,
            float forwardMovement,
            float damageMultiplier,
            Optional<class_2960> sound,
            Optional<class_2960> hitSound
    ) {
        public KineticWeaponComponent() {
            this(10, 0, new KineticCondition(), new KineticCondition(), new KineticCondition(), 0.0f, 1.0f, Optional.empty(), Optional.empty());
        }
    }

    public record PiercingWeaponComponent(
            boolean dealsKnockback,
            boolean dismounts,
            Optional<class_2960> sound,
            Optional<class_2960> hitSound
    ) {
        public PiercingWeaponComponent() { this(true, false, Optional.empty(), Optional.empty()); }
    }

    public record SwingAnimationComponent(String type, int duration) {
        public SwingAnimationComponent() { this("whack", 6); }
    }

    public record EquippableComponent(
            String slot,
            class_2960 equipSound,
            class_2960 model,
            Optional<class_2960> cameraOverlay,
            boolean dispensable,
            boolean damageOnHurt
    ) {
        public EquippableComponent() {
            this("chest", class_2960.method_60654("minecraft:item.armor.equip_generic"), class_2960.method_60654("minecraft:stick"), Optional.empty(), true, true);
        }
    }

    public record ConsumableComponent(
            float consumeSeconds,
            String animation,
            class_2960 sound,
            boolean hasConsumeParticles,
            List<class_2960> onConsumeEffects
    ) {
        public ConsumableComponent() {
            this(1.6f, "eat", class_2960.method_60654("minecraft:entity.generic.eat"), true, new ArrayList<>());
        }
    }

    public record JukeboxPlayableComponent(class_2960 song, boolean showInTooltip) {
        public JukeboxPlayableComponent() { this(class_2960.method_60654("minecraft:precipice"), true); }
    }

    public record FoodComponent(int nutrition, float saturation, boolean canAlwaysEat) {
        public FoodComponent() { this(0, 0.0f, false); }
    }

    public record DamageComponent(int damage) {
        public DamageComponent() { this(0); }
    }

    public record MaxDamageComponent(int maxDamage) {
        public MaxDamageComponent() { this(0); }
    }

    public record MaxStackSizeComponent(int size) {
        public MaxStackSizeComponent() { this(64); }
    }

    public record UnbreakableComponent(boolean value) {
        public UnbreakableComponent() { this(true); }
    }

    public record RepairCostComponent(int cost) {
        public RepairCostComponent() { this(0); }
    }

    public record EnchantableComponent(int value) {
        public EnchantableComponent() { this(0); }
    }

    public record EnchantmentsComponent(Map<class_2960, Integer> enchantments) {
        public EnchantmentsComponent() { this(new LinkedHashMap<>()); }
    }

    public record StoredEnchantmentsComponent(Map<class_2960, Integer> enchantments) {
        public StoredEnchantmentsComponent() { this(new LinkedHashMap<>()); }
    }

    public record AttributeModifiersComponent(List<AttributeModifier> modifiers) {
        public AttributeModifiersComponent() { this(new ArrayList<>()); }
    }

    public record DamageResistantComponent(List<class_2960> types) {
        public DamageResistantComponent() { this(new ArrayList<>()); }
    }

    public record BlocksAttacksComponent(List<class_2960> bypassedBy) {
        public BlocksAttacksComponent() { this(new ArrayList<>()); }
    }

    public record BannerPatternsComponent(List<Map<String, Object>> patterns) {
        public BannerPatternsComponent() { this(new ArrayList<>()); }
    }

    public record BaseColorComponent(String color) {
        public BaseColorComponent() { this("white"); }
    }

    public record BeesComponent(List<Map<String, Object>> bees) {
        public BeesComponent() { this(new ArrayList<>()); }
    }

    public record BlockEntityDataComponent(Map<String, Object> data) {
        public BlockEntityDataComponent() { this(new LinkedHashMap<>()); }
    }

    public record BlockStateComponent(Map<String, Object> states) {
        public BlockStateComponent() { this(new LinkedHashMap<>()); }
    }

    public record BreakSoundComponent(class_2960 sound) {
        public BreakSoundComponent() { this(class_2960.method_60654("minecraft:block.stone.break")); }
    }

    public record BucketEntityDataComponent(Map<String, Object> data) {
        public BucketEntityDataComponent() { this(new LinkedHashMap<>()); }
    }

    public record BundleContentsComponent(List<ItemStack> items) {
        public BundleContentsComponent() { this(new ArrayList<>()); }
    }

    public record CanBreakComponent(List<class_2960> blocks) {
        public CanBreakComponent() { this(new ArrayList<>()); }
    }

    public record CanPlaceOnComponent(List<class_2960> blocks) {
        public CanPlaceOnComponent() { this(new ArrayList<>()); }
    }

    public record ChargedProjectilesComponent(List<ItemStack> items) {
        public ChargedProjectilesComponent() { this(new ArrayList<>()); }
    }

    public record ContainerLootComponent(class_2960 lootTable, long seed) {
        public ContainerLootComponent() { this(class_2960.method_60654("minecraft:empty"), 0L); }
    }

    public record CustomDataComponent(Map<String, Object> data) {
        public CustomDataComponent() { this(new LinkedHashMap<>()); }
    }

    public record CustomModelDataComponent(List<Float> floats, List<Boolean> flags, List<String> strings, List<Integer> colors) {
        public CustomModelDataComponent() { this(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); }
    }

    public record CustomNameComponent(String jsonText) {
        public CustomNameComponent() { this(""); }
    }

    public record DyeComponent(class_1767 color) {
        public DyeComponent() { this(class_1767.field_7952); }
    }

    public record DyedColorComponent(int rgb) {
        public DyedColorComponent() { this(0xFFFFFF); }
    }

    public record EntityDataComponent(Map<String, Object> data) {
        public EntityDataComponent() { this(new LinkedHashMap<>()); }
    }

    public record FireworkExplosionComponent(
            String shape,
            List<Integer> colors,
            List<Integer> fadeColors,
            boolean trail,
            boolean twinkle
    ) {
        public FireworkExplosionComponent() {
            this("small_ball", new ArrayList<>(), new ArrayList<>(), false, false);
        }
    }

    public record FireworksComponent(List<FireworkExplosionComponent> explosions, int flightDuration) {
        public FireworksComponent() { this(new ArrayList<>(), 0); }
    }

    public record GliderComponent() {}

    public record WeaponComponent(float attackDamage, float attackSpeed) {
        public WeaponComponent() { this(0.0f, 0.0f); }
    }

    public record InstrumentComponent(class_2960 instrument) {
        public InstrumentComponent() { this(class_2960.method_60654("minecraft:ponder_goat_horn")); }
    }

    public record IntangibleProjectileComponent() {}

    public record ItemNameComponent(String text) {
        public ItemNameComponent() { this(""); }
    }

    public record LoreComponent(List<String> lines) {
        public LoreComponent() { this(new ArrayList<>()); }
    }

    public record LockComponent(String key) {
        public LockComponent() { this(""); }
    }

    public record LodestoneTrackerComponent(Optional<class_2960> targetDimension, Optional<String> targetPosition, boolean tracked) {
        public LodestoneTrackerComponent() { this(Optional.empty(), Optional.empty(), false); }
    }

    public record MapColorComponent(int color) {
        public MapColorComponent() { this(0); }
    }

    public record MapDecorationComponent(String id, int x, int z, boolean tracked) {
        public MapDecorationComponent() { this("", 0, 0, false); }
    }

    public record MapDecorationsComponent(List<MapDecorationComponent> decorations) {
        public MapDecorationsComponent() { this(new ArrayList<>()); }
    }

    public record MapIdComponent(int id) {
        public MapIdComponent() { this(0); }
    }

    public record NoteBlockSoundComponent(class_2960 sound) {
        public NoteBlockSoundComponent() { this(class_2960.method_60654("minecraft:block.note_block.harp")); }
    }

    public record OminousBottleAmplifierComponent(int value) {
        public OminousBottleAmplifierComponent() { this(0); }
    }

    public record PotDecorationsComponent(List<class_2960> patterns) {
        public PotDecorationsComponent() { this(new ArrayList<>()); }
    }

    public record PotionContentsComponent(List<class_2960> effects) {
        public PotionContentsComponent() { this(new ArrayList<>()); }
    }

    public record PotionDurationScaleComponent(float scale) {
        public PotionDurationScaleComponent() { this(1.0f); }
    }

    public record ProfileComponent(UUID uuid, String name, Map<String, String> properties) {
        public ProfileComponent() { this(null, "", new LinkedHashMap<>()); }
    }

    public record ProvidesBannerPatternsComponent(List<class_2960> patterns) {
        public ProvidesBannerPatternsComponent() { this(new ArrayList<>()); }
    }

    public record ProvidesTrimMaterialComponent(class_2960 material) {
        public ProvidesTrimMaterialComponent() { this(class_2960.method_60654("minecraft:iron")); }
    }

    public record RarityComponent(String rarity) {
        public RarityComponent() { this("common"); }
    }

    public record RecipesComponent(List<class_2960> recipes) {
        public RecipesComponent() { this(new ArrayList<>()); }
    }

    public record SuspiciousStewEffectsComponent(List<ConsumeEffect> effects) {
        public SuspiciousStewEffectsComponent() { this(new ArrayList<>()); }
    }

    public static final class ToolComponent {
        private List<ToolRule> rules = new ArrayList<>();
    }

    public static final class TrimComponent {
        private class_2960 material = class_2960.method_60654("minecraft:iron");
        private class_2960 pattern = class_2960.method_60654("minecraft:iron");
    }

    public record WritableBookContentComponent(List<String> pages) {
        public WritableBookContentComponent() { this(new ArrayList<>()); }
    }

    public record WrittenBookContentComponent(
            String title,
            String author,
            List<String> pages,
            boolean resolved
    ) {
        public WrittenBookContentComponent() {
            this("", "", new ArrayList<>(), false);
        }
    }

    public static final Map<String, Type> REGISTERED_COMPONENTS = new LinkedHashMap<>();

    static {
        REGISTERED_COMPONENTS.put("minecraft:attack_range", AttackRangeComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:use_effects", UseEffectsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:minimum_attack_charge", MinimumAttackChargeComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:damage_type", DamageTypeComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:kinetic_weapon", KineticWeaponComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:piercing_weapon", PiercingWeaponComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:swing_animation", SwingAnimationComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:intangible_projectile", IntangibleProjectileComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:consumable", ConsumableComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:food", FoodComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:damage", DamageComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:max_damage", MaxDamageComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:max_stack_size", MaxStackSizeComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:unbreakable", UnbreakableComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:repair_cost", RepairCostComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:enchantable", EnchantableComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:enchantments", EnchantmentsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:stored_enchantments", StoredEnchantmentsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:attribute_modifiers", AttributeModifiersComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:damage_resistant", DamageResistantComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:blocks_attacks", BlocksAttacksComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:repairable", RepairableComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:death_protection", DeathProtectionComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:fire_resistant", FireResistantComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:use_remainder", UseRemainderComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:use_cooldown", UseCooldownComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:enchantment_glint_override", EnchantmentGlintOverrideComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:glint_override", GlintOverrideComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:tooltip_display", TooltipDisplayComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:tooltip_style", TooltipStyleComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:item_model", ItemModelComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:item_name", ItemNameComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:custom_name", CustomNameComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:lore", LoreComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:rarity", RarityComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:dyed_color", DyedColorComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:dye", DyeComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:equippable", EquippableComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:glider", GliderComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:weapon", WeaponComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:instrument", InstrumentComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:note_block_sound", NoteBlockSoundComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:break_sound", BreakSoundComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:tool", ToolComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:bundle_contents", BundleContentsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:container", new TypeToken<List<ContainerEntry>>(){}.getType());
        REGISTERED_COMPONENTS.put("minecraft:container_loot", ContainerLootComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:charged_projectiles", ChargedProjectilesComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:bucket_entity_data", BucketEntityDataComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:can_break", CanBreakComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:can_place_on", CanPlaceOnComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:block_state", BlockStateComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:block_entity_data", BlockEntityDataComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:entity_data", EntityDataComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:custom_data", CustomDataComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:profile", ProfileComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:lodestone_tracker", LodestoneTrackerComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:map_color", MapColorComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:map_decorations", MapDecorationsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:map_id", MapIdComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:writable_book_content", WritableBookContentComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:written_book_content", WrittenBookContentComponent.class);

        REGISTERED_COMPONENTS.put("minecraft:base_color", BaseColorComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:bees", BeesComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:banner_patterns", BannerPatternsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:pot_decorations", PotDecorationsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:potion_contents", PotionContentsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:potion_duration_scale", PotionDurationScaleComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:ominous_bottle_amplifier", OminousBottleAmplifierComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:custom_model_data", CustomModelDataComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:debug_stick_state", CustomDataComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:firework_explosion", FireworkExplosionComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:fireworks", FireworksComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:provides_banner_patterns", ProvidesBannerPatternsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:provides_trim_material", ProvidesTrimMaterialComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:recipes", RecipesComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:lock", LockComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:suspicious_stew_effects", SuspiciousStewEffectsComponent.class);
        REGISTERED_COMPONENTS.put("minecraft:trim", TrimComponent.class);
    }
}
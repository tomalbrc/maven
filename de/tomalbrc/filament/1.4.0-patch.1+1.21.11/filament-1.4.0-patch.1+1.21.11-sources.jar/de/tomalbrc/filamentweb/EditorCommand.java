package de.tomalbrc.filamentweb;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import de.tomalbrc.bil.util.Permissions;
import de.tomalbrc.filamentweb.service.AuthFilter;
import java.net.URI;
import java.util.UUID;
import net.minecraft.class_12094;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;

public class EditorCommand {
    public static LiteralCommandNode<class_2168> register() {
        var hatNode = class_2170
                .method_9247("editor").requires(Permissions.require("filament.editor", class_12094.field_63199.method_75026()));

        return hatNode.executes(EditorCommand::execute).build();
    }

    private static int execute(CommandContext<class_2168> context) {
        var player = context.getSource().method_44023();

        StringBuilder key = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            key.append((int) (Math.random() * 100) % 10);
        }

        if (player != null) {
            var uri = FilamentEditorConfig.getInstance().externalAddress + "/login?id=" + player.method_5845();
            context.getSource().method_45068(
                    class_2561.method_43470("Open Editor: " + uri)
                            .method_27696(class_2583.field_24360
                                    .method_10958(new class_2558.class_10608(URI.create(uri)))
                                    .method_10949(new class_2568.class_10613(class_2561.method_43470(uri)))
                            ).method_10852(class_2561.method_43470(", your key: " + key.toString()).method_27696(class_2583.field_24360))
            );

            AuthFilter.REQUESTS.put(player.method_5667(), key.toString());
        } else {
            var id = UUID.randomUUID();
            AuthFilter.SERVER_REQUEST.put(id, key.toString());

            var uri = FilamentEditorConfig.getInstance().externalAddress + "/login?id=" + id;
            context.getSource().method_45068(
                    class_2561.method_43470("Open Editor: " + uri)
                            .method_27696(class_2583.field_24360
                                    .method_10958(new class_2558.class_10608(URI.create(uri)))
                                    .method_10949(new class_2568.class_10613(class_2561.method_43470(uri)))
                            ).method_10852(class_2561.method_43470(", your key: " + key.toString()).method_27696(class_2583.field_24360))
            );
        }
        return 0;
    }
}

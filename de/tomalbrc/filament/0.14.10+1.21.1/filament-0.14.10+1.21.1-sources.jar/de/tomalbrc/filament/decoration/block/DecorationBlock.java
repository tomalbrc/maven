package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.util.VirtualDestroyStage;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;

public abstract class DecorationBlock extends class_2248 implements PolymerBlock, class_3737, VirtualDestroyStage.Marker {
    final protected class_2960 decorationId;

    public static final class_2758 LIGHT_LEVEL = class_2741.field_12538;

    public static final class_2746 WATERLOGGED = class_2741.field_12508;

    protected final class_2689<class_2248, class_2680> stateDefinitionEx;

    public DecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties);
        this.decorationId = decorationId;

        // todo
        //FlammableBlockRegistry.getDefaultInstance().add(this, 5, 10);

        // the StateDefinition built too early, cant access DecorationData from within createBlockStateDefinition
        class_2689.class_2690<class_2248, class_2680> builder = new class_2689.class_2690<>(this);
        this.method_9515(builder);
        this.stateDefinitionEx = builder.method_11668(class_2248::method_9564, class_2680::new);

        var data = getDecorationData();
        var state = this.stateDefinitionEx.method_11664();
        if (data.isLightEnabled()) {
            state = state.method_11657(LIGHT_LEVEL, !data.hasLightBehaviours() && data.properties().mayBeLightSource() && !data.properties().lightEmission.isMap() ? data.properties().lightEmission.getRawValue() : 0);
        }
        if (data.properties().waterloggable) {
            state = state.method_11657(WATERLOGGED, false);
        }
        this.method_9590(state);
    }

    @Override
    @NotNull
    public class_2689<class_2248, class_2680> method_9595() {
        return this.stateDefinitionEx;
    }

    public DecorationData getDecorationData() {
        return DecorationRegistry.getDecorationDefinition(this.decorationId);
    }

    @Override
    public boolean forceLightUpdates(class_2680 blockState) { return blockState.method_28498(LIGHT_LEVEL) && blockState.method_11654(LIGHT_LEVEL) > 0; }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        if (this.decorationId == null)
            return;

        DecorationData data = getDecorationData();
        if (data != null) {
            if (data.isLightEnabled()) {
                builder.method_11667(LIGHT_LEVEL);
            }

            if (data.properties().waterloggable) {
                builder.method_11667(WATERLOGGED);
            }
        }
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        var passthrough = !getDecorationData().hasBlocks();
        var block = passthrough ? state.method_28498(DecorationBlock.WATERLOGGED) && state.method_11654(DecorationBlock.WATERLOGGED) ? class_2246.field_10382 : class_2246.field_10124 : class_2246.field_10499;
        return state.method_11654(DecorationBlock.WATERLOGGED) && !passthrough ?
                block.method_9564().method_11657(class_2741.field_12508, true) :
                block.method_9564();
    }

    @Override
    public void method_55124(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
        if (!blockState.method_26215()) {
            this.removeDecoration(level, blockPos, null);
        }
    }

    @Override
    @NotNull
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2680 returnVal = super.method_9576(level, blockPos, blockState, player);
        this.removeDecoration(level, blockPos, player);
        return returnVal;
    }

    private void removeDecoration(class_1937 level, class_2338 blockPos, class_1657 player) {
        class_2586 blockEntity = level.method_8321(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            decorationBlockEntity.destroyStructure(player == null || !player.method_7337());
            if (player != null) for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : decorationBlockEntity.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                    decorationBehaviour.postBreak(decorationBlockEntity, blockPos, player);
                }
            }
        } else {
            level.method_22352(blockPos, false);
        }
    }

    @Override
    @NotNull
    public class_265 method_9549(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        if (!getDecorationData().hasBlocks()) {
            return class_259.method_1073();
        } else {
            return class_259.method_1077();
        }
    }

    @Override
    public boolean method_10310(@Nullable class_1657 player, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3611 fluid) {
        if (DecorationRegistry.isDecoration(blockState)) {
            DecorationData data = ((DecorationBlock)blockState.method_26204()).getDecorationData();
            if (data != null && (data.properties().waterloggable || !data.properties().solid)) {
                return fluid == class_3612.field_15910 || fluid == class_3612.field_15909;
            }
        }

        return false;
    }

    public boolean method_10311(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_3610 fluidState) {
        if (DecorationRegistry.isDecoration(blockState) && ((DecorationBlock)blockState.method_26204()).getDecorationData() != null) {
            DecorationData data = ((DecorationBlock)blockState.method_26204()).getDecorationData();
            if (data.properties().waterloggable) {
                return class_3737.super.method_10311(levelAccessor, blockPos, blockState, fluidState);
            } else {
                return false;
            }
        }

        return false;
    }

    @Override
    @NotNull
    public class_3610 method_9545(class_2680 blockState) {
        return blockState.method_28498(WATERLOGGED) && blockState.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(blockState);
    }

    @Override
    @NotNull
    public class_2680 method_9559(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        if (blockState.method_28498(WATERLOGGED) && blockState.method_11654(WATERLOGGED)) {
            levelAccessor.method_39281(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelAccessor));
        }

        return super.method_9559(blockState, direction, blockState2, levelAccessor, blockPos, blockPos2);
    }

    @Override
    @Nullable
    public class_2680 method_9605(class_1750 blockPlaceContext) {
        class_3610 fluidState = blockPlaceContext.method_8045().method_8316(blockPlaceContext.method_8037());
        boolean bl = fluidState.method_15771() && fluidState.method_15772() == class_3612.field_15910;
        var res = super.method_9605(blockPlaceContext);
        assert res != null;
        return res.method_28498(WATERLOGGED) ? res.method_11657(WATERLOGGED, bl) : res;
    }
}

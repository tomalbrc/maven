package de.tomalbrc.filament.util;

import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.joml.*;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3341;
import net.minecraft.class_3532;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import net.minecraft.class_8104;

public class DecorationUtil {
    public static void forEachRotated(List<DecorationData.BlockConfig> blockConfigs, class_2338 originBlockPos, float rotation, Consumer<class_2338> consumer) {
        if (blockConfigs != null) {
            for (DecorationData.BlockConfig blockConfig : blockConfigs) {
                Vector3fc origin = blockConfig.origin();
                Vector3fc size = blockConfig.size();
                for (int x = 0; x < size.x(); x++) {
                    for (int y = 0; y < size.y(); y++) {
                        for (int z = 0; z < size.z(); z++) {
                            Vector3f pos = new Vector3f(x, y, z).add(origin);
                            Vector3f offset = pos.mul(rotation % 90 != 0 ? org.joml.Math.sqrt(2) : 1);
                            offset.rotateY(org.joml.Math.toRadians(rotation + (FilamentConfig.getInstance().alternativeBlockPlacement ? 0 : 180)));

                            class_2338 blockPos = new class_2338(originBlockPos).method_10069(-org.joml.Math.round(offset.x), org.joml.Math.round(offset.y), Math.round(offset.z));
                            consumer.accept(blockPos);
                        }
                    }
                }
            }
        }
    }

    public static Vector2f barrierDimensions(List<DecorationData.BlockConfig> blockConfigs, float rotation) {
        if (!blockConfigs.isEmpty()) {
            List<class_2338> posList = new ObjectArrayList<>();
            DecorationUtil.forEachRotated(blockConfigs, class_2338.field_10980, rotation, posList::add);
            Optional<class_3341> boundingBox = class_3341.method_35411(posList);
            if (boundingBox.isPresent()) {
                return new Vector2f(java.lang.Math.max(boundingBox.get().method_35414(), boundingBox.get().method_14663()), boundingBox.get().method_14660());
            }
        }
        return new Vector2f();
    }

    public static InteractionElement decorationInteraction(DecorationBlockEntity blockEntity) {
        InteractionElement element = new InteractionElement();
        element.setHandler(new VirtualElement.InteractionHandler() {
            @Override
            public void interactAt(class_3222 player, class_1268 hand, class_243 pos) {
                class_3218 serverLevel = element.getHolder().getAttachment().getWorld();
                class_2338 blockPos = class_2338.method_49638(element.getHolder().getAttachment().getPos());
                if (serverLevel.method_8505(player, blockPos)) {
                    blockEntity.interact(player, hand, blockEntity.method_11016().method_46558().method_1023(0, 0.5f, 0).method_1019(pos));
                }
            }

            @Override
            public void attack(class_3222 player) {
                class_3218 serverLevel = element.getHolder().getAttachment().getWorld();
                class_2338 blockPos = class_2338.method_49638(element.getHolder().getAttachment().getPos());
                player.field_13974.method_14263(blockPos, class_2846.class_2847.field_12968, class_2350.field_11036, serverLevel.method_31600(), 0);
            }
        });

        if (blockEntity.getDecorationData() != null && blockEntity.getDecorationData().size() != null) {
            element.setSize(blockEntity.getDecorationData().size().x, blockEntity.getDecorationData().size().y);
        } else {
            element.setSize(1.f, blockEntity.getDirection().equals(class_2350.field_11033) ? 1.f : .5f); // default
        }

        var q = blockEntity.getDirection().method_62675();
        if (blockEntity.getDirection() != class_2350.field_11033 && blockEntity.getDirection() != class_2350.field_11036) {
            element.setOffset(new class_243(q.method_10263(), q.method_10264() + element.getHeight(), q.method_10260()).method_18805(1.f-element.getWidth(), 1, 1.f-element.getWidth()).method_1021(-0.5f));
        } else {
            element.setOffset(new class_243(q.method_10263(), q.method_10264(), q.method_10260()).method_1031(0,  blockEntity.getDirection() == class_2350.field_11036 ? -1.5f : 0.5f + ((1.f-element.getHeight())), 0));
        }

        return element;
    }

    public static InteractionElement decorationInteraction(DecorationData decorationData) {
        InteractionElement element = new InteractionElement();
        element.setHandler(new VirtualElement.InteractionHandler() {
            @Override
            public void attack(class_3222 player) {
                class_3218 serverLevel = element.getHolder().getAttachment().getWorld();
                class_2338 blockPos = class_2338.method_49638(element.getHolder().getAttachment().getPos());
                player.field_13974.method_14263(blockPos, class_2846.class_2847.field_12968, class_2350.field_11036, serverLevel.method_31600(), 0);
            }
        });
        element.setSize(1.f, 1.f);

        if (decorationData.size() != null) {
            element.setSize(decorationData.size().x, decorationData.size().y);
        } else {
            element.setSize(1.f, 1.f);
        }

        element.setOffset(new class_243(0, -0.5f, 0));

        return element;
    }

    public static ItemDisplayElement decorationItemDisplay(DecorationBlockEntity blockEntity) {
        ItemDisplayElement display = decorationItemDisplay(blockEntity.getDecorationData(), blockEntity.getDirection(), blockEntity.getVisualRotationYInDegrees());
        display.setItem(blockEntity.getItem().method_46651(1));
        return display;
    }

    public static ItemDisplayElement decorationItemDisplay(DecorationData data, class_2350 direction, float rotation) {
        ItemDisplayElement itemDisplayElement = new ItemDisplayElement(class_7923.field_41178.method_10223(data.id()).orElseThrow().comp_349());
        itemDisplayElement.setTeleportDuration(1);

        if (data != null && data.properties().glow) {
            itemDisplayElement.setBrightness(class_8104.field_42264);
        }

        Vector2f size = new Vector2f(1);
        if (data.hasBlocks()) {
            size = DecorationUtil.barrierDimensions(data.blocks(), rotation);
        } else if (data.size() != null) {
            size = data.size();
        }

        Matrix4f matrix4f = new Matrix4f().identity();
        matrix4f.scale(0.5f);

        if (direction == class_2350.field_11033 || direction == class_2350.field_11036) {
            matrix4f.setTranslation(0, -0.5f, 0);

            float ang = (float) java.lang.Math.toRadians(rotation + 180);
            double angleRadians = class_3532.method_15349(-class_3532.method_15374(ang), class_3532.method_15362(ang));
            matrix4f.rotate(class_7833.field_40716.rotation((float) angleRadians).normalize());
            matrix4f.rotate(class_7833.field_40714.rotationDegrees(-90));
            if (direction == class_2350.field_11033) {
                matrix4f.rotate(class_7833.field_40714.rotationDegrees(180));
                matrix4f.setTranslation(0, 0.5f, 0);
            }
        } else {
            double angleRadians = class_3532.field_29847 * direction.method_10144();
            Quaternionf rot = class_7833.field_40716.rotation((float) angleRadians).conjugate().normalize();
            matrix4f.rotate(rot);
            matrix4f.setTranslation(new Vector3f(0.f, 0.f, -0.5f).rotate(rot));

        }

        itemDisplayElement.setDisplayWidth(size.x * 2.f);
        itemDisplayElement.setDisplayHeight(size.y * 2.f);

        itemDisplayElement.setTransformation(matrix4f);
        itemDisplayElement.setModelTransformation(data.properties().display);

        return itemDisplayElement;
    }

    public static void showBreakParticle(class_3218 level, class_1799 stack, float x, float y, float z) {
        level.method_65096(new class_2392(class_2398.field_11218, stack), x, y, z, 27, 0.125, 0.125, 0.125, 0.05);
    }
}

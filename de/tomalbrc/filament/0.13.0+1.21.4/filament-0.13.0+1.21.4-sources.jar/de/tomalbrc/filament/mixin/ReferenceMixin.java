package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.registry.BlockRegistry;
import de.tomalbrc.filament.registry.ItemRegistry;
import it.unimi.dsi.fastutil.objects.ObjectArraySet;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.Set;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

// for ability to supply tags in filament jsons
@Mixin(class_6880.class_6883.class)
public abstract class ReferenceMixin<T> {
    @Shadow public abstract boolean isBound();

    @Shadow @Nullable private class_5321<T> key;

    @Shadow @Nullable private Set<class_6862<T>> tags;

    @Inject(method = "bindTags", at = @At("HEAD"), cancellable = true)
    private void dd(Collection<class_6862<T>> collection, CallbackInfo ci) {
        if (this.key != null && this.key.method_58273().method_29177() == class_7923.field_41178.method_46765().method_29177() && ItemRegistry.ITEMS_TAGS.containsKey(this.key.method_29177())) {
            // inject tags
            Set<class_6862<T>> modifiableCopy = new ObjectArraySet<>(collection);
            var tags = ItemRegistry.ITEMS_TAGS.get(this.key.method_29177());
            if (tags != null) for (class_2960 tag : tags) {
                class_6862<T> newTagKey = class_6862.method_40092(key.method_58273(), tag);
                modifiableCopy.add(newTagKey);
            }

            this.tags = modifiableCopy;
            ci.cancel();

        } else if (this.key != null && this.key.method_58273().method_29177() == class_7923.field_41175.method_46765().method_29177() && BlockRegistry.BLOCKS_TAGS.containsKey(this.key.method_29177())) {
            // inject tags
            Set<class_6862<T>> modifiableCopy = new ObjectArraySet<>(collection);
            var tags = BlockRegistry.BLOCKS_TAGS.get(this.key.method_29177());
            if (tags != null) for (class_2960 tag : tags) {
                class_6862<T> newTagKey = class_6862.method_40092(key.method_58273(), tag);
                modifiableCopy.add(newTagKey);
            }
            this.tags = modifiableCopy;
            ci.cancel();
        }
    }
}

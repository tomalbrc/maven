package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.util.BlockUtil;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.core.api.item.PolymerItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2428;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

@Mixin(class_1747.class)
public abstract class BlockItemMixin {
    @Shadow public abstract class_2248 getBlock();

    @Inject(method = "place", locals = LocalCapture.CAPTURE_FAILSOFT, at = @At("TAIL"))
    private void filament$onPlaceBlock(class_1750 context, CallbackInfoReturnable<class_1269> cir, class_1750 context2, class_2680 placementState, class_2338 blockPos, class_1937 level) {
        class_1747 blockItem = (class_1747) (Object) this;

        if (context.method_8036() instanceof class_3222 player && !player.method_21823() &&
                !context.method_7717() &&
                !(blockItem instanceof PolymerItem)
        ) {
            class_2338 pos = context.method_8037();
            class_2338 clickedPos = pos.method_10093(context.method_8038().method_10153());
            class_2680 clickedState = context.method_8045().method_8320(clickedPos);

            if (clickedState.method_26204() instanceof PolymerBlock polymerBlock && polymerBlock.getPolymerBlockState(clickedState, PacketContext.create(player)).method_26204() instanceof class_2428) {
                BlockUtil.playBlockPlaceSound(player, pos, placementState.method_26231());
            }
        }
    }

    @Inject(method = "appendHoverText", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;appendHoverText(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/Item$TooltipContext;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V"), cancellable = true)
    void filament$fixupAppendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag, CallbackInfo ci) {
        if (this.getBlock() == null) {
            ci.cancel();
        }
    }
}

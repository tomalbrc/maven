package de.tomalbrc.filament.decoration.util.impl;

import de.tomalbrc.filament.data.behaviours.decoration.Lock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

public class LockImpl {
    public Lock lock;
    public boolean unlocked = false;
    public String command = null;

    public LockImpl(Lock lock) {
        this.lock = lock;
    }

    public boolean interact(class_3222 player, DecorationBlockEntity decorationBlockEntity) {
        if (this.unlocked)
            return false;

        class_1792 key = this.lock.key == null ? null : class_7923.field_41178.method_10223(this.lock.key);
        class_1799 mainHandItem = player.method_5998(class_1268.field_5808);
        boolean hasHandItem = !mainHandItem.method_7960();
        boolean holdsKeyAndIsValid = hasHandItem && key != null && mainHandItem.method_31574(key);
        boolean noItemNoKey = !hasHandItem && (key == null);
        if (holdsKeyAndIsValid || noItemNoKey) {
            if (this.lock.consumeKey && hasHandItem) {
                mainHandItem.method_7934(1);
            }

            // TODO: FIX LOCK ANIMATION
            //if (this.lock.unlockAnimation != null && !lock.unlockAnimation.isEmpty() && decorationBlockEntity instanceof AjDecorationBlockEntity ajDecorationEntity) {
            //    decorationBlockEntity.play(lock.unlockAnimation);
            //}

            this.unlocked = true;

            boolean validCommand = this.command != null && !this.command.isEmpty();
            boolean validLockCommand = this.lock.command != null && !this.lock.command.isEmpty();
            if ((validCommand || validLockCommand) && player.method_5682() != null) {
                player.method_5682().method_3734().method_44252(player.method_5682().method_3739().method_9208(decorationBlockEntity.method_11016().method_46558()), validCommand ? this.command : this.lock.command);
            }

            if (this.lock.discard) {
                decorationBlockEntity.destroyStructure(false);
            }
        }

        return this.unlocked;
    }

    public void read(class_2487 compoundTag) {
        if (compoundTag.method_10545("Lock")) {
            class_2487 lock = compoundTag.method_10562("Lock");

            if (compoundTag.method_10545("Command"))
                this.command = lock.method_10558("Command");

            if (compoundTag.method_10545("Unlocked"))
                this.unlocked = lock.method_10577("Unlocked");
        }
    }

    public void write(class_2487 compoundTag) {
        class_2487 lockTag = new class_2487();

        if (this.command != null && !this.command.isEmpty())
            lockTag.method_10582("Command", this.command);

        lockTag.method_10556("Unlocked", this.unlocked);

        compoundTag.method_10566("Lock", lockTag);
    }
}

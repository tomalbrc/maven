package de.tomalbrc.filament.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import de.tomalbrc.filament.decoration.block.DecorationBlock;

public class PickCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        LiteralCommandNode<class_2168> pickNode = class_2170
                .method_9247("pick")
                .executes(PickCommand::execute)
                .build();

        dispatcher.getRoot().addChild(pickNode);
    }

    private static int execute(CommandContext<class_2168> context) {
        if (context.getSource() != null && context.getSource().method_44023() != null) {
            class_3222 player = context.getSource().method_44023();

            for (int i = 1; i <= 8; i++) {
                class_243 pos = player.method_33571().method_1019(player.method_5828(1).method_1029().method_1021(i*0.5f));
                class_2338 blockPos = class_2338.method_49638(pos);

                class_2680 state = player.method_37908().method_8320(blockPos);
                if (state.method_26204() instanceof DecorationBlock) {
                    if (player.method_37908().method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                        class_1799 item = decorationBlockEntity.getItem().method_7972();

                        if (player.method_7337()) {
                            player.method_6122(class_1268.field_5808, item);
                        } else {
                            int slot = player.method_31548().method_7395(item);
                            if (slot != -1) {
                                player.method_31548().method_7365(slot);
                            }
                        }

                        // eh, may actually not be successful, but it's not like this return value changes anything..?
                        return Command.SINGLE_SUCCESS;
                    }
                } else if (!state.method_26215() && !state.method_51176()) {
                    player.method_6122(class_1268.field_5808, state.method_26204().method_8389().method_7854());
                    return Command.SINGLE_SUCCESS;
                }
            }
        }
        return 0;
    }
}

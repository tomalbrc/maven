package de.tomalbrc.filament.registry.filament;

import de.tomalbrc.filament.enchantment.*;
import de.tomalbrc.filament.util.Constants;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

@SuppressWarnings("unused")
public class EnchantmentRegistry {
    public static class_1887 BLACKENED_EDGE = register(new class_2960(Constants.MOD_ID, "blackened_edge"), new BlackenedEdgeEnchantment());
    public static class_1887 LETHARGY = register(new class_2960(Constants.MOD_ID, "lethargy"), new LethargyEnchantment());
    public static class_1887 LUMINOUS_BLADE = register(new class_2960(Constants.MOD_ID, "luminous_blade"), new LuminousBladeEnchantment());
    public static class_1887 WINTERS_GRASP = register(new class_2960(Constants.MOD_ID, "winters_grasp"), new WintersGraspEnchantment());
    public static class_1887 MAGNETIZED = register(new class_2960(Constants.MOD_ID, "magnetized"), new MagnetizedEnchantment());
    public static class_1887 INFERNAL_TOUCH = register(new class_2960(Constants.MOD_ID, "infernal_touch"), new InfernalTouchEnchantment());

    public static void register() {
    }

    private static class_1887 register(class_2960 id, class_1887 enchantment) {
        class_2378.method_10230(class_7923.field_41176, id, enchantment);
        return enchantment;
    }
}

package de.tomalbrc.filament.item;

import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerArmorModel;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5151;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;
import de.tomalbrc.filament.data.ItemData;

import java.util.List;

public class SimpleItem extends class_1792 implements PolymerItem, class_5151 {
    final protected ItemData itemData;
    final protected Object2ObjectOpenHashMap<String, PolymerModelData> modelData;

    @Nullable
    PolymerArmorModel armorModel = null;

    public SimpleItem(class_1793 properties, ItemData itemData) {
        super(properties);
        this.itemData = itemData;
        this.modelData = this.itemData.requestModels();

        // For armor
        if (this.itemData.behaviour() != null && this.itemData.behaviour().armor != null && this.itemData.behaviour().armor.texture != null) {
            this.armorModel = PolymerResourcePackUtils.requestArmor(this.itemData.behaviour().armor.texture);
        }
    }

    @Override
    public void method_7851(class_1799 itemStack, @Nullable class_1937 level, List<class_2561> tooltip, class_1836 tooltipFlag) {
        if (itemData.properties() != null)
            itemData.properties().appendHoverText(tooltip);
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, @Nullable class_3222 player) {
        return itemData.vanillaItem() != null ? itemData.vanillaItem() : class_1802.field_8407;
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        return modelData != null ? this.modelData.get("default").value() : -1;
    }

    @Override
    public int getPolymerArmorColor(class_1799 itemStack, @Nullable class_3222 player) {
        return armorModel != null ? this.armorModel.color() : -1;
    }

    public class_1304 method_7685() {
        if (itemData.behaviour() != null && itemData.behaviour().armor != null && itemData.behaviour().armor.slot != null) {
            return itemData.behaviour().armor.slot;
        }
        return class_1304.field_6173;
    }
}

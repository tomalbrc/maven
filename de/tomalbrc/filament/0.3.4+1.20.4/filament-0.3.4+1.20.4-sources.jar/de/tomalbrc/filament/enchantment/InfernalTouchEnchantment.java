package de.tomalbrc.filament.enchantment;

import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_1893;

public class InfernalTouchEnchantment extends class_1887 implements PolymerEnchantment {
    public InfernalTouchEnchantment() {
        super(class_1888.field_9088, class_1886.field_9069, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public int method_8182(int level) {
        return level*50;
    }

    @Override
    public int method_8183() {
        return 1;
    }

    @Override
    protected boolean method_8180(class_1887 enchantment) {
        return super.method_8180(enchantment) && enchantment != class_1893.field_9099;
    }

    @Override
    public boolean method_8192(class_1799 itemStack) {
        return super.method_8192(itemStack) && itemStack.method_7909() instanceof class_1810;
    }
}

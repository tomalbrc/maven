package de.tomalbrc.filament.enchantment;

import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_3222;

public class MagnetizedEnchantment extends class_1887 implements PolymerEnchantment {
    public MagnetizedEnchantment() {
        super(class_1888.field_9090, class_1886.field_9069, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public int method_8182(int level) {
        return level*27;
    }

    @Override
    public int method_8183() {
        return 1;
    }

    @Override
    protected boolean method_8180(class_1887 enchantment) {
        return super.method_8180(enchantment);
    }

    @Override
    public class_1887 getPolymerReplacement(class_3222 player) {
        return null;
    }
}

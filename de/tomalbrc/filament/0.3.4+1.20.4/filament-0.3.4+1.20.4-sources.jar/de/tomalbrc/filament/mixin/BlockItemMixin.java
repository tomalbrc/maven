package de.tomalbrc.filament.mixin;

import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2428;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import de.tomalbrc.filament.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1747.class)
public class BlockItemMixin {
    @Inject(method = "place", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("TAIL"))
    private void onPlaceBlock(class_1750 context, CallbackInfoReturnable<class_1269> cir, class_1750 context2, class_2680 placementState, class_2338 blockPos, class_1937 level) {
        class_1747 blockItem = (class_1747) (Object) this;

        if (context.method_8036() instanceof class_3222 player && !player.method_21823() &&
            !context.method_7717() &&
            !(blockItem instanceof PolymerItem)
        ) {
            class_2338 pos = context.method_8037();
            class_2338 clickedPos = pos.method_10093(context.method_8038().method_10153());
            class_2680 clickedState = context.method_8045().method_8320(clickedPos);

            if (clickedState.method_26204() instanceof PolymerBlock polymerBlock && polymerBlock.getPolymerBlock(clickedState, player) instanceof class_2428) {
                Util.playBlockPlaceSound(player, pos, placementState.method_26231());
            }
        }
    }
}

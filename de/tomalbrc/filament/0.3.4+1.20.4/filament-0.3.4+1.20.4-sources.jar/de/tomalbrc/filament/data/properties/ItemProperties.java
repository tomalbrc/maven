package de.tomalbrc.filament.data.properties;

import org.jetbrains.annotations.Nullable;
import de.tomalbrc.filament.data.behaviours.item.ItemBehaviourList;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_4174;

// For shared properties that make sense for both, item *and* decoration
public class ItemProperties {
    public int durability = Integer.MIN_VALUE;
    public int stackSize = 64;
    public List<String> lore;
    public boolean fireResistant;

    // for blocks & decoration
    public int lightEmission = Integer.MIN_VALUE;

    public void appendHoverText(List<class_2561> tooltip) {
        if (lore != null)
            lore.forEach(line -> tooltip.add(class_2561.method_43470(line)));
    }

    public class_1792.class_1793 toItemProperties() {
        return toItemProperties(null, null);
    }

    public class_1792.class_1793 toItemProperties(@Nullable class_1792 vanillaItem, @Nullable ItemBehaviourList behaviour) {
        class_1792.class_1793 props = new class_1792.class_1793();

        props.method_7889(stackSize);

        if (durability != Integer.MIN_VALUE)
            props.method_7895(durability);

        if (fireResistant)
            props.method_24359();

        if (behaviour != null && behaviour.food != null) {
            class_4174.class_4175 builder = new class_4174.class_4175();

            if (behaviour.food.meat) builder.method_19236();
            if (vanillaItem != null) {
                class_4174 vanillaFood = vanillaItem.method_19264();
                if (vanillaFood != null) {
                    if (vanillaFood.method_19234()) builder.method_19241();
                    if (vanillaFood.method_19233()) builder.method_19240();
                }
            }

            builder.method_19237(behaviour.food.saturation);
            builder.method_19238(behaviour.food.hunger);

            props.method_19265(builder.method_19242());
        }

        return props;
    }

    public boolean isLightSource() {
        return this.lightEmission != Integer.MIN_VALUE;
    }
}

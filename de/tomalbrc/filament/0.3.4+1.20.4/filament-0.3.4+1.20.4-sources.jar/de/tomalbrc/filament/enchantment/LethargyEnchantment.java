package de.tomalbrc.filament.enchantment;

import eu.pb4.polymer.core.api.other.PolymerEnchantment;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_3222;

public class LethargyEnchantment extends class_1887 implements PolymerEnchantment {
    public LethargyEnchantment() {
        super(class_1888.field_9087, class_1886.field_9074, new class_1304[] {class_1304.field_6173});
    }

    @Override
    public int method_8182(int level) {
        return 8*level;
    }

    @Override
    public int method_8183() {
        return 4;
    }

    @Override
    public void method_8189(class_1309 user, class_1297 target, int level) {
        if (target instanceof class_1309 livingEntity) {
            livingEntity.method_6092(new class_1293(class_1294.field_5909, 20 * 3 * level, level - 1));
        }

        super.method_8189(user, target, level);
    }

    @Override
    public class_1887 getPolymerReplacement(class_3222 player) {
        return null;
    }
}
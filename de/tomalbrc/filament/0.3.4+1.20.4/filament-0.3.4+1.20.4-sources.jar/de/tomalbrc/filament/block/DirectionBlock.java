package de.tomalbrc.filament.block;

import com.mojang.serialization.MapCodec;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import de.tomalbrc.filament.data.BlockData;

import java.util.HashMap;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class DirectionBlock extends class_2318 implements PolymerTexturedBlock {
    private final HashMap<String, class_2680> stateMap;
    private final class_2680 breakEventState;

    public MapCodec<DirectionBlock> method_53969() {
        return null;
    }

    public DirectionBlock(class_2251 properties, BlockData data) {
        super(properties);
        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
    }

    @Override
    public class_2248 getPolymerBlock(class_2680 state) {
        return this.getPolymerBlockState(state).method_26204();
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return stateMap.get(state.method_11654(field_10927).method_15434());
    }
}

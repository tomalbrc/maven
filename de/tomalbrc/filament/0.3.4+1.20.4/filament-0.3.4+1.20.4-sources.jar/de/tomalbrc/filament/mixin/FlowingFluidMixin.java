package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.registry.filament.DecorationRegistry;
import it.unimi.dsi.fastutil.objects.Object2ByteLinkedOpenHashMap;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_3609.class)
public class FlowingFluidMixin {

    @Inject(method = "canSpreadTo", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("TAIL"), cancellable = true)
    private void filament$canSpreadTo(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_3610 fluidState, class_3611 fluid, CallbackInfoReturnable<Boolean> cir) {
        if (DecorationRegistry.isDecoration(blockState2)) {
            boolean isWaterloggable = this.isWaterloggable((DecorationBlock) blockState2.method_26204()) && direction != class_2350.field_11033;
            boolean isSolid = this.isSolid((DecorationBlock) blockState2.method_26204()) && direction != class_2350.field_11033;
            cir.setReturnValue(isWaterloggable || !isSolid);
        }
    }

    @Inject(method = "spreadTo", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("TAIL"))
    protected void filament$spreadTo(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_3610 fluidState, CallbackInfo ci) {
        if (DecorationRegistry.isDecoration(blockState) && !isWaterloggable((DecorationBlock) blockState.method_26204()) && !isSolid((DecorationBlock) blockState.method_26204())) {
            if (levelAccessor.method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                decorationBlockEntity.destroyStructure(true);
            }

            // let it overflow with liquid
            levelAccessor.method_8652(blockPos, fluidState.method_15759(), 3);
        }
    }

    @Inject(method = "canPassThrough", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("TAIL"), cancellable = true)
    private void filament$canPassThrough(class_1922 blockGetter, class_3611 fluid, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_3610 fluidState, CallbackInfoReturnable<Boolean> cir) {
        // pass-thu but only non-waterloggable blocks and non-solid
        if (DecorationRegistry.isDecoration(blockState2) && !isWaterloggable((DecorationBlock) blockState2.method_26204()) && !isSolid((DecorationBlock) blockState2.method_26204()))
            cir.setReturnValue(this.canFlowThrough(blockState2));
    }
    @Inject(method = "canPassThroughWall", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("TAIL"), cancellable = true)
    private void filament$canPassThroughWall(class_2350 direction, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2338 blockPos2, class_2680 blockState2, CallbackInfoReturnable<Boolean> cir, Object2ByteLinkedOpenHashMap object2ByteLinkedOpenHashMap, class_2248.class_2249 blockStatePairKey, class_265 voxelShape, class_265 voxelShape2, boolean bl) {
        if (DecorationRegistry.isDecoration(blockState) || DecorationRegistry.isDecoration(blockState2))
            cir.setReturnValue(true);
    }

    @Unique
    private boolean canFlowThrough(class_2680 blockState) {
        if (DecorationRegistry.isDecoration(blockState)) {
            DecorationBlock decorationBlock = (DecorationBlock) blockState.method_26204();

            if (decorationBlock.getDecorationData() != null && decorationBlock.getDecorationData().properties() != null) {
                return !decorationBlock.getDecorationData().hasBlocks() && !decorationBlock.getDecorationData().properties().waterloggable && !decorationBlock.getDecorationData().properties().solid;
            }
        }

        return false;
    }

    @Unique
    private boolean isWaterloggable(DecorationBlock decorationBlock) {
        if (decorationBlock.getDecorationData() != null && decorationBlock.getDecorationData().properties() != null) {
            return decorationBlock.getDecorationData().properties().waterloggable;
        }

        return false;
    }

    @Unique
    private boolean isSolid(DecorationBlock decorationBlock) {
        if (decorationBlock.getDecorationData() != null && decorationBlock.getDecorationData().properties() != null) {
            return decorationBlock.getDecorationData().properties().solid;
        }

        return false;
    }
}

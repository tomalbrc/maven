package de.tomalbrc.filament.block;

import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_3222;

public class SimpleBlockItem extends CustomBlockItem implements PolymerItem {
    private final PolymerModelData polymerModel;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties);
        this.polymerModel = PolymerResourcePackUtils.requestModel(
                data.properties().itemBase,
                data.itemResource() != null && data.itemResource().models() != null ? data.itemResource().models().get("default") : data.blockResource().models().entrySet().iterator().next().getValue()
        );
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, class_3222 player) {
        return this.polymerModel.item();
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, class_3222 player) {
        return this.polymerModel.value();
    }
}
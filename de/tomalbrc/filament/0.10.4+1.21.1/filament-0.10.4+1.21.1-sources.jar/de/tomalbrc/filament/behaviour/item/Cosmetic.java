package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3468;
import net.minecraft.class_5151;
import net.minecraft.class_9701;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

/**
 * Cosmetics; either head or chestplate slot, can be Blockbenchmodel for chestplate slot or simple item model for either
 */
public class Cosmetic implements ItemBehaviour<Cosmetic.Config> {
    private final Config config;

    public Cosmetic(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Cosmetic.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        if (item instanceof class_5151) {
            return swapWithEquipmentSlot(item, level, player, interactionHand);
        }

        return ItemBehaviour.super.use(item, level, player, interactionHand);
    }

    public static class_1271<class_1799> swapWithEquipmentSlot(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        class_1304 equipmentSlot = player.method_32326(itemStack);
        if (!player.method_56991(equipmentSlot)) {
            return class_1271.method_22430(itemStack);
        } else {
            class_1799 itemStack2 = player.method_6118(equipmentSlot);
            if ((!class_1890.method_60142(itemStack2, class_9701.field_51656) || player.method_7337()) && !class_1799.method_7973(itemStack, itemStack2)) {
                if (!level.method_8608()) {
                    player.method_7259(class_3468.field_15372.method_14956(item));
                }

                class_1799 itemStack3 = itemStack2.method_7960() ? itemStack : itemStack2.method_51164();
                itemStack.method_57008(1, player);
                class_1799 itemStack4 = itemStack.method_7972();
                player.method_5673(equipmentSlot, itemStack4.method_46651(1));
                return class_1271.method_29237(itemStack3, level.method_8608());
            } else {
                return class_1271.method_22431(itemStack);
            }
        }
    }

    @Override
    public class_1304 getEquipmentSlot() {
        return this.config.slot;
    }

    public static class Config {
        /**
         * The equipment slot for the cosmetic (head, chest).
         */
        public class_1304 slot;

        /**
         * The resource location of the animated model for the cosmetic.
         */
        public class_2960 model;

        /**
         * The name of the animation to autoplay. The animation should be loopable
         */
        public String autoplay;

        /**
         * Scale of the chest cosmetic
         */
        public Vector3f scale = new Vector3f(1);

        /**
         * Translation of the chest cosmetic
         */
        public Vector3f translation = new Vector3f();
    }
}

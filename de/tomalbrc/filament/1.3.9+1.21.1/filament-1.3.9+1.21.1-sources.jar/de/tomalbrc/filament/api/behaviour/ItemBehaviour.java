package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7225;

public interface ItemBehaviour<T> extends Behaviour<T> {
    default void init(class_1792 item, BehaviourHolder behaviourHolder) {
    }

    default void appendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> consumer, class_1836 tooltipFlag) {
    }

    default class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        return class_1271.method_22430(player.method_5998(interactionHand));
    }

    default Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.empty();
    }

    default class_1269 useOn(class_1838 useOnContext) {
        return class_1269.field_5811;
    }

    default void onUseTick(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
    }

    default void releaseUsing(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
    }

    default boolean useOnRelease(class_1799 itemStack) {
        return false;
    }

    default void modifyPolymerItemStack(Map<String, class_2960> models, class_1799 original, class_1799 replacement, class_1836 tooltipType, class_7225.class_7874 lookup, @Nullable class_3222 player) {
    }

    default boolean mineBlock(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_1309 livingEntity) {
        return false;
    }

    default boolean hurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        return true;
    }

    default void postHurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {}

    default float getAttackDamageBonus(class_1297 entity, float f, class_1282 damageSource) {
        return 0.f;
    }

    default @Nullable class_1282 getDamageSource(class_1309 livingEntity) {
        return null;
    }

    default class_1304 getEquipmentSlot() {
        return class_1304.field_6173;
    }

    default int modifyPolymerArmorColor(class_1799 itemStack, @Nullable class_3222 player, int color) {
        return -1;
    }

    default int modifyPolymerCustomModelData(Map<String, PolymerModelData> modelData, class_1799 itemStack, @Nullable class_3222 player) {
        return -1;
    }
}

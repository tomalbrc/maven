package de.tomalbrc.filament.registry;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.block.*;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.datafixer.config.BlockDataFix;
import de.tomalbrc.filament.item.FilamentItem;
import de.tomalbrc.filament.util.*;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import net.minecraft.core.Registry;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public class BlockRegistry {
    public static Map<Identifier, Collection<Identifier>> BLOCKS_TAGS = new Object2ReferenceOpenHashMap<>();

    public static void register(Path filepath, InputStream inputStream) throws IOException {
        JsonElement element = JsonParser.parseReader(new InputStreamReader(inputStream));
        try {
            BlockData data = Json.GSON.fromJson(element, BlockData.class);
            data.filepath = filepath;
            BlockDataFix.fixup(element, data);
            Util.handleComponentsCustom(element, data);

            register(data);
        } catch (Exception e) {
            Filament.LOGGER.error("Could not load file! Error: {}", String.valueOf(e.fillInStackTrace()));
            Filament.LOGGER.info("Path: {}", filepath);
            Filament.LOGGER.info("File: \n{}", element.toString());
        }
    }

    public static void register(InputStream inputStream) throws IOException {
        register(null, inputStream);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void register(BlockData data) {
        if (BuiltInRegistries.BLOCK.containsKey(data.id())) {
            var block = BuiltInRegistries.BLOCK.getValue(data.id());
            if (block.isFilamentBlock() && block.asItem().isFilamentItem()) {
                block.asItem().asFilamentItem().initBehaviours(data.behaviour());
                block.asFilamentBlock().initBehaviours(data.behaviour());
                postRegistration(block.asItem().asFilamentItem(), block.asFilamentBlock(), data);
            }
            return;
        }

        BlockProperties properties = data.properties();
        BlockBehaviour.Properties blockProperties = properties.toBlockProperties();

        SimpleBlock customBlock;
        // ok this is starting to get messy
        if (data.requiresEntityBlock()) {
            if (data.virtual()) {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleVirtualBlockWithEntity(props, data), blockProperties, data.blockTags());
            } else {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleBlockWithEntity(props, data), blockProperties, data.blockTags());
            }
        } else {
            if (data.virtual()) {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleVirtualBlock(props, data), blockProperties, data.blockTags());
            } else {
                customBlock = BlockRegistry.registerBlock(key(data.id()), (props)-> new SimpleBlock(props, data), blockProperties, data.blockTags());
            }
        }

        Item.Properties itemProperties = data.properties().toItemProperties();

        SimpleBlockItem item = ItemRegistry.registerItem(ItemRegistry.key(data.id()), (newProps) -> new SimpleBlockItem(newProps, customBlock, data), itemProperties, data.group() != null ? data.group() : Constants.BLOCK_GROUP_ID, data.itemTags());
        postRegistration(item, customBlock, data);

        FilamentRegistrationEvents.BLOCK.invoker().registered(data, item, customBlock);
    }

    static void postRegistration(FilamentItem item, SimpleBlock customBlock, Data<?> data) {
        BehaviourUtil.postInitItem(item.asItem(), item, data.behaviour());
        BehaviourUtil.postInitBlock(customBlock, data.behaviour());
        Translations.add(item.asItem(), customBlock, data);

        // has to run before `postRegister` since it may add block models from textures
        RPUtil.create(item, data);

        customBlock.postRegister();
    }

    public static ResourceKey<Block> key(Identifier id) {
        return ResourceKey.create(Registries.BLOCK, id);
    }

    public static <T extends Block> T registerBlock(ResourceKey<Block> resourceKey, Function<BlockBehaviour.Properties, T> function, BlockBehaviour.Properties properties, @Nullable Set<Identifier> blockTags) {
        T block = function.apply(properties.setId(resourceKey));
        if (blockTags != null) for (Identifier tag : blockTags) {
            var list = BLOCKS_TAGS.computeIfAbsent(tag, x -> new ArrayList<>());
            list.add(resourceKey.identifier());
        }
        return Registry.register(BuiltInRegistries.BLOCK, resourceKey, block);
    }

    public static class BlockDataReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public Identifier getFabricId() {
            return Identifier.fromNamespaceAndPath(Constants.MOD_ID, Constants.MOD_ID);
        }

        @Override
        public void onResourceManagerReload(ResourceManager resourceManager) {
            load("filament/block", null, resourceManager, (id, inputStream) -> {
                try {
                    BlockRegistry.register(obtainPath(id, resourceManager), inputStream);
                } catch (Exception e) {
                    Filament.LOGGER.error("Failed to load block resource \"{}\".", id);
                }
            });
        }
    }
}

package de.tomalbrc.filament.api.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.minecraft.class_7225;

public interface DecorationBehaviour<T> extends Behaviour<T> {
    default void init(DecorationBlockEntity blockEntity) {}

    default ElementHolder createHolder(DecorationBlockEntity blockEntity) {
        return null;
    }

    default void onElementAttach(DecorationBlockEntity blockEntity, ElementHolder holder) {}

    default class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) { return class_1269.field_5811; }

    default void read(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {}

    default void write(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {}

    default void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {}

    default void modifyDrop(DecorationBlockEntity decorationBlockEntity, class_1799 itemStack) {}
}
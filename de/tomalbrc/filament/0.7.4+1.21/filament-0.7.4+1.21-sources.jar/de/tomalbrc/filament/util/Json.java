package de.tomalbrc.filament.util;

import com.google.gson.*;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.behaviours.BehaviourConfigMap;
import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.BlockModelType;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_3619;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.class_9323;

public class Json {
    public static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .registerTypeHierarchyAdapter(class_2680.class, new BlockStateDeserializer())
            .registerTypeHierarchyAdapter(class_1304.class, new EquipmentSlotDeserializer())
            .registerTypeHierarchyAdapter(Vector3f.class, new Vector3fDeserializer())
            .registerTypeHierarchyAdapter(Vector2f.class, new Vector2fDeserializer())
            .registerTypeHierarchyAdapter(Quaternionf.class, new QuaternionfDeserializer())
            .registerTypeHierarchyAdapter(class_2960.class, new class_2960.class_2961())
            .registerTypeHierarchyAdapter(BlockModelType.class, new BlockModelTypeDeserializer())
            .registerTypeHierarchyAdapter(class_811.class, new ItemDisplayContextDeserializer())
            .registerTypeHierarchyAdapter(class_9323.class, new DataComponentsDeserializer())
            .registerTypeHierarchyAdapter(class_3619.class, new PushReactionDeserializer())
            .registerTypeHierarchyAdapter(class_2248.class, new RegistryDeserializer<>(class_7923.field_41175))
            .registerTypeHierarchyAdapter(class_1792.class, new RegistryDeserializer<>(class_7923.field_41178))
            .registerTypeHierarchyAdapter(class_3414.class, new RegistryDeserializer<>(class_7923.field_41172))
            .registerTypeHierarchyAdapter(BehaviourConfigMap.class, new BehaviourConfigMap.Deserializer())
            .registerTypeHierarchyAdapter(BlockData.BlockType.class, new BlockData.BlockType.Deserializer())
            .create();

    public static class BlockStateDeserializer implements JsonDeserializer<class_2680> {
        @Override
        public class_2680 deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String name = json.getAsString().toLowerCase();

            class_2259.class_7211 parsed;
            try {
                parsed = class_2259.method_41957(class_7923.field_41175.method_46771(), name, false);
            } catch (CommandSyntaxException e) {
                throw new JsonParseException("Invalid BlockState value: " + name);
            }

            return parsed.comp_622();
        }
    }

    public static class EquipmentSlotDeserializer implements JsonDeserializer<class_1304> {
        @Override
        public class_1304 deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String name = json.getAsString().toLowerCase();

            for (class_1304 slot : class_1304.values()) {
                if (slot.name().equalsIgnoreCase(name)) {
                    return slot;
                }
            }

            throw new JsonParseException("Invalid EquipmentSlot value: " + name);
        }
    }

    public static class QuaternionfDeserializer implements JsonDeserializer<Quaternionf> {
        @Override
        public Quaternionf deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonArray jsonArray = jsonElement.getAsJsonArray();

            if (jsonArray.size() < 3) {
                throw new JsonParseException("Array size should be at least 3 for euler angle deserialization.");
            }

            float x = jsonArray.get(0).getAsFloat();
            float y = jsonArray.get(1).getAsFloat();
            float z = jsonArray.get(2).getAsFloat();

            return new Quaternionf().rotateXYZ(x * class_3532.field_29847, y * class_3532.field_29847, z * class_3532.field_29847);
        }
    }

    public static class Vector3fDeserializer implements JsonDeserializer<Vector3f> {
        @Override
        public Vector3f deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonArray jsonArray = jsonElement.getAsJsonArray();

            if (jsonArray.size() < 3) {
                throw new JsonParseException("Array size should be at least 3 for Vector3f deserialization.");
            }

            float x = jsonArray.get(0).getAsFloat();
            float y = jsonArray.get(1).getAsFloat();
            float z = jsonArray.get(2).getAsFloat();

            return new Vector3f(x, y, z);
        }
    }

    public static class Vector2fDeserializer implements JsonDeserializer<Vector2f> {
        @Override
        public Vector2f deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonArray jsonArray = jsonElement.getAsJsonArray();

            if (jsonArray.size() < 2) {
                throw new JsonParseException("Array size should be at least 2 for Vector2f deserialization.");
            }

            float x = jsonArray.get(0).getAsFloat();
            float y = jsonArray.get(1).getAsFloat();

            return new Vector2f(x, y);
        }
    }

    private static class BlockModelTypeDeserializer implements JsonDeserializer<BlockModelType> {
        @Override
        public BlockModelType deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
                throw new JsonParseException("Expected string, got " + element);
            }

            String value = element.getAsString().toUpperCase();
            try {
                return BlockModelType.valueOf(value);
            } catch (IllegalArgumentException e) {
                throw new JsonParseException("Invalid BlockModelType value: " + value, e);
            }
        }
    }

    private static class ItemDisplayContextDeserializer implements JsonDeserializer<class_811> {
        @Override
        public class_811 deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
                throw new JsonParseException("Expected string, got " + element);
            }

            String value = element.getAsString().toUpperCase();
            try {
                return class_811.valueOf(value);
            } catch (IllegalArgumentException e) {
                throw new JsonParseException("Invalid ItemDisplayContext value: " + value, e);
            }
        }
    }

    private static class PushReactionDeserializer implements JsonDeserializer<class_3619> {
        @Override
        public class_3619 deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
                throw new JsonParseException("Expected string, got " + element);
            }

            String value = element.getAsString().toUpperCase();
            try {
                return class_3619.valueOf(value);
            } catch (IllegalArgumentException e) {
                throw new JsonParseException("Invalid BlockModelType value: " + value, e);
            }
        }
    }

    private record RegistryDeserializer<T>(class_2378<T> registry) implements JsonDeserializer<T> {
        @Override
        public T deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            return this.registry.method_10223(class_2960.method_60654(element.getAsString()));
        }
    }

    public static class DataComponentsDeserializer implements JsonDeserializer<class_9323> {
        @Override
        public class_9323 deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            class_6903.class_7863 registryInfoLookup = createContext(class_5455.method_40302(class_7923.field_41167));
            DataResult<Pair<class_9323, JsonElement>> result = class_9323.field_50234.decode(class_6903.method_40414(JsonOps.INSTANCE, registryInfoLookup), jsonElement);

            if (result.resultOrPartial().isEmpty()) {
                return null;
            }

            return result.resultOrPartial().get().getFirst();
        }

        private static class_6903.class_7863 createContext(class_5455 registryAccess) {
            final Map<class_5321<? extends class_2378<?>>, class_6903.class_7862<?>> map = new HashMap<>();
            registryAccess.method_40311().forEach((registryEntry) -> map.put(registryEntry.comp_350(), createInfoForContextRegistry(registryEntry.comp_351())));
            return new class_6903.class_7863() {
                public <T> Optional<class_6903.class_7862<T>> method_46623(class_5321<? extends class_2378<? extends T>> resourceKey) {
                    return Optional.ofNullable((class_6903.class_7862)map.get(resourceKey));
                }
            };
        }

        private static <T> class_6903.class_7862<T> createInfoForContextRegistry(class_2378<T> registry) {
            return new class_6903.class_7862(registry.method_46771(), registry.method_46772(), registry.method_31138());
        }
    }
}

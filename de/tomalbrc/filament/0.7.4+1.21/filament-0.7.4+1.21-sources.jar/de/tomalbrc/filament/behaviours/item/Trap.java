package de.tomalbrc.filament.behaviours.item;

import de.tomalbrc.filament.api.behaviour.item.ItemBehaviour;
import java.util.List;
import net.minecraft.class_2960;

/**
 * Mob trap
 */
public class Trap implements ItemBehaviour<Trap.TrapConfig> {
    private final TrapConfig config;

    public Trap(TrapConfig config) {
        this.config = config;
    }

    @Override
    public TrapConfig getConfig() {
        return config;
    }

    public static class TrapConfig {
        // allowed util types to trap
        public List<class_2960> types = null;

        public List<class_2960> requiredEffects = null;

        public int chance = 50;

        public int useDuration = 0;
    }
}

package de.tomalbrc.filament.behaviours;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.registry.BehaviourRegistry;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_2960;

public class BehaviourMap implements Iterable<Map.Entry<class_2960, Behaviour<?>>> {
    private final Map<class_2960, Behaviour<?>> behaviourMap = new Object2ObjectOpenHashMap<>();
    public <T> void put(class_2960 resourceLocation, Behaviour<?> behaviour) {
        this.behaviourMap.put(resourceLocation, behaviour);
    }

    public <T> T get(class_2960 resourceLocation) {
        return (T) this.behaviourMap.get(resourceLocation);
    }

    public void from(BehaviourConfigMap configMap) {
        if (configMap != null) configMap.forEach((resourceLocation, behaviour) -> {
            this.put(resourceLocation, BehaviourRegistry.create(resourceLocation, behaviour));
        });
    }

    public boolean isEmpty() {
        return this.behaviourMap.isEmpty();
    }

    @Override
    public Iterator<Map.Entry<class_2960, Behaviour<?>>> iterator() {
        return this.behaviourMap.entrySet().iterator();
    }
}

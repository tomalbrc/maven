package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4538;
import org.jetbrains.annotations.Nullable;

public class ComplexDecorationBlock extends DecorationBlock implements class_2343 {
    public ComplexDecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties, decorationId);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new DecorationBlockEntity(blockPos, blockState);
    }

    @Override
    public class_1799 method_9574(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        class_2586 blockEntity = levelReader.method_8321(blockPos);
        class_1799 stack = blockEntity instanceof DecorationBlockEntity decorationBlockEntity ? decorationBlockEntity.getItem().method_46651(1) : super.method_9574(levelReader, blockPos, blockState);
        return stack;
    }
}

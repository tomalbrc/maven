package de.tomalbrc.filament.api.registry;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.behaviours.block.Powersource;
import de.tomalbrc.filament.behaviours.block.Repeater;
import de.tomalbrc.filament.behaviours.block.Strippable;
import de.tomalbrc.filament.behaviours.decoration.*;
import de.tomalbrc.filament.behaviours.item.*;
import de.tomalbrc.filament.util.Constants;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2960;

public class BehaviourRegistry {
    private static final Map<class_2960, BehaviourType> behaviourMap = new Object2ObjectOpenHashMap<>();

    public static void init() {
        registerBuiltin();
    }

    private static void registerBuiltin() {
        registerBehaviour(Constants.Behaviours.ARMOR, Armor.class);
        registerBehaviour(Constants.Behaviours.COSMETIC, Cosmetic.class);
        registerBehaviour(Constants.Behaviours.EXECUTE, Execute.class);
        registerBehaviour(Constants.Behaviours.FOOD, Food.class);
        registerBehaviour(Constants.Behaviours.FUEL, Fuel.class);
        registerBehaviour(Constants.Behaviours.INSTRUMENT, Instrument.class);
        registerBehaviour(Constants.Behaviours.SHOOT, Shoot.class);
        registerBehaviour(Constants.Behaviours.TRAP, Trap.class);

        registerBehaviour(Constants.Behaviours.REPEATER, Repeater.class);
        registerBehaviour(Constants.Behaviours.POWERSOURCE, Powersource.class);
        registerBehaviour(Constants.Behaviours.STRIPPABLE, Strippable.class);

        registerBehaviour(Constants.Behaviours.ANIMATION, Animation.class);
        registerBehaviour(Constants.Behaviours.CONTAINER, Container.class);
        registerBehaviour(Constants.Behaviours.LOCK, Lock.class);
        registerBehaviour(Constants.Behaviours.SEAT, Seat.class);
        registerBehaviour(Constants.Behaviours.SHOWCASE, Showcase.class);
    }

    public static void registerBehaviour(class_2960 resourceLocation, Class<? extends Behaviour<?>> type) {
        behaviourMap.put(resourceLocation, new BehaviourType(resourceLocation, type, o -> {
            try {
                return type.getDeclaredConstructor(Behaviour.getConfigType(type)).newInstance(o);
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException |
                     NoSuchMethodException e) {
                throw new RuntimeException(e);
            }
        }));
    }

    public static Type getConfigType(class_2960 key) {
        BehaviourType info = behaviourMap.get(key);
        return Behaviour.getConfigType(info.type);
    }

    public static Behaviour<?> create(class_2960 key, Object config) {
        BehaviourType info = behaviourMap.get(key);
        return (info != null) ? info.createInstance(config) : null;
    }

    public record BehaviourType(class_2960 resourceLocation, Class<? extends Behaviour<?>> type, Function<Object, Behaviour> function) {
        public Behaviour createInstance(Object object) {
            return function.apply(object);
        }
    }
}

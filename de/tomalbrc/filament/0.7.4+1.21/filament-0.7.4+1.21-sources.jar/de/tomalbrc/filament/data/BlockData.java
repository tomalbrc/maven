package de.tomalbrc.filament.data;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.annotations.SerializedName;
import de.tomalbrc.filament.behaviours.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Type;
import java.util.HashMap;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_9323;


public record BlockData(
        @NotNull class_2960 id,
        @NotNull BlockResource blockResource,
        @NotNull ItemResource itemResource,
        @NotNull BlockModelType blockModelType,
        @NotNull BlockProperties properties,
        @Nullable BlockType type,
        @SerializedName("behaviour")
        @Nullable BehaviourConfigMap behaviourConfig,
        @Nullable class_9323 components
        ) {


    public HashMap<String, class_2680> createStateMap() {
        HashMap<String, class_2680> val = new HashMap<>();

        if (blockResource.couldGenerate()) {
            //val = BlockModelGenerator.generate(blockResource);
            throw new UnsupportedOperationException("Not implemented");
        }
        else if (blockResource.models() != null) {
            for (HashMap.Entry<String, class_2960> entry : this.blockResource.models().entrySet()) {
                PolymerBlockModel blockModel = PolymerBlockModel.of(entry.getValue());

                var requestedState = PolymerBlockResourceUtils.requestBlock(this.blockModelType, blockModel);
                val.put(entry.getKey(), requestedState);

                if (requestedState.method_28498(class_2482.field_11502) && requestedState.method_28498(class_2482.field_11501)) {
                    PolymerBlockResourceUtils.requestBlock(this.blockModelType, blockModel);
                }
            }
        }

        return val;
    }

    public boolean isPowersource() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.POWERSOURCE) != null;
    }

    public boolean isRepeater() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.REPEATER) != null;
    }
    public boolean isStrippable() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.STRIPPABLE) != null;
    }

    public boolean isFuel() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.FUEL) != null;
    }

    public boolean isCosmetic() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.COSMETIC) != null;
    }

    public record BlockType(class_2960 resourceLocation) {
        public static BlockType ofFilament(String path) {
            return new BlockType(class_2960.method_60655("filament", path));
        }

        public static BlockType of(String path) {
            return new BlockType(class_2960.method_60654(path));
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null)
                return false;

            if (BlockType.class == this.getClass() && ((BlockType)obj).resourceLocation() != null && this.resourceLocation != null)
                return ((BlockType)obj).resourceLocation().equals(this.resourceLocation);

            return false;
        }

        @Override
        public int hashCode() {
            return resourceLocation.hashCode();
        }

        public static class Deserializer implements JsonDeserializer<BlockType> {
            @Override
            public BlockType deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
                String resLoc = jsonElement.getAsString();
                class_2960 resourceLocation;
                if (resLoc.contains(":"))
                    return BlockType.of(resLoc);
                else
                    return BlockType.ofFilament(resLoc);
            }
        }
    }
}

package de.tomalbrc.filament.block;

import de.tomalbrc.filament.behaviours.block.Powersource;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import java.util.HashMap;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4970;

public class SimpleBlock extends class_2248 implements PolymerTexturedBlock {
    protected final HashMap<String, class_2680> stateMap;
    protected final class_2680 breakEventState;
    protected final BlockData blockData;

    public SimpleBlock(class_4970.class_2251 properties, BlockData data) {
        super(properties);
        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
        this.blockData = data;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return this.stateMap.get("default");
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public boolean method_9506(class_2680 blockState) {
        return this.blockData.isPowersource();
    }

    @Override
    public int method_9524(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        if (this.blockData.isPowersource()) {
            assert this.blockData.behaviourConfig() != null;
            Powersource.PowersourceConfig powersource = this.blockData.behaviourConfig().get(Constants.Behaviours.POWERSOURCE);
            return powersource.value;
        } else {
            return 0;
        }
    }
}

package de.tomalbrc.filament.registry;

import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import java.util.Map;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class StrippableRegistry {
    private static final Map<class_2680, class_2960> strippables = new Reference2ObjectArrayMap<>();

    public static class_2680 getStrippable(class_2680 blockState) {
        return class_7923.field_41175.method_10223(strippables.get(blockState)).method_9564();
    }

    public static boolean has(class_2680 blockState) {
        return strippables.containsKey(blockState);
    }

    public static void add(class_2680 blockState, class_2960 replace) {
        strippables.putIfAbsent(blockState, replace);
    }
}

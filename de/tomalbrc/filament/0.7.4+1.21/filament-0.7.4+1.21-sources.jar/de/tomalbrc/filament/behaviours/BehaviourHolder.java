package de.tomalbrc.filament.behaviours;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import net.minecraft.class_2960;

public interface BehaviourHolder {
    <T extends Behaviour> T getBehaviour(class_2960 resourceLocation);
}
package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviours.item.Shoot;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.registry.EntityRegistry;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

public class ThrowingItem extends SimpleItem implements PolymerItem {
    private final Shoot.ShootConfig shootConfig;

    public ThrowingItem(class_1792.class_1793 properties, ItemData itemData) {
        super(properties, itemData);
        assert itemData.behaviourConfig() != null;
        this.shootConfig = itemData.behaviourConfig().get(Constants.Behaviours.SHOOT);
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);

        user.method_7357().method_7906(this, 8);
        class_1799 itemStack = user.method_5998(hand);

        if (!level.field_9236) {
            BaseProjectileEntity projectile = EntityRegistry.BASE_PROJECTILE.method_5883(level);
            if (projectile != null) {
                projectile.method_33574(user.method_19538().method_1031(0, user.method_5751(), 0));
                Util.damageAndBreak(1, itemStack, user, class_1657.method_56079(hand));

                float pitch = user.method_36455();
                float yaw = user.method_36454();
                double speed = this.shootConfig.speed; // Adjust the speed as needed

                Vector3f deltaMovement = new Vector3f(
                        -(float) Math.sin(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch)),
                        -(float) Math.sin(Math.toRadians(pitch)),
                        (float) Math.cos(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch))
                ).mul((float) speed);

                projectile.method_36456(user.method_36454());
                projectile.method_36457(user.method_36455());
                projectile.method_18800(deltaMovement.x, deltaMovement.y, deltaMovement.z);

                var projItem = this.shootConfig.projectile != null ? class_7923.field_41178.method_10223(this.shootConfig.projectile).method_7854() : itemStack.method_46651(1);
                projectile.setProjectileStack(projItem);
                projectile.setPickupStack(projItem);
                projectile.method_7432(user);
                projectile.method_7438(this.shootConfig.baseDamage);

                if (user.method_7337()) {
                    projectile.field_7572 = class_1665.class_1666.field_7594;
                }
            }

            level.method_8649(projectile);
            level.method_43129(null, projectile, this.shootConfig.sound != null ? class_7923.field_41172.method_10223(this.shootConfig.sound) : class_3417.field_15001.comp_349(), class_3419.field_15254, 1.0F, 1.0F);
            if (!user.method_7337() && this.shootConfig.consumes) {
                itemStack.method_7934(1);
            }
        }

        if (res.method_5467() == class_1269.field_21466) user.method_7259(class_3468.field_15372.method_14956(this));
        return class_1271.method_22428(itemStack);
    }
}

package de.tomalbrc.filament.behaviours.item;

import de.tomalbrc.filament.api.behaviour.item.ItemBehaviour;
import net.minecraft.class_1304;
import net.minecraft.class_2960;
import org.joml.Vector3f;

/**
 * Cosmetics; either head or chestplate slot, can be Blockbenchmodel for chestplate slot or simple item model for either
 */
public class Cosmetic implements ItemBehaviour<Cosmetic.CosmeticConfig> {
    private final CosmeticConfig config;

    public Cosmetic(CosmeticConfig config) {
        this.config = config;
    }

    @Override
    public CosmeticConfig getConfig() {
        return this.config;
    }

    public static class CosmeticConfig {
        /**
         * The equipment slot for the cosmetic (head, chest).
         */
        public class_1304 slot;

        /**
         * The resource location of the animated model for the cosmetic.
         */
        public class_2960 model;

        /**
         * The name of the animation to autoplay. The animation should be loopable
         */
        public String autoplay;

        /**
         * Scale of the chest cosmetic
         */
        public Vector3f scale = new Vector3f(1);

        /**
         * Translation of the chest cosmetic
         */
        public Vector3f translation = new Vector3f();
    }
}

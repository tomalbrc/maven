package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviours.item.Armor;
import de.tomalbrc.filament.behaviours.item.Cosmetic;
import de.tomalbrc.filament.behaviours.item.Execute;
import de.tomalbrc.filament.behaviours.item.Fuel;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.registry.FuelRegistry;
import de.tomalbrc.filament.trim.FilamentTrimPatterns;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.resourcepack.api.PolymerArmorModel;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5151;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8053;
import net.minecraft.class_8055;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class SimpleItem extends class_1792 implements PolymerItem, class_5151 {
    final protected ItemData itemData;
    final protected Object2ObjectOpenHashMap<String, PolymerModelData> modelData;

    @Nullable
    PolymerArmorModel armorModel = null;

    @Nullable
    FilamentTrimPatterns.FilamentTrimHolder trimHolder = null;

    public SimpleItem(class_1793 properties, ItemData itemData) {
        super(properties);

        this.itemData = itemData;
        this.modelData = this.itemData.requestModels();

        // For armor
        if (this.itemData.isArmor()) {
            Armor.ArmorConfig armor = this.itemData.behaviourConfig().get(Constants.Behaviours.ARMOR);
            if (!armor.trim && armor.texture != null)
                this.armorModel = PolymerResourcePackUtils.requestArmor(armor.texture);
            else if (armor.texture != null) {
                this.trimHolder = FilamentTrimPatterns.addConfig(armor);
            }
        }

        if (this.itemData.isCosmetic() || this.itemData.isArmor()) {
            class_2315.method_10009(this, class_1738.field_7879);
        }

        if (this.itemData.isFuel()) {
            Fuel.FuelConfig fuel = this.itemData.behaviourConfig().get(Constants.Behaviours.FUEL);
            FuelRegistry.add(this, fuel.value);
        }
    }

    private static class_6903.class_7863 createContext(class_5455 registryAccess) {
        final Map<class_5321<? extends class_2378<?>>, class_6903.class_7862<?>> map = new HashMap<>();
        registryAccess.method_40311().forEach((registryEntry) -> map.put(registryEntry.comp_350(), createInfoForContextRegistry(registryEntry.comp_351())));
        return new class_6903.class_7863() {
            public <T> Optional<class_6903.class_7862<T>> method_46623(class_5321<? extends class_2378<? extends T>> resourceKey) {
                return Optional.ofNullable((class_6903.class_7862)map.get(resourceKey));
            }
        };
    }

    private static <T> class_6903.class_7862<T> createInfoForContextRegistry(class_2378<T> registry) {
        return new class_6903.class_7862(registry.method_46771(), registry.method_46772(), registry.method_31138());
    }

    @Override
    public boolean method_7873(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        return this.itemData.components().method_57832(class_9334.field_50077);
    }

    @Override
    public void method_59978(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        if (this.itemData.components().method_57832(class_9334.field_50077))
            itemStack.method_7970(1, livingEntity2, class_1304.field_6173);
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        if (itemData.properties() != null)
            itemData.properties().appendHoverText(list);
    }

    @Override
    public class_1799 getPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, class_7225.class_7874 lookup, @Nullable class_3222 player) {
        class_1799 itemStack1 = PolymerItemUtils.createItemStack(itemStack, tooltipType, lookup, player);
        if (this.trimHolder != null)
            itemStack1.method_57379(class_9334.field_49607, new class_8053(lookup.method_46759(class_7924.field_42083).get().method_46746(class_8055.field_42007).get(), this.trimHolder.trimPattern, false));
        return itemStack1;
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, @Nullable class_3222 player) {
        return itemData.vanillaItem() != null ? itemData.vanillaItem() : class_1802.field_8407;
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        return modelData != null ? this.modelData.get("default").value() : -1;
    }

    @Override
    public int getPolymerArmorColor(class_1799 itemStack, @Nullable class_3222 player) {
        return armorModel != null ? this.armorModel.color() : -1;
    }

    @Override
    @NotNull
    public class_1304 method_7685() {
        boolean isArmor = itemData.isArmor();
        boolean isCosmetic = itemData.isCosmetic();
        if (isArmor) {
            Armor.ArmorConfig armor = itemData.behaviourConfig().get(Constants.Behaviours.ARMOR);
            if (armor.slot != null) return armor.slot;
        } else if (isCosmetic) {
            Cosmetic.CosmeticConfig cosmetic = itemData.behaviourConfig().get(Constants.Behaviours.COSMETIC);
            if (cosmetic.slot != null) return cosmetic.slot;
        }

        return class_1304.field_6173;
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);

        if (this.itemData.canExecute()) {
            Execute.ExecuteConfig execute = this.itemData.behaviourConfig().get(Constants.Behaviours.EXECUTE);
            if (execute.command != null) {
                user.method_5682().method_3734().method_44252(user.method_5671(), execute.command);

                user.method_7259(class_3468.field_15372.method_14956(this));

                if (execute.sound != null) {
                    var sound = execute.sound;
                    level.method_43129(null, user, class_7923.field_41172.method_10223(sound), class_3419.field_15254, 1.0F, 1.0F);
                }

                if (execute.consumes) {
                    user.method_5998(hand).method_7934(1);
                }
                res = class_1271.method_22428(user.method_5998(hand));
            }
        }

        if (this.itemData.isArmor() || this.itemData.isCosmetic()) {
            res = this.method_48576(this, level, user, hand);
        }

        return res;
    }

    public ItemData getItemData() {
        return this.itemData;
    }
}

package de.tomalbrc.filament.item;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.data.properties.ItemProperties;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6903;
import net.minecraft.class_7699;
import net.minecraft.class_9280;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static net.minecraft.class_9334.field_49637;
import static net.minecraft.class_9334.field_54199;

/**
 * Universal item, base for all filament items, with behaviour support
 * I wish BlockItem was an interface...
 */
public class SimpleItem extends class_1747 implements PolymerItem, BehaviourHolder {
    private ItemData itemData;
    protected ItemProperties properties;

    protected final class_1792 vanillaItem;

    protected final BehaviourMap behaviours = new BehaviourMap();

    public BehaviourMap getBehaviours() {
        return this.behaviours;
    }

    public SimpleItem(class_2248 block, class_1793 properties, ItemData itemData, class_1792 vanillaItem) {
        super(block, properties);
        this.initBehaviours(itemData.behaviour());

        this.vanillaItem = vanillaItem;
        this.itemData = itemData;
        this.properties = itemData.properties();
    }

    public SimpleItem(class_2248 block, class_1793 itemProperties, ItemProperties props, class_1792 vanillaItem) {
        super(block, itemProperties);

        this.vanillaItem = vanillaItem;
        this.properties = props;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void method_7860(class_1799 itemStack) {
        super.method_7860(itemStack);

        if (this.itemData != null) {
            for (Map.Entry<class_9331<?>, JsonObject> entry : this.itemData.getAdditionalComponents().entrySet()) {
                var codec = entry.getKey().method_57875();
                assert codec != null;

                class_6903.class_7863 registryInfoLookup = Json.DataComponentsDeserializer.createContext(Filament.REGISTRY_ACCESS.method_45926());
                var result = codec.decode(class_6903.method_40414(JsonOps.INSTANCE, registryInfoLookup), entry.getValue());
                if (result.hasResultOrPartial()) {
                    class_9331 type = entry.getKey();
                    itemStack.method_57379(type, (Object) result.getOrThrow().getFirst());
                }
            }
        }
    }

    @Override
    @SuppressWarnings("NullableProblems")
    @Nullable // yes there is no block item for simple items
    public class_2248 method_7711() {
        return super.method_7711();
    }

    @Override
    @NotNull
    public class_7699 method_45322() {
        return this.method_7711() != null ? this.method_7711().method_45322() : this.vanillaItem.method_45322();
    }

    @Override
    public void method_7852(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.onUseTick(level, livingEntity, itemStack, i);
            }
        }
    }

    @Override
    public boolean method_7840(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var res = itemBehaviour.releaseUsing(itemStack, level, livingEntity, useDuration);
                if (res) return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_7838(class_1799 itemStack) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                boolean didUse = itemBehaviour.useOnRelease(itemStack);
                if (didUse) return true;
            }
        }
        return false;
    }

    @Override
    public int method_7881(class_1799 itemStack, class_1309 livingEntity) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var val = itemBehaviour.getUseDuration(itemStack, livingEntity);
                if (val.isPresent()) return val.get();
            }
        }
        return 0;
    }

    @Override
    public boolean method_7873(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        return this.method_57347().method_57832(class_9334.field_50077);
    }

    @Override
    public void method_59978(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        if (this.method_57347().method_57832(class_9334.field_50077))
            itemStack.method_7970(1, livingEntity2, class_1304.field_6173);
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.appendHoverText(itemStack, tooltipContext, list, tooltipFlag);
            }
        }
        this.properties.appendHoverText(list);
        super.method_7851(itemStack, tooltipContext, list, tooltipFlag);
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, PacketContext packetContext) {
        return this.vanillaItem != null ? this.vanillaItem : class_1802.field_8407;
    }

    @Override
    public final class_1799 getPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, PacketContext packetContext) {
        class_1799 stack = PolymerItemUtils.createItemStack(itemStack, tooltipType, packetContext);

        class_2960 dataComponentModel = null;
        if (this.itemData != null && this.itemData.components().method_57832(field_54199)) {
            dataComponentModel = this.itemData.components().method_57829(field_54199);
        } else if (this.itemData != null) {
            dataComponentModel = this.itemData.itemResource() == null ? itemData.vanillaItem().method_57347().method_57829(field_54199) : null;
        }
        if (dataComponentModel != null) stack.method_57379(field_54199, dataComponentModel);

        if (!itemStack.method_57826(field_49637)) {
            class_9280 customModelData = this.itemData != null && this.itemData.components().method_57832(field_49637) ? this.itemData.components().method_57829(field_49637) : getModel();
            if (customModelData != null) stack.method_57379(field_49637, customModelData);
        }

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.modifyPolymerItemStack(this.getModelMap(), itemStack, stack, tooltipType, packetContext.getRegistryWrapperLookup(), packetContext.getPlayer());
            }
        }

        return stack;
    }

    protected Map<String, class_2960> getModelMap() {
        return this.itemData.itemResource() == null ? Map.of() : Objects.requireNonNull(this.itemData.itemResource()).models();
    }

    @Nullable
    protected class_9280 getModel() {
        return null;
    }

    @Override
    @NotNull
    public class_1269 method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);
        if (res.method_23665()) {
            return res;
        }

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                res = itemBehaviour.use(this, level, user, hand);
                if (res.method_23665()) {
                    return res;
                }
            }
        }

        return res;
    }

    @Override
    @NotNull
    public class_1269 method_7884(class_1838 useOnContext) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                var res = itemBehaviour.useOn(useOnContext);
                if (res.method_23665()) {
                    return res;
                }
            }
        }

        if (this.method_7711() instanceof SimpleBlock) {
            var res = super.method_7884(useOnContext);
            if (res.method_23665()) {
                return res;
            }
        }

        return class_1269.field_5814;
    }

    @Override
    protected boolean method_7708(class_1750 context, class_2680 state) {
        if (!super.method_7708(context, state)) {
            return false;
        }

        if (context.method_8036() instanceof class_3222 player) {
            Util.handleBlockPlaceEffects(player, context.method_20287(), context.method_8037(), state.method_26231());
        }

        return true;
    }
}

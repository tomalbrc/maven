package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.item.BaseProjectileEntity;
import de.tomalbrc.filament.registry.EntityRegistry;
import de.tomalbrc.filament.util.Util;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.class_9463;
import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Item behaviour for projectile shooting
 */
public class Shoot implements ItemBehaviour<Shoot.Config> {
    private final Config config;

    public Shoot(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Shoot.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, BehaviourHolder behaviourHolder) {
        ItemBehaviour.super.init(item, behaviourHolder);
        if (config.dispenserSupport) class_2315.method_10009(item, new Snowball.SnowballDispenseBehavior(item, class_9463.class_9464.field_50147));
    }

    @Override
    public class_1269 use(class_1792 item, class_1937 level, class_1657 user, class_1268 hand) {
        user.method_7357().method_62835(user.method_5998(hand), config.cooldown);
        class_1799 itemStack = user.method_5998(hand);

        if (!level.method_8608()) {
            BaseProjectileEntity projectile = EntityRegistry.BASE_PROJECTILE.method_5883(level, class_3730.field_16461);
            if (projectile != null) {
                projectile.config = config;

                projectile.method_33574(user.method_19538().method_1031(0, user.method_5751(), 0));
                Util.damageAndBreak(1, itemStack, user, class_1657.method_56079(hand));

                float pitch = user.method_36455();
                float yaw = user.method_36454();
                double speed = this.config.speed; // Adjust the speed as needed

                Vector3f deltaMovement = new Vector3f(
                        -(float) Math.sin(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch)),
                        -(float) Math.sin(Math.toRadians(pitch)),
                        (float) Math.cos(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch))
                ).mul((float) speed);

                projectile.method_36456(user.method_36454());
                projectile.method_36457(user.method_36455());
                projectile.method_18800(deltaMovement.x, deltaMovement.y, deltaMovement.z);

                class_1799 projItem = this.config.projectile != null ? class_7923.field_41178.method_63535(this.config.projectile).method_7854() : itemStack.method_46651(1);
                class_1799 pickupItem = this.config.pickupItem != null ? class_7923.field_41178.method_63535(this.config.pickupItem).method_7854() : projItem;
                projectile.method_7432(user);
                projectile.setPickupStack(pickupItem);
                projectile.setBase(itemStack.method_7972());
                projectile.setProjectileStack(projItem);
                projectile.method_7438(this.config.baseDamage);

                if (user.method_68878()) {
                    projectile.field_7572 = class_1665.class_1666.field_7594;
                }
            }

            level.method_8649(projectile);
            level.method_43129(null, projectile, this.config.sound != null ? class_7923.field_41172.method_63535(this.config.sound) : class_3417.field_15001.comp_349(), class_3419.field_15254, config.volume, config.pitch);
            if (!user.method_68878()) {
                if (this.config.consumes) itemStack.method_7934(1);
                else itemStack.method_71012(1, user, hand);
            }
        }

        user.method_7259(class_3468.field_15372.method_14956(item));

        return class_1269.field_21466;
    }

    public static class Config {
        /**
         * Indicates whether the shooting action consumes the item
         */
        public boolean consumes;

        /**
         * Indicates whether the item gets damaged when using
         */
        public boolean damages;

        /**
         * The base damage of the projectile.
         */
        public double baseDamage = 2.0;

        /**
         * The speed at which the projectile is fired.
         */
        public double speed = 1.0;

        /**
         * Cooldown ticks
         */
        public int cooldown = 8;

        /**
         * The identifier for the projectile item
         */
        public class_2960 projectile;

        public class_2960 pickupItem;

        public boolean dispenserSupport = false;
        public boolean canPickUp = false;
        public boolean dropAsItem = true;

        /**
         * Sound effect to play when shooting
         */
        public class_2960 sound = class_3417.field_15001.comp_349().comp_3319();
        public float volume = 1.f;
        public float pitch = 1.f;

        public class_2960 hitSound = class_3417.field_15213.comp_3319();
        public float hitVolume = 1.f;
        public float hitPitch = 1.f;

        public class_2960 hitGroundSound = class_3417.field_15104.comp_3319();

        /**
         * Display context of the item display
         */
        public class_811 display = class_811.field_4315;

        /**
         * Rotation
         */
        public Quaternionf rotation = new Quaternionf().rotationY(class_3532.field_29847*90);

        /**
         * Translation
         */
        public Vector3f translation = new Vector3f();

        /**
         * Scale
         */
        public Vector3f scale = new Vector3f(0.6f);
    }
}

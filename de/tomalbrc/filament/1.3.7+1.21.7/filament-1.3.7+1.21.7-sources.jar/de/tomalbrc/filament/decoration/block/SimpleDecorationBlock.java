package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.holder.DecorationHolder;
import de.tomalbrc.filament.util.BlockUtil;
import de.tomalbrc.filament.util.DecorationUtil;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_7923;
import net.minecraft.class_8567;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

public class SimpleDecorationBlock extends DecorationBlock implements BlockWithElementHolder {
    public SimpleDecorationBlock(class_2251 properties, DecorationData data) {
        super(properties, data);
    }

    @Nullable
    public ElementHolder createElementHolder(class_3218 world, class_2338 blockPos, class_2680 initialBlockState) {
        DecorationHolder holder = new DecorationHolder(() -> visualItemStack(world, blockPos, initialBlockState));
        DecorationUtil.setupElements(holder, this.getDecorationData(), class_2350.field_11036, this.getVisualRotationYInDegrees(initialBlockState), this.visualItemStack(world, blockPos, initialBlockState), null);
        return holder;
    }

    @Override
    @NotNull
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2680 returnVal = super.method_9576(level, blockPos, blockState, player);
        if (!player.method_56992()) this.method_9556(level, player, blockPos, blockState, null, player.method_6047());
        return returnVal;
    }

    @Override
    public class_1799 visualItemStack(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        var item = class_7923.field_41178.method_63535(this.data.id()).method_7854();

        if (stateMap != null && cmdMap != null) {
            var val = stateMap.get(behaviourModifiedBlockState(blockState, blockState));
            if (val != null && cmdMap.containsKey(val)) {
                item.method_57379(class_9334.field_54199, data.id().method_45138("block/"));
                item.method_57379(class_9334.field_49637, new class_9280(List.of(), List.of(), List.of(cmdMap.get(val)), List.of()));
            }
        }

        return item;
    }

    @Override
    @NotNull
    public List<class_1799> method_9560(class_2680 blockState, class_8567.class_8568 builder) {
        if (this.getDecorationData().properties().drops) {
            List<class_1799> list = ObjectArrayList.of(class_7923.field_41178.method_63535(this.decorationId).method_7854());
            list.addAll(super.method_9560(blockState, builder));
            return list;
        } else {
            return super.method_9560(blockState, builder);
        }
    }

    @Override
    protected void method_33614(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState) {
        if (level.field_9236) return;

        BlockUtil.playBreakSound(level, blockPos, blockState);

        if (data.properties().showBreakParticles)
            DecorationUtil.showBreakParticle((class_3218) level, data.properties().useItemParticles ? class_7923.field_41178.method_63535(this.decorationId).method_7854() : this.getDecorationData().properties().blockBase.method_8389().method_7854(), (float) blockPos.method_46558().method_10216(), (float) blockPos.method_46558().method_10214(), (float) blockPos.method_46558().method_10215());
    }
}

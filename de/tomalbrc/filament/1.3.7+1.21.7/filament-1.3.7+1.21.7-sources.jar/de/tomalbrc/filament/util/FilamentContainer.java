package de.tomalbrc.filament.util;

import de.tomalbrc.filament.api.behaviour.ContainerLike;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_3222;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_8934;

public class FilamentContainer extends class_1277 implements class_8934 {
    List<class_1309> menus = new ObjectArrayList<>();

    private boolean valid = true;

    private final boolean purge;
    private final DecorationBlockEntity blockEntity;

    private Runnable closeCallback;
    private Runnable openCallback;

    public FilamentContainer(DecorationBlockEntity blockEntity, int size, boolean purge) {
        super(size);

        this.method_5489(x -> blockEntity.method_5431());
        this.blockEntity = blockEntity;
        this.purge = purge;
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return this.valid && !blockEntity.method_11015();
    }

    @Override
    public boolean method_49104(class_1263 target, int slot, class_1799 stack) {
        return this.valid;
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return this.valid && !blockEntity.method_11015() && stack.method_7947() <= getMaxStackSize(slot) - method_5438(slot).method_7947();
    }

    public int getMaxStackSize(int slot) {
        return method_5444();
    }

    public void setValid(boolean valid) {
        if (!valid) {
            for (class_1309 entity : this.menus) {
                if (entity instanceof class_3222 player) player.method_7346();
            }
        }
        this.valid = valid;
    }

    public boolean hasViewers() {
        return !this.menus.isEmpty();
    }

    @Override
    public void method_5435(class_1657 player) {
        this.method_54873(player);
        this.method_54873(player);
        super.method_5435(player);

        if (!player.method_7325() && this.menus.isEmpty() && this.openCallback != null) {
            this.openCallback.run();
        }

        this.menus.add(player);
    }

    @Override
    public void method_5432(class_1657 player) {
        super.method_5432(player);

        this.menus.remove(player);

        if (this.menus.isEmpty() && this.closeCallback != null) {
            this.closeCallback.run();
        }

        if (this.purge && this.menus.isEmpty())
            this.method_5448();
    }

    public void setCloseCallback(Runnable closeCallback) {
        this.closeCallback = closeCallback;
    }

    public void setOpenCallback(Runnable openCallback) {
        this.openCallback = openCallback;
    }

    @Override
    public boolean method_5442() {
        this.method_54873(null);
        return super.method_5442();
    }

    @Override
    public @NotNull class_1799 method_5438(int n) {
        this.method_54873(null);
        return super.method_5438(n);
    }

    @Override
    public @NotNull class_1799 method_5434(int n, int n2) {
        this.method_54873(null);
        return super.method_5434(n, n2);
    }

    @Override
    public @NotNull class_1799 method_5441(int n) {
        this.method_54873(null);
        return super.method_5441(n);
    }

    @Override
    public void method_5447(int n, class_1799 itemStack) {
        this.method_54873(null);
        super.method_5447(n, itemStack);
    }

    @Override
    public @NotNull class_2371<class_1799> method_54454() {
        this.method_54873(null);
        return this.field_5828;
    }

    public DecorationBlockEntity getBlockEntity() {
        return blockEntity;
    }

    @Override
    public @Nullable class_5321<class_52> method_54869() {
        var containerLike = DecorationData.getFirstContainer(blockEntity);
        if (containerLike != null)
            return containerLike.getLootTable();
        return null;
    }

    @Override
    public void method_11285(@Nullable class_5321<class_52> resourceKey) {
        var containerLike = DecorationData.getFirstContainer(blockEntity);
        if (containerLike != null) containerLike.setLootTable(resourceKey);
    }

    @Override
    public long method_54870() {
        var containerLike = DecorationData.getFirstContainer(blockEntity);
        if (containerLike != null)
            return containerLike.getLootTableSeed();
        return 0;
    }

    @Override
    public void method_54866(long l) {
        var containerLike = DecorationData.getFirstContainer(blockEntity);
        if (containerLike != null)
            containerLike.setLootTableSeed(l);
    }

    @Override
    public @NotNull class_2338 method_11016() {
        return blockEntity.method_11016();
    }

    @Override
    public @Nullable class_1937 method_10997() {
        return blockEntity.method_10997();
    }

    public static boolean isPickUpContainer(class_1263 container) {
        ContainerLike containerLike;
        return container instanceof FilamentContainer filamentContainer && (containerLike = DecorationData.getFirstContainer(filamentContainer.getBlockEntity())) != null && containerLike.canPickUp();
    }
}

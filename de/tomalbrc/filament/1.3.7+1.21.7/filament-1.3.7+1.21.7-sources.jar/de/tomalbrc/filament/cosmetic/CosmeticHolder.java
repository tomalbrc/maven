package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.util.FilamentConfig;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import eu.pb4.polymer.virtualentity.impl.EntityExt;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.joml.Vector3f;

import java.util.Objects;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2716;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_4050;
import net.minecraft.class_8042;
import net.minecraft.class_811;

public class CosmeticHolder extends ElementHolder {
    private final class_1309 entity;
    private final ItemDisplayElement displayElement;

    boolean hidden = false;

    private CosmeticInterface access() {
        return (CosmeticInterface) this.entity;
    }

    public CosmeticHolder(class_1309 entity, class_1799 itemStack) {
        super();

        this.entity = entity;

        this.displayElement = new ItemDisplayElement(itemStack.method_7972());
        this.displayElement.setInvisible(true);

        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(itemStack);
        if (cosmeticData != null) {
            this.displayElement.setItemDisplayContext(cosmeticData.display);
            this.displayElement.setLeftRotation(cosmeticData.rotation);
            this.displayElement.setTranslation(cosmeticData.translation);
            this.displayElement.setScale(cosmeticData.scale);
            if (FilamentConfig.getInstance().alternativeCosmeticPlacement) {
                this.displayElement.setItemDisplayContext(class_811.field_4316);
                this.displayElement.setTranslation(new Vector3f(0, 1.25f,0));
                this.displayElement.setScale(new Vector3f(0.625f));
            }
        }

        this.displayElement.setTeleportDuration(1);
        this.displayElement.ignorePositionUpdates();

        this.addElement(this.displayElement);
    }

    @Override
    public void onTick() {
        if (this.entity.method_29504() || entity.method_31481()) {
            destroy();
        }

        if (this.entity.method_18376() == class_4050.field_18079 || this.entity.method_18376() == class_4050.field_18078 || (this.entity instanceof  class_3222 serverPlayer && serverPlayer.method_7325())) {
            if (!hidden) {
                hideForAll(this);
                hidden = true;
            }
        } else {
            if (hidden) {
                showForAll(this);
                this.updatePosition();

                var packet = VirtualEntityUtils.createRidePacket(entity.method_5628(), ((EntityExt)entity).polymerVE$getVirtualRidden());
                this.sendPacket(packet);

                hidden = false;
            }

            this.displayElement.setYaw(access().filament$bodyYaw());
            this.displayElement.setPitch(this.entity.method_5715() ? 25 : 0);
            if (FilamentConfig.getInstance().alternativeCosmeticPlacement) {
                this.displayElement.setTranslation(new Vector3f(0, this.entity.method_5715() ? 1.325f : 1.25f, this.entity.method_5715() ? 0.15f : 0));
            }
            else {
                Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(this.displayElement.getItem());
                this.displayElement.setTranslation(cosmeticData.translation.add(new Vector3f(0, 0, this.entity.method_5715() ? 0.15f : 0), new Vector3f()));
            }
        }

        super.onTick();
    }

    @Override
    protected void notifyElementsOfPositionUpdate(class_243 newPos, class_243 delta) {
    }

    public static void hideForAll(ElementHolder elementHolder) {
        for (class_3244 player : elementHolder.getWatchingPlayers()) {
            player.method_14364(new class_2716(elementHolder.getEntityIds()));
        }
    }

    public static void showForAll(ElementHolder elementHolder) {
        for (class_3244 player : elementHolder.getWatchingPlayers()) {
            var packets = new ObjectArrayList<class_2596<? super class_2602>>();
            for (VirtualElement e : elementHolder.getElements()) {
                Objects.requireNonNull(packets);
                e.startWatching(player.field_14140, packets::add);
            }
            player.method_14364(new class_8042(packets));
        }
    }

    public class_243 getPos() {
        return this.entity instanceof class_3222 ? this.entity.method_19538() : this.entity.method_33571();
    }
}

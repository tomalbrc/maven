package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.behaviour.AsyncTickingBlockBehaviour;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.util.AsyncBlockTicker;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2843;
import net.minecraft.class_3218;
import net.minecraft.class_5539;
import net.minecraft.class_6749;
import net.minecraft.class_6755;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2818.class)
public abstract class LevelChunkAsyncMixin extends class_2791 {
    @Shadow @Final class_1937 level;

    @Shadow public abstract class_1937 getLevel();

    public LevelChunkAsyncMixin(class_1923 chunkPos, class_2843 upgradeData, class_5539 levelHeightAccessor, class_2378<class_1959> registry, long l, @Nullable class_2826[] levelChunkSections, @Nullable class_6749 blendingData) {
        super(chunkPos, upgradeData, levelHeightAccessor, registry, l, levelChunkSections, blendingData);
    }

    @Inject(method = "setBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/world/level/block/Block;)Z", ordinal = 0))
    private void filament$removeOldAsyncTicker(class_2338 blockPos, class_2680 blockState, int i, CallbackInfoReturnable<class_2680> cir) {
        var x = AsyncBlockTicker.getBlock(blockPos);
        if (x != null) {
            if (x != blockState.method_26204()) {
                AsyncBlockTicker.remove(blockPos);
            } else if (blockState.method_26204() instanceof SimpleBlock simpleBlock && getLevel() instanceof class_3218 serverLevel && AsyncBlockTicker.get(blockPos) == null) {
                AsyncBlockTicker.add(blockPos, simpleBlock, serverLevel);
            }
        }
    }

    @Inject(method = "setBlockState", at = @At(value = "FIELD", target = "Lnet/minecraft/world/level/Level;isClientSide:Z", ordinal = 1, shift = At.Shift.BEFORE))
    private void filament$addAsyncTicker(class_2338 blockPos, class_2680 blockState, int i, CallbackInfoReturnable<class_2680> cir) {
        var x = AsyncBlockTicker.getBlock(blockPos);
        if (x == null && this.level instanceof class_3218 serverLevel && blockState.method_26204() instanceof SimpleBlock simpleBlock && filament$isAsyncTickingBlock(simpleBlock)) {
            AsyncBlockTicker.add(blockPos, simpleBlock, serverLevel);
        }
    }

    @Inject(method = "<init>(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/UpgradeData;Lnet/minecraft/world/ticks/LevelChunkTicks;Lnet/minecraft/world/ticks/LevelChunkTicks;J[Lnet/minecraft/world/level/chunk/LevelChunkSection;Lnet/minecraft/world/level/chunk/LevelChunk$PostLoadProcessor;Lnet/minecraft/world/level/levelgen/blending/BlendingData;)V", at = @At("TAIL"))
    private void filament$loadAsyncTicker(class_1937 level, class_1923 chunkPos, class_2843 upgradeData, class_6755 levelChunkTicks, class_6755 levelChunkTicks2, long l, class_2826[] levelChunkSections, class_2818.class_6829 postLoadProcessor, class_6749 blendingData, CallbackInfo ci) {
        if (level instanceof class_3218 serverLevel) {
            var sections = this.method_12006();
            for (int i = 0; i < sections.length; i++) {
                var section = sections[i];
                if (section != null && !section.method_38292()) {
                    var container = section.method_12265();
                    if (container.method_19526(blockState -> blockState.method_26204() instanceof SimpleBlock simpleBlock && filament$isAsyncTickingBlock(simpleBlock))) {
                        class_2680 state;
                        for (byte x = 0; x < 16; x++) {
                            for (byte z = 0; z < 16; z++) {
                                for (byte y = 0; y < 16; y++) {
                                    state = container.method_12321(x, y, z);
                                    if (state.method_26204() instanceof SimpleBlock simpleBlock && simpleBlock.hasData()) {
                                        if (filament$isAsyncTickingBlock(simpleBlock)) {
                                            var blockPos = chunkPos.method_35231(x, this.method_31604(i) * 16 + y, z);
                                            AsyncBlockTicker.add(blockPos, simpleBlock, serverLevel);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Unique
    private static boolean filament$isAsyncTickingBlock(SimpleBlock simpleBlock) {
        return simpleBlock.data().behaviour().test(behaviourType -> AsyncTickingBlockBehaviour.class.isAssignableFrom(behaviourType.type()));
    }
}

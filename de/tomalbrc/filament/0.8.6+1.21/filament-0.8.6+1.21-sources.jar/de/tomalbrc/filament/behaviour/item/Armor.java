package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.trim.FilamentTrimPatterns;
import eu.pb4.polymer.resourcepack.api.PolymerArmorModel;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5151;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_8053;
import net.minecraft.class_8055;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Armor item behaviour, using fancypants shader via polymer or armor trims
 */
public class Armor implements ItemBehaviour<Armor.Config> {
    private final Config config;
    private PolymerArmorModel armorModel;
    private FilamentTrimPatterns.FilamentTrimHolder trimHolder;

    public Armor(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Armor.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, BehaviourHolder behaviourHolder) {
        if (!config.trim && config.texture != null)
            this.armorModel = PolymerResourcePackUtils.requestArmor(config.texture);
        else if (config.texture != null) {
            this.trimHolder = FilamentTrimPatterns.addConfig(config);
        }

        class_2315.method_10009(item, class_1738.field_7879);
    }

    public class_1799 modifyPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, class_7225.class_7874 lookup, @Nullable class_3222 player) {
        if (this.trimHolder != null)
            itemStack.method_57379(class_9334.field_49607, new class_8053(lookup.method_46759(class_7924.field_42083).get().method_46746(class_8055.field_42007).get(), this.trimHolder.trimPattern, false));
        return itemStack;
    }

    public int modifyPolymerArmorColor(class_1799 itemStack, @Nullable class_3222 player, int color) {
        return this.armorModel != null ? this.armorModel.color() : color;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        if (item instanceof class_5151 equipable) {
            return equipable.method_48576(item, level, player, interactionHand);
        }
        return ItemBehaviour.super.use(item, level, player, interactionHand);
    }

    @Override
    public class_1304 getEquipmentSlot() {
        return this.config.slot;
    }

    public static class Config {
        /**
         * The equipment slot for the armor piece (e.g., head, chest, legs, or feet).
         */
        public class_1304 slot;

        /**
         * The resource location of the texture associated with the armor.
         */
        public class_2960 texture;

        /**
         * Flag whether to use armor trims instead of shader based armor
         */
        public boolean trim = false;
    }
}

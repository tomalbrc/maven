package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import net.minecraft.class_1303;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6019;
import org.jetbrains.annotations.NotNull;

public class DropXp implements BlockBehaviour<DropXp.Config> {
    private final Config config;

    public DropXp(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public DropXp.Config getConfig() {
        return this.config;
    }

    @Override
    public void spawnAfterBreak(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean bl) {
        if (bl) {
            this.spawnXpAfterEnchantCheck(serverLevel, blockPos, itemStack, this.getRange());
        }
    }

    private class_6017 getRange() {
        if (this.config.max == this.config.min) {
            return class_6016.method_34998(this.config.min);
        }

        return class_6019.method_35017(this.config.min, this.config.max);
    }

    protected void spawnXpAfterEnchantCheck(class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, class_6017 intProvider) {
        int i = class_1890.method_60157(serverLevel, itemStack, intProvider.method_35008(serverLevel.method_8409()));
        if (i > 0) {
            this.spawnXp(serverLevel, blockPos, i);
        }
    }

    private void spawnXp(class_3218 serverLevel, class_2338 blockPos, int amount) {
        if (serverLevel.method_8450().method_8355(class_1928.field_19392)) {
            class_1303.method_31493(serverLevel, class_243.method_24953(blockPos), amount);
        }
    }

    public static class Config {
        public int min = 0;
        public int max = 0;
    }
}
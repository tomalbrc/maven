package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.registry.BlockRegistry;
import de.tomalbrc.filament.registry.ItemRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3497;
import net.minecraft.class_3503;

// for ability to supply tags in filament jsons
@Mixin(class_3503.class)
public abstract class TagLoaderMixin {

    @Inject(method = "load", at = @At(value = "INVOKE", target = "Ljava/util/List;forEach(Ljava/util/function/Consumer;)V"))
    private void filament$customTags(class_3300 resourceManager, CallbackInfoReturnable<Map<class_2960, List<class_3503.class_5145>>> cir, @Local(ordinal = 0) class_2960 id, @Local(ordinal = 1) class_2960 id2, @Local List<class_3503.class_5145> list) {
        if (id.method_12832().startsWith("tags/item")) {
            var collection = ItemRegistry.ITEMS_TAGS.get(id2);
            if (collection != null) for (class_2960 itemId : collection) {
                list.add(new class_3503.class_5145(class_3497.method_43937(itemId), itemId.method_12836()));
            }
        }
        else if (id.method_12832().startsWith("tags/block")) {
            var collection = BlockRegistry.BLOCKS_TAGS.get(id2);
            if (collection != null) for (class_2960 itemId : collection) {
                list.add(new class_3503.class_5145(class_3497.method_43937(itemId), itemId.method_12836()));
            }
        }
    }
}

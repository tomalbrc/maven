package de.tomalbrc.filament.data;

import com.google.gson.annotations.SerializedName;
import de.tomalbrc.filament.behaviours.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.DecorationProperties;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.joml.Vector3f;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_9323;

public record DecorationData(
        @NotNull class_2960 id,
        @NotNull class_2960 model,

        @Nullable class_1792 vanillaItem,

        @Nullable List<BlockConfig> blocks,

        @Nullable Vector2f size,

        @Nullable DecorationProperties properties,

        @SerializedName("behaviour")
        @Nullable BehaviourConfigMap behaviourConfig,
        @Nullable class_9323 components
) {
    public PolymerModelData requestModel() {
        return PolymerResourcePackUtils.requestModel(vanillaItem != null ? vanillaItem : class_1802.field_8054, model);
    }

    public boolean isSeat() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.SEAT) != null;
    }

    public boolean isContainer() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.CONTAINER) != null;
    }

    public boolean hasAnimation() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.ANIMATION) != null;
    }

    public boolean hasBlocks() {
        return this.blocks != null;
    }

    public boolean isShowcase() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.SHOWCASE) != null;
    }

    public boolean isLock() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.LOCK) != null;
    }

    public boolean isFuel() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.FUEL) != null;
    }

    public boolean isSimple() {
        boolean singleBlock = (!this.hasBlocks() || Util.barrierDimensions(this.blocks(), 0).equals(1, 1));
        boolean hasBehaviour = this.behaviourConfig() != null;
        boolean canBeDyed = this.vanillaItem != null && (vanillaItem == class_1802.field_18138 || vanillaItem == class_1802.field_8450);
        return !canBeDyed && !hasBehaviour && (singleBlock || this.size != null);
    }

    public boolean isCosmetic() {
        return this.behaviourConfig != null && this.behaviourConfig.get(Constants.Behaviours.COSMETIC) != null;
    }

    public record BlockConfig(Vector3f origin,
                       Vector3f size,
                       class_2680 block) { }
}

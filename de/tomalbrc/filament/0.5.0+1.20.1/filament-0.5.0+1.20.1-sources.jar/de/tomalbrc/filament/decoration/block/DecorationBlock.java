package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.filament.DecorationRegistry;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import org.jetbrains.annotations.Nullable;

public abstract class DecorationBlock extends class_2248 implements PolymerBlock, class_3737 {
    final protected class_2960 decorationId;

    public static final class_2758 LIGHT_LEVEL = class_2741.field_12538;

    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    public static final class_2746 PASSTHROUGH = class_2746.method_11825("passthrough");

    public DecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties);
        this.decorationId = decorationId;

        // todo
        //FlammableBlockRegistry.getDefaultInstance().add(this, 5, 10);

        this.method_9590(this.field_10647.method_11664()
                .method_11657(LIGHT_LEVEL, 0)
                .method_11657(PASSTHROUGH, false)
                .method_11657(WATERLOGGED, false)
        );
    }

    public DecorationData getDecorationData() {
        return DecorationRegistry.getDecorationDefinition(this.decorationId);
    }

    @Override
    public boolean forceLightUpdates(class_2680 blockState) { return blockState.method_11654(LIGHT_LEVEL) > 0; }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LIGHT_LEVEL, PASSTHROUGH, WATERLOGGED);
    }

    @Override
    public class_2248 getPolymerBlock(class_2680 state) {
        return state.method_11654(DecorationBlock.PASSTHROUGH) ? state.method_11654(DecorationBlock.WATERLOGGED) ? class_2246.field_10382 : class_2246.field_10124 : class_2246.field_10499;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return state.method_11654(DecorationBlock.WATERLOGGED) && !state.method_11654(DecorationBlock.PASSTHROUGH) ?
                this.getPolymerBlock(state).method_9564().method_11657(class_2741.field_12508, true) :
                this.getPolymerBlock(state).method_9564();
    }

    /*
    @Override
    public void onExplosionHit(BlockState blockState, Level level, BlockPos blockPos, Explosion explosion, BiConsumer<ItemStack, BlockPos> biConsumer) {
        if (!blockState.isAir() && explosion.getBlockInteraction() != Explosion.BlockInteraction.TRIGGER_BLOCK) {
            this.removeDecoration(level, blockPos, null);
        }
    }
    */

    @Override
    public void method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        this.removeDecoration(level, blockPos, player);
    }

    private void removeDecoration(class_1937 level, class_2338 blockPos, class_1657 player) {
        class_2586 blockEntity = level.method_8321(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            decorationBlockEntity.destroyStructure(player == null || !player.method_7337());
        }
    }

    @Override
    public class_265 method_9549(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        if (blockState.method_11654(PASSTHROUGH)) {
            return class_259.method_1073();
        } else {
            return class_259.method_1077();
        }
    }

    @Override
    public boolean method_10310(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3611 fluid) {
        if (DecorationRegistry.isDecoration(blockState) &&
                ((DecorationBlock) blockState.method_26204()).getDecorationData() != null &&
                ((DecorationBlock) blockState.method_26204()).getDecorationData().properties() != null &&
                ((DecorationBlock) blockState.method_26204()).getDecorationData().properties().waterloggable) {
            return class_3737.super.method_10310(blockGetter, blockPos, blockState, fluid);
        }
        return false;
    }

    public boolean method_10311(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_3610 fluidState) {
        if (DecorationRegistry.isDecoration(blockState) && ((DecorationBlock)blockState.method_26204()).getDecorationData() != null && ((DecorationBlock)blockState.method_26204()).getDecorationData().properties() != null) {
            if (((DecorationBlock)blockState.method_26204()).getDecorationData().properties().waterloggable) {
                return class_3737.super.method_10311(levelAccessor, blockPos, blockState, fluidState);
            } else {
                return false;
            }
        }

        return false;
    }

    public class_3610 method_9545(class_2680 blockState) {
        return blockState.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(blockState);
    }

    @Override
    public class_2680 method_9559(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        if (blockState.method_11654(WATERLOGGED).booleanValue()) {
            levelAccessor.method_39281(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelAccessor));
        }

        return super.method_9559(blockState, direction, blockState2, levelAccessor, blockPos, blockPos2);
    }

    @Override
    @Nullable
    public class_2680 method_9605(class_1750 blockPlaceContext) {
        class_3610 fluidState = blockPlaceContext.method_8045().method_8316(blockPlaceContext.method_8037());
        boolean bl = fluidState.method_15771() && fluidState.method_15772() == class_3612.field_15910;
        return super.method_9605(blockPlaceContext).method_11657(WATERLOGGED, bl);
    }
}

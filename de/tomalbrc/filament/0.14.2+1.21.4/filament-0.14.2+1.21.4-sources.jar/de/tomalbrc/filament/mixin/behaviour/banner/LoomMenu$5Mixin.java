package de.tomalbrc.filament.mixin.behaviour.banner;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.FilamentItem;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "net.minecraft.world.inventory.LoomMenu$5")
public class LoomMenu$5Mixin {
    @Inject(method = "mayPlace", at = @At("RETURN"), cancellable = true)
    private void filament$allowCustomItems(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        if (itemStack.method_7909() instanceof FilamentItem filamentItem && filamentItem.has(Behaviours.BANNER_PATTERN))
            cir.setReturnValue(true);
    }
}

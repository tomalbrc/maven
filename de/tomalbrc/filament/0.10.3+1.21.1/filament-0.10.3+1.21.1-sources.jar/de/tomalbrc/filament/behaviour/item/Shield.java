package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1746;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

/**
 * Fuel behaviour
 */
public class Shield implements ItemBehaviour<Shield.Config> {
    private final Config config;

    public Shield(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Shield.Config getConfig() {
        return this.config;
    }

    @Override
    public void appendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        class_1746.method_7705(itemStack, list);
    }

    public Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.of(72000);
    }

    @Override
    public class_1271<class_1799> use(class_1792 self, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        player.method_6019(interactionHand);
        return class_1271.method_22428(itemStack);
    }

    @Override
    public class_1304 getEquipmentSlot() {
        return class_1304.field_6171;
    }

    public static class Config {
    }
}
package de.tomalbrc.filament.mixin.behaviour.cosmetic;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.Armor;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.cosmetic.AnimatedCosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.cosmetic.CosmeticUtil;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.registry.ModelRegistry;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Map;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

@Mixin(value = class_1309.class)
public abstract class LivingEntityMixin implements CosmeticInterface {
    @Unique
    private final Map<String, CosmeticHolder> filamentCosmeticHolder = new Object2ObjectOpenHashMap<>();

    @Unique
    private final Map<String, AnimatedCosmeticHolder> filamentAnimatedCosmeticHolder = new Object2ObjectOpenHashMap<>();

    @Inject(method = "getEquipmentSlotForItem", at = @At(value = "HEAD"), cancellable = true)
    private void filament$customGetEquipmentSlotForItem(class_1799 itemStack, CallbackInfoReturnable<class_1304> cir) {
        Cosmetic.Config cosmetic = CosmeticUtil.getCosmeticData(itemStack);
        if (cosmetic != null) {
            cir.setReturnValue(cosmetic.slot);
        }
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.ARMOR))  {
            Armor.Config armor = simpleItem.get(Behaviours.ARMOR).getConfig();
            cir.setReturnValue(armor.slot);
        }
    }

    @Inject(method = "onEquipItem", at = @At(value = "HEAD"))
    private void filament$customOnEquipItem(class_1304 equipmentSlot, class_1799 oldItemStack, class_1799 newItemStack, CallbackInfo ci) {
        if (oldItemStack.method_7909() instanceof SimpleItem simpleItem && CosmeticUtil.isCosmetic(oldItemStack)) {
            var slot = simpleItem.get(Behaviours.COSMETIC).getConfig().slot;
            if (slot == equipmentSlot) filament$destroyHolder(slot.method_5923());
        }

        if (newItemStack.method_7909() instanceof SimpleItem simpleItem && CosmeticUtil.isCosmetic(newItemStack)) {
            var slot = simpleItem.get(Behaviours.COSMETIC).getConfig().slot;
            if (slot == equipmentSlot) {
                filament$destroyHolder(slot.method_5923());
                filament$addHolder(class_1309.class.cast(this), newItemStack.method_7909(), newItemStack, slot.method_5923());
            }
        }
    }

    @Inject(method = "doHurtEquipment", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/entity/LivingEntity;getItemBySlot(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;", shift = At.Shift.AFTER), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void filament$customOnDoHurtEquipment(class_1282 damageSource, float f, class_1304[] equipmentSlots, CallbackInfo ci, @Local class_1799 itemStack, @Local class_1304 equipmentSlot) {
        if (!(itemStack.method_7909() instanceof class_1738) && itemStack.method_7909() instanceof SimpleItem && itemStack.method_58407(damageSource)) {
            int i = (int)Math.max(1.0F, f / 4.0F);
            itemStack.method_7970(i, (class_1309)(Object)this, equipmentSlot);
        }
    }

    @Inject(method = "remove", at = @At(value = "HEAD"))
    private void filament$onRemove(class_1297.class_5529 removalReason, CallbackInfo ci) {
        var self = class_1309.class.cast(this);
        for (class_1799 itemStack : self.method_5661()) {
            if (CosmeticUtil.isCosmetic(itemStack))
                filament$destroyHolder(self.method_32326(itemStack).method_5923());
        }
    }

    @Unique
    @Override
    public void filament$addHolder(class_1309 livingEntity, class_1792 simpleItem, class_1799 itemStack, String slot) {
        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(simpleItem);

        if (cosmeticData.model != null) {
            if (!filamentAnimatedCosmeticHolder.containsKey(slot)) {
                var animatedCosmeticHolder = new AnimatedCosmeticHolder(livingEntity, ModelRegistry.getModel(cosmeticData.model));
                EntityAttachment.ofTicking(animatedCosmeticHolder, livingEntity);

                if (livingEntity instanceof class_3222 serverPlayer)
                    animatedCosmeticHolder.startWatching(serverPlayer);

                if (cosmeticData.autoplay != null) {
                    animatedCosmeticHolder.getAnimator().playAnimation(cosmeticData.autoplay);
                }
                filamentAnimatedCosmeticHolder.put(slot, animatedCosmeticHolder);
            }
        }
        else {
            if (!filamentCosmeticHolder.containsKey(slot)) {
                var cosmeticHolder = new CosmeticHolder(livingEntity, itemStack);
                EntityAttachment.ofTicking(cosmeticHolder, livingEntity);

                if (livingEntity instanceof class_3222 serverPlayer)
                    cosmeticHolder.startWatching(serverPlayer);

                filamentCosmeticHolder.put(slot, cosmeticHolder);
            }
        }
    }

    @Unique
    @Override
    public void filament$destroyHolder(String slot) {
        if (filamentAnimatedCosmeticHolder.containsKey(slot)) {
            filamentAnimatedCosmeticHolder.get(slot).getAttachment().destroy();
            filamentAnimatedCosmeticHolder.get(slot).destroy();
            filamentAnimatedCosmeticHolder.remove(slot);
        }
        if (filamentCosmeticHolder.containsKey(slot)) {
            filamentCosmeticHolder.get(slot).getAttachment().destroy();
            filamentCosmeticHolder.get(slot).destroy();
            filamentCosmeticHolder.remove(slot);
        }
    }
}

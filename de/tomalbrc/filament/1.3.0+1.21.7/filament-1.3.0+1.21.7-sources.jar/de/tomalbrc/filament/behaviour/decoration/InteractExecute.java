package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.ExecuteUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Interact-execute behaviour for decoration
 */
public class InteractExecute implements DecorationBehaviour<InteractExecute.Config> {
    public Config config;

    public InteractExecute(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public InteractExecute.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        DecorationBehaviour.super.init(blockEntity);
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        class_1792 key = this.config.key == null ? null : class_7923.field_41178.method_63535(this.config.key);
        class_1799 mainHandItem = player.method_5998(class_1268.field_5808);
        boolean hasHandItem = !mainHandItem.method_7960();
        boolean holdsKeyAndIsValid = hasHandItem && key != null && mainHandItem.method_31574(key);
        boolean noKey = key == null;
        var pos = getConfig().atBlock ? decorationBlockEntity.method_11016().method_46558() : null;
        if (holdsKeyAndIsValid || noKey) {
            if (this.config.consumeKey && hasHandItem) {
                mainHandItem.method_7934(1);
            }

            if (this.config.animation != null && !config.animation.isEmpty() && decorationBlockEntity.getOrCreateHolder() != null) {
                decorationBlockEntity.getOrCreateHolder().playAnimation(config.animatePerPlayer ? player : null, config.animation, 0, commandsPost() == null ? null : (serverPlayer -> {
                    var cmdsPost = commandsPost();
                    if (player.method_5682() != null && cmdsPost != null) {
                        if (getConfig().console) {
                            ExecuteUtil.asConsole(player, pos, cmdsPost.toArray(new String[0]));
                        }
                        else {
                            ExecuteUtil.asPlayer(player, pos, cmdsPost.toArray(new String[0]));
                        }
                    }

                    if (config.animationPost != null) {
                        decorationBlockEntity.getOrCreateHolder().playAnimation(config.animatePerPlayer ? player : null, config.animationPost);
                    }
                }));
            }

            var cmds = commands();
            boolean hasCommand = cmds != null && !cmds.isEmpty();
            if (hasCommand && player.method_5682() != null) {
                if (getConfig().console) {
                    ExecuteUtil.asConsole(player, pos, cmds.toArray(new String[0]));
                }
                else {
                    ExecuteUtil.asPlayer(player, pos, cmds.toArray(new String[0]));
                }

                return class_1269.field_5812;
            }

            if (this.config.discard) {
                decorationBlockEntity.destroyStructure(false);
            }
        } else if (!noKey) {
            var cmds = commandsIncorrectKey();
            if (player.method_5682() != null && cmds != null) {
                if (getConfig().console) {
                    ExecuteUtil.asConsole(player, pos, cmds.toArray(new String[0]));
                }
                else {
                    ExecuteUtil.asPlayer(player, pos, cmds.toArray(new String[0]));
                }
            }

            if (config.animationIncorrectKey != null) {
                decorationBlockEntity.getOrCreateHolder().playAnimation(config.animatePerPlayer ? player : null, config.animationIncorrectKey);
            }
        }

        return class_1269.field_21466;
    }

    private List<String> commands() {
        return config.commands == null ? config.command == null ? null : List.of(config.command) : config.commands;
    }

    private List<String> commandsPost() {
        return config.commandsPostAnimation == null ? config.commandPostAnimation == null ? null : List.of(config.commandPostAnimation) : config.commandsPostAnimation;
    }

    private List<String> commandsIncorrectKey() {
        return config.commandsIncorrectKey == null ? config.commandIncorrectKey == null ? null : List.of(config.commandIncorrectKey) : config.commandsIncorrectKey;
    }

    public static class Config {
        /**
         * The identifier of the key required to unlock.
         */
        public class_2960 key = null;

        /**
         * Determines whether the key should be consumed upon unlocking.
         */
        public boolean consumeKey = false;

        /**
         * Specifies whether the lock util should be discarded after unlocking.
         */
        public boolean discard = false;

        /**
         * Name of the animation to play upon successful unlocking (if applicable).
         */
        public String animation = null;

        /**
         * Name of animation to player after the first one ended
         */
        public String animationPost = null;

        /**
         * Whether to play animation only for player interacting with the decoration
         */
        public boolean animatePerPlayer = false;

        /**
         * Command to execute when the lock is successfully unlocked (if specified).
         * The command can be overwritten using NBT, the path for the command is Lock.Command in the block entities' NBT
         * `data modify @e[...] Lock.Command set value "say hello"`
         */
        public String command = null;

        /**
         * List of commands. See above
         */
        public List<String> commands = null;

        /**
         * Commands to run after animation
         */
        public String commandPostAnimation = null;

        /**
         * List of to run after animation
         */
        public List<String> commandsPostAnimation = null;

        /**
         * List of commands to run on incorrect key
         */
        public String commandIncorrectKey = null;
        public List<String> commandsIncorrectKey = null;
        public String animationIncorrectKey = null;

        /**
         * Whether to execute the commands at the interacted blocks' position instead of the players position
         */
        public boolean atBlock = false;
        public boolean console;
    }
}
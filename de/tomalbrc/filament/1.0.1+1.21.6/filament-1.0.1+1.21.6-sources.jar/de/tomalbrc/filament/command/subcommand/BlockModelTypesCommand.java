package de.tomalbrc.filament.command.subcommand;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import de.tomalbrc.bil.util.Permissions;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import java.util.Arrays;
import java.util.stream.Collectors;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class BlockModelTypesCommand {
    public static LiteralCommandNode<class_2168> register() {
        var node = class_2170
                .method_9247("block-model-types").requires(Permissions.require("filament.command.block-model-types", 2));

        return node.executes(BlockModelTypesCommand::execute).build();
    }

    private static int execute(CommandContext<class_2168> context) {
        var player = context.getSource().method_44023();
        if (player != null) {
            var r = Arrays.stream(BlockModelType.values()).map(x -> {
                var left = PolymerBlockResourceUtils.getBlocksLeft(x);
                return String.format("§3%s§r: §" + (left <= 3 ? "4" : left <= 10 ? "6" : "2") + "%d§r", x.name(), left);
            }).collect(Collectors.joining(", "));
            context.getSource().method_9226(() -> class_2561.method_43470("BlockModelTypes: " + r), false);
        }
        return 0;
    }
}

package de.tomalbrc.filament.decoration;

import Z;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviours.item.Cosmetic;
import de.tomalbrc.filament.behaviours.item.Fuel;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.registry.FuelRegistry;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_5151;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.List;

public class DecorationItem extends class_1747 implements PolymerItem, class_5151 {
    final private DecorationData decorationData;
    final private PolymerModelData modelData;

    public DecorationItem(class_2248 block, DecorationData decorationData, class_1792.class_1793 properties) {
        super(block, properties);
        this.decorationData = decorationData;
        this.modelData = this.decorationData.requestModel();

        if (this.decorationData.isFuel()) {
            Fuel.FuelConfig fuel = this.decorationData.behaviourConfig().get(Constants.Behaviours.FUEL);
            FuelRegistry.add(this, fuel.value);
        }
    }

    public DecorationData getDecorationData() {
        return this.decorationData;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        if (this.decorationData.vanillaItem() == class_1802.field_18138) {
            list.add(class_2561.method_43470("§9Dyeable"));
        }

        if (this.decorationData.properties() != null) {
            this.decorationData.properties().appendHoverText(list);
        }

        if (itemStack.method_57826(class_9334.field_49622)) {
            Iterator<class_1799> itemStackIterator = itemStack.method_57825(class_9334.field_49622, class_9288.field_49334).method_59714().iterator();
            int i = 0;
            int j = 0;
            while(itemStackIterator.hasNext()) {
                class_1799 itemStack2 = itemStackIterator.next();
                j++;
                if (i <= 4) {
                    i++;
                    list.add(class_2561.method_43469("container.shulkerBox.itemCount", itemStack2.method_7964(), itemStack2.method_7947()));
                }
            }
            if (j - i > 0) {
                list.add(class_2561.method_43469("container.shulkerBox.more", j - i).method_27692(class_124.field_1056));
            }
        }
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, @Nullable class_3222 player) {
        return modelData.item();
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        return modelData.value();
    }

    public static float getVisualRotationYInDegrees(class_2350 direction, int rotation) {
        int i = direction.method_10166().method_10178() ? 90 * direction.method_10171().method_10181() : 0;
        return (float) class_3532.method_15392(180 + direction.method_10161() * 90 + rotation * 45 + i);
    }

    @Override
    public class_1269 method_7884(class_1838 useOnContext) {
        if (decorationData == null) {
            Filament.LOGGER.warn("Can't use decoration Item: Missing decoration formats!");
            return class_1269.field_5814;
        }

        var replaceable = useOnContext.method_8045().method_8320(useOnContext.method_8037()).method_45474();

        class_2338 blockPos = useOnContext.method_8037();
        class_2350 direction = replaceable ? class_2350.field_11036 : useOnContext.method_8038();
        class_2338 relativeBlockPos = replaceable ? blockPos : blockPos.method_10093(direction);
        class_1657 player = useOnContext.method_8036();
        class_1799 itemStack = useOnContext.method_8041();
        class_1937 level = useOnContext.method_8045();

        int rotation = 0;
        if (decorationData.properties() != null && decorationData.properties().rotate) {
            if (decorationData.properties().rotateSmooth) {
                rotation = Util.SEGMENTED_ANGLE8.method_48125(useOnContext.method_8044()-180);
            } else {
                rotation = Util.SEGMENTED_ANGLE8.method_48124(useOnContext.method_8042().method_10153());
            }
        }

        boolean propertyPlaceCheck = true;
        if (decorationData.properties() != null) {
            propertyPlaceCheck = decorationData.properties().placement.canPlace(direction);
        }

        float angle = this.getVisualRotationYInDegrees(direction, rotation);

        if (player == null || !this.mayPlace(player, direction, itemStack, relativeBlockPos) || !propertyPlaceCheck) {
            return class_1269.field_5814;
        } else if (this.canPlaceAt(level, relativeBlockPos, useOnContext.method_8042().method_10153(), useOnContext.method_8038(), angle) && itemStack.method_7909() instanceof DecorationItem) {
            if (decorationData.hasBlocks()) {
                int finalRotation = rotation;
                Util.forEachRotated(decorationData.blocks(), relativeBlockPos, angle, blockPos2 -> {
                    level.method_22352(blockPos2, false);

                    class_1750 blockPlaceContext = new class_1750(player, useOnContext.method_20287(), itemStack, new class_3965(useOnContext.method_17698(), useOnContext.method_8038(), blockPos2, useOnContext.method_17699()));
                    class_2680 blockState = DecorationRegistry.getDecorationBlock(decorationData.id()).method_9605(blockPlaceContext);
                    if (decorationData.properties() != null && decorationData.properties().isLightSource()) {
                        blockState = blockState.method_11657(DecorationBlock.LIGHT_LEVEL, decorationData.properties().lightEmission);
                    }

                    if (!decorationData.properties().waterloggable)
                        blockState = blockState.method_11657(DecorationBlock.WATERLOGGED, false);

                    if (decorationData.isSimple()) {
                        blockState = blockState.method_11657(SimpleDecorationBlock.FACING, direction);
                        blockState = blockState.method_11657(SimpleDecorationBlock.ROTATION, (finalRotation + 4) % 8);
                    }

                    level.method_8501(blockPos2, blockState);

                    if (!decorationData.isSimple() && level.method_8321(blockPos2) instanceof DecorationBlockEntity decorationBlockEntity) {
                        decorationBlockEntity.setMain(new class_2338(blockPos2).method_10059(relativeBlockPos));
                        decorationBlockEntity.setItem(itemStack.method_46651(1));
                        decorationBlockEntity.setRotation(finalRotation);
                        decorationBlockEntity.setDirection(direction);
                        decorationBlockEntity.setupBehaviour(decorationData);
                        decorationBlockEntity.attach((class_3218) level);
                    }
                });
            } else {
                class_1750 blockPlaceContext = new class_1750(player, useOnContext.method_20287(), itemStack, new class_3965(useOnContext.method_17698(), useOnContext.method_8038(), useOnContext.method_8037(), useOnContext.method_17699()));

                class_2680 blockState = DecorationRegistry.getDecorationBlock(decorationData.id()).method_9605(blockPlaceContext);
                blockState = blockState.method_11657(DecorationBlock.PASSTHROUGH, true);

                if (!decorationData.properties().waterloggable) {
                    blockState = blockState.method_11657(DecorationBlock.WATERLOGGED, false);
                }

                if (decorationData.properties() != null && decorationData.properties().isLightSource()) {
                    blockState = blockState.method_11657(DecorationBlock.LIGHT_LEVEL, decorationData.properties().lightEmission);
                }

                if (decorationData.isSimple()) {
                    blockState = blockState.method_11657(SimpleDecorationBlock.FACING, direction);
                    blockState = blockState.method_11657(SimpleDecorationBlock.ROTATION, (rotation + 4) % 8);
                }

                level.method_8501(relativeBlockPos, blockState);
                if (!decorationData.isSimple() && level.method_8321(relativeBlockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                    decorationBlockEntity.setMain(class_2338.field_10980);
                    decorationBlockEntity.setItem(itemStack.method_46651(1));
                    decorationBlockEntity.setRotation(rotation);
                    decorationBlockEntity.setDirection(direction);
                    decorationBlockEntity.setupBehaviour(decorationData);
                    decorationBlockEntity.attach((class_3218) level);
                }
            }

            player.method_6019(useOnContext.method_20287());
            itemStack.method_7934(1);

            level.method_8396(null, blockPos, class_3417.field_14574, class_3419.field_15248, 1.0F, 1.0F);

            return class_1269.method_29236(level.field_9236);
        }

        return class_1269.field_5814;
    }

    protected boolean mayPlace(class_1657 player, class_2350 direction, class_1799 itemStack, class_2338 blockPos) {
        return !player.method_37908().method_31606(blockPos) && player.method_7343(blockPos, direction, itemStack);
    }

    /**
     * Check if multi-block structure can be placed
     */
    private boolean canPlaceAt(class_1937 level, class_2338 blockPos, class_2350 direction, class_2350 clickedFace, float angle) {
        if (!level.method_8320(blockPos).method_45474()) {
            return false;
        }

        if (decorationData.hasBlocks()) {
            boolean canPlace[] = new boolean[]{true};
            Util.forEachRotated(decorationData.blocks(), blockPos, angle, blockPos2 -> {
                if (!level.method_8320(blockPos2).method_45474()) {
                    canPlace[0] = false;
                }
            });
            return canPlace[0];
        }

        return true;
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);

        if (res.method_5467() != class_1269.field_21466 && this.decorationData.isCosmetic()) {
            res = this.method_48576(this, level, user, hand);
        }

        return res;
    }

    @Override
    @NotNull
    public class_1304 method_7685() {
        boolean cosmetic = decorationData.isCosmetic();
        if (cosmetic) {
            Cosmetic.CosmeticConfig cosmetic1 = this.decorationData.behaviourConfig().get(Constants.Behaviours.COSMETIC);
            if (cosmetic1.slot != null)
                return cosmetic1.slot;
        }
        return class_1304.field_6173;
    }
}

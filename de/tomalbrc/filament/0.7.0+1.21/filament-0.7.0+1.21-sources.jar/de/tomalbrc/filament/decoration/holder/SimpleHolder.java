package de.tomalbrc.filament.decoration.holder;

import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.BlockBoundAttachment;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class SimpleHolder extends ElementHolder {
    private InteractionElement interactionElement;
    private ItemDisplayElement displayElement;

    public SimpleHolder() {
        super();
    }

    @Override
    protected void updateInitialPosition() {
        super.updateInitialPosition();

        if (this.getAttachment() instanceof BlockBoundAttachment blockBoundAttachment) {
            this.setBlock(blockBoundAttachment.getBlockPos(), blockBoundAttachment.getBlockState());
        }
    }

    public void setBlock(class_2338 pos, class_2680 blockState) {
        if (DecorationRegistry.isDecoration(blockState) && this.displayElement == null) {
            SimpleDecorationBlock decorationBlock = (SimpleDecorationBlock) blockState.method_26204();

            this.displayElement = Util.decorationItemDisplay(decorationBlock.getDecorationData(), blockState.method_11654(SimpleDecorationBlock.FACING), Util.SEGMENTED_ANGLE8.method_48126(blockState.method_11654(SimpleDecorationBlock.ROTATION)));
            this.addElement(displayElement);

            if (!decorationBlock.getDecorationData().hasBlocks()) {
                this.interactionElement = Util.decorationInteraction(pos);
                this.addElement(interactionElement);
            }
        }
    }
}
package de.tomalbrc.filament.behaviours.decoration;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.decoration.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.holder.DecorationHolder;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.elements.BlockDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7833;
import net.minecraft.class_7924;

/**
 * For item showcase decoration
 */
public class Showcase implements DecorationBehaviour<Showcase.ShowcaseConfig> {
    private static final String SHOWCASE_KEY = "Showcase";
    private static final String ITEM = "Item";

    private final ShowcaseConfig config;

    Object2ObjectOpenHashMap<ShowcaseMeta, DisplayElement> showcases = new Object2ObjectOpenHashMap<>();

    public Showcase(ShowcaseConfig config) {
        this.config = config;
    }

    @Override
    public ShowcaseConfig getConfig() {
        return this.config;
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (!player.method_21823() && decorationBlockEntity.getDecorationHolder() instanceof DecorationHolder) {
            Showcase.ShowcaseMeta showcase = getClosestShowcase(decorationBlockEntity, location);
            class_1799 itemStack = player.method_5998(hand);

            if (this.canUseShowcaseItem(showcase, itemStack)) {
                if (!player.method_5998(hand).method_7960()) {

                    if (this.getShowcaseItemStack(showcase) != null) {
                        Util.spawnAtLocation(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016().method_46558(), this.getShowcaseItemStack(showcase));
                    }

                    this.setShowcaseItemStack(decorationBlockEntity, showcase, itemStack.method_46651(1));
                    itemStack.method_7934(1);
                } else if (this.getShowcaseItemStack(showcase) != null) {
                    player.method_6122(hand, this.getShowcaseItemStack(showcase));
                    this.setShowcaseItemStack(decorationBlockEntity, showcase, class_1799.field_8037);
                }

                decorationBlockEntity.method_5431();

                return class_1269.field_21466;
            }
        }

        return class_1269.field_5811;
    }

    @Override
    public void read(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {
        if (compoundTag.method_10545(SHOWCASE_KEY) && blockEntity.getDecorationHolder() != null) {
            class_2487 showcaseTag = compoundTag.method_10562(SHOWCASE_KEY);
            DecorationHolder holder = DecorationHolder.class.cast(blockEntity.getDecorationHolder());
            if (holder == null)
                return;

            Showcase showcase = blockEntity.getBehaviour(Constants.Behaviours.SHOWCASE);
            for (int i = 0; i < showcase.config.size(); i++) {
                Showcase.ShowcaseMeta showcaseMeta = showcase.config.get(i);
                String key = ITEM + i;
                if (showcase != null && showcaseTag.method_10545(key)) {
                    setShowcaseItemStack(blockEntity, showcaseMeta, class_1799.method_57359(provider, showcaseTag.method_10562(key)));
                }
            }
        }
    }

    @Override
    public void write(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {
        if (blockEntity.getDecorationHolder() != null) {
            class_2487 showcaseTag = new class_2487();

            for (int i = 0; i < config.size(); i++) {
                Showcase.ShowcaseMeta showcase = config.get(i);
                if (showcase != null && !getShowcaseItemStack(showcase).method_7960())
                    showcaseTag.method_10566(ITEM + i, getShowcaseItemStack(showcase).method_57358(provider));
            }

            compoundTag.method_10566(SHOWCASE_KEY, showcaseTag);
        }
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        if (decorationBlockEntity.getDecorationHolder() instanceof DecorationHolder decorationHolder) {
            config.forEach(showcase -> {
                class_1799 itemStack = getShowcaseItemStack(showcase);
                if (itemStack != null && !itemStack.method_7960()) {
                    Util.spawnAtLocation(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016().method_46558(), this.getShowcaseItemStack(showcase));
                }
            });
        }
    }

    public Showcase.ShowcaseMeta getClosestShowcase(DecorationBlockEntity decorationBlockEntity, class_243 location) {
        if (config.size() == 1) {
            return config.get(0);
        }
        else {
            double dist = Double.MAX_VALUE;
            Showcase.ShowcaseMeta nearest = null;
            for (Showcase.ShowcaseMeta showcase : config) {
                class_243 q = decorationBlockEntity.method_11016().method_46558().method_1019(new class_243(this.showcaseTranslation(decorationBlockEntity, showcase)));
                double distance = q.method_1022(location);

                if (distance < dist) {
                    dist = distance;
                    nearest = showcase;
                }
            }

            return nearest;
        }
    }

    private Vector3f showcaseTranslation(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase) {
        return new Vector3f(showcase.offset).sub(0, 0.475f, 0).rotate(class_7833.field_40715.rotation(class_3532.field_29847 * decorationBlockEntity.getVisualRotationYInDegrees()));
    }

    public void setShowcaseItemStack(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        boolean isBlockItem = itemStack.method_7909() instanceof class_1747;

        DisplayElement element = this.showcases.get(showcase);
        DisplayElement newElement;

        boolean dynNeedsUpdate = showcase.type == Showcase.ShowcaseType.dynamic && element != null && !(element instanceof BlockDisplayElement && isBlockItem);

        if (element == null || dynNeedsUpdate) {
            if (element != null) { // update dynamic display, remove old
                decorationBlockEntity.getDecorationHolder().removeElement(element);
                this.showcases.remove(showcase);
            }

            newElement = this.createShowcase(decorationBlockEntity, showcase, itemStack);
            decorationBlockEntity.getDecorationHolder().addElement(newElement);
        } else {
            if (element instanceof BlockDisplayElement blockDisplayElement && itemStack.method_7909() instanceof class_1747 blockItem) {
                blockDisplayElement.setBlockState(blockItem.method_7711().method_9564());
            } else if (element instanceof ItemDisplayElement itemDisplayElement) {
                itemDisplayElement.setItem(itemStack);
            }
        }

        decorationBlockEntity.getDecorationHolder().tick();
    }

    private BlockDisplayElement element(class_1747 blockItem) {
        BlockDisplayElement displayElement = new BlockDisplayElement();
        displayElement.setBlockState(blockItem.method_7711().method_9564());
        return displayElement;
    }
    private ItemDisplayElement element(class_1799 itemStack) {
        ItemDisplayElement displayElement = new ItemDisplayElement();
        displayElement.setItem(itemStack.method_7972());
        return displayElement;
    }
    private DisplayElement createShowcase(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        DisplayElement element = null;

        switch (showcase.type) {
            case item -> element = this.element(itemStack);
            case block -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem) {
                    element = this.element(blockItem);
                }
            }
            case dynamic -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem) {
                    element = this.element(blockItem);
                } else {
                    element = this.element(itemStack);
                }
            }
        }

        if (element != null) {
            element.setScale(showcase.scale);
            element.setLeftRotation(showcase.rotation);
            Quaternionf rot = class_7833.field_40715.rotationDegrees(decorationBlockEntity.getVisualRotationYInDegrees()+180).normalize();
            if (element instanceof BlockDisplayElement) {
                element.setTranslation(this.showcaseTranslation(decorationBlockEntity, showcase).add(new Vector3f(-.5f, -.5f, -.5f).rotate(rot).mul(showcase.scale)));
            } else {
                element.setTranslation(this.showcaseTranslation(decorationBlockEntity, showcase));
            }

            element.setRightRotation(rot);

            this.showcases.put(showcase, element);
        } else {
            Filament.LOGGER.error("In valid showcase type for " + itemStack.method_7909().method_7876());
        }

        return element;
    }

    public class_1799 getShowcaseItemStack(Showcase.ShowcaseMeta showcase) {
        DisplayElement element = this.showcases.get(showcase);
        if (element instanceof ItemDisplayElement itemDisplayElement) {
            return itemDisplayElement.getItem().method_7972();
        } else if (element instanceof BlockDisplayElement itemDisplayElement) {
            return itemDisplayElement.getBlockState().method_26204().method_8389().method_7854();
        }
        return class_1799.field_8037;
    }

    public boolean canUseShowcaseItem(Showcase.ShowcaseMeta showcase, class_1799 item) {
        boolean hasFilterItems = showcase.filterItems != null && !showcase.filterItems.isEmpty();
        boolean hasFilterTags = showcase.filterTags != null && !showcase.filterTags.isEmpty();

        if (hasFilterTags) {
            for (var filterTag: showcase.filterTags) {
                class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, filterTag);
                if (item.method_31573(key)) {
                    return true;
                }
            }
        }

        if (hasFilterItems) {
            for (var filterTag: showcase.filterItems) {
                if (item.method_31574(filterTag)) {
                    return true;
                }
            }
        }

        return !(hasFilterItems || hasFilterTags);
    }


    public static class ShowcaseMeta {
        /**
         * Offset for positioning the showcased item
         */
        public Vector3f offset = new Vector3f();

        /**
         * Scale of the showcased item
         */
        public Vector3f scale = new Vector3f(1);

        /**
         * Rotation of the showcased item
         */
        public Quaternionf rotation = new Quaternionf();

        /**
         * Type to display, block for blocks (block display), item for items (item display), dynamic uses blocks if possible, otherwise item (block/item display)
         */
        public ShowcaseType type = ShowcaseType.item;

        /**
         * Items to allow
         */
        public List<class_1792> filterItems;

        /**
         * Items with given item tags to allow
         */
        public List<class_2960> filterTags;
    }

    public enum ShowcaseType {
        item,
        block,
        dynamic // block when possible, item otherwise
    }

    public static class ShowcaseConfig extends ObjectArrayList<ShowcaseMeta> { }
}
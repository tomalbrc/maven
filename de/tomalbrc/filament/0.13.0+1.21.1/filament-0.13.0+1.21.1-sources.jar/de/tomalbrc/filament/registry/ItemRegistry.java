package de.tomalbrc.filament.registry;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.util.*;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_7923;
import net.minecraft.class_9336;

public class ItemRegistry {
    public static Map<class_2960, Collection<class_2960>> ITEMS_TAGS = new Object2ReferenceOpenHashMap<>();

    public static void register(InputStream inputStream) throws IOException {
        register(Json.GSON.fromJson(new InputStreamReader(inputStream, StandardCharsets.UTF_8), ItemData.class));
    }

    static public void register(ItemData data) {
        if (class_7923.field_41178.method_10250(data.id())) return;

        class_1792.class_1793 properties = data.properties().toItemProperties(data.behaviourConfig());

        if (data.properties().copyComponents) {
            for (class_9336 component : data.vanillaItem().method_57347()) {
                properties.method_57349(component.comp_2443(), component.comp_2444());
            }
        }

        for (class_9336 component : data.components()) {
            properties.method_57349(component.comp_2443(), component.comp_2444());
        }

        SimpleItem item = new SimpleItem(null, properties, data, data.vanillaItem());
        BehaviourUtil.postInitItem(item, item, data.behaviourConfig());
        Translations.add(item, null, data);

        registerItem(data.id(), item, data.itemGroup() != null ? data.itemGroup() : Constants.ITEM_GROUP_ID, data.itemTags());
        RPUtil.create(item, data.id(), data.itemResource());

        FilamentRegistrationEvents.ITEM.invoker().registered(data, item);
    }

    public static void registerItem(class_2960 identifier, class_1792 item, class_2960 itemGroup, @Nullable Collection<class_2960> tags) {
        class_2378.method_10230(class_7923.field_41178, identifier, item);
        ItemGroupRegistry.addItem(itemGroup, item);
    }

    public static class ItemDataReloadListener implements FilamentSynchronousResourceReloadListener {
        static private boolean printedInfo = false;

        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "items");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            load("filament/item", null, resourceManager, (id, inputStream) -> {
                try {
                    ItemRegistry.register(inputStream);
                } catch (IOException e) {
                    Filament.LOGGER.error("Failed to load item resource \"{}\".", id, e);
                }
            });
            if (!printedInfo) {
                for (String s : Arrays.asList("Filament items registered: " + ITEMS_TAGS.size(), "Filament blocks registered: " + BlockRegistry.BLOCKS_TAGS.size(), "Filament decorations registered: " + DecorationRegistry.REGISTERED_DECORATIONS, "Filament decoration block entities registered: " + DecorationRegistry.REGISTERED_BLOCK_ENTITIES)) {
                    Filament.LOGGER.info(s);
                }
                printedInfo = true;
            }
        }
    }
}
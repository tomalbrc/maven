package de.tomalbrc.filament.registry;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.decoration.Container;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.*;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_9282;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import net.minecraft.class_9336;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class DecorationRegistry {
    private static final Reference2ObjectOpenHashMap<class_2960, DecorationData> decorations = new Reference2ObjectOpenHashMap<>();
    private static final Reference2ObjectOpenHashMap<class_2960, class_2248> decorationBlocks = new Reference2ObjectOpenHashMap<>();
    private static final Reference2ObjectOpenHashMap<class_2248, class_2591<DecorationBlockEntity>> decorationBlockEntities = new Reference2ObjectOpenHashMap<>();
    public static int REGISTERED_BLOCK_ENTITIES = 0;
    public static int REGISTERED_DECORATIONS = 0;

    public static void register(InputStream inputStream) throws IOException {
        register(Json.GSON.fromJson(new InputStreamReader(inputStream, StandardCharsets.UTF_8), DecorationData.class));
    }

    static public void register(DecorationData data) {
        for (Map.Entry<class_2960, DecorationData> entry : decorations.entrySet()) {
            if (entry.getKey().equals(data.id())) return;
        }

        decorations.put(data.id(), data);

        DecorationBlock block;
        class_4970.class_2251 props = data.properties().toBlockProperties();

        if (!data.isSimple()) {
            block = new ComplexDecorationBlock(props.method_50012(class_3619.field_15972), data.id());

            class_2591<DecorationBlockEntity> DECORATION_BLOCK_ENTITY = FabricBlockEntityTypeBuilder.create(DecorationBlockEntity::new, block).build();
            EntityRegistry.registerBlockEntity(data.id(), DECORATION_BLOCK_ENTITY);

            decorationBlockEntities.put(block, DECORATION_BLOCK_ENTITY);
            REGISTERED_BLOCK_ENTITIES++;
        } else {
            block = new SimpleDecorationBlock(props.method_42327(), data.id());
        }

        decorationBlocks.put(data.id(), block);
        BlockRegistry.registerBlock(data.id(), block, data.blockTags());

        class_1792.class_1793 properties = data.properties().toItemProperties();
        if (data.properties().copyComponents) {
            for (class_9336 component : data.vanillaItem().method_57347()) {
                properties.method_57349(component.comp_2443(), component.comp_2444());
            }
        }

        for (class_9336 component : data.components()) {
            properties.method_57349(component.comp_2443(), component.comp_2444());
        }

        if (data.behaviourConfig() != null && data.isContainer()) {
            Container.ContainerConfig container = data.behaviourConfig().get(Behaviours.CONTAINER);
            if (container.canPickup)
                properties.method_57349(class_9334.field_49622, class_9288.field_49334);
        }

        if (data.vanillaItem() == class_1802.field_18138 || data.vanillaItem() == class_1802.field_8450) {
            properties.method_57349(class_9334.field_49644, new class_9282(0xdaad6d, false));
        }

        DecorationItem item = new DecorationItem(block, data, properties);
        BehaviourUtil.postInitItem(item, item, data.behaviourConfig());
        ItemRegistry.registerItem(data.id(), item, data.itemGroup() != null ? data.itemGroup() : Constants.DECORATION_GROUP_ID, data.itemTags());
        Translations.add(item, block, data);

        RPUtil.create(item, data.id(), data.itemResource());

        FilamentRegistrationEvents.DECORATION.invoker().registered(data, item, (DecorationBlock)block);
    }

    public static DecorationData getDecorationDefinition(class_2960 resourceLocation) {
        return decorations.get(resourceLocation);
    }

    public static boolean isDecoration(class_2680 blockState) {
        return blockState.method_26204() instanceof DecorationBlock;
    }

    public static DecorationBlock getDecorationBlock(class_2960 resourceLocation) {
        return (DecorationBlock) decorationBlocks.get(resourceLocation);
    }

    public static class_2591<DecorationBlockEntity> getBlockEntityType(class_2680 blockState) {
        return decorationBlockEntities.get(blockState.method_26204());
    }


    public static class DecorationDataReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "decorations");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            load("filament/decoration", null, resourceManager, (id, inputStream) -> {
                try {
                    DecorationRegistry.register(inputStream);
                } catch (IOException e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"{}\".", id);
                }
            });
        }
    }
}

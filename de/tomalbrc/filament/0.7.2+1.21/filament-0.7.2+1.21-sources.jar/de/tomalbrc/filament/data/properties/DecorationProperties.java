package de.tomalbrc.filament.data.properties;

import net.minecraft.class_2350;
import net.minecraft.class_3619;
import net.minecraft.class_811;

public class DecorationProperties extends ItemProperties {
    public boolean rotate = false;
    public boolean rotateSmooth = false;

    public Placement placement = Placement.DEFAULT;
    public boolean glow = false;

    public class_3619 pushReaction = class_3619.field_15974;

    public boolean waterloggable = true;
    public boolean solid = false;

    public class_811 display = class_811.field_4319;

    public record Placement(boolean wall, boolean floor, boolean ceiling) {
        public static Placement DEFAULT = new Placement(false, true, false);
        public boolean canPlace(class_2350 direction) {
            boolean upDown = direction == class_2350.field_11036 || direction == class_2350.field_11033;
            return (wall && !upDown) || (floor && direction == class_2350.field_11036) || (ceiling && direction == class_2350.field_11033);
        }
    }
}

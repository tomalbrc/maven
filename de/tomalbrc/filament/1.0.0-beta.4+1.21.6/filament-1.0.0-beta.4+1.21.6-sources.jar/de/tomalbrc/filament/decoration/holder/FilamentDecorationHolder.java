package de.tomalbrc.filament.decoration.holder;

import de.tomalbrc.filament.decoration.block.DecorationBlock;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.BlockAwareAttachment;
import eu.pb4.polymer.virtualentity.api.attachment.HolderAttachment;
import eu.pb4.polymer.virtualentity.api.elements.GenericEntityElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public interface FilamentDecorationHolder {
    <T extends VirtualElement> T addElement(T element);

    void removeElement(VirtualElement element);

    void tick();

    class_243 getPos();

    @Nullable HolderAttachment getAttachment();

    boolean isAnimated();

    class_1799 getPickResult();

    default void updateVisualItem(class_1799 newItem) {

    }

    default void playAnimation(String animation, int priority) {
    }

    default void playAnimation(String animation) {
    }

    default void setYaw(float rotation) {
        for (VirtualElement element : this.asPolymerHolder().getElements()) {
            if (element instanceof GenericEntityElement displayElement) {
                displayElement.setYaw(rotation-180);
            }
        }

        if (!isAnimated())
            tick();
    }

    default ElementHolder asPolymerHolder() {
        return (ElementHolder) this;
    }

    default void update(class_2680 blockState) {
        HolderAttachment attachment = this.getAttachment();
        if (attachment instanceof BlockAwareAttachment blockBoundAttachment) {
            class_2680 attachmentBlockState = blockBoundAttachment.getBlockState();
            DecorationBlock decorationBlock = (DecorationBlock) attachmentBlockState.method_26204();
            // the decoration block entity does not have the blockstate available when update() is called, use blockState from attachment
            this.updateVisualItem(decorationBlock.visualItemStack(blockBoundAttachment.getWorld(), blockBoundAttachment.getBlockPos(), blockState));
            this.setYaw(decorationBlock.getVisualRotationYInDegrees(blockState));
            this.tick();
        }
    }
}

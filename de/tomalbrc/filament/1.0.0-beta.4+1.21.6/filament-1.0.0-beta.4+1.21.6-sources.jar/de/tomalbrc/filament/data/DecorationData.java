package de.tomalbrc.filament.data;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.data.properties.DecorationProperties;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.data.resource.ResourceProvider;
import de.tomalbrc.filament.util.DecorationUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_9323;

@SuppressWarnings("unused")
public final class DecorationData extends AbstractBlockData<DecorationProperties> {
    private final @Nullable List<BlockConfig> blocks;
    private final @Nullable Vector2f size;
    private final @Nullable Boolean itemFrame;
    private final @Nullable class_2680 block;

    public DecorationData(
            @NotNull class_2960 id,
            @Nullable class_1792 vanillaItem,
            @Nullable Map<String, String> translations,
            @Nullable class_2561 displayName,
            @Nullable ItemResource itemResource,
            @Nullable class_2960 itemModel,
            @Nullable BehaviourConfigMap behaviourConfig,
            @Nullable class_9323 components,
            @Nullable class_2960 itemGroup,
            @Nullable Set<class_2960> itemTags,
            @Nullable Set<class_2960> blockTags,
            @Nullable DecorationProperties properties,
            @Nullable List<BlockConfig> blocks,
            @Nullable class_2680 block,
            @Nullable Vector2f size,
            @Nullable Boolean itemFrame
    ) {
        super(id, vanillaItem, translations, displayName, itemResource, itemModel, behaviourConfig, components, itemGroup, properties, itemTags, blockTags);
        this.blocks = blocks;
        this.size = size;
        this.itemFrame = itemFrame;
        this.block = block;
    }

    @Override
    public @NotNull ResourceProvider preferredResource() {
        assert this.itemResource != null;
        return this.itemResource;
    }

    @Override
    @NotNull
    public DecorationProperties properties() {
        if (properties == null) {
            this.properties = new DecorationProperties();
        }
        return this.properties ;
    }

    public boolean isContainer() {
        return this.behaviour().has(Behaviours.CONTAINER);
    }

    public boolean hasBlocks() {
        return this.blocks != null;
    }

    public int countBlocks() {
        if (!this.hasBlocks())
            return 0;

        int count = 0;
        for (BlockConfig block : this.blocks) {
            count += (int) (block.size().x() * block.size().y() * block.size().z());
        }

        return count;
    }

    @Override
    public boolean requiresEntityBlock() {
        boolean singleBlock = (!this.hasBlocks() || DecorationUtil.barrierDimensions(Objects.requireNonNull(this.blocks()), 0).equals(1, 1));
        boolean hasDecorationBehaviour = this.behaviour().test((a) -> DecorationBehaviour.class.isAssignableFrom(a.type()));
        boolean canBeDyed = this.vanillaItem != null && (this.vanillaItem == class_1802.field_18138 || this.vanillaItem == class_1802.field_8450);
        boolean groundOnly = !this.properties().placement.wall() && !this.properties().placement.ceiling();

        return !groundOnly || canBeDyed || hasDecorationBehaviour || (!singleBlock && this.size == null);
    }

    public @Nullable List<BlockConfig> blocks() {
        return this.blocks;
    }

    public @Nullable Vector2f size() {
        return this.size;
    }

    public @Nullable Boolean itemFrame() {
        return this.itemFrame;
    }

    public @NotNull class_2680 block() {
        return this.block != null ? this.block : class_2246.field_10499.method_9564();
    }

    @Override
    public Map<class_2680, BlockData.BlockStateMeta> createStandardStateMap() {
        return null;
    }

    @Override
    public BlockResource blockResource() {
        return null;
    }

    @Override
    public boolean virtual() {
        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (DecorationData) obj;
        return Objects.equals(this.id, that.id);
    }

    @Override
    public String toString() {
        return "DecorationData[" +
                "id=" + id + ", " +
                "itemResource=" + itemResource + ", " +
                "vanillaItem=" + vanillaItem + ", " +
                "blocks=" + blocks + ", " +
                "size=" + size + ", " +
                "properties=" + properties + ", " +
                "behaviourConfig=" + behaviour + ", " +
                "components=" + components + ", " +
                "itemGroup=" + group + ']';
    }

    public record BlockConfig(Vector3f origin,
                              Vector3f size) {
    }
}

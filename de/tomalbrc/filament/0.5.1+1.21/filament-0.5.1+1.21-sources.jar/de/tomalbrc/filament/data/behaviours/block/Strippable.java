package de.tomalbrc.filament.data.behaviours.block;

import net.minecraft.class_2960;

/**
 * Block behaviour for strippable blocks (with an axe)
 * Copies blockstate properties if applicabable
 */
public class Strippable {
    /**
     * Replacement block
     */
    public class_2960 replacement;
}
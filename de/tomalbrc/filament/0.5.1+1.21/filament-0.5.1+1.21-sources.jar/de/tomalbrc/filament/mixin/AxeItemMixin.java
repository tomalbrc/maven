package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.registry.filament.StrippableRegistry;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.core.api.item.PolymerItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Optional;
import net.minecraft.class_1743;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

@Mixin(class_1743.class)
public class AxeItemMixin {
    @Inject(method = "getStripped", locals = LocalCapture.CAPTURE_FAILSOFT, at = @At("RETURN"), cancellable = true)
    private void filament$onGetStripped(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (StrippableRegistry.has(blockState)) {
            var ns = StrippableRegistry.getStrippable(blockState);
            for (class_2769 property : blockState.method_28501()) {
                if (ns.method_28498(property)) {
                    ns.method_11657(property, blockState.method_11654(property));
                }
            }
            cir.setReturnValue(Optional.of(ns));
        }
    }
}

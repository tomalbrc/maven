package de.tomalbrc.filament.item;

import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.registry.filament.FuelRegistry;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerArmorModel;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5151;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SimpleItem extends class_1792 implements PolymerItem, class_5151 {
    final protected ItemData itemData;
    final protected Object2ObjectOpenHashMap<String, PolymerModelData> modelData;

    @Nullable
    PolymerArmorModel armorModel = null;

    public SimpleItem(class_1793 properties, ItemData itemData) {
        super(properties);
        this.itemData = itemData;
        this.modelData = this.itemData.requestModels();

        // For armor
        if (this.itemData.isArmor() && this.itemData.behaviour().armor.texture != null) {
            this.armorModel = PolymerResourcePackUtils.requestArmor(this.itemData.behaviour().armor.texture);
        }

        if (this.itemData.isCosmetic() || this.itemData.isArmor()) {
            class_2315.method_10009(this, class_1738.field_7879);
        }

        if (this.itemData.isFuel()) {
            FuelRegistry.add(this, this.itemData.behaviour().fuel.value);
        }
    }

    @Override
    public boolean method_7873(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        return this.itemData.components().method_57832(class_9334.field_50077);
    }

    @Override
    public void method_59978(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        if (this.itemData.components().method_57832(class_9334.field_50077))
            itemStack.method_7970(1, livingEntity2, class_1304.field_6173);
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        if (itemData.properties() != null)
            itemData.properties().appendHoverText(list);
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, @Nullable class_3222 player) {
        return itemData.vanillaItem() != null ? itemData.vanillaItem() : class_1802.field_8407;
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        return modelData != null ? this.modelData.get("default").value() : -1;
    }

    @Override
    public int getPolymerArmorColor(class_1799 itemStack, @Nullable class_3222 player) {
        return armorModel != null ? this.armorModel.color() : -1;
    }

    @Override
    @NotNull
    public class_1304 method_7685() {
        boolean armor = itemData.isArmor() && itemData.behaviour().armor.slot != null;
        boolean cosmetic = itemData.isCosmetic() && itemData.behaviour().cosmetic.slot != null;
        if (armor || cosmetic) {
            return armor ? itemData.behaviour().armor.slot : itemData.behaviour().cosmetic.slot;
        }
        return class_1304.field_6173;
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);

        if (this.itemData.canExecute() && this.itemData.behaviour().execute.command != null) {
            user.method_5682().method_3734().method_44252(user.method_5671(), this.itemData.behaviour().execute.command);

            user.method_7259(class_3468.field_15372.method_14956(this));

            if (this.itemData.behaviour().execute.sound != null) {
                var sound = this.itemData.behaviour().execute.sound;
                level.method_43129(null, user, class_7923.field_41172.method_10223(sound), class_3419.field_15248, 1.0F, 1.0F);
            }

            if (this.itemData.behaviour().execute.consumes) {
                user.method_5998(hand).method_7934(1);
                res = class_1271.method_22428(user.method_5998(hand));
            }
            else
                res = class_1271.method_22428(user.method_5998(hand));
        }

        if (this.itemData.isArmor() || this.itemData.isCosmetic()) {
            res = this.method_48576(this, level, user, hand);
        }

        return res;
    }

    public ItemData getItemData() {
        return this.itemData;
    }
}

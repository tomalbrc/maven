package de.tomalbrc.filament.registry;

import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.file.loader.AjBlueprintLoader;
import de.tomalbrc.bil.file.loader.AjModelLoader;
import de.tomalbrc.bil.file.loader.BbModelLoader;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.resource.FilamentSynchronousResourceReloadListener;
import it.unimi.dsi.fastutil.objects.Object2ReferenceArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceMap;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.apache.commons.io.FilenameUtils;
import org.jspecify.annotations.NonNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class ModelRegistry {
    private static final String BBMODEL_SUFFIX = ".bbmodel";
    private static final String AJMODEL_SUFFIX = ".ajmodel";
    private static final String AJBP_SUFFIX = ".ajblueprint";

    private static final Object2ReferenceMap<Identifier, Model> ajmodels = new Object2ReferenceArrayMap<>();

    public static Model getModel(Identifier model) {
        return ajmodels.get(model);
    }

    public static class AjModelReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public @NonNull Identifier getFabricId() {
            return Identifier.fromNamespaceAndPath(Constants.MOD_ID, "model");
        }

        @Override
        public void onResourceManagerReload(ResourceManager resourceManager) {
            var resources = resourceManager.listResources("filament/model", path -> path.getPath().endsWith(".ajmodel") || path.getPath().endsWith(".ajblueprint") || path.getPath().endsWith(".bbmodel"));

            for (Map.Entry<Identifier, Resource> entry : resources.entrySet()) {
                try (var inputStream = entry.getValue().open()) {
                    String path = entry.getKey().getPath();
                    Model model = null;
                    if (path.endsWith(AJMODEL_SUFFIX)) {
                        model = new AjModelLoader().load(inputStream, FilenameUtils.getBaseName(path));
                    } else if (path.endsWith(AJBP_SUFFIX)) {
                        model = new AjBlueprintLoader().load(inputStream, FilenameUtils.getBaseName(path));
                    } else if (path.endsWith(BBMODEL_SUFFIX)) {
                        model = new BbModelLoader().load(inputStream, FilenameUtils.getBaseName(path));
                    } else {
                        Filament.LOGGER.warn("Non-bbmodel-model file found at {}, ignoring", path);
                    }

                    if (model != null)
                        ajmodels.put(sanitize(entry.getKey()), model);

                } catch (Exception e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"{}\".", entry.getKey());
                }
            }

            Filament.LOGGER.info("filament models registered: {}", ajmodels.size());
        }
    }

    public static Identifier sanitize(Identifier identifier) {
        String path = identifier.getPath();
        String customPath = path.substring(path.contains("/") ? path.lastIndexOf('/')+1 : 0, path.lastIndexOf('.'));
        return Identifier.fromNamespaceAndPath(identifier.getNamespace(), customPath);
    }

    public static void registerAjModel(InputStream inputStream, Identifier Identifier) throws IOException {
        ajmodels.put(sanitize(Identifier), new AjModelLoader().load(inputStream, Identifier.getPath()));
    }

    public static void registerBbModel(InputStream inputStream, Identifier Identifier) throws IOException {
        ajmodels.put(sanitize(Identifier), new BbModelLoader().load(inputStream, Identifier.getPath()));
    }

    public static void registerAjBlueprintModel(InputStream inputStream, Identifier Identifier) throws IOException {
        ajmodels.put(sanitize(Identifier), new AjBlueprintLoader().load(inputStream, Identifier.getPath()));
    }
}

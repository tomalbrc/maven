package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.util.annotation.RegistryRef;
import net.minecraft.advancements.triggers.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.BlockTransformer;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.HoneycombItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BlockTransformers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.WeatheringCopper;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class Stripper implements ItemBehaviour<Stripper.Config> {
    private final Config config;

    public Stripper(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Stripper.Config getConfig() {
        return config;
    }

    @Override
    public InteractionResult useOn(UseOnContext useOnContext) {
        Level level = useOnContext.getLevel();
        BlockPos blockPos = useOnContext.getClickedPos();
        Player player = useOnContext.getPlayer();

        BlockState optional = this.getNewBlockState(useOnContext);
        if (optional == null) {
            return InteractionResult.PASS;
        } else {
            ItemStack itemStack = useOnContext.getItemInHand();
            if (player instanceof ServerPlayer) {
                CriteriaTriggers.ITEM_USED_ON_BLOCK.trigger((ServerPlayer)player, blockPos, itemStack);
            }

            level.setBlock(blockPos, optional, Block.UPDATE_IMMEDIATE | Block.UPDATE_CLIENTS | Block.UPDATE_NEIGHBORS);
            level.gameEvent(GameEvent.BLOCK_CHANGE, blockPos, GameEvent.Context.of(player, optional));
            if (player != null) {
                itemStack.hurtAndBreak(1, player, useOnContext.getHand());
            }

            return InteractionResult.SUCCESS;
        }
    }

    private BlockState getNewBlockState(UseOnContext useOnContext) {
        var t = Filament.REGISTRY_ACCESS.compositeAccess().get(BlockTransformers.AXE).orElseThrow().value().transforms();
        BlockState replacement = null;
        var blockPos = useOnContext.getClickedPos();
        var level = useOnContext.getLevel();
        var blockState = level.getBlockState(blockPos);
        for (BlockTransformer.BlockTransformData transformData : t) {
            var tr = transformData.blockStateProvider().value().getOptionalState(level, level.getRandom(),  blockPos);
            if (tr != null && !transformData.disallowedFaces().contains(useOnContext.getClickedFace())) {
                replacement = tr.withPropertiesOf(blockState);
                break;
            }
        }

        if (replacement != null) {
            level.playSound(null, blockPos, SoundEvent.createVariableRangeEvent(config.sound), SoundSource.BLOCKS, 1.0F, 1.0F);
            return replacement;
        } else {
            Optional<BlockState> opt = WeatheringCopper.getPrevious(blockState);
            if (opt.isPresent()) {
                level.playSound(null, blockPos, SoundEvents.AXE_SCRAPE.value(), SoundSource.BLOCKS, 1.0F, 1.0F);
                level.levelEvent(null, LevelEvent.PARTICLES_SCRAPE, blockPos, 0);
                return opt.get();
            } else {
                opt = Optional.ofNullable(HoneycombItem.WAX_OFF_BY_BLOCK.get().get(blockState.getBlock())).map((block) -> block.withPropertiesOf(blockState));
                if (opt.isPresent()) {
                    level.playSound(null, blockPos, SoundEvents.AXE_WAX_OFF.value(), SoundSource.BLOCKS, 1.0F, 1.0F);
                    level.levelEvent(null, LevelEvent.PARTICLES_WAX_OFF, blockPos, 0);
                    return opt.get();
                } else {
                    return null;
                }
            }
        }
    }

    public static class Config {
        @RegistryRef("sound_event")
        public Identifier sound = SoundEvents.AXE_STRIP.key().identifier();
    }
}

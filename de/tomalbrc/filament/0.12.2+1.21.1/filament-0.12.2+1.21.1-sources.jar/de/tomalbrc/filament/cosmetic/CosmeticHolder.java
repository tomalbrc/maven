package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.util.FilamentConfig;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.joml.Vector3f;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2716;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_8042;
import net.minecraft.class_811;

public class CosmeticHolder extends ElementHolder {
    private final class_1309 entity;
    private final ItemDisplayElement displayElement;

    private double prevX = 0;
    private double prevZ = 0;

    private float bodyYaw;

    private final Consumer<class_3244> startWatchingCallback;

    boolean hidden = false;

    public CosmeticHolder(class_1309 entity, class_1799 itemStack, Consumer<class_3244> startWatchingCallback) {
        super();

        this.startWatchingCallback = startWatchingCallback;

        this.entity = entity;

        this.displayElement = new ItemDisplayElement(itemStack);

        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(itemStack);
        if (cosmeticData != null) {
            this.displayElement.setTranslation(cosmeticData.translation);
            this.displayElement.setScale(cosmeticData.scale);
            if (FilamentConfig.getInstance().alternativeCosmeticPlacement) {
                this.displayElement.setModelTransformation(class_811.field_4316);
                this.displayElement.setTranslation(new Vector3f(0, 1.25f,0));
                this.displayElement.setScale(new Vector3f(0.625f));
            }
        }

        this.displayElement.setTeleportDuration(1);

        this.addElement(this.displayElement);
    }

    @Override
    public void onTick() {
        super.onTick();

        this.tickMovement(this.entity);

        if (this.entity.method_18376() == class_4050.field_18079) {
            if (!hidden) {
                hideForAll(this);
                hidden = true;
            }
        } else {
            if (hidden) {
                showForAll(this);
                for (class_3244 player : this.getWatchingPlayers()) {
                    startWatchingCallback.accept(player);
                }
                hidden = false;
            }

            this.displayElement.setYaw(this.bodyYaw);
            this.displayElement.setPitch(this.entity.method_5715() ? 25 : 0);

            if (FilamentConfig.getInstance().alternativeCosmeticPlacement) {
                this.displayElement.setTranslation(new Vector3f(0, this.entity.method_5715() ? 1.325f : 1.25f, this.entity.method_5715() ? 0.15f : 0));
            }
            else {
                Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(this.displayElement.getItem());
                this.displayElement.setTranslation(cosmeticData.translation.add(new Vector3f(0, 0, this.entity.method_5715() ? 0.15f : 0)));
            }
        }

        this.prevX = this.entity.method_23317();
        this.prevZ = this.entity.method_23321();
    }

    private void tickMovement(final class_1309 player) {
        float yaw = this.entity.method_36454();
        double i = player.method_23317() - this.prevX;
        double d = player.method_23321() - this.prevZ;
        float f = (float)(i * i + d * d);
        float g = this.bodyYaw;
        if (f > 0.0025f) {
            // Using internal Mojang math utils here
            float l = (float) class_3532.method_15349(d, i) * class_3532.field_29848 - 90.0F;
            float m = class_3532.method_15379(class_3532.method_15393(yaw) - l);
            if (95.f < m && m < 265.f) {
                g = l - 180.f;
            } else {
                g = l;
            }
        }

        this.turnBody(g, yaw);
    }

    public void turnBody(float bodyRotation, float yaw) {
        float f = class_3532.method_15393(bodyRotation - this.bodyYaw);
        this.bodyYaw += f * 0.3F;
        float g = class_3532.method_15393(yaw - this.bodyYaw);
        if (g < -75.0F) {
            g = -75.0F;
        }

        if (g >= 75.0F) {
            g = 75.0F;
        }

        this.bodyYaw = yaw - g;
        if (g * g > 2500.0F) {
            this.bodyYaw += g * 0.2F;
        }
    }

    @Override
    protected void notifyElementsOfPositionUpdate(class_243 newPos, class_243 delta) {
    }
    @Override
    protected void updateInitialPosition() {
        if (this.entity instanceof class_3222 serverPlayer) this.startWatching(serverPlayer);
    }

    @Override
    public boolean startWatching(class_3244 player) {
        var ret = super.startWatching(player);
        this.startWatchingCallback.accept(player);
        return ret;
    }

    public static void hideForAll(ElementHolder elementHolder) {
        for (class_3244 player : elementHolder.getWatchingPlayers()) {
            player.method_14364(new class_2716(elementHolder.getEntityIds()));
        }
    }

    public static void showForAll(ElementHolder elementHolder) {
        for (class_3244 player : elementHolder.getWatchingPlayers()) {
            var packets = new ObjectArrayList<class_2596<? super class_2602>>();
            for (VirtualElement e : elementHolder.getElements()) {
                Objects.requireNonNull(packets);
                e.startWatching(player.field_14140, packets::add);
            }
            player.method_14364(new class_8042(packets));
        }
    }
}

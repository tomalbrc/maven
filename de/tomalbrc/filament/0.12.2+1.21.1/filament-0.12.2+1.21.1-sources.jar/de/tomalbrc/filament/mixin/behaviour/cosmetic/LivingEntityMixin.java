package de.tomalbrc.filament.mixin.behaviour.cosmetic;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.cosmetic.AnimatedCosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.cosmetic.CosmeticUtil;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.registry.ModelRegistry;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import it.unimi.dsi.fastutil.ints.IntArraySet;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

@Mixin(value = class_1309.class)
public abstract class LivingEntityMixin implements CosmeticInterface {
    @Shadow public abstract class_1304 getEquipmentSlotForItem(class_1799 itemStack);

    @Shadow public abstract class_1799 getItemBySlot(class_1304 equipmentSlot);

    @Unique
    private final IntArraySet displays = new IntArraySet();

    @Unique
    private final Map<String, ElementHolder> filamentCosmeticHolder = new Object2ObjectOpenHashMap<>();

    // COSMETIC, ARMOR, ELYTRA
    @Inject(method = "getEquipmentSlotForItem", at = @At(value = "HEAD"), cancellable = true)
    private void filament$customGetEquipmentSlotForItem(class_1799 itemStack, CallbackInfoReturnable<class_1304> cir) {
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.method_7685() != class_1304.field_6173)  {
            cir.setReturnValue(simpleItem.method_7685());
        }
    }

    // ARMOR
    @Inject(method = "onEquipItem", at = @At(value = "HEAD"))
    private void filament$customOnEquipItem(class_1304 equipmentSlot, class_1799 oldItemStack, class_1799 newItemStack, CallbackInfo ci) {
        if (equipmentSlot == class_1304.field_6169) {
            return;
        }

        if (oldItemStack.method_7909() instanceof SimpleItem simpleItem && CosmeticUtil.isCosmetic(oldItemStack)) {
            var slot = simpleItem.get(Behaviours.COSMETIC).getConfig().slot;
            if (slot == equipmentSlot) filament$destroyHolder(slot.method_5923());
        }

        // hotswap case
        {
            if (oldItemStack.method_7960() && !CosmeticUtil.isCosmetic(this.getItemBySlot(this.getEquipmentSlotForItem(newItemStack)))) {
                var slot = this.getEquipmentSlotForItem(newItemStack);
                filament$destroyHolder(slot.method_5923());
            }
        }

        if (newItemStack.method_7909() instanceof SimpleItem simpleItem && CosmeticUtil.isCosmetic(newItemStack)) {
            var slot = simpleItem.get(Behaviours.COSMETIC).getConfig().slot;
            if (slot == equipmentSlot || (oldItemStack.method_7960() && equipmentSlot != class_1304.field_6173)) {
                filament$destroyHolder(slot.method_5923());
                filament$addHolder(class_1309.class.cast(this), newItemStack.method_7909(), newItemStack, slot.method_5923());
            }
        }
    }

    // ARMOR
    @Inject(method = "doHurtEquipment", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/entity/LivingEntity;getItemBySlot(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;", shift = At.Shift.AFTER), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void filament$customOnDoHurtEquipment(class_1282 damageSource, float f, class_1304[] equipmentSlots, CallbackInfo ci, @Local class_1799 itemStack, @Local class_1304 equipmentSlot) {
        if (!(itemStack.method_7909() instanceof class_1738) && itemStack.method_7909() instanceof SimpleItem && itemStack.method_58407(damageSource)) {
            int i = (int)Math.max(1.0F, f / 4.0F);
            itemStack.method_7970(i, (class_1309)(Object)this, equipmentSlot);
        }
    }

    // COSMETIC
    @Inject(method = "remove", at = @At(value = "HEAD"))
    private void filament$onRemove(class_1297.class_5529 removalReason, CallbackInfo ci) {
        var self = class_1309.class.cast(this);
        for (class_1799 itemStack : self.method_5661()) {
            if (CosmeticUtil.isCosmetic(itemStack))
                filament$destroyHolder(self.method_32326(itemStack).method_5923());
        }
    }

    @Unique
    @Override
    public void filament$addHolder(class_1309 livingEntity, class_1792 simpleItem, class_1799 itemStack, String slot) {
        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(simpleItem);

        ElementHolder holder = null;
        Consumer<class_3244> cb = (player) -> {
            player.method_14364(VirtualEntityUtils.createRidePacket(livingEntity.method_5628(), this.displays.toIntArray()));
        };

        if (cosmeticData.model != null && !filamentCosmeticHolder.containsKey(slot)) {
            holder = new AnimatedCosmeticHolder(livingEntity, ModelRegistry.getModel(cosmeticData.model), cb);
        }
        else if (!filamentCosmeticHolder.containsKey(slot)) {
            holder = new CosmeticHolder(livingEntity, itemStack, cb);
        }

        EntityAttachment.ofTicking(holder, livingEntity);

        for (VirtualElement element : holder.getElements()) {
            displays.addAll(element.getEntityIds());
        }

        if (livingEntity instanceof class_3222 serverPlayer)
            holder.startWatching(serverPlayer);

        if (cosmeticData.autoplay != null && holder instanceof AnimatedCosmeticHolder animatedHolder) {
            animatedHolder.getAnimator().playAnimation(cosmeticData.autoplay);
        }

        filamentCosmeticHolder.put(slot, holder);
    }

    @Unique
    @Override
    public void filament$destroyHolder(String slot) {
        if (filamentCosmeticHolder.containsKey(slot)) {
            var holder = filamentCosmeticHolder.get(slot);

            for (VirtualElement element : holder.getElements()) {
                displays.removeAll(element.getEntityIds());
            }

            filamentCosmeticHolder.get(slot).getAttachment().destroy();
            filamentCosmeticHolder.get(slot).destroy();
            filamentCosmeticHolder.remove(slot);
        }
    }
}

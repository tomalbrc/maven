package de.tomalbrc.filament.behaviour.item;

import com.google.common.collect.ImmutableList;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1671;
import net.minecraft.class_1676;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_7923;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Bow behaviour
 */
public class Bow implements ItemBehaviour<Bow.Config>, ItemPredicateModelProvider {
    private final Config config;

    public Bow(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Bow.Config getConfig() {
        return this.config;
    }

    protected void shoot(class_3218 serverLevel, class_1309 livingEntity, class_1268 interactionHand, class_1799 itemStack, List<class_1799> list, float f, boolean fullPower) {
        float spread = class_1890.method_60118(serverLevel, itemStack, livingEntity, 0.0f);
        float i = list.size() == 1 ? 0.0f : 2.0f * spread / (float)(list.size() - 1);
        float j = (float)((list.size() - 1) % 2) * i / 2.0f;
        float k = 1.0f;
        for (int l = 0; l < list.size(); ++l) {
            class_1799 itemStack2 = list.get(l);
            if (itemStack2.method_7960()) continue;
            float m = j + k * (float)((l + 1) / 2) * i;
            k = -k;
            class_1676 projectile = this.createProjectile(serverLevel, livingEntity, itemStack, itemStack2, fullPower);
            this.shootProjectile(livingEntity, projectile, f, (float) 1.0, m);
            serverLevel.method_8649(projectile);
            itemStack.method_7970(this.getDurabilityUse(itemStack2), livingEntity, class_1309.method_56079(interactionHand));
            if (itemStack.method_7960()) break;
        }
    }

    protected int getDurabilityUse(class_1799 itemStack) {
        return itemStack.method_31574(class_1802.field_8639) ? 3 : 1;
    }

    protected class_1676 createProjectile(class_1937 level, class_1309 livingEntity, class_1799 itemStack, class_1799 itemStack2, boolean bl) {
        if (itemStack2.method_31574(class_1802.field_8639)) {
            return new class_1671(level, itemStack2, livingEntity, livingEntity.method_23317(), livingEntity.method_23320() - 0.15000000596046448, livingEntity.method_23321(), true);
        } else {
            return createArrow(level, livingEntity, itemStack, itemStack2, bl);
        }
    }

    protected class_1676 createArrow(class_1937 level, class_1309 livingEntity, class_1799 itemStack, class_1799 itemStack2, boolean crit) {
        class_1792 item = itemStack2.method_7909();
        class_1744 arrowItem = item instanceof class_1744 ? (class_1744)item : (class_1744) class_1802.field_8107;
        class_1665 abstractArrow = arrowItem.method_7702(level, itemStack2, livingEntity, itemStack);
        if (crit) {
            abstractArrow.method_7439(true);
        }
        return abstractArrow;
    }

    @Override
    public void releaseUsing(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        if (!(livingEntity instanceof class_1657 player)) {
            return;
        }
        class_1799 itemStack2 = player.method_18808(itemStack);
        if (itemStack2.method_7960()) {
            return;
        }
        int j = this.getUseDuration(itemStack, livingEntity).orElseThrow() - useDuration;
        float currentPower = class_1753.method_7722(j);
        if (currentPower < 0.1) {
            return;
        }

        List<class_1799> list = class_1753.method_57390(itemStack, itemStack2, player);
        if (level instanceof class_3218 serverLevel && !list.isEmpty()) {
            this.shoot(serverLevel, player, player.method_6058(), itemStack, list, currentPower * config.powerMultiplier, currentPower == 1.0f);
        }

        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), config.shootSound, class_3419.field_15248, 1.0f, 1.0f / (level.method_8409().method_43057() * 0.4f + 1.2f) + currentPower * 0.5f);
        player.method_7259(class_3468.field_15372.method_14956(itemStack.method_7909()));
    }

    public void shootProjectile(class_1309 livingEntity, class_1676 projectile, float f, float g, float h) {
        projectile.method_24919(livingEntity, livingEntity.method_36455(), livingEntity.method_36454() + h, 0.0f, f, g);
    }

    @Override
    public Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.of(72000);
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        boolean hasProjectile = !player.method_18808(itemStack).method_7960();
        if (player.method_56992() || hasProjectile) {
            player.method_6019(interactionHand);
            return class_1271.method_22428(itemStack);
        }
        return class_1271.method_22431(itemStack);
    }

    public Predicate<class_1799> supportedProjectiles() {
        return itemStack -> {
            for (var itemId : config.supportedProjectiles) {
                if (itemStack.method_31574(class_7923.field_41178.method_10223(itemId)))
                    return true;
            }
            return false;
        };
    }

    public Predicate<class_1799> supportedHeldProjectiles() {
        return itemStack -> {
            for (var itemId : config.supportedHeldProjectiles) {
                if (itemStack.method_31574(class_7923.field_41178.method_10223(itemId)))
                    return true;
            }
            return false;
        };
    }

    @Override
    public void generate(class_2960 id, ItemResource itemResource) {
        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(resourcePackBuilder ->
            ItemAssetGenerator.createBow(
                resourcePackBuilder, id,
                itemResource
            )
        );
    }

    public static class Config {
        /**
         * Power multiplier for the projectile
         */
        public float powerMultiplier = 3.f;

        public List<class_2960> supportedProjectiles = ImmutableList.of(class_2960.method_60656("arrow"), class_2960.method_60656("spectral_arrow"));
        public List<class_2960> supportedHeldProjectiles = ImmutableList.of(class_2960.method_60656("arrow"), class_2960.method_60656("spectral_arrow"), class_2960.method_60656("firework_rocket"));

        public class_3414 shootSound = class_3417.field_14600;
    }
}
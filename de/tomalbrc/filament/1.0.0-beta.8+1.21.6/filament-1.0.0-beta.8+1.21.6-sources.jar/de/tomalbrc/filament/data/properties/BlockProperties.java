package de.tomalbrc.filament.data.properties;

import com.google.gson.annotations.SerializedName;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

@SuppressWarnings({"FieldCanBeLocal", "FieldMayBeFinal"})
public class BlockProperties extends ItemProperties {
    @NotNull
    public class_2248 blockBase = class_2246.field_10340;
    public boolean requiresTool = true;
    public float explosionResistance = Float.MIN_VALUE;
    public float destroyTime = Float.MIN_VALUE;

    public BlockStateMappedProperty<Boolean> isSuffocating = null;
    public BlockStateMappedProperty<Boolean> redstoneConductor = null;
    public BlockStateMappedProperty<Integer> lightEmission = null;

    public boolean transparent = false;
    public boolean allowsSpawning = false;
    public boolean replaceable = false;
    public boolean collision = true;

    public boolean solid = true;

    public class_3619 pushReaction = class_3619.field_15974;

    public class_2960 lootTable = null;

    public boolean virtual;

    public Sounds sounds;

    public class_4970.class_2251 toBlockProperties() {
        class_4970.class_2251 props = class_4970.class_2251.method_9637();
        props.method_9626(this.blockBase.method_9564().method_26231());
        if (this.sounds != null) {
            props.method_9626(this.sounds.asSoundType());
        }

        if (this.destroyTime != Float.MIN_VALUE) props.method_36557(this.destroyTime);
        if (this.explosionResistance != Float.MIN_VALUE) props.method_36558(this.explosionResistance);
        else if (this.destroyTime != Float.MIN_VALUE) props.method_36558(this.destroyTime);
        if (this.mayBeLightSource()) props.method_9631((state) -> this.lightEmission.getOrDefault(state, 0));
        if (this.mayBeRedstoneConductor())
            props.method_26236((blockState, blockGetter, blockPos) -> this.redstoneConductor.getOrDefault(blockState, false));
        if (this.requiresTool) props.method_29292();
        if (this.replaceable) props.method_51371();
        if (this.transparent) props.method_22488();
        if (!this.collision) props.method_9634();

        if (this.lootTable != null)
            props.method_63502(Optional.of(class_5321.method_29179(class_7924.field_50079, this.lootTable)));

        if (this.isSuffocating != null)
            props.method_26243((blockState, blockGetter, blockPos) -> this.isSuffocating.getValue(blockState));

        props.method_31710(this.blockBase.method_26403());

        if (this.solid) props.method_51369();
        else props.method_51370();

        props.method_26235((blockState, blockGetter, blockPos, entityType) -> this.allowsSpawning);
        props.method_50012(this.pushReaction);

        return props;
    }

    public boolean mayBeRedstoneConductor() {
        return this.redstoneConductor != null && (this.redstoneConductor.isMap() || (this.redstoneConductor.getRawValue() != null && this.redstoneConductor.getRawValue()));
    }

    public boolean mayBeLightSource() {
        return this.lightEmission != null && (this.lightEmission.isMap() || (this.lightEmission.getRawValue() != null && this.lightEmission.getRawValue() > 0));
    }

    public record Sounds(
            float volume,
            float pitch,
            @SerializedName("break") class_2960 breakSound,
            @SerializedName("step") class_2960 stepSound,
            @SerializedName("place") class_2960 placeSound,
            @SerializedName("hit") class_2960 hitSound,
            @SerializedName("fall") class_2960 fallSound
    ) {
        class_2498 asSoundType() {
            return new class_2498(
                    volume,
                    pitch,
                    class_3414.method_47908(breakSound),
                    class_3414.method_47908(stepSound),
                    class_3414.method_47908(placeSound),
                    class_3414.method_47908(hitSound),
                    class_3414.method_47908(fallSound)
            );
        }
    }
}

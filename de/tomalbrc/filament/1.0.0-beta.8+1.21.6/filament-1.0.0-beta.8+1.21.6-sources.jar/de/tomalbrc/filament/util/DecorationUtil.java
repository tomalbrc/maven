package de.tomalbrc.filament.util;

import com.google.common.collect.ImmutableList;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.decoration.holder.FilamentDecorationHolder;
import de.tomalbrc.filament.decoration.util.ItemFrameElement;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_265;
import net.minecraft.class_2675;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3341;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_7833;
import net.minecraft.class_8042;
import net.minecraft.class_8104;
import net.minecraft.class_811;
import net.minecraft.class_9280;
import net.minecraft.class_9334;
import net.minecraft.network.protocol.game.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.*;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class DecorationUtil {
    public static Int2ObjectOpenHashMap<Supplier<class_1799>> VIRTUAL_ENTITY_PICK_MAP = new Int2ObjectOpenHashMap<>();

    public static void forEachRotated(List<DecorationData.BlockConfig> blockConfigs, class_2338 originBlockPos, float rotation, Consumer<class_2338> consumer) {
        if (blockConfigs != null) {
            for (DecorationData.BlockConfig blockConfig : blockConfigs) {
                Vector3fc origin = blockConfig.origin();
                Vector3fc size = blockConfig.size();
                for (int x = 0; x < size.x(); x++) {
                    for (int y = 0; y < size.y(); y++) {
                        for (int z = 0; z < size.z(); z++) {
                            Vector3f pos = new Vector3f(x, y, z).add(origin);
                            var hMul = rotation % 90 != 0 ? Math.sqrt(2) : 1;
                            Vector3f offset = pos.mul(hMul, 1, hMul);
                            offset.rotateY(class_3532.field_29847 * (rotation + (FilamentConfig.getInstance().alternativeBlockPlacement ? 0 : 180)));

                            class_2338 blockPos = new class_2338(originBlockPos).method_10069(-Math.round(offset.x), Math.round(offset.y), Math.round(offset.z));
                            consumer.accept(blockPos);
                        }
                    }
                }
            }
        }
    }

    public static Vector2f barrierDimensions(List<DecorationData.BlockConfig> blockConfigs, float rotation) {
        if (!blockConfigs.isEmpty()) {
            List<class_2338> posList = new ObjectArrayList<>();
            DecorationUtil.forEachRotated(blockConfigs, class_2338.field_10980, rotation, posList::add);
            Optional<class_3341> boundingBox = class_3341.method_35411(posList);
            if (boundingBox.isPresent()) {
                return new Vector2f(java.lang.Math.max(boundingBox.get().method_35414(), boundingBox.get().method_14663()), boundingBox.get().method_14660());
            }
        }
        return new Vector2f();
    }

    public static InteractionElement decorationInteraction(DecorationData decorationData, class_2350 direction, @Nullable OnInteract onInteract) {
        InteractionElement element = new InteractionElement();
        if (decorationData != null && decorationData.size() != null) {
            element.setSize(decorationData.size().x, decorationData.size().y);
        } else {
            element.setSize(1.f, direction.equals(class_2350.field_11033) ? 1.f : .5f); // default
        }

        element.setHandler(new VirtualElement.InteractionHandler() {
            @Override
            public void interactAt(class_3222 player, class_1268 hand, class_243 pos) {
                class_3218 serverLevel = player.method_51469();
                class_2338 blockPos = class_2338.method_49638(element.getHolder().getAttachment().getPos());
                class_1269 result = class_1269.field_5811;
                if (onInteract != null && serverLevel.method_8505(player, blockPos)) {
                    result = onInteract.interact(player, hand, blockPos.method_61082().method_1019(pos));
                }

                if (!result.method_23665()) DecorationUtil.defaultVirtualInteraction(player, hand, blockPos, pos, element.getHeight());
            }

            @Override
            public void attack(class_3222 player) {
                class_3218 serverLevel = player.method_51469();
                class_2338 blockPos = class_2338.method_49638(element.getHolder().getAttachment().getPos());
                player.field_13974.method_14263(blockPos, class_2846.class_2847.field_12968, class_2350.field_11036, serverLevel.method_31600(), 0);
            }
        });

        var dirUnitVec = direction.method_62675();
        if (direction != class_2350.field_11033 && direction != class_2350.field_11036) {
            element.setOffset(new class_243(dirUnitVec.method_10263(), dirUnitVec.method_10264() + element.getHeight(), dirUnitVec.method_10260()).method_18805(1.f-element.getWidth(), 1, 1.f-element.getWidth()).method_1021(-0.5f));
        } else {
            element.setOffset(new class_243(dirUnitVec.method_10263(), dirUnitVec.method_10264(), dirUnitVec.method_10260()).method_1031(0,  direction == class_2350.field_11036 ? -1.5f : 0.5f + ((1.f-element.getHeight())), 0));
        }

        return element;
    }

    public static ItemDisplayElement decorationItemDisplay(@NotNull DecorationData data, class_2350 direction, float rotation, class_1799 itemStack) {
        ItemDisplayElement element = new ItemDisplayElement(itemStack);
        element.setInvisible(true);
        element.setTeleportDuration(0);

        if (data.properties().glow) {
            element.setBrightness(class_8104.field_42264);
        }

        Vector2f size = new Vector2f(1);
        if (data.hasBlocks()) {
            size = DecorationUtil.barrierDimensions(data.blocks(), rotation);
        } else if (data.size() != null) {
            size = data.size();
        }

        Matrix4f matrix4f = transform(data.properties().display, direction);

        element.setYaw(rotation - (180));

        element.setDisplayWidth(size.x * 3.f);
        element.setDisplayHeight(size.y * 3.f);

        element.setTransformation(matrix4f);
        element.setItemDisplayContext(data.properties().display);

        return element;
    }

    private static Matrix4f transform(class_811 context, class_2350 direction) {
        Matrix4f matrix4f = new Matrix4f();

        return switch (context) {
            case field_4319 -> {
                matrix4f.scale(0.5f);

                if (direction == class_2350.field_11033 || direction == class_2350.field_11036) {
                    matrix4f.setTranslation(0, direction == class_2350.field_11033 ? 0.5f : -0.5f, 0);

                    matrix4f.rotate(class_7833.field_40714.rotationDegrees(-90));
                    if (direction == class_2350.field_11033) {
                        matrix4f.rotate(class_7833.field_40714.rotationDegrees(180));
                    }
                } else {
                    matrix4f.setTranslation(new Vector3f(0.f, 0.f, -0.5f));
                }

                yield matrix4f;
            }
            case field_4316 -> {
                matrix4f.translate(0, 1.91f, 0);
                matrix4f.scaleLocal(0.64f);
                yield matrix4f;
            }
            default -> matrix4f;
        };
    }

    public static void showBreakParticle(class_3218 level, class_1799 stack, float x, float y, float z) {
        showBreakParticle(level, class_259.method_1077(), stack, class_2338.method_49637(x, y, z));
    }

    public static void showBreakParticleShaped(class_3218 level, class_2338 blockPos, class_2680 blockState, class_1799 stack) {
        if (blockState.method_26215() || !blockState.method_45475()) {
            return;
        }
        class_265 voxelShape = blockState.method_26218(level, blockPos);
        showBreakParticle(level, voxelShape, stack, blockPos);
    }

    public static void showBreakParticle(class_3218 level, class_265 voxelShape, class_1799 stack, class_2338 blockPos) {
        double div = 0.25;
        List<class_2596<? super class_2602>> packets = new ObjectArrayList<>();
        voxelShape.method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
            double dx = Math.min(1.0, maxX - minX);
            double dy = Math.min(1.0, maxY - minY);
            double dz = Math.min(1.0, maxZ - minZ);
            int nx = Math.max(2, class_3532.method_15384(dx / div));
            int ny = Math.max(2, class_3532.method_15384(dy / div));
            int nz = Math.max(2, class_3532.method_15384(dz / div));
            for (int iX = 0; iX < nx; ++iX) {
                for (int iY = 0; iY < ny; ++iY) {
                    for (int iZ = 0; iZ < nz; ++iZ) {
                        double deltaX = (iX + 0.5) / nx;
                        double deltaY = (iY + 0.5) / ny;
                        double deltaZ = (iZ + 0.5) / nz;
                        double xOffset = deltaX * dx + minX;
                        double yOffset = deltaY * dy + minY;
                        double zOffset = deltaZ * dz + minZ;
                        packets.add(new class_2675(new class_2392(class_2398.field_11218, stack), true, false, blockPos.method_10263() + xOffset, blockPos.method_10264() + yOffset, blockPos.method_10260() + zOffset, (float)deltaX - 0.5f, (float)deltaY - 0.5f, (float)deltaZ - 0.5f, 0.25f, 0));
                    }
                }
            }
        });

        if (!packets.isEmpty()) {
            class_8042 bundlePacket = new class_8042(packets);
            for (class_3222 player : level.method_18456()) {
                if (player.method_19538().method_1022(blockPos.method_46558()) < 512) {
                    player.field_13987.method_14364(bundlePacket);
                }
            }
        }
    }

    public static class_1799 placementAdjustedItem(class_1799 itemStack, ItemResource itemResource, boolean wall, boolean ceiling) {
        var converted = clientsideItem(itemStack);

        // TODO: this should be a behaviour
        if (wall && itemResource.getModels().containsKey("wall")) {
            converted.method_57379(class_9334.field_49637, new class_9280(ImmutableList.of(), ImmutableList.of(), ImmutableList.of("wall"), ImmutableList.of()));
            return converted;
        }

        if (ceiling && itemResource.getModels().containsKey("ceiling")) {
            converted.method_57379(class_9334.field_49637, new class_9280(ImmutableList.of(), ImmutableList.of(), ImmutableList.of("ceiling"), ImmutableList.of()));
            return converted;
        }

        if (itemResource.getModels().containsKey("floor")) {
            converted.method_57379(class_9334.field_49637, new class_9280(ImmutableList.of(), ImmutableList.of(), ImmutableList.of("floor"), ImmutableList.of()));
            return converted;
        }

        converted.method_57381(class_9334.field_49631);
        return converted;
    }

    public static class_1799 clientsideItem(class_1799 itemStack) {
        if (itemStack == null)
            return class_1799.field_8037;

        if (!(itemStack.method_7909() instanceof PolymerItem)) {
            return itemStack.method_46651(1);
        } else {
            return ((PolymerItem)itemStack.method_7909()).getPolymerItemStack(itemStack, class_1836.field_41070, PacketContext.create(Filament.REGISTRY_ACCESS.method_45926()));
        }
    }

    public static void setupElements(@NotNull FilamentDecorationHolder holder, @NotNull DecorationData data, @NotNull class_2350 direction, float rotation, @NotNull class_1799 itemStack, @Nullable OnInteract onInteract) {
        boolean addDisplay = !holder.isAnimated();

        if (data.hasBlocks() && addDisplay) {
            holder.addElement(DecorationUtil.decorationItemDisplay(data, direction, rotation, itemStack));
        } else if (data.size() != null) {
            if (addDisplay)
                holder.addElement(DecorationUtil.decorationItemDisplay(data, direction, rotation, itemStack));
            holder.addElement(DecorationUtil.decorationInteraction(data, direction, onInteract));
        } else {
            if (data.itemFrame() == Boolean.TRUE && addDisplay) {
                ItemFrameElement itemFrameElement = new ItemFrameElement(data, direction, Util.SEGMENTED_ANGLE8.method_48125(rotation), itemStack, onInteract);
                holder.addElement(itemFrameElement);
            } else if (!data.hasBlocks()) {
                // Just using display+interaction again with 1.0 width, 0.5 height
                if (addDisplay) holder.addElement(DecorationUtil.decorationItemDisplay(data, direction, rotation, itemStack));
                holder.addElement(DecorationUtil.decorationInteraction(data, direction, onInteract));
            }
        }
    }

    public static void defaultVirtualInteraction(class_3222 player, class_1268 hand, class_2338 blockPos, class_243 position, float height) {
        player.field_13987.method_12046(new class_2885(hand, new class_3965(blockPos.method_46558().method_1019(position), class_2350.method_58251(position.method_18805(1, 1.f/height * 0.5, 1)), blockPos, false), 0));
    }

    @FunctionalInterface
    public interface OnInteract {
        class_1269 interact(class_3222 player, class_1268 hand, class_243 pos);
    }
}

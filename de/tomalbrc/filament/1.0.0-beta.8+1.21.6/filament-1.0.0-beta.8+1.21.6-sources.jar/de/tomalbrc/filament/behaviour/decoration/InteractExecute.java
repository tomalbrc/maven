package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.bil.util.command.CommandParser;
import de.tomalbrc.bil.util.command.ParsedCommand;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Interact-execute behaviour for decoration
 */
public class InteractExecute implements DecorationBehaviour<InteractExecute.Config> {
    public Config config;
    public ParsedCommand[] parsedCommands = null;
    public ParsedCommand[] parsedCommandsPost = null;

    public InteractExecute(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public InteractExecute.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        DecorationBehaviour.super.init(blockEntity);

        var commands = commands();
        if (commands != null) {
            List<ParsedCommand> commandList = new ArrayList<>();
            for (String command : commands) {
                commandList.addAll(Arrays.asList(CommandParser.parse(command)));
            }
            this.parsedCommands = commandList.toArray(new ParsedCommand[0]);
        }

        var commandsPost = commandsPost();
        if (commandsPost != null) {
            List<ParsedCommand> commandListPost = new ArrayList<>();
            for (String command : commandsPost) {
                commandListPost.addAll(Arrays.asList(CommandParser.parse(command)));
            }
            this.parsedCommandsPost = commandListPost.toArray(new ParsedCommand[0]);
        }
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        class_1792 key = this.config.key == null ? null : class_7923.field_41178.method_63535(this.config.key);
        class_1799 mainHandItem = player.method_5998(class_1268.field_5808);
        boolean hasHandItem = !mainHandItem.method_7960();
        boolean holdsKeyAndIsValid = hasHandItem && key != null && mainHandItem.method_31574(key);
        boolean noItemNoKey = !hasHandItem && (key == null);
        if (holdsKeyAndIsValid || noItemNoKey) {
            if (this.config.consumeKey && hasHandItem) {
                mainHandItem.method_7934(1);
            }

            if (this.config.animation != null && !config.animation.isEmpty() && decorationBlockEntity.getOrCreateHolder() != null) {
                decorationBlockEntity.getOrCreateHolder().playAnimation(config.animatePerPlayer ? player : null, config.animation, 0, commandsPost() == null ? null : (serverPlayer -> {
                    var css = player.method_64396().method_36321(player.method_5682()).method_9230(4);
                    if (getConfig().atBlock)
                        css = css.method_9208(decorationBlockEntity.method_11016().method_46558());

                    if (player.method_5682() != null && parsedCommandsPost != null) {
                        for (ParsedCommand cmd : parsedCommandsPost) {
                            cmd.execute(player.method_5682().method_3734().method_9235(), css);
                        }
                    }

                    if (config.animationPost != null && (!config.animatePerPlayer || player.method_51469() == decorationBlockEntity.method_10997())) {
                        decorationBlockEntity.getOrCreateHolder().playAnimation(config.animatePerPlayer ? player : null, config.animationPost);
                    }
                }));
            }

            boolean hasCommand = parsedCommands != null && parsedCommands.length > 0;
            boolean validLockCommand = this.config.command != null && !this.config.command.isEmpty();
            if ((hasCommand || validLockCommand) && player.method_5682() != null) {
                var css = player.method_64396().method_36321(player.method_5682()).method_9230(4);
                if (getConfig().atBlock)
                    css = css.method_9208(decorationBlockEntity.method_11016().method_46558());

                if (hasCommand) {
                    for (ParsedCommand cmd : parsedCommands) {
                        cmd.execute(player.method_5682().method_3734().method_9235(), css);
                    }
                }

                return class_1269.field_21466;
            }

            if (this.config.discard) {
                decorationBlockEntity.destroyStructure(false);
            }
        }

        return class_1269.field_5811;
    }

    private List<String> commands() {
        return config.commands == null ? config.command == null ? null : List.of(config.command) : config.commands;
    }

    private List<String> commandsPost() {
        return config.commandsPostAnimation == null ? config.commandPostAnimation == null ? null : List.of(config.commandPostAnimation) : config.commandsPostAnimation;
    }

    public static class Config {
        /**
         * The identifier of the key required to unlock.
         */
        public class_2960 key = null;

        /**
         * Determines whether the key should be consumed upon unlocking.
         */
        public boolean consumeKey = false;

        /**
         * Specifies whether the lock util should be discarded after unlocking.
         */
        public boolean discard = false;

        /**
         * Name of the animation to play upon successful unlocking (if applicable).
         */
        public String animation = null;

        /**
         * Name of animation to player after the first one ended
         */
        public String animationPost = null;

        /**
         * Whether to play animation only for player interacting with the decoration
         */
        public boolean animatePerPlayer = false;

        /**
         * Command to execute when the lock is successfully unlocked (if specified).
         * The command can be overwritten using NBT, the path for the command is Lock.Command in the block entities' NBT
         * `formats modify @e[entitySpecifier] Lock.Command set value "say hello"`
         */
        public String command = null;

        /**
         * List of commands. See above
         */
        public List<String> commands = null;

        /**
         * Whether to run commands after animation
         */
        public String commandPostAnimation = null;
        public List<String> commandsPostAnimation = null;

        public boolean atBlock = false;
    }
}
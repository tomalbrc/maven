package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_10774;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1540;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;

@SuppressWarnings({"unused", "UnusedReturnValue", "javadoc"})
public interface BlockBehaviour<T> extends Behaviour<T> {
    /**
     * Called after the block and item were registered
     * @param item Item of the block
     * @param block The block
     * @param behaviourHolder filament behaviour holder (usually the block)
     */
    default void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {

    }

    /**
     * Allows to modify the blockstate to block-model map used by filament/polymer for the client-side representation of a blockstate (might be filtered)
     * @param map current default blockstate to model map
     * @param blockData block data
     * @return true when the state-map was modified
     */
    default boolean modifyStateMap(Map<class_2680, BlockData.BlockStateMeta> map, BlockData blockData) {
        return false;
    }

    /**
     * Allows to modify the default blockstate of the block holding this behaviour
     * @param blockState the current default blockstate
     * @return the new default blockstate
     */
    default class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState;
    }

    /**
     * Allows to add block-state-properties to the block holding this behaviour
     * @param builder state-definition builder
     * @return flag whether something was added
     */
    default boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        return false;
    }

    /**
     *
     * @param blockState the blockstate
     * @return optional wether to use the blockstates shape for light occlusion
     */
    default Optional<Boolean> useShapeForLightOcclusion(class_2680 blockState) {
        return Optional.empty();
    }

    /**
     * Allows to modify the blockstate for a given placement, before being placed.
     * @param blockState default blockstate (or modified one by a different behaviour)
     * @param blockPlaceContext context
     * @return new blockstate for placement
     */
    default class_2680 getStateForPlacement(class_2680 blockState, class_1750 blockPlaceContext) {
        return blockState;
    }

    /**
     * Whether the block can be replaced like grass when placing another block in its place
     * @param blockState blockstate to replace
     * @param blockPlaceContext context
     * @return optional flag
     */
    default Optional<Boolean> canBeReplaced(class_2680 blockState, class_1750 blockPlaceContext) {
        return Optional.empty();
    }

    /**
     * Shape update
     * @param blockState
     * @param levelReader
     * @param scheduledTickAccess
     * @param blockPos
     * @param direction
     * @param blockPos2
     * @param blockState2
     * @param randomSource
     * @return
     */
    default class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        return blockState;
    }

    /**
     *
     * @param blockState
     * @param level
     * @param blockPos
     * @param block
     * @param orientation
     * @param bl
     */
    default void neighborChanged(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_9904 orientation, boolean bl) {
    }

    /**
     *
     * @param level
     * @param blockPos
     * @param blockState
     * @param player
     */
    default void playerWillDestroy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
    }

    /**
     *
     * @param blockState
     * @param pathComputationType
     * @return
     */
    default Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
        return Optional.empty();
    }

    /**
     *
     * @param blockState
     * @return
     */
    @Nullable
    default class_3610 getFluidState(class_2680 blockState) {
        return null;
    }

    /**
     *
     * @param blockState
     * @param level
     * @param blockPos
     * @param explosion
     * @param biConsumer
     */
    default void onExplosionHit(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
    }

    /**
     *
     * @param explosion
     * @return
     */
    default boolean dropFromExplosion(class_1927 explosion) {
        return true;
    }

    /**
     *
     * @param blockState
     * @param rotation
     * @return
     */
    default class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return null;
    }

    /**
     *
     * @param blockState
     * @param mirror
     * @return
     */
    default class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return null;
    }

    /**
     *
     * @param blockState
     * @return
     */
    default boolean isSignalSource(class_2680 blockState) {
        return false;
    }

    /**
     *
     * @param blockState
     * @param blockGetter
     * @param blockPos
     * @param direction
     * @return
     */
    default int getDirectSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return 0;
    }

    /**
     *
     * @param blockState
     * @param blockGetter
     * @param blockPos
     * @param direction
     * @return
     */
    default int getSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return 0;
    }

    /**
     *
     * @param blockState
     * @param level
     * @param blockPos
     * @param blockState2
     * @param bl
     */
    default void onPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
    }

    /**
     *
     * @param level
     * @param blockPos
     * @param blockState
     * @param livingEntity
     * @param itemStack
     */
    default void setPlacedBy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1309 livingEntity, class_1799 itemStack) {
    }

    /**
     * Called on removal to update neighbours
     * @param blockState
     * @param serverLevel
     * @param blockPos
     * @param bl
     */
    default void affectNeighborsAfterRemoval(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, boolean bl) {
    }

    /**
     *
     * @param blockState
     * @param serverLevel
     * @param blockPos
     * @param itemStack
     * @param bl
     */
    default void spawnAfterBreak(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean bl) {
    }

    /**
     *
     * @param blockState
     * @param levelReader
     * @param blockPos
     * @return
     */
    default boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return true;
    }

    /**
     *
     * @param blockState
     * @return
     */
    default boolean isRandomlyTicking(class_2680 blockState) {
        return false;
    }

    /**
     *
     * @param blockState
     * @param serverLevel
     * @param blockPos
     * @param randomSource
     */
    default void randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
    }

    /**
     * Tick
     * @param blockState state of ticking block
     * @param serverLevel level
     * @param blockPos position
     * @param randomSource random source
     */
    default void tick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
    }

    /**
     * In some cases your block behaviour may need block states that visually look the same on clients.
     * This method allows to change block state properties before being passed on to getCustomPolymerBlockState
     */
    default class_2680 filteredBlockState(class_2680 blockState) {
        return blockState;
    }

    /**
     * Allows to change the clone item-stack of the block
     *
     * @param itemStack The item of the block
     * @param levelReader The level(-reader)
     * @param blockPos Position of the block in world
     * @param blockState State of the picked block
     * @return The clone (pick) itemstack of the block
     */
    default class_1799 getCloneItemStack(class_1799 itemStack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return null;
    }

    /**
     * Called when interacted with, with empty hands
     *
     * @param blockState State of the block interacted with
     * @param level World of the player/block
     * @param blockPos position of the block in the world
     * @param player Player that interacted with the block
     * @param blockHitResult Block-hit information
     * @return The result of the interaction with this block
     */
    default class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        return class_1269.field_5811;
    }

    /**
     * Called when interacted with, with an item in hand.
     *
     * @param itemStack Item that was held by the player / used for the interaction
     * @param blockState State of the block that was interacted with
     * @param level level
     * @param blockPos block pos of interaction
     * @param player Player that interacted with the block
     * @param interactionHand interaction hand
     * @param blockHitResult Block-hit information
     * @return The result of the interaction with this block with the item
     */
    @Nullable
    default class_1269 useItemOn(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        return null;
    }

    /**
     * Caled when a projectile hits the block.
     *
     * @param level level
     * @param blockState state of the hit block
     * @param blockHitResult Block-hit information
     * @param projectile Projectile entity
     */
    default void onProjectileHit(class_1937 level, class_2680 blockState, class_3965 blockHitResult, class_1676 projectile) {
    }

    /**
     * Seed for blockstate at blockpos
     * @param blockState
     * @param blockPos
     * @return
     */
    default Optional<Long> getSeed(class_2680 blockState, class_2338 blockPos) {
        return Optional.empty();
    }

    /**
     * Damage source that is used for fall damage
     * @param entity damaged entity
     * @return the source of damage
     */
    @Nullable
    default class_1282 getFallDamageSource(class_1297 entity) {
        return null;
    }

    /**
     * Called when a falling block lands
     * @param level
     * @param blockPos
     * @param blockState
     * @param blockState2
     * @param fallingBlockEntity
     */
    default void onLand(class_1937 level, class_2338 blockPos, class_2680 blockState, class_2680 blockState2, class_1540 fallingBlockEntity) {
    }

    /**
     * Callback on broken after fall
     * @param level
     * @param blockPos
     * @param fallingBlockEntity
     */
    default void onBrokenAfterFall(class_1937 level, class_2338 blockPos, class_1540 fallingBlockEntity) {
    }

    /**
     * Called when a block was exploded. Used for tnt behaviour for example to ignite the block
     * @param serverLevel
     * @param blockPos
     * @param explosion
     */
    default void wasExploded(class_3218 serverLevel, class_2338 blockPos, class_1927 explosion) {
    }

    default Optional<Boolean> hasAnalogOutputSignal(class_2680 blockState) {
        return Optional.empty();
    }

    default int getAnalogOutputSignal(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return 0;
    }

    default void entityInside(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1297 entity, class_10774 insideBlockEffectApplier) {
    }
}
package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_2170;
import net.minecraft.class_3300;
import net.minecraft.class_5350;
import net.minecraft.class_5455;
import net.minecraft.class_7699;

@Mixin(class_5350.class)
public class ReloadableServerResourcesMixin {
    @Inject(at = @At("HEAD"), method = "loadResources")
    private static void filament$loadResources(class_3300 resourceManager, class_5455.class_6890 frozen, class_7699 featureFlagSet, class_2170.class_5364 commandSelection, int i, Executor executor, Executor executor2, CallbackInfoReturnable<CompletableFuture<class_5350>> cir) {
        Util.loadDatapackContents(resourceManager);
        PolymerItemGroupUtils.invalidateItemGroupCache();
    }
}
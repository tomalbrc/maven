package de.tomalbrc.filament.data.resource;

import de.tomalbrc.filament.data.BlockData;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4943;

public record BlockResource(Map<String, class_2960> models,
                           Map<String, class_2960> textures,
                           Map<String, class_2960> vanilla) {

    public boolean couldGenerate() {
        return this.textures != null;
    }

    public boolean hasValidModels(BlockData.BlockType type) {
        if (models == null || type == null)
            return false;

        boolean horizontal_directional =
                models.containsKey("north") &&
                models.containsKey("south") &&
                models.containsKey("west") &&
                models.containsKey("east");

        switch (type) {
            case block -> {
                return models.containsKey("default");
            }
            case column -> {
                return models.containsKey("x") && models.containsKey("y") && models.containsKey("z");
            }
            case directional -> {
                return models.containsKey("up") && models.containsKey("down") && horizontal_directional;
            }
            case horizontal_directional -> {
                return horizontal_directional;
            }
        }

        return false;
    }

    public List<class_4942> getTemplates(BlockData.BlockType blockType) {
        switch (blockType) {
            case block -> {
                return List.of(class_4943.field_22972);
            }
            case column -> {
                return List.of(class_4943.field_41276, class_4943.field_41277, class_4943.field_41278);
            }
            case directional -> {
                return List.of(class_4943.field_22942);
            }
            case horizontal_directional -> {
                return List.of();
            }
        }

        return null;
    }

    public boolean hasValidTextures(BlockData.BlockType type) {
        if (models == null || type == null)
            return false;

        boolean horizontal_directional =
                models.containsKey("north") &&
                        models.containsKey("south") &&
                        models.containsKey("west") &&
                        models.containsKey("east");

        switch (type) {
            case block -> {
                return models.containsKey("default");
            }
            case column -> {
                return models.containsKey("top") && models.containsKey("side") && models.containsKey("bottom");
            }
            case directional, horizontal_directional -> {
                return models.containsKey("front") && models.containsKey("top") && models.containsKey("side");
            }
        }

        return false;
    }
}

package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.filament.block.SimpleBlockItem;
import de.tomalbrc.filament.data.behaviours.item.Cosmetic;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class CosmeticUtil {
    public static boolean isCosmetic(class_1799 itemStack) {
        if (itemStack.method_7909() instanceof DecorationItem simpleItem && simpleItem.getDecorationData().isCosmetic()) {
            return true;
        }
        if (itemStack.method_7909() instanceof SimpleBlockItem simpleItem && simpleItem.getBlockData().isCosmetic()) {
            return true;
        }
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.getItemData().isCosmetic()) {
            return true;
        }

        return false;
    }

    public static Cosmetic getCosmeticData(class_1799 itemStack) {
        return getCosmeticData(itemStack.method_7909());
    }

    public static Cosmetic getCosmeticData(class_1792 item) {
        Cosmetic cosmeticData = null;
        if (item instanceof DecorationItem simpleItem && simpleItem.getDecorationData().isCosmetic()) {
            cosmeticData = simpleItem.getDecorationData().behaviour().cosmetic;
        }
        if (item instanceof SimpleBlockItem simpleItem && simpleItem.getBlockData().isCosmetic()) {
            cosmeticData = simpleItem.getBlockData().behaviour().cosmetic;
        }
        if (item instanceof SimpleItem simpleItem && simpleItem.getItemData().isCosmetic()) {
            cosmeticData = simpleItem.getItemData().behaviour().cosmetic;
        }

        return cosmeticData;
    }
}

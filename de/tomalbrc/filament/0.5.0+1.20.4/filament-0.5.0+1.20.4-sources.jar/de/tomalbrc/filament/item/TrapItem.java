package de.tomalbrc.filament.item;

import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.data.behaviours.item.Trap;
import de.tomalbrc.filament.util.Util;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_3730;
import net.minecraft.class_5761;
import net.minecraft.class_7923;

public class TrapItem extends SimpleItem {
    public TrapItem(class_1793 properties, ItemData itemData) {
        super(properties, itemData);
    }

    private Trap trapData() {
        Trap trap = this.itemData.behaviour().trap;
        return trap;
    }

    @Override
    public void method_7851(class_1799 itemStack, @Nullable class_1937 level, List<class_2561> tooltip, class_1836 tooltipFlag) {
        if (itemStack.method_7948().method_10545("Type")) {
            class_1299<?> type = class_7923.field_41177.method_10223(new class_2960(itemStack.method_7948().method_10558("Type")));
            tooltip.add(class_2561.method_43470("Contains ").method_10852(class_2561.method_43471(type.method_5882()))); // todo: make "Contains " translateable?
        }
        else {
            if (this.trapData().requiredEffects != null) {
                tooltip.add(class_2561.method_43470("Requires effects: "));
                for (int i = 0; i < this.trapData().requiredEffects.size(); i++) {
                    var e = this.trapData().requiredEffects.get(i);
                    tooltip.add(class_2561.method_43470("› ").method_10852(class_2561.method_43471(class_7923.field_41174.method_10223(e).method_5567()))); // todo: make "Contains " translateable?
                }
            }
            tooltip.add(class_2561.method_43470("Chance: " + this.trapData().chance));
        }

        super.method_7851(itemStack, level, tooltip, tooltipFlag);
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        return this.modelData != null ? canSpawn(itemStack) ? this.modelData.get("trapped").value() : this.modelData.get("default").value() : -1;
    }

    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 interactionHand) {
        super.method_7836(level, player, interactionHand);

        class_1799 itemStack = player.method_5998(interactionHand);
        if (this.itemData.isTrap()) {
            this.use(player, interactionHand);
            return class_1271.method_22428(itemStack);
        } else {
            return class_1271.method_22431(itemStack);
        }
    }

    public void use(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);

        Trap trap = this.itemData.behaviour().trap;
        player.method_6019(hand);

        if (trap.useDuration > 0) player.method_7357().method_7906(this, trap.useDuration);

        player.method_7259(class_3468.field_15372.method_14956(this));

        Util.damageAndBreak(1, itemStack, player, class_1657.method_32326(player.method_5998(hand)));
    }

    public class_1269 method_7884(class_1838 useOnContext) {
        // TODO: maybe check for lava / safe ground?
        if (useOnContext.method_8036() != null && canSpawn(useOnContext.method_8041()) && useOnContext.method_8045() instanceof class_3218 serverLevel) {
            this.spawn(serverLevel, useOnContext.method_8041(), useOnContext.method_8037());
            use(useOnContext.method_8036(), useOnContext.method_20287());
        }

        return class_1269.field_5811;
    }

    private static boolean canSpawn(class_1799 useOnContext) {
        return useOnContext.method_7948().method_10545("Type");
    }

    private void spawn(class_3218 serverLevel, class_1799 itemStack, class_2338 blockPos) {
        class_1299<?> entityType = class_7923.field_41177.method_10223(new class_2960(itemStack.method_7948().method_10558("Type")));
        class_1297 entity = entityType.method_47821(serverLevel, blockPos.method_10086(1), class_3730.field_16473);
        if (entity instanceof class_1308 mob) {
            this.loadFromTag(mob, itemStack.method_7948());
        }

        int damage = itemStack.method_7919();
        itemStack.method_7980(null);
        itemStack.method_7974(damage);
    }

    public boolean canUseOn(class_1308 mob) {
        Trap trap = this.trapData();
        class_2960 mobType = class_7923.field_41177.method_10221(mob.method_5864());
        return trap.types.contains(mobType);
    }

    public boolean canSave(class_1308 mob) {
        boolean hasEffects = true;
        if (this.trapData().requiredEffects != null) {
            hasEffects = false;
            for (int i = 0; i < this.trapData().requiredEffects.size(); i++) {
                var effectId = this.trapData().requiredEffects.get(i);
                var optional = class_7923.field_41174.method_10223(effectId);
                if (optional != null && mob.method_6059(optional)) {
                    hasEffects = true;
                }
            }
        }

        return hasEffects && mob.method_6051().method_43048(100) <= this.trapData().chance;
    }

    public void saveToTag(class_1308 mob, class_1799 itemStack) {
        // todo: read additional nbt, Bucketable not good enough
        class_5761.method_35167(mob, itemStack);

        class_2960 resourceLocation = class_7923.field_41177.method_10221(mob.method_5864());
        itemStack.method_7948().method_10582("Type", resourceLocation.toString());
    }

    public void loadFromTag(class_1308 mob, class_2487 compoundTag) {
        // todo: write additional nbt, Bucketable not good enough
        class_5761.method_35168(mob, compoundTag);
    }
}

package de.tomalbrc.filament.registry.filament;

import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.file.loader.AjModelLoader;
import de.tomalbrc.bil.file.loader.BbModelLoader;
import de.tomalbrc.filament.Filament;
import it.unimi.dsi.fastutil.objects.Object2ReferenceArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceMap;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class ModelRegistry {
    private static final Object2ReferenceMap<class_2960, Model> ajmodels = new Object2ReferenceArrayMap<>();

    public static Model getModel(class_2960 model) {
        return ajmodels.get(model);
    }

    public static class AjModelReloadListener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return new class_2960("filament:ajmodel");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/model", path -> path.method_12832().endsWith(".ajmodel") || path.method_12832().endsWith(".bbmodel"));

            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
                try (var inputStream = entry.getValue().method_14482()) {
                    Model model = entry.getKey().method_12832().endsWith(".ajmodel") ? new AjModelLoader().load(inputStream, entry.getKey().method_12832()) : new BbModelLoader().load(inputStream, entry.getKey().method_12832());
                    ajmodels.put(sanitize(entry.getKey()), model);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"" + entry.getKey() + "\".");
                }
            }

            Filament.LOGGER.info("filament decorations registered: " + DecorationRegistry.REGISTERED_DECORATIONS);
            Filament.LOGGER.info("filament decoration block entities registered: " + DecorationRegistry.REGISTERED_BLOCK_ENTITIES);
        }
    }

    public static class_2960 sanitize(class_2960 resourceLocation) {
        String path = resourceLocation.method_12832();
        String customPath = path.substring(path.contains("/") ? path.lastIndexOf('/')+1 : 0, path.lastIndexOf('.'));
        return new class_2960(resourceLocation.method_12836(), customPath);
    }

    public static void registerAjModel(InputStream inputStream, class_2960 resourceLocation) throws IOException {
        ajmodels.put(resourceLocation, new AjModelLoader().load(inputStream, resourceLocation.method_12832()));
    }

    public static void registerBbModel(InputStream inputStream, class_2960 resourceLocation) throws IOException {
        ajmodels.put(resourceLocation, new BbModelLoader().load(inputStream, resourceLocation.method_12832()));
    }
}

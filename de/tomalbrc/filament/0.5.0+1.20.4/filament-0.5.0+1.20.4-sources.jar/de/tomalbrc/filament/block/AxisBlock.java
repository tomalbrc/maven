package de.tomalbrc.filament.block;

import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import java.util.HashMap;
import net.minecraft.class_2248;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4970;

public class AxisBlock extends class_2465 implements PolymerTexturedBlock {
    private final HashMap<String, class_2680> stateMap;
    private final class_2680 breakEventState;

    public AxisBlock(class_4970.class_2251 properties, BlockData data) {
        super(properties);
        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
    }

    @Override
    public class_2248 getPolymerBlock(class_2680 state) {
        return this.getPolymerBlockState(state).method_26204();
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return switch (state.method_11654(field_11459)) {
            case field_11048 -> this.stateMap.get("x");
            case field_11052 -> this.stateMap.get("y");
            case field_11051 -> this.stateMap.get("z");
        };
    }
}

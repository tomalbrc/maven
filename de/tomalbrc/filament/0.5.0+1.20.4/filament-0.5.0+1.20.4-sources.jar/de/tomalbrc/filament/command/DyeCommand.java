package de.tomalbrc.filament.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import de.tomalbrc.filament.util.HideFlags;
import de.tomalbrc.filament.util.Util;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2487;
import java.util.Optional;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;

public class DyeCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        var dyeNode = class_2170
                .method_9247("dye").requires(Permissions.require("filament.command.dye", 1));

        var colorArg = class_2170.method_9244("color", StringArgumentType
                .string());

        dispatcher.register(dyeNode.then(colorArg.executes(DyeCommand::execute)));
    }

    private static int execute(CommandContext<class_2168> context) {
        if (context.getSource().method_44023() != null) {
            class_1799 item = context.getSource().method_44023().method_6047();
            if (item != null && !item.method_7960()) {
                String hexColorString = getString(context, "color");
                Optional<Integer> color = Util.validateAndConvertHexColor(hexColorString);
                if (color.isPresent()) {
                    class_2487 itemNbt = item.method_7948();
                    class_2487 displayTag = new class_2487();
                    displayTag.method_10569("color", color.get());
                    itemNbt.method_10566("display", displayTag);
                    itemNbt.method_10569("HideFlags", HideFlags.HideDyed.getValue());
                    return Command.SINGLE_SUCCESS;
                }
            }
        }
        return 0;
    }
}

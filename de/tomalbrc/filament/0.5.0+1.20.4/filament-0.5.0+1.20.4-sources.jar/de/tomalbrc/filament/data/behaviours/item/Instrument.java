package de.tomalbrc.filament.data.behaviours.item;

import net.minecraft.class_2960;

public class Instrument {
    public class_2960 sound = null;

    public int range = 0;

    public int useDuration = 0;
}

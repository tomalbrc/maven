package de.tomalbrc.filament.registry.filament;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.Json;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1792;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3619;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class DecorationRegistry {
    public static int REGISTERED_BLOCK_ENTITIES = 0;
    public static int REGISTERED_DECORATIONS = 0;

    private static final Object2ObjectOpenHashMap<class_2960, DecorationData> decorations = new Object2ObjectOpenHashMap<>();

    private static final Object2ObjectOpenHashMap<class_2960, class_2248> decorationBlocks = new Object2ObjectOpenHashMap<>();
    private static final Object2ObjectOpenHashMap<class_2248, class_2591<DecorationBlockEntity>> decorationBlockEntities = new Object2ObjectOpenHashMap<>();

    public static void register(InputStream inputStream) throws IOException {
        register(Json.GSON.fromJson(new InputStreamReader(inputStream, StandardCharsets.UTF_8), DecorationData.class));
    }

    static public void register(DecorationData data) {
        if (decorations.containsKey(data.id())) return;

        decorations.put(data.id(), data);

        DecorationBlock block;

        if (!data.isSimple()) {
            block = new ComplexDecorationBlock(FabricBlockSettings.create().nonOpaque().luminance(blockState ->
                    blockState.method_11654(DecorationBlock.LIGHT_LEVEL)
            ).breakInstantly().dropsNothing().dynamicBounds().allowsSpawning((x, y, z, w) -> false).pistonBehavior(class_3619.field_15972), data.id());

            class_2591<DecorationBlockEntity> DECORATION_BLOCK_ENTITY = FabricBlockEntityTypeBuilder.create(DecorationBlockEntity::new, block).build();
            EntityRegistry.registerBlockEntity(data.id(), DECORATION_BLOCK_ENTITY);

            decorationBlockEntities.put(block, DECORATION_BLOCK_ENTITY);
            REGISTERED_BLOCK_ENTITIES++;
        } else {
            block = new SimpleDecorationBlock(FabricBlockSettings.create().nonOpaque().luminance(blockState ->
                    blockState.method_11654(DecorationBlock.LIGHT_LEVEL)
            ).breakInstantly().dropsNothing().dynamicBounds().allowsSpawning((x, y, z, w) -> false).pistonBehavior(data.properties() != null ? data.properties().pushReaction : class_3619.field_15974), data.id());
        }

        decorationBlocks.put(data.id(), block);
        BlockRegistry.registerBlock(data.id(), block);

        var properties = data.properties() != null ? data.properties().toItemProperties() : new class_1792.class_1793().method_7889(16);

        ItemRegistry.registerItem(data.id(), new DecorationItem(data, properties), ItemRegistry.CUSTOM_DECORATIONS);

        REGISTERED_DECORATIONS++;
    }

    public static DecorationData getDecorationDefinition(class_2960 resourceLocation) {
        return decorations.get(resourceLocation);
    }

    public static boolean isDecoration(class_2248 block) {
        return decorationBlocks.containsValue(block);
    }

    public static boolean isDecoration(class_2680 blockState) {
        return isDecoration(blockState.method_26204());
    }

    public static DecorationBlock getDecorationBlock(class_2960 resourceLocation) {
        return (DecorationBlock) decorationBlocks.get(resourceLocation);
    }

    public static class_2591<DecorationBlockEntity> getBlockEntityType(class_2680 blockState) {
        return decorationBlockEntities.get(blockState.method_26204());
    }


    public static class DecorationDataReloadListener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return new class_2960("filament:decorations");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/decoration", path -> path.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
                try (var reader = new InputStreamReader(entry.getValue().method_14482())) {
                    DecorationData data = Json.GSON.fromJson(reader, DecorationData.class);
                    DecorationRegistry.register(data);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"" + entry.getKey() + "\".");
                }
            }

            Filament.LOGGER.info("filament decorations registered: " + DecorationRegistry.REGISTERED_DECORATIONS);
            Filament.LOGGER.info("filament decoration block entities registered: " + DecorationRegistry.REGISTERED_BLOCK_ENTITIES);
        }
    }
}

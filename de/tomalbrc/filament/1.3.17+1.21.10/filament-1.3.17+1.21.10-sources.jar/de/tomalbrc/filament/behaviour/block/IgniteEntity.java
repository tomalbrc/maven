package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import net.minecraft.class_10774;
import net.minecraft.class_10776;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.NotNull;

public class IgniteEntity implements BlockBehaviourWithEntity<IgniteEntity.Config> {
    private final Config config;

    public IgniteEntity(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public IgniteEntity.Config getConfig() {
        return this.config;
    }

    @Override
    public void entityInside(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1297 entity, class_10774 insideBlockEffectApplier) {
        insideBlockEffectApplier.method_67638(class_10776.field_61896);
        insideBlockEffectApplier.method_67638(class_10776.field_56643);
        insideBlockEffectApplier.method_67640(class_10776.field_56643, entityx -> entityx.method_64419(entityx.method_73183().method_48963().method_48794(), this.config.fireDamage));
    }

    public static class Config {
        float fireDamage = 1;
    }
}
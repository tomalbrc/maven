package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_1799;

public class CosmeticUtil {
    public static boolean isCosmetic(class_1799 itemStack) {
        return getCosmeticData(itemStack) != null;
    }

    public static Cosmetic.Config getCosmeticData(class_1799 item) {
        Cosmetic.Config cosmeticData = null;
        if (item.method_7909().isFilamentItem() && item.method_7909().has(Behaviours.COSMETIC)) {
            cosmeticData = item.method_7909().getOrThrow(Behaviours.COSMETIC).getConfig();
        }
        if (item.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var wrapped = item.method_58694(FilamentComponents.SKIN_DATA_COMPONENT);
            if (wrapped != null && wrapped.method_7909().isFilamentItem() && wrapped.method_7909().has(Behaviours.COSMETIC)) {
                cosmeticData = wrapped.method_7909().getOrThrow(Behaviours.COSMETIC).getConfig();
            }
        }
        return cosmeticData;
    }
}

package de.tomalbrc.filament.mixin.behaviour.fishing_rod;

import de.tomalbrc.filament.behaviour.Behaviours;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1536.class)
public class FishingHookMixin {
    @Inject(method = "shouldStopFishing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/FishingHook;discard()V"), cancellable = true)
    private void filament$customShouldStopFishing(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        class_1799 itemStack = player.method_6047();
        class_1799 itemStack2 = player.method_6079();
        if (isRod(itemStack) || isRod(itemStack2)) {
            cir.setReturnValue(false);
        }
    }

    @Unique
    private boolean isRod(class_1799 itemStack) {
        return itemStack.method_7909().isFilamentItem() && itemStack.method_7909().has(Behaviours.FISHING_ROD);
    }
}

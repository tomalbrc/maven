package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.ContainerLike;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.AbstractHorizontalFacing;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.mixin.accessor.ChestBlockInvoker;
import de.tomalbrc.filament.registry.OxidizableRegistry;
import de.tomalbrc.filament.registry.StrippableRegistry;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.TextUtil;
import de.tomalbrc.filament.util.Util;
import net.minecraft.class_10225;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_11565;
import net.minecraft.class_1258;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4732;
import net.minecraft.class_4838;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_5953;
import net.minecraft.class_7923;
import net.minecraft.class_9288;
import net.minecraft.class_9297;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.class_9473;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiPredicate;

public class AnimatedChest extends AbstractHorizontalFacing<AnimatedChest.Config> implements BlockBehaviour<AnimatedChest.Config>, DecorationBehaviour<AnimatedChest.Config>, ContainerLike {
    private final de.tomalbrc.filament.behaviour.decoration.AnimatedChest.Config config;

    public FilamentContainer container;
    public class_5321<class_52> lootTable;
    public long lootTableSeed;

    class_2591<DecorationBlockEntity> TYPE;

    public AnimatedChest(de.tomalbrc.filament.behaviour.decoration.AnimatedChest.Config config) {
        super(null);
        this.config = config;
    }

    @Override
    @NotNull
    public de.tomalbrc.filament.behaviour.decoration.AnimatedChest.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        var id = block.method_40142().method_40237().method_29177();
        TYPE = (class_2591<DecorationBlockEntity>) class_7923.field_41181.method_63535(id);
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        DecorationBehaviour.super.init(blockEntity);

        TYPE = (class_2591<DecorationBlockEntity>) blockEntity.method_11017();

        this.container = new FilamentContainer(blockEntity, config.size, config.purge);

        var item = blockEntity.getItem();
        if (item.method_57826(class_9334.field_49622)) {
            Objects.requireNonNull(blockEntity.getItem().method_58694(class_9334.field_49622)).method_57492(container.field_5828);
        }

        if (config.openAnimation != null) {
            container.setOpenCallback(() -> blockEntity.getOrCreateHolder().playAnimation(config.openAnimation, 2));
        }
        if (config.closeAnimation != null) {
            container.setCloseCallback(() -> blockEntity.getOrCreateHolder().playAnimation(config.closeAnimation, 2));
        }
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        container.setValid(false);

        if (!config.canPickup)
            class_1264.method_5451(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016(), container);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        super.createBlockStateDefinition(builder);
        builder.method_11667(class_2741.field_12506);
    }

    protected class_2680 updateShapeSimple(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2680 blockState2) {
        if (blockState.method_11654(class_2741.field_12508)) {
            scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
        }

        if (canConnectTo(blockState, blockState2) && direction.method_10166().method_10179()) {
            class_2745 chestType = blockState2.method_11654(class_2281.field_10770);
            if (blockState.method_11654(class_2281.field_10770) == class_2745.field_12569 && chestType != class_2745.field_12569 && blockState.method_11654(class_2281.field_10768) == blockState2.method_11654(class_2281.field_10768) && class_2281.method_9758(blockState2) == direction.method_10153()) {
                return blockState.method_11657(class_2281.field_10770, chestType.method_11824());
            }
        } else if (class_2281.method_9758(blockState) == direction) {
            return blockState.method_11657(class_2281.field_10770, class_2745.field_12569);
        }

        return blockState;
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        var blockState3 = updateShapeSimple(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockState2);

        if (canConnectTo(blockState, blockState2) && !blockState3.method_11654(class_2281.field_10770).equals(class_2745.field_12569) && class_2281.method_9758(blockState3) == direction) {
            return blockState2.method_26204().method_34725(blockState3);
        }

        return blockState3;
    }

    public static boolean canConnectTo(class_2680 state1, class_2680 state2) {
        return state1.method_27852(state2.method_26204()) || OxidizableRegistry.sameOxidizable(state1.method_26204(), state2.method_26204()) || StrippableRegistry.get(state1.method_26204()) == state2.method_26204() || StrippableRegistry.get(state2.method_26204()) == state1.method_26204();
    }


    protected @NotNull class_2680 getStateForPlacementSimple(class_2680 state, class_1750 blockPlaceContext) {
        class_2745 chestType = class_2745.field_12569;
        class_2350 direction = blockPlaceContext.method_8042().method_10153();
        class_3610 fluidState = blockPlaceContext.method_8045().method_8316(blockPlaceContext.method_8037());
        boolean bl = blockPlaceContext.method_8046();
        class_2350 direction2 = blockPlaceContext.method_8038();
        if (direction2.method_10166().method_10179() && bl) {
            class_2350 direction3 = this.candidatePartnerFacing(state, blockPlaceContext, direction2.method_10153());
            if (direction3 != null && direction3.method_10166() != direction2.method_10166()) {
                direction = direction3;
                chestType = direction3.method_10160() == direction2.method_10153() ? class_2745.field_12571 : class_2745.field_12574;
            }
        }

        if (chestType == class_2745.field_12569 && !bl) {
            if (direction == this.candidatePartnerFacing(state, blockPlaceContext, direction.method_10170())) {
                chestType = class_2745.field_12574;
            } else if (direction == this.candidatePartnerFacing(state, blockPlaceContext, direction.method_10160())) {
                chestType = class_2745.field_12571;
            }
        }

        return state.method_11657(class_2281.field_10768, direction).method_11657(class_2281.field_10770, chestType).method_11657(class_2281.field_10772, fluidState.method_15772() == class_3612.field_15910);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 state, class_1750 blockPlaceContext) {
        var blockState = getStateForPlacementSimple(state, blockPlaceContext);

        if (((BehaviourHolder) state.method_26204()).has(Behaviours.OXIDIZABLE)) {
            class_2680 blockState2 = blockPlaceContext.method_8045().method_8320(blockPlaceContext.method_8037().method_10093(class_2281.method_9758(blockState)));
            if (!blockState2.method_26215() && blockState2.method_26204() instanceof DecorationBlock && !blockState2.method_11654(class_2281.field_10770).equals(class_2745.field_12569)) {
                BehaviourHolder placed = (BehaviourHolder) blockState.method_26204();
                BehaviourHolder other = (BehaviourHolder) blockState2.method_26204();
                class_2680 maybeFinal = blockState;
                class_2680 blockStateOther = blockState2;
                if (placed.has(Behaviours.STRIPPABLE) != other.has(Behaviours.STRIPPABLE)) {
                    blockStateOther = this.unwaxed(placed, blockState).orElse(blockState2);
                    maybeFinal = this.unwaxed(other, blockState2).orElse(maybeFinal);
                }

                class_2248 block = maybeFinal.method_26204();
                if (placed.has(Behaviours.OXIDIZABLE) && other.has(Behaviours.OXIDIZABLE) && placed.getOrThrow(Behaviours.OXIDIZABLE).getConfig().weatherState.ordinal() <= other.getOrThrow(Behaviours.OXIDIZABLE).getConfig().weatherState.ordinal()) {
                    block = blockStateOther.method_26204();
                }

                return block.method_34725(blockState2);
            }
        }

        return blockState;
    }

    private Optional<class_2680> unwaxed(BehaviourHolder copperChestBlock, class_2680 blockState) {
        if (!copperChestBlock.has(Behaviours.STRIPPABLE)) {
            return Optional.of(blockState);
        }

        return Optional.ofNullable(class_5953.field_29561.get().get(blockState.method_26204())).map(block -> block.method_34725(blockState));
    }

    @Nullable
    private class_2350 candidatePartnerFacing(class_2680 state, class_1750 blockPlaceContext, class_2350 direction) {
        class_2680 blockState = blockPlaceContext.method_8045().method_8320(blockPlaceContext.method_8037().method_10093(direction));
        return blockState.method_27852(state.method_26204()) && blockState.method_11654(class_2281.field_10770) == class_2745.field_12569 ? blockState.method_11654(class_2281.field_10768) : null;
    }

    @Override
    public void write(class_11372 output, DecorationBlockEntity decorationBlockEntity) {
        if (!container.method_54872(output))
            class_1262.method_5426(output.method_71461("Container"), this.container.field_5828);
    }

    @Override
    public void read(class_11368 input, DecorationBlockEntity decorationBlockEntity) {
        if (!container.method_54871(input))
            input.method_71420("Container").ifPresent(x -> class_1262.method_5429(x, container.field_5828));
    }

    @Override
    public Optional<Boolean> hasAnalogOutputSignal(class_2680 blockState) {
        return Optional.of(Boolean.TRUE);
    }

    @Override
    public int getAnalogOutputSignal(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2350 direction) {
        return class_1703.method_7618(getContainer(blockState, level, blockPos, config.ignoreBlock));
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (level instanceof class_3218 serverLevel) {
            class_3908 menuProvider = this.getMenuProvider(blockState, level, blockPos);
            if (menuProvider != null) {
                player.method_17355(menuProvider);
                player.method_7259(class_3468.field_15419.method_14956(class_3468.field_15395));
                if (config.angerPiglins) class_4838.method_24733(serverLevel, player, true);
            }
        }

        return class_1269.field_5812;
    }

    @Nullable
    protected class_3908 getMenuProvider(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return this.combine(blockState, level, blockPos, config.ignoreBlock).apply(MENU_PROVIDER_COMBINER).orElse(null);
    }

    @Override
    public void affectNeighborsAfterRemoval(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, boolean bl) {
        class_1264.method_66221(blockState, serverLevel, blockPos);
    }

    @Override
    public class_1799 getCloneItemStack(class_1799 itemStack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        return itemStack;
    }

    @Override
    public void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9473 dataComponentGetter) {
        dataComponentGetter.method_58695(class_9334.field_49622, class_9288.field_49334).method_57492(this.container.field_5828);
        class_9297 seededContainerLoot = dataComponentGetter.method_58694(class_9334.field_49626);
        if (seededContainerLoot != null) {
            this.lootTable = seededContainerLoot.comp_2414();
            this.lootTableSeed = seededContainerLoot.comp_2415();
        }
    }

    @Override
    public void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {
        builder.method_57840(class_9334.field_49622, class_9288.method_57493(this.container.field_5828));
        if (this.lootTable != null) {
            builder.method_57840(class_9334.field_49626, new class_9297(this.lootTable, this.lootTableSeed));
        }
    }

    @Override
    public void removeComponentsFromTag(DecorationBlockEntity decorationBlockEntity, class_11372 valueOutput) {
        valueOutput.method_71478("LootTable");
        valueOutput.method_71478("LootTableSeed");
    }

    @Override
    public void modifyDrop(DecorationBlockEntity blockEntity, class_1799 itemStack) {
        if (config.canPickup) {
            itemStack.method_57379(class_9334.field_49622, class_9288.method_57493(container.method_54454()));
        }
    }

    @Override
    public class_2561 customName() {
        return container.getBlockEntity().method_58693().method_58694(class_9334.field_49631);
    }

    @Override
    public @Nullable class_1263 container() {
        return getContainer(container.getBlockEntity().method_11010(), container.getBlockEntity().method_10997(), container.getBlockEntity().method_11016(), config.ignoreBlock);
    }

    @Override
    public boolean showCustomName() {
        return config.showCustomName;
    }

    @Override
    public boolean hopperDropperSupport() {
        return config.hopperDropperSupport;
    }

    @Override
    public boolean canPickUp() {
        return config.canPickup;
    }

    @Override
    public void setLootTable(@Nullable class_5321<class_52> resourceKey) {
        lootTable = resourceKey;
    }

    @Override
    public @Nullable class_5321<class_52> getLootTable() {
        return lootTable;
    }

    @Override
    public void setLootTableSeed(long l) {
        lootTableSeed = l;
    }

    @Override
    public long getLootTableSeed() {
        return lootTableSeed;
    }

    public static class Config {
        /**
         * The name displayed in the container UI
         */
        public String name = "Chest";

        /**
         * The name displayed in the container UI for double chests
         */
        public String nameDouble = "Double Chest";

        /**
         * The size of the container, has to be 5 slots or a multiple of 9, up to 6 rows of 9 slots.
         */
        public int size = 9;

        /**
         * Indicates whether the container's contents should be cleared when no player is viewing the inventory.
         */
        public boolean purge = false;

        /**
         * The name of the animation to play when the container is opened
         */
        public String openAnimation = null;

        /**
         * The name of the animation to play when the container is closed
         */
        public String closeAnimation = null;

        /**
         * Flag to indicate whether the container can be picked up like shulker boxes.
         */
        public boolean canPickup = false;

        /**
         * Support hopper and dropper blocks
         */
        public boolean hopperDropperSupport = true;

        /**
         * Show custom name from item stack
         */
        public boolean showCustomName = true;

        /**
         * Ignore blocking by redstone conductor and cats
         */
        public boolean ignoreBlock = false;

        public class_2350 blockDirection = class_2350.field_11036;

        /**
         * Anger nearby piglins
         */
        public boolean angerPiglins = true;
    }

    public class_1263 getContainer(class_2680 blockState, class_1937 level, class_2338 blockPos, boolean ignoreBlock) {
        return combine(blockState, level, blockPos, ignoreBlock).apply(CONTAINER_COMBINER).orElse(null);
    }

    public boolean isBlockedAt(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState) {
        class_2350 dir = config.blockDirection;
        if (dir.method_10166().method_10179()) {
            var localRot = dir.method_10144();
            var facing = blockState.method_11654(class_2281.field_10768).method_10144();
            dir = class_2350.method_10150(facing - localRot);
        }
        return levelAccessor.method_8320(blockPos.method_10093(dir)).method_26212(levelAccessor, blockPos) || (dir == class_2350.field_11036 && ChestBlockInvoker.isCatSittingOnChest(levelAccessor, blockPos));
    }

    public class_4732.class_4734<DecorationBlockEntity> combine(class_2680 blockState, class_1937 level, class_2338 blockPos, boolean ignoreBlock) {
        BiPredicate<class_1936, class_2338> biPredicate;
        if (ignoreBlock) {
            biPredicate = (levelAccessor, blockPosx) -> false;
        } else {
            biPredicate = (levelAccessor, pos) -> this.isBlockedAt(levelAccessor, pos, blockState);
        }

        return class_4732.method_24173(TYPE, class_2281::method_24169, class_2281::method_9758, class_2281.field_10768, blockState, level, blockPos, biPredicate);
    }

    public static class_4732.class_3923<DecorationBlockEntity, Optional<class_1263>> CONTAINER_COMBINER = new class_4732.class_3923<>() {
        @Override
        public @NotNull Optional<net.minecraft.class_1263> acceptDouble(DecorationBlockEntity container, DecorationBlockEntity container2) {
            var c1 = container.getOrThrow(Behaviours.ANIMATED_CHEST).container;
            var c2 = container2.getOrThrow(Behaviours.ANIMATED_CHEST).container;
            return Optional.of(new class_1258(c1, c2) {
                @Override
                public @NotNull List<class_11565> method_72379() {
                    return container2.getOrThrow(Behaviours.ANIMATED_CHEST).container.method_72379();
                }
            });
        }

        @Override
        public @NotNull Optional<net.minecraft.class_1263> acceptSingle(DecorationBlockEntity container) {
            return Optional.of(container.getOrThrow(Behaviours.ANIMATED_CHEST).container);
        }

        @Override
        public @NotNull Optional<net.minecraft.class_1263> method_24174() {
            return Optional.empty();
        }
    };

    public boolean canOpen(class_1657 player) {
        return !player.method_7325();
    }

    public static class_4732.class_3923<DecorationBlockEntity, Optional<class_3908>> MENU_PROVIDER_COMBINER = new class_4732.class_3923<>() {
        @Override
        public @NotNull Optional<class_3908> acceptDouble(final DecorationBlockEntity chestBlockEntity, final DecorationBlockEntity chestBlockEntity2) {
            var c1 = chestBlockEntity.getOrThrow(Behaviours.ANIMATED_CHEST);
            var c2 = chestBlockEntity2.getOrThrow(Behaviours.ANIMATED_CHEST);
            final class_1263 container = new class_1258(c1.container, c2.container) {
                @Override
                public @NotNull List<class_11565> method_72379() {
                    return c2.container.method_72379();
                }
            };

            return Optional.of(new class_3908() {
                @Override
                @Nullable
                public class_1703 createMenu(int id, class_1661 inventory, class_1657 player) {
                    c1.container.method_54873(inventory.field_7546);
                    c2.container.method_54873(inventory.field_7546);

                    if (c1.canOpen(player) && c2.canOpen(player)) {
                        return Util.createMenu(container, id, player);
                    } else {
                        return null;
                    }
                }

                @Override
                public @NotNull class_2561 method_5476() {
                    var cname = c1.customName();
                    return cname != null && c1.showCustomName() ? cname : TextUtil.formatText(c1.config.nameDouble);
                }
            });
        }

        @Override
        public @NotNull Optional<class_3908> acceptSingle(DecorationBlockEntity chestBlockEntity) {
            var c1 = chestBlockEntity.getOrThrow(Behaviours.ANIMATED_CHEST);
            FilamentContainer container = c1.container;

            var menuProvider = new class_3908() {
                @Override
                @Nullable
                public class_1703 createMenu(int id, class_1661 inventory, class_1657 player) {
                    if (c1.canOpen(player)) {
                        return Util.createMenu(container, id, player);
                    } else {
                        return null;
                    }
                }

                @Override
                public @NotNull class_2561 method_5476() {
                    var cname = c1.customName();
                    return cname != null && c1.showCustomName() ? cname : TextUtil.formatText(c1.config.name);
                }
            };

            return Optional.of(menuProvider);
        }

        @Override
        public @NotNull Optional<class_3908> method_24174() {
            return Optional.empty();
        }
    };
}
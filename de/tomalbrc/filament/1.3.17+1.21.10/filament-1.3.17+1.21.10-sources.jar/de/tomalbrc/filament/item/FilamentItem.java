package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.injection.FilamentItemExtension;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

@SuppressWarnings("unused")
public interface FilamentItem extends BehaviourHolder, FilamentItemExtension {
    FilamentItemDelegate getDelegate();

    Data<?> getData();

    default Map<String, class_2960> getModelMap() {
        var resource = this.getData().preferredResource();
        var defaultResource = this.getData().itemResource();
        return resource != null ? resource.getModels() : defaultResource != null ? defaultResource.getModels() : null;
    }

    void verifyComponentsAfterLoad(class_1799 itemStack);

    default class_1792 asItem() {
        return (class_1792) this;
    }

    default FilamentItem asFilamentItem() {
        return this;
    }
}

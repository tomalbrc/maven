package de.tomalbrc.filament.datafixer.fix;

import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Dynamic;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.datafixer.DataFix;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.BlockUtil;
import de.tomalbrc.filament.util.Util;
import java.util.*;
import net.minecraft.class_1208;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_2841;
import net.minecraft.class_2852;
import net.minecraft.class_2960;
import net.minecraft.class_6563;

public class ChangeVersionAndRotationState extends com.mojang.datafixers.DataFix {
    public ChangeVersionAndRotationState(Schema outputSchema) {
        super(outputSchema, true);
    }

    public static com.mojang.datafixers.DataFix create(Schema outputSchema) {
        return new ChangeVersionAndRotationState(outputSchema);
    }

    @Override
    public TypeRewriteRule makeRule() {
        Type<?> type = this.getInputSchema().getType(class_1208.field_5726);
        Type<?> type2 = this.getOutputSchema().getType(class_1208.field_5726);
        return writeFixAndRead("UpdateFilamentDecorations", type, type2, this::fix);
    }

    private Dynamic<?> fix(Dynamic<?> dynamic) {
        try {
            List<Dynamic<?>> blockEntities = dynamic.get("block_entities").asList(dyn -> dyn.castTyped(class_2509.field_11560));
            if (blockEntities == null || blockEntities.isEmpty())
                return dynamic;

            List<Dynamic<?>> sections = dynamic.get("sections").asList(dyn -> dyn.castTyped(class_2509.field_11560));

            var blendingData = dynamic.get("blending_data");
            var min = blendingData.get("min_section").asInt(-4);

            Map<Integer, List<Dynamic<?>>> map = new HashMap<>();
            for (Dynamic<?> blockEntity : blockEntities) {
                var id = blockEntity.get("id").read(class_2960.field_25139);
                if (id.isError())
                    continue;

                var v = blockEntity.get("V");
                if (v == null || v.get().isError())
                    continue;

                var version = v.asInt(0);
                if (!id.getOrThrow().method_12836().equals(class_2960.field_33381) && version < DataFix.VERSION) {
                    var yData = blockEntity.get("y").asInt(0);
                    var idx = (yData - min * 16) / 16;
                    map.computeIfAbsent(idx, (x) -> new ArrayList<>()).add(blockEntity);
                }
            }

            if (!map.isEmpty()) {
                for (Integer idx : map.keySet()) {
                    var entries = map.get(idx);
                    var section = sections.get(idx);

                    var states = section.get("block_states");

                    class_2841<class_2680> palettedContainer = states.read(class_2487.field_25128).mapOrElse(tag -> BLOCK_STATE_CODEC.parse(class_2509.field_11560, tag).promotePartial(string -> {}).getOrThrow(class_2852.class_9314::new), (tagError) -> new class_2841<>(class_2246.field_10124.method_9564(), class_6563.method_74162(class_2248.field_10651)));

                    for (Dynamic<?> blockEntityData : entries) {
                        var yData = blockEntityData.get("y").asInt(0);
                        var x = blockEntityData.get("x").asInt(0) & 15;
                        var y = yData & 15;
                        var z = blockEntityData.get("z").asInt(0) & 15;

                        var dir = class_2350.method_10143(blockEntityData.get(DecorationBlockEntity.DIRECTION).asInt(class_2350.field_11036.method_10146()));
                        var rot = blockEntityData.get("Rotation");

                        var state = palettedContainer.method_12321(x,y,z);
                        if (state.method_26204() instanceof DecorationBlock && state.method_28498(BlockUtil.ROTATION)) {
                            state = state.method_11657(BlockUtil.ROTATION, Util.SEGMENTED_ANGLE8.method_48125(DataFix.getVisualRotationYInDegrees(dir, rot.asInt(0))));
                            palettedContainer.method_12328(x, y, z, state);
                        }

                        var upgradedBlockEntityData = blockEntityData.set("V", dynamic.createInt(2)).remove("Rotation");
                        blockEntities.set(blockEntities.indexOf(blockEntityData), upgradedBlockEntityData);
                    }

                    var result = BLOCK_STATE_CODEC.encodeStart(class_2509.field_11560, palettedContainer);
                    class_2520 tag = result.getOrThrow();
                    section = section.replaceField("block_states", "block_states", Optional.of(new Dynamic<>(class_2509.field_11560, tag)));
                    sections.set(idx, section);
                }

                dynamic = dynamic.set("block_entities", dynamic.createList(blockEntities.stream())).set("sections", dynamic.createList(sections.stream()));
            }
        } catch (Exception e) {
            Filament.LOGGER.info("Error during data fix", e);
        }

        return dynamic;
    }

    private static final Codec<class_2841<class_2680>> BLOCK_STATE_CODEC = class_2841.method_44343(
            class_2680.field_24734, class_6563.method_74162(class_2248.field_10651), class_2246.field_10124.method_9564()
    );
}
package de.tomalbrc.filament.mixin.component.backpack;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_1799;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImplMixin {
    @Shadow public class_3222 player;

    @Inject(method = "handleUseItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItem(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;"), cancellable = true)
    private void filament$backpackInteraction(class_2886 serverboundUseItemPacket, CallbackInfo ci, @Local class_1799 itemStack) {
        if (itemStack.method_7947() == 1 && itemStack.method_57826(FilamentComponents.BACKPACK) && itemStack.method_57826(class_9334.field_49622)) {
            var backpackOptions = itemStack.method_58694(FilamentComponents.BACKPACK);
            assert backpackOptions != null;
            if (!(player.method_5715() && backpackOptions.sneakOnly())) {
                backpackOptions.open(itemStack, player);
                ci.cancel();
            }
        }
    }

    @Inject(method = "handleUseItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItemOn(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;"), cancellable = true)
    private void filament$backpackInteraction(class_2885 serverboundUseItemOnPacket, CallbackInfo ci, @Local class_1799 itemStack) {
        if (itemStack.method_7947() == 1 && itemStack.method_57826(FilamentComponents.BACKPACK)) {
            var backpackOptions = itemStack.method_58694(FilamentComponents.BACKPACK);
            assert backpackOptions != null;
            if (backpackOptions.preventPlacement() && !(player.method_5715() && backpackOptions.sneakOnly())) {
                backpackOptions.open(itemStack, player);
                ci.cancel();
            }
        }
    }
}

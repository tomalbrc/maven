package de.tomalbrc.filament.mixin.behaviour.waxable;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.registry.WaxableRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2673;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3222;
import net.minecraft.class_5953;
import net.minecraft.class_6088;

@Mixin(class_5953.class)
public class HoneycombItemMixin {
    @Inject(method = "getWaxed", at = @At("RETURN"), cancellable = true)
    private static void filament$customWaxable(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (cir.getReturnValue().isEmpty() && blockState.method_26204().isFilamentBlock() && blockState.method_26204().has(Behaviours.WAXABLE)) {
            cir.setReturnValue(Optional.of(WaxableRegistry.getWaxed(blockState.method_26204()).method_34725(blockState)));
        }
    }

    @Inject(method = "method_34719", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;levelEvent(Lnet/minecraft/world/entity/Entity;ILnet/minecraft/core/BlockPos;I)V", ordinal = 0))
    private static void filament$broadcastToPlayer(class_1838 useOnContext, class_2338 blockPos, class_1937 level, class_2680 blockState, class_2680 blockState2, CallbackInfoReturnable<class_1269> cir, @Local class_1657 player) {
        if (!level.method_8608() && WaxableRegistry.getPrevious(blockState2.method_26204()) != null) {
            ((class_3222)player).field_13987.method_14364(new class_2673(class_6088.field_31156, blockPos, 0, false));

            if (blockState.method_28498(class_2281.field_10770) && blockState.method_11654(class_2281.field_10770) != class_2745.field_12569) {
                ((class_3222)player).field_13987.method_14364(new class_2673(class_6088.field_31156, class_2281.method_72581(blockPos, blockState2), 0, false));
            }
        }
    }
}

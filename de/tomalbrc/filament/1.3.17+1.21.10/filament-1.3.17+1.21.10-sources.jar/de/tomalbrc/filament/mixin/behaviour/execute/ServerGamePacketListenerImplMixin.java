package de.tomalbrc.filament.mixin.behaviour.execute;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.ExecuteAttackItem;
import net.minecraft.class_1799;
import net.minecraft.class_2879;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImplMixin {
    @Shadow public class_3222 player;

    @Inject(method = "handleAnimate", at = @At("TAIL"))
    private void filament$handleSwing(class_2879 serverboundSwingPacket, CallbackInfo ci) {
        class_1799 itemStack = this.player.method_5998(serverboundSwingPacket.method_12512());
        if (itemStack.method_7909().isFilamentItem()) {
            ExecuteAttackItem ex = itemStack.method_7909().get(Behaviours.ITEM_ATTACK_EXECUTE);
            if (ex != null && !ex.getConfig().onEntityAttack) {
                ex.runCommandItem(this.player, itemStack.method_7909(), serverboundSwingPacket.method_12512());
            }
        }
    }
}

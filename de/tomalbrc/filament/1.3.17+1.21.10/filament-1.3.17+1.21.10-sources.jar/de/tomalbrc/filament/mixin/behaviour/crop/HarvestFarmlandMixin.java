package de.tomalbrc.filament.mixin.behaviour.crop;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.Behaviours;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1277;
import net.minecraft.class_1646;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_4099;
import net.minecraft.class_4140;
import net.minecraft.class_4142;
import net.minecraft.class_4217;
import net.minecraft.class_5712;

@Mixin(class_4217.class)
public abstract class HarvestFarmlandMixin {
    @Shadow private @Nullable class_2338 aboveFarmlandPos;

    @Shadow @Final private List<class_2338> validFarmlandAroundVillager;

    @Shadow @Nullable protected abstract class_2338 getValidFarmland(class_3218 serverLevel);

    @Shadow private long nextOkStartTime;

    @Inject(method = "validPos", at = @At("RETURN"), cancellable = true)
    private void filament$validPos(class_2338 blockPos, class_3218 serverLevel, CallbackInfoReturnable<Boolean> cir) {
        class_2680 blockState = serverLevel.method_8320(blockPos);
        if (blockState.method_26204().isFilamentBlock() && blockState.method_26204().has(Behaviours.CROP) && blockState.method_26204().getOrThrow(Behaviours.CROP).isMaxAge(blockState)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "tick(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/npc/Villager;J)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerLevel;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;", shift = At.Shift.BY, by = 3, ordinal = 1))
    private void filament$onTick(class_3218 serverLevel, class_1646 villager, long l, CallbackInfo ci, @Local class_2680 blockState, @Local(ordinal = 0) class_2248 block, @Local(ordinal = 1) class_2248 block2) {
        if (block.isFilamentBlock()) {
            if (filament$isCustomCrop(block) && block.getOrThrow(Behaviours.CROP).isMaxAge(blockState) && aboveFarmlandPos != null) {
                serverLevel.method_8651(this.aboveFarmlandPos, true, villager);

                if (blockState.method_26215() && filament$isCustomCrop(block2) && villager.method_19623()) {
                    class_1277 simpleContainer = villager.method_35199();
                    for (int i = 0; i < simpleContainer.method_5439(); ++i) {
                        class_1799 itemStack = simpleContainer.method_5438(i);
                        if (!itemStack.method_7960() && itemStack.method_31573(class_3489.field_44591) && itemStack.method_7909() instanceof class_1747 blockItem && filament$isCustomCrop(blockItem.method_7711())) {
                            class_2680 blockState2 = blockItem.method_7711().method_9564();
                            serverLevel.method_8501(this.aboveFarmlandPos, blockState2);
                            serverLevel.method_43276(class_5712.field_28164, this.aboveFarmlandPos, class_5712.class_7397.method_43286(villager, blockState2));
                        } else {
                            continue;
                        }
                        serverLevel.method_43128(null, this.aboveFarmlandPos.method_10263(), this.aboveFarmlandPos.method_10264(), this.aboveFarmlandPos.method_10260(), class_3417.field_17611, class_3419.field_15245, 1.0f, 1.0f);
                        itemStack.method_7934(1);
                        if (!itemStack.method_7960()) break;
                        simpleContainer.method_5447(i, class_1799.field_8037);
                        break;
                    }
                }

                if (!block.getOrThrow(Behaviours.CROP).isMaxAge(blockState)) {
                    this.validFarmlandAroundVillager.remove(this.aboveFarmlandPos);
                    this.aboveFarmlandPos = this.getValidFarmland(serverLevel);
                    if (this.aboveFarmlandPos != null) {
                        this.nextOkStartTime = l + 20;
                        villager.method_18868().method_18878(class_4140.field_18445, new class_4142(new class_4099(this.aboveFarmlandPos), 0.5f, 1));
                        villager.method_18868().method_18878(class_4140.field_18446, new class_4099(this.aboveFarmlandPos));
                    }
                }
            }
        }
    }

    @Unique boolean filament$isCustomCrop(class_2248 block) {
        return block.isFilamentBlock() && block.has(Behaviours.CROP) && block.getOrThrow(Behaviours.CROP).getConfig().villagerInteraction;
    }
}

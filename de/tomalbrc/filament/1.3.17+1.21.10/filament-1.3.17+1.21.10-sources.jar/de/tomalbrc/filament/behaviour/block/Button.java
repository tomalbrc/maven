package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;
import net.minecraft.class_10774;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_9902;
import net.minecraft.class_9904;

public class Button implements BlockBehaviour<Button.Config> {
    private final Config config;

    public Button(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Button.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1269 useWithoutItem(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (state.method_11654(class_2269.field_10729)) {
            return class_1269.field_21466;
        } else {
            this.press(state, level, pos, player);
            return class_1269.field_5812;
        }
    }

    @Override
    public void onExplosionHit(class_2680 state, class_3218 level, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> dropConsumer) {
        if (explosion.method_60274() && !(Boolean)state.method_11654(class_2269.field_10729)) {
            this.press(state, level, pos, null);
        }
    }

    public void press(class_2680 state, class_1937 level, class_2338 pos, @Nullable class_1657 player) {
        level.method_8652(pos, state.method_11657(class_2269.field_10729, true), class_2248.field_31036);
        this.updateNeighbours(state, level, pos);
        level.method_64310(pos, state.method_26204(), this.config.ticksToStayPressed.getValue(state));
        this.playSound(level, pos, true);
        level.method_33596(player, class_5712.field_28174, pos);
    }

    protected void playSound(class_1936 level, class_2338 pos, boolean on) {
        level.method_45447(null, pos, this.getSound(on), class_3419.field_15245);
    }

    protected class_3414 getSound(boolean on) {
        return on ? class_3414.method_47908(this.config.clickOnSound) : class_3414.method_47908(this.config.clickOffSound);
    }

    @Override
    public void affectNeighborsAfterRemoval(class_2680 state, class_3218 level, class_2338 pos, boolean movedByPiston) {
        if (!movedByPiston && state.method_11654(class_2269.field_10729)) {
            this.updateNeighbours(state, level, pos);
        }
    }

    @Override
    public int getSignal(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return state.method_11654(class_2269.field_10729) ? this.config.powerlevel.getValue(state) : 0;
    }

    @Override
    public int getDirectSignal(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return state.method_11654(class_2269.field_10729) && Lever.getConnectedDirection(state) == direction ? this.config.powerlevel.getValue(state) : 0;
    }

    @Override
    public boolean isSignalSource(class_2680 state) {
        return true;
    }

    @Override
    public void tick(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(class_2269.field_10729)) {
            this.pressCheck(state, level, pos);
        }
    }

    @Override
    public void entityInside(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity, class_10774 effectApplier) {
        if (!level.method_8608() && this.config.canBeActivatedByArrows.getValue(state) && !(Boolean)state.method_11654(class_2269.field_10729)) {
            this.pressCheck(state, level, pos);
        }
    }

    protected void pressCheck(class_2680 state, class_1937 level, class_2338 pos) {
        class_1665 abstractArrow = this.config.canBeActivatedByArrows.getValue(state) ? level.method_18467(class_1665.class, state.method_26218(level, pos).method_1107().method_996(pos)).stream().findFirst().orElse(null) : null;
        boolean hasArrowInside = abstractArrow != null;
        boolean isPowered = state.method_11654(class_2269.field_10729);
        if (hasArrowInside != isPowered) {
            level.method_8652(pos, state.method_11657(class_2269.field_10729, hasArrowInside), class_2248.field_31036);
            this.updateNeighbours(state, level, pos);
            this.playSound(level, pos, hasArrowInside);
            level.method_33596(abstractArrow, hasArrowInside ? class_5712.field_28174 : class_5712.field_28175, pos);
        }

        if (hasArrowInside) {
            level.method_64310(pos, state.method_26204(), this.config.ticksToStayPressed.getValue(state));
        }
    }

    private void updateNeighbours(class_2680 state, class_1937 level, class_2338 pos) {
        class_2350 direction = Lever.getConnectedDirection(state).method_10153();
        class_9904 orientation = class_9902.method_61826(level, direction, direction.method_10166().method_10179() ? class_2350.field_11036 : state.method_11654(class_2269.field_11177));
        level.method_8452(pos, state.method_26204(), orientation);
        level.method_8452(pos.method_10093(direction), state.method_26204(), orientation);
    }

    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2269.field_11177, class_2269.field_10729, class_2269.field_11007);
    }

    public static class Config {
        public BlockStateMappedProperty<Integer> powerlevel = BlockStateMappedProperty.of(15);
        public BlockStateMappedProperty<Integer> ticksToStayPressed = BlockStateMappedProperty.of(100);
        public BlockStateMappedProperty<Boolean> canBeActivatedByArrows = BlockStateMappedProperty.of(true);
        public class_2960 clickOnSound = class_3417.field_14699.comp_3319();
        public class_2960 clickOffSound = class_3417.field_15105.comp_3319();
    }
}
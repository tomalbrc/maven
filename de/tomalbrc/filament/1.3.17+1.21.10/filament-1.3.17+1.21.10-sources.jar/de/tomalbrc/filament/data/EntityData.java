package de.tomalbrc.filament.data;

import com.google.common.collect.ImmutableSet;
import com.google.gson.annotations.SerializedName;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.BehaviourList;
import de.tomalbrc.filament.data.properties.EntityProperties;
import de.tomalbrc.filament.entity.BiomeHelper;
import it.unimi.dsi.fastutil.objects.ObjectArraySet;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1299;
import net.minecraft.class_1972;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

public class EntityData {
    private final @NotNull class_2960 id;
    private final @Nullable class_2960 entityType;
    private final @Nullable Map<String, String> translations;
    private final @Nullable AnimationInfo animation;
    private @Nullable EntityProperties properties;
    @SerializedName(value = "behaviour", alternate = {"behaviours", "behaviors", "behavior"})
    private @Nullable BehaviourConfigMap behaviour;
    private final @Nullable BehaviourList goals;
    private final @Nullable Set<class_2960> entityTags;
    private final @Nullable Map<class_2960, Double> attributes;
    private final @Nullable SpawnInfo spawn;

    protected EntityData(
            @NotNull class_2960 id,
            @Nullable Map<String, String> translations,
            @Nullable AnimationInfo animation,
            @Nullable class_2960 entityType,
            @Nullable EntityProperties properties,
            @Nullable BehaviourList goals,
            @Nullable BehaviourConfigMap behaviour,
            @Nullable Set<class_2960> entityTags,
            @Nullable Map<class_2960, Double> attributes,
            @Nullable SpawnInfo spawn
            ) {
        this.id = id;
        this.translations = translations;
        this.animation = animation;
        this.entityType = entityType;
        this.properties = properties;
        this.behaviour = behaviour;
        this.goals = goals;
        this.entityTags = entityTags;
        this.attributes = attributes;
        this.spawn = spawn;
    }

    public @NotNull class_2960 id() {
        return id;
    }

    public @NotNull class_2960 entityType() {
        return entityType == null ? class_7923.field_41177.method_10221(class_1299.field_6093) : entityType;
    }

    public @Nullable Map<String, String> translations() {
        return translations;
    }

    public @Nullable AnimationInfo animation() {
        return animation;
    }

    public @NotNull BehaviourConfigMap behaviour() {
        if (behaviour == null)
            behaviour = new BehaviourConfigMap();
        return behaviour;
    }

    public @Nullable Set<class_2960> entityTags() {
        return entityTags;
    }

    public @Nullable Map<class_2960, Double> attributes() {
        return attributes;
    }

    public @NotNull EntityProperties properties() {
        if (properties == null) {
            properties = new EntityProperties();
        }

        return properties;
    }

    @NotNull
    public BehaviourList goals() {
        return goals == null ? BehaviourList.EMPTY : goals;
    }

    @Nullable
    public SpawnInfo spawn() {
        return spawn;
    }

    public record AnimationInfo(
            class_2960 model,
            String idleAnimation,
            String walkAnimation
    ) {}

    public record SpawnInfo(
        int weight,
        int minGroupSize,
        int maxGroupSize,
        boolean foundInOverworld,
        boolean foundInNether,
        boolean foundInEnd,
        Set<class_2960> spawnsLike,
        Set<class_2960> biomes,
        Set<class_2960> biomeTags
    ) {
        public void add(class_1299<?> entityType) {
            Set<class_1299<?>> spawns = spawnsLike == null ? ImmutableSet.of() : null;
            if (spawns == null) {
                spawns = new ObjectArraySet<>();
                for (class_2960 resourceLocation : spawnsLike) {
                    spawns.add(class_7923.field_41177.method_63535(resourceLocation));
                }
            }

            Predicate<BiomeSelectionContext> biomeSelectors = spawns.isEmpty() ? ((x) -> false) : BiomeSelectors.spawnsOneOf(spawns);
            if (biomes != null) biomeSelectors = biomeSelectors.or(BiomeSelectors.includeByKey(class_1972.field_9471, class_1972.field_38748));
            if (biomeTags != null) {
                for (class_2960 tag : biomeTags) {
                    biomeSelectors = biomeSelectors.or(BiomeSelectors.tag(class_6862.method_40092(class_7924.field_41236, tag)));
                }
            }

            if (foundInOverworld) biomeSelectors = biomeSelectors.and(BiomeSelectors.foundInOverworld());
            if (foundInNether) biomeSelectors = biomeSelectors.and(BiomeSelectors.foundInTheNether());
            if (foundInEnd) biomeSelectors = biomeSelectors.and(BiomeSelectors.foundInTheEnd());

            BiomeHelper.addSpawn(entityType, weight, minGroupSize, maxGroupSize, biomeSelectors);
        }
    }
}

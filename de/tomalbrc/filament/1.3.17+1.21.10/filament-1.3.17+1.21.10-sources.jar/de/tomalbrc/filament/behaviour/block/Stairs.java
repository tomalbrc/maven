package de.tomalbrc.filament.behaviour.block;

import com.google.gson.JsonParseException;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.data.AbstractBlockData;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.util.FilamentBlockResourceUtils;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2760;
import net.minecraft.class_2778;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;

public class Stairs implements BlockBehaviour<Stairs.Config>, class_3737 {
  private final Config config;

  public Stairs(Config config) {
    this.config = config;
  }

  @Override
  @NotNull
  public Stairs.Config getConfig() {
    return this.config;
  }

  @Override
  public class_2680 modifyDefaultState(class_2680 blockState) {
    return blockState.method_11657(class_2510.field_11571, class_2350.field_11043).method_11657(class_2510.field_11572, class_2760.field_12617).method_11657(class_2510.field_11565, class_2778.field_12710).method_11657(class_2510.field_11573, false);
  }

  @Override
  public Optional<Boolean> useShapeForLightOcclusion(class_2680 blockState) {
    return Optional.of(false);
  }

  @Override
  public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
    builder.method_11667(class_2510.field_11571, class_2510.field_11572, class_2510.field_11565, class_2510.field_11573);
  }
  private static boolean canTakeShape(class_2680 state, class_1922 level, class_2338 pos, class_2350 face) {
    class_2680 blockState = level.method_8320(pos.method_10093(face));
    return !isStairs(blockState) || blockState.method_11654(class_2510.field_11571) != state.method_11654(class_2510.field_11571) || blockState.method_11654(class_2510.field_11572) != state.method_11654(class_2510.field_11572);
  }

  public static boolean isStairs(class_2680 state) {
    if(state.method_26204() instanceof class_2510) {
      return true;
    }
    else if(state.method_26204() instanceof SimpleBlock) {
      for(Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behavior: ((SimpleBlock) state.method_26204()).getBehaviours()) {
        if(behavior.getKey().id().toString().equals("filament:stairs")) return true;
      }
    }
    return false;
  }

  private static class_2778 getStairsShape(class_2680 state, class_1922 level, class_2338 pos) {
    class_2350 direction = state.method_11654(class_2510.field_11571);
    class_2680 blockState = level.method_8320(pos.method_10093(direction));
    if (isStairs(blockState) && state.method_11654(class_2510.field_11572) == blockState.method_11654(class_2510.field_11572)) {
      class_2350 direction2 = blockState.method_11654(class_2510.field_11571);
      if (direction2.method_10166() != state.method_11654(class_2510.field_11571).method_10166() && canTakeShape(state, level, pos, direction2.method_10153())) {
        if (direction2 == direction.method_10160()) {
          return class_2778.field_12708;
        }

        return class_2778.field_12709;
      }
    }

    class_2680 blockState2 = level.method_8320(pos.method_10093(direction.method_10153()));
    if (isStairs(blockState2) && state.method_11654(class_2510.field_11572) == blockState2.method_11654(class_2510.field_11572)) {
      class_2350 direction3 = blockState2.method_11654(class_2510.field_11571);
      if (direction3.method_10166() != state.method_11654(class_2510.field_11571).method_10166() && canTakeShape(state, level, pos, direction3)) {
        if (direction3 == direction.method_10160()) {
          return class_2778.field_12712;
        }

        return class_2778.field_12713;
      }
    }

    return class_2778.field_12710;
  }

  @Override
  public class_2680 getStateForPlacement(class_2680 prevBlockState, class_1750 context) {
    class_2350 direction = context.method_8038();
    class_2338 blockPos = context.method_8037();
    class_3610 fluidState = context.method_8045().method_8316(blockPos);
    class_2680 blockState = this.modifyDefaultState(prevBlockState).method_11657(class_2510.field_11571, context.method_8042()).method_11657(class_2510.field_11572, direction != class_2350.field_11033 && (direction == class_2350.field_11036 || !(context.method_17698().field_1351 - (double)blockPos.method_10264() > (double)0.5F)) ? class_2760.field_12617 : class_2760.field_12619).method_11657(class_2510.field_11573, fluidState.method_15772() == class_3612.field_15910);
    return blockState.method_11657(class_2510.field_11565, getStairsShape(blockState, context.method_8045(), blockPos));

  }

  @Override
  public Optional<Boolean> canBeReplaced(class_2680 blockState, class_1750 blockPlaceContext) {
    return Optional.of(false);
  }

  @Override
  public class_3610 getFluidState(class_2680 blockState) {
    if (blockState.method_11654(class_2510.field_11573)) {
      return class_3612.field_15910.method_15729(false);
    }
    return null;
  }

  @Override
  public boolean method_10311(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_3610 fluidState) {
    return class_3737.super.method_10311(levelAccessor, blockPos, blockState, fluidState);
  }

  @Override
  public boolean method_10310(@Nullable class_1309 livingEntity, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3611 fluid) {
    return class_3737.super.method_10310(livingEntity, blockGetter, blockPos, blockState, fluid);
  }

  @Override
  public class_2680 updateShape(class_2680 state, class_4538 level, class_10225 scheduledTickAccess, class_2338 pos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
    if (state.method_11654(class_2510.field_11573)) {
      scheduledTickAccess.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
    }
    return direction.method_10166().method_10179() ? state.method_11657(class_2510.field_11565, getStairsShape(state, level, pos)) : state;
  }

  @Override
  public Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
    return switch (pathComputationType) {
      case field_50, field_51 -> Optional.of(false);
      case field_48 -> Optional.of(blockState.method_26227().method_15767(class_3486.field_15517));
    };
  }

  public static BlockModelType getStairs(class_2350 direction, class_2760 blockHalf, class_2778 shape, boolean waterlogged) {
    if (direction.method_10166().method_10178()) {
      throw new IllegalArgumentException("Only horizontal directions are supported!");
    }

    var self = new StringBuilder();
    self.append("STAIRS_").append(direction.name())
            .append("_").append(blockHalf.name())
            .append("_").append(shape.name());


    if (waterlogged) {
      self.append("_WATERLOGGED");
    }

    // Bit ugly, but works
    return BlockModelType.valueOf(self.toString());
  }

  @Override
  public boolean modifyStateMap(Map<class_2680, BlockData.BlockStateMeta> map, AbstractBlockData<? extends BlockProperties> data) {
    for (Map.Entry<String, PolymerBlockModel> entry : data.blockResource().models().entrySet()) {
      PolymerBlockModel blockModel = entry.getValue();

      class_2259.class_7211 parsed;
      String str = String.format("%s[%s]", data.id(), entry.getKey());
      try {
        parsed = class_2259.method_41957(class_7923.field_41175, str, false);
      } catch (CommandSyntaxException e) {
        throw new JsonParseException("Invalid BlockState value: " + str);
      }

      class_2680 state = parsed.comp_622();
      BlockModelType stairState = getStairs(
              state.method_11654(class_2510.field_11571),
              state.method_11654(class_2510.field_11572),
              state.method_11654(class_2510.field_11565),
              false
      );

      class_2680 requestedState = FilamentBlockResourceUtils.requestBlock(stairState, blockModel, data.virtual());
      map.put(parsed.comp_622(), BlockData.BlockStateMeta.of(requestedState, blockModel));
    }
    for (Map.Entry<class_2680, BlockData.BlockStateMeta> entry : map.entrySet()) {
      var blockState = entry.getValue().blockState();
      if (blockState.method_28498(class_2510.field_11573) && !blockState.method_11654(class_2510.field_11573)) {
        BlockModelType stairStateWet = getStairs(
                blockState.method_11654(class_2510.field_11571),
                blockState.method_11654(class_2510.field_11572),
                blockState.method_11654(class_2510.field_11565),
                true
        );
        var res = FilamentBlockResourceUtils.requestBlock(stairStateWet, entry.getValue().polymerBlockModel(), data.virtual());
        map.put(entry.getKey().method_11657(class_2510.field_11573, true), BlockData.BlockStateMeta.of(res, entry.getValue().polymerBlockModel()));
      }
    }

    return true;
  }

  public static class Config {
  }
}

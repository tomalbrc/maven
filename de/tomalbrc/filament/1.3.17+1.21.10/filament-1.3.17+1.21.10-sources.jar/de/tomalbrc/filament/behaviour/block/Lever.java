package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2401;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_9902;
import net.minecraft.class_9904;

public class Lever implements BlockBehaviour<Lever.Config> {
    private final Config config;

    public Lever(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Lever.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        this.cycle(blockState, level, blockPos);
        return class_1269.field_5812;
    }

    public void onExplosionHit(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
        if (explosion.method_60274()) {
            this.cycle(blockState, serverLevel, blockPos);
        }
    }

    private void cycle(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        blockState = blockState.method_28493(class_2401.field_11265);
        level.method_8652(blockPos, blockState, class_2248.field_31036);
        this.updateNeighbours(blockState, level, blockPos);
        playSound(null, level, blockPos, blockState);
        level.method_33596(null, blockState.method_11654(class_2401.field_11265) ? class_5712.field_28174 : class_5712.field_28175, blockPos);
    }

    protected void playSound(@Nullable class_1657 player, class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState) {
        float pitch = config.pitch.getOrDefault(blockState, blockState.method_11654(class_2401.field_11265) ? 0.6F : 0.5F);
        levelAccessor.method_8396(player, blockPos, class_3414.method_47908(config.sound.getValue(blockState)), class_3419.field_15245, config.volume.getValue(blockState), pitch);
    }

    @Override
    public void affectNeighborsAfterRemoval(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, boolean bl) {
        if (!bl && blockState.method_11654(class_2401.field_11265)) {
            this.updateNeighbours(blockState, serverLevel, blockPos);
        }

    }

    @Override
    public int getSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return blockState.method_11654(class_2401.field_11265) ? config.powerlevel.getValue(blockState) : 0;
    }

    @Override
    public int getDirectSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return blockState.method_11654(class_2401.field_11265) && getConnectedDirection(blockState) == direction ? config.powerlevel.getValue(blockState) : 0;
    }

    @Override
    public boolean isSignalSource(class_2680 blockState) {
        return true;
    }

    private void updateNeighbours(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        class_2350 direction = getConnectedDirection(blockState).method_10153();
        class_9904 orientation = class_9902.method_61826(level, direction, direction.method_10166().method_10179() ? class_2350.field_11036 : blockState.method_11654(class_2401.field_11177));
        level.method_8452(blockPos, blockState.method_26204(), orientation);
        level.method_8452(blockPos.method_10093(direction), blockState.method_26204(), orientation);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2401.field_11007, class_2401.field_11177, class_2401.field_11265);
    }

    static class_2350 getConnectedDirection(class_2680 state) {
        return switch (state.method_11654(class_2401.field_11007)) {
            case field_12473 -> class_2350.field_11033;
            case field_12475 -> class_2350.field_11036;
            default -> state.method_11654(class_2401.field_11177);
        };
    }

    public static class Config {
        public BlockStateMappedProperty<Integer> powerlevel = BlockStateMappedProperty.of(15);
        public BlockStateMappedProperty<class_2960> sound = BlockStateMappedProperty.of(class_3417.field_14962.comp_3319());
        public BlockStateMappedProperty<Float> volume = BlockStateMappedProperty.of(0.3f);
        public BlockStateMappedProperty<Float> pitch = BlockStateMappedProperty.empty();
    }
}
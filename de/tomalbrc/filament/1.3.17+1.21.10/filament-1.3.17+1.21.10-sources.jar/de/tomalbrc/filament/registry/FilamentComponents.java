package de.tomalbrc.filament.registry;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.TextUtil;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.other.PolymerComponent;
import net.minecraft.class_1277;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9135;
import net.minecraft.class_9288;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public class FilamentComponents {
    public static final class_9331<class_1799> SKIN_DATA_COMPONENT = new class_9331.class_9332<class_1799>().method_57881(class_1799.field_24671).method_57882(class_1799.field_48349).method_57880();
    public static final class_9331<class_6885<class_1792>> SKIN_COMPONENT = new class_9331.class_9332<class_6885<class_1792>>().method_57881(class_6895.method_40340(class_7924.field_41197)).method_57882(class_9135.method_58001(class_7924.field_41197)).method_57880();

    public static final class_9331<BackpackOptions> BACKPACK = new class_9331.class_9332<BackpackOptions>().method_57881(BackpackOptions.CODEC).method_57880();

    public static void register() {
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(Constants.MOD_ID, "skin_data"), SKIN_DATA_COMPONENT);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(Constants.MOD_ID, "skin"), SKIN_COMPONENT);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(Constants.MOD_ID, "backpack"), BACKPACK);

        PolymerComponent.registerDataComponent(SKIN_COMPONENT);
        PolymerComponent.registerDataComponent(SKIN_DATA_COMPONENT);
        PolymerComponent.registerDataComponent(BACKPACK);
    }

    public record BackpackOptions(int size, boolean preventPlacement, String titlePrefix, boolean sneakOnly) {
        public static final Codec<BackpackOptions> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        Codec.INT.optionalFieldOf("size", 27).forGetter(BackpackOptions::size),
                        Codec.BOOL.optionalFieldOf("prevent_placement", false).forGetter(BackpackOptions::preventPlacement),
                        Codec.STRING.optionalFieldOf("title_prefix", "").forGetter(BackpackOptions::titlePrefix),
                        Codec.BOOL.optionalFieldOf("sneak_only", false).forGetter(BackpackOptions::sneakOnly)
                ).apply(instance, BackpackOptions::new)
        );

        public void open(class_1799 itemStack, class_3222 player) {
            class_9288 container = itemStack.method_58694(class_9334.field_49622);
            if (container != null) {
                final int selectedSlot = player.method_31548().method_67532();
                class_1277 container1 = new class_1277(size);
                container.method_57492(container1.field_5828);
                container1.method_5489(x -> itemStack.method_57379(class_9334.field_49622, class_9288.method_57493(container1.field_5828)));

                class_3908 provider = new class_747((id, inventory, p) -> Util.createMenu(container1, id, player, selectedSlot), class_2561.method_43473().method_10852(TextUtil.formatText(this.titlePrefix())).method_10852(itemStack.method_58695(class_9334.field_49631, itemStack.method_58694(class_9334.field_50239))));
                player.method_17355(provider);
            }
        }
    }
}

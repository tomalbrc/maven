package de.tomalbrc.filament.mixin.component.backpack;

import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2624;
import net.minecraft.class_9323;
import net.minecraft.class_9473;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2624.class)
public class BaseContainerBlockEntityMixin {
    @Unique
    FilamentComponents.BackpackOptions filament$backpackOptions;

    @Inject(method = "applyImplicitComponents", at = @At(value = "TAIL"))
    private void filament$backpackApplyImplicitComponents(class_9473 dataComponentGetter, CallbackInfo ci) {
        var bp = dataComponentGetter.method_58694(FilamentComponents.BACKPACK);
        if (bp != null)
            filament$backpackOptions = bp;
    }

    @Inject(method = "collectImplicitComponents", at = @At(value = "TAIL"))
    private void filament$backpackCollectImplicitComponents(class_9323.class_9324 builder, CallbackInfo ci) {
        if (filament$backpackOptions != null)
            builder.method_57840(FilamentComponents.BACKPACK, filament$backpackOptions);
    }

    @Inject(method = "removeComponentsFromTag", at = @At(value = "TAIL"))
    private void filament$backpackRemoveComponentsFromTag(class_11372 valueOutput, CallbackInfo ci) {
        valueOutput.method_71478("Backpack");
    }

    @Inject(method = "loadAdditional", at = @At(value = "TAIL"))
    private void filament$backpackLoadAdditional(class_11368 valueInput, CallbackInfo ci) {
        valueInput.method_71426("Backpack", FilamentComponents.BackpackOptions.CODEC).ifPresent(x -> {
            this.filament$backpackOptions = x;
        });
    }

    @Inject(method = "saveAdditional", at = @At(value = "TAIL"))
    private void filament$backpackSaveAdditional(class_11372 valueOutput, CallbackInfo ci) {
        if (this.filament$backpackOptions != null) {
            valueOutput.method_71468("Backpack", FilamentComponents.BackpackOptions.CODEC, filament$backpackOptions);
        }
    }
}

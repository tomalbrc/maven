package de.tomalbrc.filament.gui;

import net.minecraft.class_1263;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_3917;

// "almost vanilla chest menu" but with checks to prevent placement of shulkers & friends into portable filament containers
// and hotbar slot-locking
public class FilamentChestMenu extends class_1707 {
    int lockSlot;

    public FilamentChestMenu(class_3917<?> menuType, int id, class_1661 inventory, class_1263 container, int lockSlot) {
        super(menuType, id, inventory, container, container.method_5439() / 9);
        this.lockSlot = lockSlot;
    }

    @Override
    protected void method_61622(class_1263 container, int x, int y) {
        if (lockSlot == -1) {
            super.method_61622(container, x, y);
        } else {
            for(int i = 0; i < 9; ++i) {
                this.method_7621(new BackpackHotbarSlot(container, lockSlot, i, x + i * 18, y));
            }
        }
    }

    @Override
    public void method_61634(class_1263 container, int i, int j) {
        for (int y = 0; y < this.method_17388(); ++y) {
            for (int x = 0; x < 9; ++x) {
                this.method_7621(new BackpackContainerSlot(container, x, y, i, j, lockSlot != -1));
            }
        }
    }
}

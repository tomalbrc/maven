package de.tomalbrc.filament.gui;

import de.tomalbrc.filament.registry.FilamentComponents;
import de.tomalbrc.filament.util.FilamentContainer;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

class BackpackContainerSlot extends class_1735 {
    private final boolean fromBackpack;

    public BackpackContainerSlot(class_1263 container, int x, int y, int i, int j, boolean fromBackpack) {
        super(container, x + y * 9, i + x * 18, j + y * 18);
        this.fromBackpack = fromBackpack;
    }

    @Override
    public boolean method_7680(class_1799 itemStack) {
        if (FilamentContainer.isPickUpContainer(field_7871) || fromBackpack)
            return itemStack.method_7909().method_31568() && (!FilamentContainer.isPickUpContainer(field_7871) && !itemStack.method_57826(FilamentComponents.BACKPACK));

        return super.method_7680(itemStack);
    }
}

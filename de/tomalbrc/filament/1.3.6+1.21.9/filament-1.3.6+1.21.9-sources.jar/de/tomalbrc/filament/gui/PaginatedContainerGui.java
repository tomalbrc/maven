package de.tomalbrc.filament.gui;

import de.tomalbrc.filament.util.FilamentConfig;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.Util;
import eu.pb4.sgui.api.GuiHelpers;
import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import net.minecraft.class_124;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_9334;

public class PaginatedContainerGui extends SimpleGui {
    GuiElementBuilder empty = GuiElementBuilder.from(class_1802.field_8407.method_7854())
            .hideDefaultTooltip()
            .setComponent(class_9334.field_50071, 1)
            .hideTooltip()
            .model(FilamentConfig.getInstance().addCustomMenuAssets ? Util.id("blank_gui") : class_1802.field_8162.method_57347().method_58694(class_9334.field_54199));

    private final class_1263 container;
    private final boolean fromBackpack;
    private int currentPage = 0;

    public PaginatedContainerGui(class_3917<?> type, class_3222 player, boolean manipulatePlayerSlots, class_1263 container, boolean fromBackpack) {
        super(type, player, manipulatePlayerSlots);
        this.container = container;
        this.fromBackpack = fromBackpack;
        populateFromContainer(currentPage);
    }

    private int slotsPerPage() {
        int w = this.getWidth();
        int h = this.getHeight() - 1;
        return w*h;
    }

    private void populateButtons() {
        int pages = Math.max(0, (this.container.method_5439() - 1) / slotsPerPage());
        for (int i = 0; i < getWidth(); i++) {
            this.setSlot(GuiHelpers.posToIndex(i, getHeight() - 1, getHeight(), getWidth()), empty.build());
        }

        // prev
        int prevIdx = GuiHelpers.posToIndex(3, getHeight() - 1, getHeight(), getWidth());
        if (currentPage > 0) this.setSlot(
                prevIdx,
                GuiElementBuilder.from(class_1802.field_8407.method_7854())
                        .hideDefaultTooltip()
                        .setName(class_2561.method_43471("book.page_button.previous"))
                        .addLoreLine(class_2561.method_43469("book.pageIndicator", class_2561.method_43470(String.valueOf(currentPage+1)), class_2561.method_43470(String.valueOf(pages+1))).method_27692(class_124.field_1063))
                        .model(Util.id("previous_gui"))
                        .setCallback(() -> {
                            Util.clickSound(player);
                            if (currentPage > 0) {
                                populateFromContainer(currentPage - 1);
                            }
                        })
        );

        // next
        int nextIdx = GuiHelpers.posToIndex(getWidth()-4, getHeight() - 1, getHeight(), getWidth());
        if (currentPage < pages) this.setSlot(
                nextIdx,
                GuiElementBuilder.from(class_1802.field_8407.method_7854())
                        .hideDefaultTooltip()
                        .setName(class_2561.method_43471("book.page_button.next"))
                        .addLoreLine(class_2561.method_43469("book.pageIndicator", class_2561.method_43470(String.valueOf(currentPage+1)), class_2561.method_43470(String.valueOf(pages+1))).method_27692(class_124.field_1063))
                        .model(Util.id("next_gui"))
                        .setCallback(() -> {
                            Util.clickSound(player);
                            int slotsPerPage = getWidth() * (getHeight() - 1);
                            int maxPage = Math.max(0, (container.method_5439() - 1) / slotsPerPage);
                            if (currentPage < maxPage) {
                                populateFromContainer(currentPage + 1);
                            }
                        })
        );
    }

    private void populateFromContainer(int page) {
        int w = this.getWidth();
        int h = this.getHeight() - (getHeight() == 1 ? 0 : 1); // bottom row for buttons

        int containerSize = this.container.method_5439();
        int slotsPerPage = slotsPerPage();
        int startIndex = page * slotsPerPage;

        if (startIndex >= containerSize) {
            currentPage = Math.max(0, (containerSize - 1) / slotsPerPage);
            startIndex = currentPage * slotsPerPage;
        } else if (page < 0) {
            currentPage = 0;
            startIndex = 0;
        } else {
            currentPage = page;
        }

        int xOffset = 0;
        boolean singleRowMode = h == 1 && containerSize <= w;
        if (singleRowMode) {
            xOffset = (w - containerSize) / 2;
        }

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int slotInGui = GuiHelpers.posToIndex(x, y, h, w);

                int slotInContainer;
                if (singleRowMode) {
                    int adjustedX = x - xOffset;
                    slotInContainer = (adjustedX >= 0 && adjustedX < containerSize) ? adjustedX : -1;
                } else {
                    slotInContainer = startIndex + (y * w + x);
                }

                if (slotInContainer >= 0 && slotInContainer < containerSize) {
                    this.setSlotRedirect(slotInGui, createSlot(container, slotInContainer));
                } else {
                    this.setSlot(slotInGui, empty.build());
                }
            }
        }

        if (getHeight() > 1) populateButtons();
    }

    public void setScreenHandler(VirtualChestMenu virtualChestMenu) {
        screenHandler = virtualChestMenu;
    }

    public class_1263 getContainer() {
        return container;
    }

    public class_1735 createSlot(class_1263 containerx, int slotInContainer) {
        return new BackpackContainerSlot(containerx, slotInContainer, 0, 0, 0, this.fromBackpack) {
            @Override
            public int method_7676(class_1799 itemStack) {
                return containerx instanceof FilamentContainer filamentContainer ? filamentContainer.getMaxStackSize(slotInContainer) : containerx.method_58350(itemStack);
            }
        };
    }
}

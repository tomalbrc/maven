package de.tomalbrc.filament.registry;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonParser;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.types.Type;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.data.EntityData;
import de.tomalbrc.filament.decoration.util.SeatEntity;
import de.tomalbrc.filament.entity.AnimatedFilamentEnemyMob;
import de.tomalbrc.filament.entity.AnimatedFilamentMob;
import de.tomalbrc.filament.entity.FilamentEnemyMob;
import de.tomalbrc.filament.entity.FilamentMob;
import de.tomalbrc.filament.item.BaseProjectileEntity;
import de.tomalbrc.filament.item.TridentEntity;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.FilamentSynchronousResourceReloadListener;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Translations;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_5132;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;

@SuppressWarnings({"unchecked", "rawtypes"})
public class EntityRegistry {
    public static Map<class_2960, Collection<class_2960>> ENTITY_TAGS = new Object2ReferenceOpenHashMap<>();

    private static final Reference2ObjectOpenHashMap<class_2960, EntityData> types = new Reference2ObjectOpenHashMap<>();

    public static final class_1299<BaseProjectileEntity> BASE_PROJECTILE = registerEntity("projectile", class_1299.class_1300.method_5903(BaseProjectileEntity::new, class_1311.field_17715).method_17687(0.5f, 0.5f).method_5901());
    public static final class_1299<TridentEntity> FILAMENT_TRIDENT = registerEntity("trident", class_1299.class_1300.method_5903(TridentEntity::new, class_1311.field_17715).method_17687(0.5f, 0.5f).method_55687(0.13f).method_5901());
    public static final class_1299<SeatEntity> SEAT_ENTITY =  registerEntity("decoration_seat", class_1299.class_1300.method_5903(SeatEntity::new, class_1311.field_17715).method_5901().method_27300(20).method_17687(0.5f, 0.1f));

    public static void register(InputStream inputStream) throws IOException {
        var element = JsonParser.parseReader(new InputStreamReader(inputStream));
        EntityData data = Json.GSON.fromJson(element, EntityData.class);
        register(data);
    }

    static public void register(EntityData data) {
        if (class_7923.field_41177.method_10250(data.id())) return;
        types.put(data.id(), data);

        var size = (data.properties().size == null || Objects.requireNonNull(data.properties().size).size() < 2) ? ImmutableList.of(1.f, 1.f) : data.properties().size;
        assert size != null;

        class_1299.class_1300 builder;
        if (data.animation() != null && data.animation().model() != null) {
            builder = class_1299.class_1300.method_5903(data.properties().forceEnemy ? AnimatedFilamentEnemyMob::new : AnimatedFilamentMob::new, data.properties().category).method_17687(size.getFirst(), size.getLast());
        } else {
            builder = class_1299.class_1300.method_5903(data.properties().forceEnemy ? FilamentEnemyMob::new : FilamentMob::new, data.properties().category).method_17687(size.getFirst(), size.getLast());
        }

        if (data.properties().fireImmune)
            builder.method_19947();
        if (data.properties().noSave)
            builder.method_5904();
        if (data.properties().noSummon)
            builder.method_5901();
        // TODO: 1.21.1
        //if (data.properties().shouldDespawnInPeaceful)
        //    builder.notInPeaceful();

        class_5132.class_5133 attributeBuilder = class_1308.method_26828();
        var attrMap = data.attributes();
        if (attrMap != null) {
            for (Map.Entry<class_2960, Double> entry : attrMap.entrySet()) {
                var attr = class_7923.field_41190.method_55841(entry.getKey());
                if (attr.isEmpty()) {
                    Filament.LOGGER.error("Invalid attribute id {} for entity {}", entry.getKey(), data.id());
                    continue;
                }
                attributeBuilder.method_26868(attr.orElseThrow(), entry.getValue());
            }
        }

        var type = registerEntity(data.id(), builder);
        FabricDefaultAttributeRegistry.register(type, attributeBuilder.method_26866());

        Translations.add(type, data);

        if (data.entityTags() != null) for (class_2960 tag : data.entityTags()) {
            var list = ENTITY_TAGS.computeIfAbsent(tag, x -> new ArrayList<>());
            list.add(data.id());
        }

        if (data.spawn() != null) {
            data.spawn().add(type);
        }

        FilamentRegistrationEvents.ENTITY.invoker().registered(data, type);
    }

    public static EntityData getData(class_2960 resourceLocation) {
        return types.get(resourceLocation);
    }

    public static void register() {
    }

    private static <T extends class_1297> class_1299 registerEntity(String str, class_1299.class_1300 type) {
        var id = class_2960.method_60655(Constants.MOD_ID, str);
        return registerEntity(id, type);
    }

    private static <T extends class_1297> class_1299 registerEntity(class_2960 id, class_1299.class_1300 type) {
        var res = class_2378.method_10230(class_7923.field_41177, id, type.method_5905(id.toString()));
        PolymerEntityUtils.registerType(res);
        return res;
    }

    public static class_5321<class_2591<?>> key(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41255, id);
    }

    public static void registerBlockEntity(class_5321<class_2591<?>> id, class_2591<?> type) {
        class_2378.method_39197(class_7923.field_41181, id, type);
        PolymerBlockUtils.registerBlockEntity(type);
    }


    public static class EntityDataReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "entities");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            load("filament/entity", null, resourceManager, (id, inputStream) -> {
                try {
                    EntityRegistry.register(inputStream);
                } catch (IOException e) {
                    Filament.LOGGER.error("Failed to load entity resource \"{}\".", id);
                }
            });
        }
    }
}

package de.tomalbrc.filament.behaviour.decoration;

import com.google.gson.*;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.ContainerLike;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.holder.FilamentDecorationHolder;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.TextUtil;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.elements.BlockDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.tracker.DisplayTrackedData;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4538;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_747;
import net.minecraft.class_7924;
import net.minecraft.class_811;
import net.minecraft.class_9288;
import net.minecraft.class_9297;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.lang.reflect.Type;
import java.util.List;

/**
 * For item showcase decoration
 */
public class Showcase implements BlockBehaviour<Showcase.Config>, DecorationBehaviour<Showcase.Config>, ContainerLike {
    private static final String SHOWCASE_KEY = "Showcase";
    private static final String ITEM = "Item";

    private final Config config;

    private final Object2ObjectOpenHashMap<ShowcaseMeta, DisplayElement> showcases = new Object2ObjectOpenHashMap<>();

    private FilamentContainer container;
    public class_5321<class_52> lootTable;
    public long lootTableSeed;

    public Showcase(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Showcase.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        this.container = new FilamentContainer(blockEntity, config.elements.size(), false) {
            @Override
            public int getMaxStackSize(int slot) {
                return config.elements.get(slot).maxStackSize;
            }
        };

        this.container.method_5489(x -> {
            for (int i = 0; i < x.method_5439(); i++) {
                var stack = x.method_5438(i);
                setShowcaseItemStack(blockEntity, config.elements.get(i), stack);
            }
        });
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (!player.method_21823() && decorationBlockEntity.getOrCreateHolder() != null) {
            if (config.useMenu) {
                class_2561 containerName = customName() != null && showCustomName() ? customName() : TextUtil.formatText(config.name);
                player.method_17355(new class_747((id, inventory, p) -> Util.createMenu(container, id, p), containerName));
                return class_1269.field_5812;
            }

            Showcase.ShowcaseMeta showcase = getClosestShowcase(decorationBlockEntity, location);
            class_1799 itemStack = player.method_5998(hand);
            class_1799 showcaseStack = this.getShowcaseItemStack(showcase);

            if (this.canUseShowcaseItem(showcase, itemStack)) {
                boolean changed = false;
                if (!player.method_5998(hand).method_7960()) {
                    changed = true;
                    if (showcaseStack != null && !showcaseStack.method_7960()) {
                        Util.spawnAtLocation(decorationBlockEntity.method_10997(), location, showcaseStack);
                    }

                    var count = container.getMaxStackSize(0);
                    this.container.method_5447(config.elements.indexOf(showcase), itemStack.method_46651(count));
                    itemStack.method_7934(count);
                    player.method_37908().method_43128(null, location.method_10216(), location.method_10214(), location.method_10215(), class_3414.method_47908(showcase.addItemSound), class_3419.field_15254, 1.0f, 1.0f);
                } else if (showcaseStack != null && !showcaseStack.method_7960()) {
                    changed = true;
                    player.method_6122(hand, showcaseStack);
                    this.container.method_5447(config.elements.indexOf(showcase), class_1799.field_8037);
                    player.method_37908().method_43128(null, location.method_10216(), location.method_10214(), location.method_10215(), class_3414.method_47908(showcase.removeItemSound), class_3419.field_15254, 1.0f, 1.0f);
                }

                if (changed) {
                    decorationBlockEntity.method_5431();
                    return class_1269.field_21466;
                }
            }
        }

        return class_1269.field_5811;
    }

    @Override
    public void read(class_2487 input, class_7225.class_7874 lookup, DecorationBlockEntity blockEntity) {
        if (!container.method_54871(input)) {
            if (input.method_10545(SHOWCASE_KEY) && blockEntity.getOrCreateHolder() != null) {
                var showcaseTag = input.method_10562(SHOWCASE_KEY);

                for (int i = 0; i < this.config.elements.size(); i++) {
                    String key = ITEM + i;
                    if (showcaseTag.method_10545(key)) {
                        var itemData = showcaseTag.method_10580(key);
                        container.field_5828.set(i, class_1799.field_24671.decode(lookup.method_57093(class_2509.field_11560), itemData).getOrThrow().getFirst());
                    }
                }
                container.method_5431();
            }
        }
        container.method_54873(null);
    }

    @Override
    public void write(class_2487 output, class_7225.class_7874 lookup, DecorationBlockEntity blockEntity) {
        if (!container.method_54872(output)) {
            if (blockEntity.getOrCreateHolder() != null) {
                class_2487 showcaseTag = output.method_10562(SHOWCASE_KEY);

                for (int i = 0; i < config.elements.size(); i++) {
                    Showcase.ShowcaseMeta showcase = config.elements.get(i);
                    if (showcase != null && !getShowcaseItemStack(showcase).method_7960())
                        showcaseTag.method_10566(ITEM + i, class_1799.field_24671.encodeStart(lookup.method_57093(class_2509.field_11560), getShowcaseItemStack(showcase)).getOrThrow());
                }

                output.method_10566(SHOWCASE_KEY, showcaseTag);
            }
        }
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        container.setValid(false);

        if (!config.canPickup) {
            class_1264.method_5451(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016(), container);
        }
    }

    public Showcase.ShowcaseMeta getClosestShowcase(DecorationBlockEntity decorationBlockEntity, class_243 location) {
        if (config.elements.size() == 1) {
            return config.elements.getFirst();
        } else {
            double dist = Double.MAX_VALUE;
            Showcase.ShowcaseMeta nearest = null;
            for (Showcase.ShowcaseMeta showcase : config.elements) {
                class_243 q = decorationBlockEntity.method_11016().method_46558().method_1019(new class_243(this.showcaseTranslation(showcase).rotateY((-decorationBlockEntity.getVisualRotationYInDegrees() + 180) * class_3532.field_29847)));
                double distance = q.method_1022(location);

                if (distance < dist) {
                    dist = distance;
                    nearest = showcase;
                }
            }

            return nearest;
        }
    }

    private Vector3f showcaseTranslation(Showcase.ShowcaseMeta showcase) {
        return new Vector3f(showcase.offset).sub(0, 0.475f, 0).rotateY(class_3532.field_29844);
    }

    public void setShowcaseItemStack(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        FilamentDecorationHolder holder = decorationBlockEntity.getOrCreateHolder();
        if (holder == null)
            return;

        boolean isBlockItem = itemStack.method_7909() instanceof class_1747 blockItem && !(blockItem.method_7711() instanceof DecorationBlock);

        DisplayElement element = this.showcases.get(showcase);

        DisplayElement newElement;

        boolean dynNeedsUpdate = showcase.type == Showcase.ShowcaseType.dynamic && element != null && !(element instanceof BlockDisplayElement && isBlockItem);

        if (element == null || dynNeedsUpdate) {
            if (element != null) { // update dynamic display, remove old
                decorationBlockEntity.getOrCreateHolder().removeElement(element);
                this.showcases.remove(showcase);
            }

            newElement = this.createShowcase(decorationBlockEntity, showcase, itemStack);
            decorationBlockEntity.getOrCreateHolder().addElement(newElement);
        } else {
            if (element instanceof BlockDisplayElement blockDisplayElement && itemStack.method_7909() instanceof class_1747 blockItem) {
                blockDisplayElement.getDataTracker().set(DisplayTrackedData.Block.BLOCK_STATE, blockItem.method_7711().method_9564(), true);
            } else if (element instanceof ItemDisplayElement itemDisplayElement) {
                itemDisplayElement.getDataTracker().set(DisplayTrackedData.Item.ITEM, itemStack.method_7972(), true);
            }

            this.showcases.put(showcase, element);
        }

        holder.tick();
    }

    private BlockDisplayElement element(class_1747 blockItem) {
        BlockDisplayElement displayElement = new BlockDisplayElement();
        displayElement.setBlockState(blockItem.method_7711().method_9564());
        return displayElement;
    }

    private DisplayElement element(ShowcaseMeta showcase, class_1799 itemStack) {
        ItemDisplayElement displayElement = new ItemDisplayElement(itemStack.method_7972());
        displayElement.setModelTransformation(showcase.display);
        displayElement.setInvisible(true);
        return displayElement;
    }

    private DisplayElement createShowcase(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        DisplayElement element = null;

        switch (showcase.type) {
            case item -> element = this.element(showcase, itemStack);
            case block -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem && !(blockItem instanceof DecorationItem)) {
                    element = this.element(blockItem);
                }
            }
            case dynamic -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem && !(blockItem instanceof DecorationItem)) {
                    element = this.element(blockItem);
                } else {
                    element = this.element(showcase, itemStack);
                }
            }
        }

        if (element != null) {
            transform(decorationBlockEntity, element, showcase);
            this.showcases.put(showcase, element);
        } else {
            Filament.LOGGER.error("In valid showcase type for {}", itemStack.method_7909().method_7876());
        }

        return element;
    }

    private void transform(DecorationBlockEntity decorationBlockEntity, DisplayElement element, ShowcaseMeta showcase) {
        if (element != null) {
            element.setScale(showcase.scale);
            element.setLeftRotation(showcase.rotation);
            element.setYaw(decorationBlockEntity.getVisualRotationYInDegrees() + 180);
            if (element instanceof BlockDisplayElement) {
                element.setTranslation(this.showcaseTranslation(showcase).add(new Vector3f(-.5f, -.5f, -.5f).mul(showcase.scale)));
            } else {
                element.setTranslation(this.showcaseTranslation(showcase));
            }
        }
    }

    public class_1799 getShowcaseItemStack(Showcase.ShowcaseMeta showcase) {
        var i = config.elements.indexOf(showcase);
        return container.method_5438(i);
    }

    public boolean canUseShowcaseItem(Showcase.ShowcaseMeta showcase, class_1799 item) {
        boolean hasFilterItems = showcase.filterItems != null && !showcase.filterItems.isEmpty();
        boolean hasFilterTags = showcase.filterTags != null && !showcase.filterTags.isEmpty();

        if (hasFilterTags) {
            for (var filterTag : showcase.filterTags) {
                class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, filterTag);
                if (item.method_31573(key)) {
                    return true;
                }
            }
        }

        if (hasFilterItems) {
            for (var filterTag : showcase.filterItems) {
                if (item.method_31574(filterTag)) {
                    return true;
                }
            }
        }

        return !(hasFilterItems || hasFilterTags);
    }

    @Override
    public void modifyDrop(DecorationBlockEntity decorationBlockEntity, class_1799 itemStack) {
        if (config.canPickup) {
            itemStack.method_57379(class_9334.field_49622, class_9288.method_57493(container.method_54454()));
        }
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        return BlockBehaviour.super.updateShape(blockState, direction, blockState2, levelAccessor, blockPos, blockPos2);
    }

    @Override
    public class_1799 getCloneItemStack(class_1799 itemStack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        return itemStack;
    }

    @Override
    public void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_2586.class_9473 dataComponentGetter) {
        class_9297 seededContainerLoot = dataComponentGetter.method_58694(class_9334.field_49626);
        if (seededContainerLoot != null) {
            this.lootTable = seededContainerLoot.comp_2414();
            this.lootTableSeed = seededContainerLoot.comp_2415();
        }

        dataComponentGetter.method_58695(class_9334.field_49622, class_9288.field_49334).method_57492(container.field_5828);
        container.method_5431();

        container.method_54873(null);
    }

    @Override
    public void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {
        builder.method_57840(class_9334.field_49622, class_9288.method_57493(container.field_5828));
        if (this.lootTable != null) {
            builder.method_57840(class_9334.field_49626, new class_9297(this.lootTable, this.lootTableSeed));
        }
    }

    @Override
    public class_2561 customName() {
        return container.getBlockEntity().method_58693().method_57829(class_9334.field_49631);
    }

    @Override
    public @Nullable class_1263 container() {
        return container;
    }

    @Override
    public boolean showCustomName() {
        return config.showCustomName;
    }

    @Override
    public boolean hopperDropperSupport() {
        return config.hopperDropperSupport;
    }

    @Override
    public boolean canPickUp() {
        return config.canPickup;
    }

    @Override
    public void removeComponentsFromTag(DecorationBlockEntity decorationBlockEntity, class_2487 valueOutput, class_7225.class_7874 lookup) {
        valueOutput.method_10551("LootTable");
        valueOutput.method_10551("LootTableSeed");
    }

    @Override
    public void setLootTable(@Nullable class_5321<class_52> resourceKey) {
        lootTable = resourceKey;
    }

    @Override
    public @Nullable class_5321<class_52> getLootTable() {
        return lootTable;
    }

    @Override
    public void setLootTableSeed(long l) {
        lootTableSeed = l;
    }

    @Override
    public long getLootTableSeed() {
        return lootTableSeed;
    }

    public static class ShowcaseMeta {
        /**
         * Offset for positioning the showcased item
         */
        public Vector3f offset = new Vector3f();

        /**
         * Scale of the showcased item
         */
        public Vector3f scale = new Vector3f(1);

        /**
         * Rotation of the showcased item
         */
        public Quaternionf rotation = new Quaternionf();

        /**
         * Type to display, block for blocks (block display), item for items (item display), dynamic uses blocks if possible, otherwise item (block/item display)
         */
        public ShowcaseType type = ShowcaseType.item;

        /**
         * Items to allow
         */
        public List<class_1792> filterItems;

        /**
         * Items with given item tags to allow
         */
        public List<class_2960> filterTags;

        public class_2960 addItemSound = class_3417.field_14667.method_14833();

        public class_2960 removeItemSound = class_3417.field_14770.method_14833();

        public int maxStackSize = 1;

        public class_811 display = class_811.field_4315;
    }

    public enum ShowcaseType {
        item,
        block,
        dynamic // block when possible, item otherwise
    }

    public static class Config {
        public boolean hopperDropperSupport = true;
        public boolean useMenu = false;
        public String name = "Showcase";
        public boolean showCustomName = true;
        public boolean canPickup = false;
        public List<ShowcaseMeta> elements;

        public static class ConfigDeserializer implements JsonDeserializer<Config> {
            @Override
            public Config deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext ctx) throws JsonParseException {
                Config config = new Config();
                if (json.isJsonArray()) {
                    config.elements = new ObjectArrayList<>();
                    for (JsonElement elem : json.getAsJsonArray()) {
                        ShowcaseMeta meta = ctx.deserialize(elem, ShowcaseMeta.class);
                        config.elements.add(meta);
                    }
                    return config;
                }

                if (json.isJsonObject()) {
                    JsonObject obj = json.getAsJsonObject();

                    if (obj.has("hopper_dropper_support"))
                        config.hopperDropperSupport = obj.get("hopper_dropper_support").getAsBoolean();
                    if (obj.has("use_menu"))
                        config.useMenu = obj.get("use_menu").getAsBoolean();
                    if (obj.has("name"))
                        config.name = obj.get("name").getAsString();
                    if (obj.has("show_custom_name"))
                        config.showCustomName = obj.get("show_custom_name").getAsBoolean();

                    if (obj.has("elements") && obj.get("elements").isJsonArray()) {
                        config.elements = new ObjectArrayList<>();
                        for (JsonElement elem : obj.getAsJsonArray("elements")) {
                            ShowcaseMeta meta = ctx.deserialize(elem, ShowcaseMeta.class);
                            config.elements.add(meta);
                        }
                    }
                    return config;
                }

                throw new JsonParseException("Invalid config format: must be object or array");
            }
        }
    }
}
package de.tomalbrc.filament.data;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.ItemProperties;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.data.resource.ResourceProvider;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_9323;
import net.minecraft.class_9331;

public abstract class Data<PropertyType extends ItemProperties> {
    protected final @NotNull class_2960 id;
    protected final @Nullable class_1792 vanillaItem;
    protected final @Nullable Map<String, String> translations;
    protected final @Nullable class_2561 displayName;
    protected @Nullable ItemResource itemResource;
    protected final @Nullable Integer itemModel;
    @SerializedName(value = "behaviour", alternate = {"behaviours", "behaviors", "behavior"})
    protected @Nullable BehaviourConfigMap behaviour;
    protected final @Nullable class_9323 components;
    protected final @Nullable class_2960 group;
    protected final @Nullable Set<class_2960> itemTags;
    protected @Nullable PropertyType properties;

    transient protected Map<class_9331<?>, JsonElement> additionalComponents;

    protected Data(
            @NotNull class_2960 id,
            @Nullable class_1792 vanillaItem,
            @Nullable Map<String, String> translations,
            @Nullable class_2561 displayName,
            @Nullable ItemResource itemResource,
            @Nullable Integer itemModel,
            @Nullable PropertyType properties,
            @Nullable BehaviourConfigMap behaviour,
            @Nullable class_9323 components,
            @Nullable class_2960 group,
            @Nullable Set<class_2960> itemTags
            ) {
        this.id = id;
        this.vanillaItem = vanillaItem;
        this.translations = translations;
        this.displayName = displayName;
        this.itemResource = itemResource;
        this.itemModel = itemModel;
        this.properties = properties;
        this.behaviour = behaviour;
        this.components = components;
        this.group = group;
        this.itemTags = itemTags;
    }

    public void putAdditional(class_9331<?> s, JsonElement jsonObject) {
        if (this.additionalComponents == null) this.additionalComponents = new Object2ObjectOpenHashMap<>();
        this.additionalComponents.put(s, jsonObject);
    }

    @NotNull
    public Map<class_9331<?>, JsonElement> getAdditionalComponents() {
        if (this.additionalComponents == null) this.additionalComponents = new Object2ObjectOpenHashMap<>();
        return additionalComponents;
    }

    public abstract @NotNull ItemProperties properties();

    public @NotNull class_2960 id() {
        return id;
    }

    public @NotNull class_1792 vanillaItem() {
        if (vanillaItem == null) {
            return class_1802.field_8407;
        }
        return vanillaItem;
    }

    public @Nullable Map<String, String> translations() {
        return translations;
    }

    public @Nullable ItemResource itemResource() {
        return itemResource;
    }

    public void setItemResource(ItemResource itemResource) {
        this.itemResource = itemResource;
    }

    public @Nullable ResourceProvider preferredResource() {
        return itemResource();
    }

    public @Nullable Integer itemModel() {
        return itemModel;
    }

    public @NotNull BehaviourConfigMap behaviour() {
        if (behaviour == null) {
            behaviour = new BehaviourConfigMap();
        }
        return behaviour;
    }

    public @NotNull class_9323 components() {
        return components == null ? class_9323.field_49584 : components;
    }

    public @Nullable class_2960 group() {
        return group;
    }

    public @Nullable Set<class_2960> itemTags() { return this.itemTags; }

    public @Nullable class_2561 displayName() {
        return this.displayName;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Data<?>) obj;
        return Objects.equals(this.id, that.id);
    }

    public Object2ObjectOpenHashMap<String, PolymerModelData> requestModels() {
        Object2ObjectOpenHashMap<String, PolymerModelData> map = new Object2ObjectOpenHashMap<>();
        if (itemResource != null) {
            itemResource.getModels().forEach((key, value) -> map.put(key, PolymerResourcePackUtils.requestModel(this.vanillaItem == null ? class_1802.field_8407 : this.vanillaItem, value)));
        }

        return map;
    }
}

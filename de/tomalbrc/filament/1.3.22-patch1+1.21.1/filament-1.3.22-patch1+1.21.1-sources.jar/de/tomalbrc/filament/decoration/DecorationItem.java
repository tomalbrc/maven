package de.tomalbrc.filament.decoration;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.block.SimpleBlockItem;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.data.properties.DecorationProperties;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.util.DecorationUtil;
import eu.pb4.polymer.core.api.item.PolymerItem;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_9334;

public class DecorationItem extends SimpleBlockItem implements PolymerItem, BehaviourHolder {
    final private DecorationData decorationData;

    public DecorationItem(class_2248 block, DecorationData decorationData, class_1792.class_1793 properties) {
        super(properties, block, decorationData);
        this.initBehaviours(decorationData.behaviour());
        this.decorationData = decorationData;
    }

    public DecorationData getDecorationData() {
        return this.decorationData;
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        if (this.decorationData.vanillaItem().method_57347().method_57832(class_9334.field_49644) || this.decorationData.components().method_57832(class_9334.field_49644)) {
            list.add(class_2561.method_43470("§9Dyeable"));
        }

        super.method_7851(itemStack, tooltipContext, list, tooltipFlag);
    }

    @Override
    @NotNull
    public class_1269 method_7884(class_1838 useOnContext) {
        if (decorationData == null) {
            Filament.LOGGER.warn("Can't use decoration Item: Missing decoration data!");
            return class_1269.field_5814;
        }

        DecorationProperties properties = decorationData.properties();

        var clickedState = useOnContext.method_8045().method_8320(useOnContext.method_8037());
        var replaceable = clickedState.method_45474();

        class_2338 blockPos = useOnContext.method_8037();
        class_2350 direction, actualDir = direction = replaceable ? class_2350.field_11036 : useOnContext.method_8038();
        class_1657 player = useOnContext.method_8036();
        class_1799 itemStack = useOnContext.method_8041();
        class_1937 level = useOnContext.method_8045();

        boolean propertyPlaceCheck = properties.placement.canPlace(direction);
        if (!propertyPlaceCheck && properties.placement.floor()) {
            direction = class_2350.field_11036;
            propertyPlaceCheck = properties.placement.canPlace(direction);
        }

        if (!propertyPlaceCheck && properties.placement.ceiling()) {
            direction = class_2350.field_11033;
            propertyPlaceCheck = properties.placement.canPlace(direction);
        }

        DecorationBlock block = DecorationRegistry.getDecorationBlock(decorationData.id());
        class_2680 blockState = block.method_9605(new class_1750(useOnContext));

        boolean forceReplace = replaceable || clickedState.method_26166(new class_1750(useOnContext));
        class_2338 relativeBlockPos;
        if (forceReplace) {
            relativeBlockPos = blockPos;
        } else {
            relativeBlockPos = blockPos.method_10093(direction);
        }

        assert blockState != null;
        float angle = block.getVisualRotationYInDegrees(blockState);

        if (!this.method_7711().method_45382(level.method_45162()) || player == null || !this.mayPlace(player, direction, itemStack, relativeBlockPos) || !propertyPlaceCheck) {
            return class_1269.field_5814;
        } else if ((forceReplace || this.canPlaceAt(level, relativeBlockPos, angle)) && itemStack.method_7909() instanceof DecorationItem) {
            DecorationItem.place(itemStack, level, blockState, relativeBlockPos, actualDir, direction, useOnContext);

            player.method_6019(useOnContext.method_20287());
            itemStack.method_57008(1, player);

            class_3414 placeSound = properties.blockBase.method_9564().method_26231().method_10598();
            level.method_8396(null, blockPos, placeSound, class_3419.field_15245, 1.0F, 1.0F);

            return class_1269.field_5812;
        }

        return class_1269.field_5814;
    }

    protected boolean mayPlace(class_1657 player, class_2350 direction, class_1799 itemStack, class_2338 blockPos) {
        return !player.method_37908().method_31606(blockPos) && player.method_7343(blockPos, direction, itemStack);
    }

    /**
     * Check if multi-block structure can be placed
     */
    private boolean canPlaceAt(class_1937 level, class_2338 blockPos, float angle) {
        if (!level.method_8320(blockPos).method_45474()) {
            return false;
        }

        if (decorationData.hasBlocks()) {
            boolean[] canPlace = new boolean[]{true};
            DecorationUtil.forEachRotated(decorationData.blocks(), blockPos, angle, blockPos2 -> {
                if (!level.method_8320(blockPos2).method_45474()) {
                    canPlace[0] = false;
                }
            });
            return canPlace[0];
        }

        return true;
    }

    @Deprecated(forRemoval = true)
    public static void place(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_2350 direction, class_1838 useOnContext, boolean q) {
        place(itemStack, level, blockState, blockPos, direction, direction, useOnContext);
    }

    public static void place(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_2350 placeDirection, class_2350 direction, class_1838 useOnContext) {
        if (!(itemStack.method_7909() instanceof DecorationItem decorationItem)) {
            Filament.LOGGER.error("Tried to place non-decoration item as decoration! Item: {}", itemStack.method_7909().method_40131().method_40237().method_29177());
            return;
        }

        DecorationData decorationData = decorationItem.decorationData;
        if (decorationData.hasBlocks() && decorationData.countBlocks() == 0)
            Filament.LOGGER.warn("Found block data with potentially invalid blocks for {} while trying to place", decorationData.id());

        DecorationBlock block = (DecorationBlock) blockState.method_26204();
        if (decorationData.hasBlocks() && decorationData.countBlocks() > 1) {
            DecorationUtil.forEachRotated(decorationData.blocks(), blockPos, block.getVisualRotationYInDegrees(blockState), blockPos2 -> {
                level.method_22352(blockPos2, false);

                var offsetState = block.method_9605(class_1750.method_16355(new class_1750(useOnContext), blockPos2, placeDirection));
                level.method_8501(blockPos2, offsetState);

                if (offsetState != null) {
                    offsetState.method_26204().method_9567(level, blockPos2, offsetState, useOnContext.method_8036(), itemStack);
                    if (useOnContext.method_8036() != null) class_174.field_1191.method_23889((class_3222) useOnContext.method_8036(), blockPos, itemStack);
                }

                if (decorationData.requiresEntityBlock() && level.method_8321(blockPos2) instanceof DecorationBlockEntity decorationBlockEntity) {
                    decorationBlockEntity.setMain(new class_2338(blockPos2).method_10059(blockPos));
                    decorationBlockEntity.setDirection(direction);
                    if (decorationBlockEntity.isMain()) updateComponents(decorationBlockEntity, itemStack);
                    decorationBlockEntity.attach(level.method_8500(blockPos));
                }
            });
        } else {
            level.method_8501(blockPos, blockState);
            blockState.method_26204().method_9567(level, blockPos, blockState, useOnContext.method_8036(), itemStack);
            if (useOnContext.method_8036() != null) class_174.field_1191.method_23889((class_3222) useOnContext.method_8036(), blockPos, itemStack);

            if (decorationData.requiresEntityBlock() && level.method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                decorationBlockEntity.setMain(class_2338.field_10980);
                decorationBlockEntity.setDirection(direction);
                updateComponents(decorationBlockEntity, itemStack);
                decorationBlockEntity.attach(level.method_8500(blockPos));
            }
        }
    }

    public static void updateComponents(DecorationBlockEntity blockEntity, class_1799 itemStack) {
        blockEntity.method_58683(itemStack);
        blockEntity.method_5431();
    }
}

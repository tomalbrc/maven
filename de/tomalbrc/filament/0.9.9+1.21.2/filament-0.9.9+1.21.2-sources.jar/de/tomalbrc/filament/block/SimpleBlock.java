package de.tomalbrc.filament.block;

import I;
import Z;
import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.class_5955;
import net.minecraft.class_9904;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class SimpleBlock extends class_2248 implements PolymerTexturedBlock, BehaviourHolder, class_3737, class_2256, class_5955 {
    protected Map<class_2680, BlockData.BlockStateMeta> stateMap;
    protected final class_2680 breakEventState;
    protected final BlockData blockData;

    protected final class_2689<class_2248, class_2680> stateDefinitionEx;

    private final BehaviourMap behaviours = new BehaviourMap();

    public BehaviourMap getBehaviours() {
        return this.behaviours;
    }

    public SimpleBlock(class_4970.class_2251 properties, BlockData data) {
        super(properties);

        this.initBehaviours(data.behaviour());
        this.breakEventState = data.properties().blockBase.method_9564();
        this.blockData = data;

        // the StateDefinition built too early, cant access BlockData from within createBlockStateDefinition
        class_2689.class_2690<class_2248, class_2680> builder = new class_2689.class_2690<>(this);
        this.method_9515(builder);
        this.stateDefinitionEx = builder.method_11668(class_2248::method_9564, class_2680::new);

        class_2680[] def = {this.stateDefinitionEx.method_11664()};
        this.forEach(behaviour -> def[0] = behaviour.modifyDefaultState(def[0]));
        this.method_9590(def[0]);
    }

    public boolean hasData() {
        return this.blockData != null;
    }

    @Override
    @NotNull
    public class_2689<class_2248, class_2680> method_9595() {
        return this.stateDefinitionEx;
    }

    public void postRegister() {
        this.stateMap = this.blockData.createStandardStateMap();
        this.forEach(behaviour -> behaviour.modifyStateMap(this.stateMap, this.blockData));
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 blockState, PacketContext packetContext) {
        if (this.stateMap != null) for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                class_2680 polyBlockState = blockBehaviour.getCustomPolymerBlockState(this.stateMap, blockState);
                if (polyBlockState != null)
                    return polyBlockState;
            }
        }
        return this.stateMap != null && this.stateMap.get(blockState) != null ? this.stateMap.get(blockState).blockState() : class_2246.field_9987.method_9564();
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, PacketContext packetContext) {
        return this.breakEventState;
    }

    private void forEach(Consumer<de.tomalbrc.filament.api.behaviour.BlockBehaviour<?>> consumer) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                consumer.accept(blockBehaviour);
            }
        }
    }

    /// --- behaviour impl

    @Override
    @NotNull
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        if (this.getBehaviours() != null)
            this.forEach(x -> x.playerWillDestroy(level, blockPos, blockState, player));
        return super.method_9576(level, blockPos, blockState, player);
    }


    @Override
    public void method_9567(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1309 livingEntity, class_1799 itemStack) {
        if (this.getBehaviours() != null)
            this.forEach(x -> x.setPlacedBy(level, blockPos, blockState, livingEntity, itemStack));
    }

    @Override
    protected long method_9535(class_2680 blockState, class_2338 blockPos) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.getSeed(blockState, blockPos);
                if (res != null && res.isPresent())
                    return res.orElseThrow();
            }
        }

        return class_3532.method_15389(blockPos);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        if (this.getBehaviours() != null)
            this.forEach(x -> x.createBlockStateDefinition(builder));
    }

    @Override
    public class_2680 method_9605(class_1750 blockPlaceContext) {
        class_2680 def = this.method_9564();
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                def = blockBehaviour.getStateForPlacement(def, blockPlaceContext);
            }
        }

        return def;
    }

    @Override
    public void method_9612(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_9904 orientation, boolean bl) {
        if (this.getBehaviours() != null)
            this.forEach(x -> x.neighborChanged(blockState, level, blockPos, block, orientation, bl));
        super.method_9612(blockState, level, blockPos, block, orientation, bl);
    }

    @Override
    public void method_55124(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
        if (this.getBehaviours() != null)
            this.forEach(x -> x.onExplosionHit(blockState, level, blockPos, explosion, biConsumer));
        super.method_55124(blockState, level, blockPos, explosion, biConsumer);
    }

    @Override
    @NotNull
    public class_2680 method_9598(class_2680 blockState, class_2470 rotation) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.rotate(blockState, rotation);
                if (res != null)
                    return res;
            }
        }
        return super.method_9598(blockState, rotation);
    }

    @Override
    @NotNull
    public class_2680 method_9569(class_2680 blockState, class_2415 mirror) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.mirror(blockState, mirror);
                if (res != null)
                    return res;
            }
        }
        return super.method_9569(blockState, mirror);
    }

    @Override
    public void method_9565(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean bl) {
        super.method_9565(blockState, serverLevel, blockPos, itemStack, bl);
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                blockBehaviour.spawnAfterBreak(blockState, serverLevel, blockPos, itemStack, bl);
            }
        }
    }

    @Override
    public boolean method_9506(class_2680 blockState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.isSignalSource(blockState);
                if (res)
                    return true;
            }
        }
        return super.method_9506(blockState);
    }

    @Override
    public int method_9603(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.getDirectSignal(blockState, blockGetter, blockPos, direction);
                if (res > 0)
                    return res;
            }
        }
        return super.method_9603(blockState, blockGetter, blockPos, direction);
    }

    @Override
    public int method_9524(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.getSignal(blockState, blockGetter, blockPos, direction);
                if (res > 0)
                    return res;
            }
        }
        return super.method_9524(blockState, blockGetter, blockPos, direction);
    }

    @Override
    protected boolean method_9526(class_2680 blockState) {
        if (this.getBehaviours() != null) for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.useShapeForLightOcclusion(blockState);
                if (res.isPresent())
                    return res.get();
            }
        }
        return super.method_9526(blockState);
    }

    @Override
    protected boolean method_9616(class_2680 blockState, class_1750 blockPlaceContext) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.canBeReplaced(blockState, blockPlaceContext);
                if (res.isPresent())
                    return res.get();
            }
        }
        return super.method_9616(blockState, blockPlaceContext);
    }

    @Override
    protected boolean method_22358(class_2680 blockState, class_3611 fluid) {
        return blockState.method_45474() || !blockData.properties().solid;
    }

    @Override
    @NotNull
    protected class_3610 method_9545(class_2680 blockState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.getFluidState(blockState);
                if (res != null)
                    return res;
            }
        }
        return super.method_9545(blockState);
    }

    @Override
    public boolean method_10311(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_3610 fluidState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour && blockBehaviour instanceof class_3737 waterloggedBlock) {
                var res = waterloggedBlock.method_10311(levelAccessor, blockPos, blockState, fluidState);
                if (res) {
                    return true;
                }
            }
        }

        if (!blockData.properties().solid) {
            levelAccessor.method_22352(blockPos, true);
            levelAccessor.method_8652(blockPos, fluidState.method_15759(), 0);
        }

        return !blockData.properties().solid;
    }

    @Override
    public boolean method_10310(@Nullable class_1657 player, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3611 fluid) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour && blockBehaviour instanceof class_3737 waterloggedBlock) {
                return waterloggedBlock.method_10310(player, blockGetter, blockPos, blockState, fluid);
            }
        }
        return !blockData.properties().solid;
    }

    @Override
    @NotNull
    protected class_2680 method_9559(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        var bs = super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                bs = blockBehaviour.updateShape(bs, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
            }
        }
        return bs;
    }

    @Override
    protected boolean method_9516(class_2680 blockState, class_10 pathComputationType) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.isPathfindable(blockState, pathComputationType);
                if (res.isPresent())
                    return res.get();
            }
        }
        return super.method_9516(blockState, pathComputationType);
    }

    @Override
    protected void method_9615(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        super.method_9615(blockState, level, blockPos, blockState2, bl);
        this.forEach(x -> x.onPlace(blockState, level, blockPos, blockState2, bl));
    }

    @Override
    protected void method_9536(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        this.forEach(x -> x.onRemove(blockState, level, blockPos, blockState2, bl));
        super.method_9536(blockState, level, blockPos, blockState2, bl);
    }

    @Override
    @NotNull
    public class_1799 method_9574(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        class_1799 stack = super.method_9574(levelReader, blockPos, blockState);

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var item = blockBehaviour.getCloneItemStack(stack, levelReader, blockPos, blockState);
                if (item != null) {
                    stack = item;
                }
            }
        }

        return stack;
    }

    @Override
    public boolean method_9558(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.canSurvive(blockState, levelReader, blockPos);
                if (!res)
                    return false;
            }
        }
        return true;
    }

    @Override
    public void method_9588(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        super.method_9588(blockState, serverLevel, blockPos, randomSource);
        this.forEach(x -> x.tick(blockState, serverLevel, blockPos, randomSource));
    }


    // random ticking

    @Override
    protected boolean method_9542(class_2680 blockState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.isRandomlyTicking(blockState);
                if (res)
                    return true;
            }
        }
        return super.method_9542(blockState);
    }

    @Override
    protected void method_9514(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        this.forEach(x -> x.randomTick(blockState, serverLevel, blockPos, randomSource));
    }

    // bonemealable impl

    @Override
    public boolean method_9651(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_2256 bonemealableBlock) {
                var res = bonemealableBlock.method_9651(levelReader, blockPos, blockState);
                if (res)
                    return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_2256 bonemealableBlock) {
                var res = bonemealableBlock.method_9650(level, randomSource, blockPos, blockState);
                if (res)
                    return true;
            }
        }
        return false;
    }

    @Override
    public void method_9652(class_3218 serverLevel, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_2256 bonemealableBlock) {
                bonemealableBlock.method_9652(serverLevel, randomSource, blockPos, blockState);
            }
        }
    }

    @Override
    @NotNull
    public class_9077 method_55770() {
        var def = class_2256.super.method_55770();
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_2256 bonemealableBlock) {
                var res = bonemealableBlock.method_55770();
                if (!res.equals(def))
                    return res;
            }
        }
        return def;
    }

    // -- interaction

    @Override
    @NotNull
    public class_1269 method_55766(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> blockBehaviour) {
                var res = blockBehaviour.useWithoutItem(blockState, level, blockPos, player, blockHitResult);
                if (res != null && res.method_23665())
                    return res;
            }
        }
        return class_1269.field_5811;
    }

    // --- oxidization


    @Override
    public void method_54764(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_5955 weatheringCopper) {
                weatheringCopper.method_54764(blockState, serverLevel, blockPos, randomSource);
            }
        }
    }

    @Override
    @NotNull
    public class_5811 method_33622() {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_5955 weatheringCopper) {
                return weatheringCopper.method_33622();
            }
        }
        return class_5811.field_28707;
    }

    @Override
    @NotNull
    public Optional<class_2680> method_54765(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof de.tomalbrc.filament.api.behaviour.BlockBehaviour<?> && behaviour.getValue() instanceof class_5955 weatheringCopper) {
                return weatheringCopper.method_54765(blockState, serverLevel, blockPos, randomSource);
            }
        }
        return Optional.empty();
    }
}

package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.decoration.holder.SimpleHolder;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_6328;
import net.minecraft.class_7923;
import net.minecraft.class_8567;

public class SimpleDecorationBlock extends DecorationBlock implements BlockWithElementHolder {
    public static final class_2754<class_2350> FACING = class_2741.field_12525;
    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 7);

    public SimpleDecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties, decorationId);

        this.method_9590(this.method_9564()
                .method_11657(FACING, class_2350.field_11036)
                .method_11657(ROTATION, 0)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING, ROTATION);
    }

    @Nullable
    public ElementHolder createElementHolder(class_3218 world, class_2338 pos, class_2680 initialBlockState) {
        return new SimpleHolder();
    }

    @Override
    protected void method_9536(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        if (!this.getDecorationData().hasBlocks()) {
            class_3414 breakSound = this.getDecorationData().properties().blockBase.method_9564().method_26231().method_10595();
            level.method_8396(null, blockPos,  breakSound, class_3419.field_15245, 1.0F, 1.0F);
        }

        if (this.getDecorationData().properties().showBreakParticles)
            Util.showBreakParticle((class_3218) level, this.getDecorationData().properties().useItemParticles ? class_7923.field_41178.method_10223(this.decorationId).orElseThrow().comp_349().method_7854() : this.getDecorationData().properties().blockBase.method_8389().method_7854(), (float) blockPos.method_46558().method_10216(), (float) blockPos.method_46558().method_10214(), (float) blockPos.method_46558().method_10215());

        super.method_9536(blockState, level, blockPos, blockState2, bl);
    }

    @Override
    @NotNull
    public List<class_1799> method_9560(class_2680 blockState, class_8567.class_8568 builder) {
        if (this.getDecorationData().properties().drops) {
            return List.of(class_7923.field_41178.method_10223(this.decorationId).orElseThrow().comp_349().method_7854());
        }
        return List.of();
    }

    @Override
    @class_6328
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2680 returnVal = super.method_9576(level, blockPos, blockState, player);
        if (!this.getDecorationData().hasBlocks()) {
            class_3414 breakSound = this.getDecorationData().properties().blockBase.method_9564().method_26231().method_10595();
            level.method_8396(null, blockPos,  breakSound, class_3419.field_15245, 1.0F, 1.0F);
        }

        if (this.getDecorationData().properties().showBreakParticles)
            Util.showBreakParticle((class_3218) level, this.getDecorationData().properties().useItemParticles ? class_7923.field_41178.method_10223(this.decorationId).orElseThrow().comp_349().method_7854() : this.getDecorationData().properties().blockBase.method_8389().method_7854(), (float) blockPos.method_46558().method_10216(), (float) blockPos.method_46558().method_10214(), (float) blockPos.method_46558().method_10215());

        if (!level.method_8608() && !player.method_7337() && this.getDecorationData().properties().drops) {
            for (class_1799 drop : this.method_9560(blockState, null)) {
                Util.spawnAtLocation(level, blockPos.method_46558(), drop);
            }
        }

        return returnVal;
    }
}

package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.holder.DecorationHolder;
import de.tomalbrc.filament.decoration.util.SeatEntity;
import de.tomalbrc.filament.registry.EntityRegistry;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3730;

/**
 * Seat behaviour for decoration
 */
public class Seat implements DecorationBehaviour<Seat.SeatConfig> {
    private final SeatConfig seatConfig;

    public Seat(SeatConfig seatConfig) {
        this.seatConfig = seatConfig;
    }

    @Override
    @NotNull
    public SeatConfig getConfig() {
        return this.seatConfig;
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (player.method_5854() == null && !player.method_21823() && decorationBlockEntity.getDecorationHolder() instanceof DecorationHolder) {
            Seat.SeatMeta seat = this.getClosestSeat(decorationBlockEntity, location);

            if (seat != null && !this.hasSeatedPlayer(decorationBlockEntity, seat)) {
                this.seatPlayer(decorationBlockEntity, seat, player);
            }

            return class_1269.field_21466;
        }

        return class_1269.field_5811;
    }

    public void seatPlayer(DecorationBlockEntity decorationBlockEntity, Seat.SeatMeta seat, class_3222 player) {
        SeatEntity seatEntity = EntityRegistry.SEAT_ENTITY.method_5883(player.method_51469(), class_3730.field_16461);
        assert seatEntity != null;
        seatEntity.method_33574(this.seatTranslation(decorationBlockEntity, seat).method_1019(decorationBlockEntity.getDecorationHolder().getPos()));
        player.method_37908().method_8649(seatEntity);
        player.method_5804(seatEntity);
        seatEntity.method_36456((decorationBlockEntity.getVisualRotationYInDegrees() - seat.direction));
    }

    public boolean hasSeatedPlayer(DecorationBlockEntity decorationBlockEntity, Seat.SeatMeta seat) {
        return !Objects.requireNonNull(decorationBlockEntity.method_10997()).method_8390(SeatEntity.class, class_238.method_30048(seatTranslation(decorationBlockEntity, seat).method_1019(decorationBlockEntity.getDecorationHolder().getPos()), 0.2, 0.2, 0.2), x -> true).isEmpty();
    }

    public Seat.SeatMeta getClosestSeat(DecorationBlockEntity decorationBlockEntity, class_243 location) {
        if (seatConfig.size() == 1) {
            return seatConfig.getFirst();
        }
        else {
            double dist = Double.MAX_VALUE;
            Seat.SeatMeta nearest = null;

            for (Seat.SeatMeta seat : seatConfig) {
                class_243 q = decorationBlockEntity.method_11016().method_46558().method_1019(seatTranslation(decorationBlockEntity, seat));
                double distance = q.method_1022(location);

                if (!this.hasSeatedPlayer(decorationBlockEntity, seat) && distance < dist) {
                    dist = distance;
                    nearest = seat;
                }
            }

            return nearest;
        }
    }

    public class_243 seatTranslation(DecorationBlockEntity decorationBlockEntity, Seat.SeatMeta seat) {
        class_243 v3 = new class_243(seat.offset).method_1023(0, 0.3, 0).method_1024((float) Math.toRadians(decorationBlockEntity.getVisualRotationYInDegrees()+180));
        return new class_243(-v3.field_1352, v3.field_1351, v3.field_1350);
    }

    public SeatEntity getSeatEntity(DecorationBlockEntity decorationBlockEntity, Seat.SeatMeta seat) {
        List<SeatEntity> entities = Objects.requireNonNull(decorationBlockEntity.method_10997()).method_8390(SeatEntity.class, class_238.method_30048(seatTranslation(decorationBlockEntity, seat).method_1019(decorationBlockEntity.getDecorationHolder().getPos()), 0.2, 0.2, 0.2), x -> true);
        if (!entities.isEmpty())
            return entities.getFirst();

        return null;
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        for (SeatMeta seatMeta : this.seatConfig) {
            var seat = getSeatEntity(decorationBlockEntity, seatMeta);
            if (seat != null && seat.method_31483() != null) {
                seat.method_31483().method_5848();
            }
        }
    }

    public static class SeatMeta {
        /**
         * The player seating offset
         */
        public Vector3f offset = new Vector3f();

        /**
         * The rotation direction of the seat
         */
        public float direction = 180;
    }

    public static class SeatConfig extends ObjectArrayList<SeatMeta> { }
}

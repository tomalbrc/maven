package de.tomalbrc.filament.registry.filament;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.registry.BlockTypeRegistry;
import de.tomalbrc.filament.block.SimpleBlockItem;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.behaviours.block.Strippable;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Json;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.class_9336;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class BlockRegistry {
    public static int REGISTERED_BLOCKS = 0;

    public static void register(InputStream inputStream) throws IOException {
        register(Json.GSON.fromJson(new InputStreamReader(inputStream, StandardCharsets.UTF_8), BlockData.class));
    }

    public static void register(BlockData data) throws IOException {
        BlockProperties properties = data.properties();
        if (class_7923.field_41175.method_10250(data.id())) return;

        class_4970.class_2251 blockProperties = properties.toBlockProperties();

        Class<? extends class_2248> blockClass = BlockTypeRegistry.get(data.type());
        class_2248 customBlock;
        try {
            customBlock = blockClass.getDeclaredConstructor(class_4970.class_2251.class, BlockData.class).newInstance(blockProperties, data);
        } catch (InstantiationException | NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }

        if (customBlock != null) {
            var itemProperties = data.properties().toItemProperties();
            if (data.components() != null) {
                for (class_9336 component : data.components()) {
                    itemProperties.method_57349(component.comp_2443(), component.comp_2444());
                }
            }

            if (data.isStrippable()) {
                Strippable strippable = data.behaviour().get(Constants.Behaviours.STRIPPABLE);
                StrippableRegistry.add(customBlock.method_9564(), strippable.replacement);
            }

            SimpleBlockItem item = new SimpleBlockItem(itemProperties, customBlock, data);
            BlockRegistry.registerBlock(data.id(), customBlock);
            ItemRegistry.registerItem(data.id(), item, ItemRegistry.CUSTOM_BLOCK_ITEMS);

            REGISTERED_BLOCKS++;
        } else {
            throw new IOException(String.format("Could not read block type {}", data.type()));
        }
    }

    public static void registerBlock(class_2960 identifier, class_2248 block) {
        class_2378.method_10230(class_7923.field_41175, identifier, block);
    }

    public static class BlockDataReloadListener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655("filament", "filament");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/block", path -> path.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {

                try (var reader = new InputStreamReader(entry.getValue().method_14482())) {
                    BlockData data = Json.GSON.fromJson(reader, BlockData.class);
                    BlockRegistry.register(data);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load block resource \"" + entry.getKey() + "\".");
                }
            }

            Filament.LOGGER.info("filament blocks registered: " + BlockRegistry.REGISTERED_BLOCKS);
        }
    }
}

package de.tomalbrc.filament.gen;

import com.google.gson.JsonObject;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4945;

public class BlockModelGenerator {
    public static String generate(class_4942 template, Map<class_4945, class_2960> stateMap) {
        JsonObject j = template.method_48524(null, stateMap);
        return j.toString();
    }


    static byte[] generateBlock() {
        return null;
    }
    static byte[] generatePillar() {
        return null;
    }
    static byte[] directional() {
        return null;
    }

    static byte[] horizontalDirectional() {
        return null;
    }
}

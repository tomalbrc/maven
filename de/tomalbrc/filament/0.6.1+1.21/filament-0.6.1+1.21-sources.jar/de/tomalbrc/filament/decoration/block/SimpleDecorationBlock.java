package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.decoration.holder.SimpleHolder;
import eu.pb4.polymer.virtualentity.api.BlockWithMovingElementHolder;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

public class SimpleDecorationBlock extends DecorationBlock implements BlockWithMovingElementHolder {
    public static final class_2753 FACING = class_2741.field_12525;
    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 7);

    public SimpleDecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties, decorationId);

        this.method_9590(this.method_9564()
                .method_11657(FACING, class_2350.field_11036)
                .method_11657(ROTATION, 0)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING, ROTATION);
    }

    @Nullable
    public ElementHolder createElementHolder(class_3218 world, class_2338 pos, class_2680 initialBlockState) {
        return new SimpleHolder();
    }
}

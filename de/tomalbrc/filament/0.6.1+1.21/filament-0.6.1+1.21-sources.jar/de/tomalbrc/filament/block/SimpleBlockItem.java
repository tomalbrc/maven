package de.tomalbrc.filament.block;

import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.behaviours.item.Cosmetic;
import de.tomalbrc.filament.data.behaviours.item.Fuel;
import de.tomalbrc.filament.registry.filament.FuelRegistry;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_3222;
import net.minecraft.class_5151;
import org.jetbrains.annotations.NotNull;

public class SimpleBlockItem extends CustomBlockItem implements PolymerItem, class_5151 {
    private final PolymerModelData polymerModel;

    private final BlockData blockData;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties);
        this.blockData = data;
        this.polymerModel = PolymerResourcePackUtils.requestModel(
                data.properties().itemBase,
                data.itemResource() != null && data.itemResource().models() != null ? data.itemResource().models().get("default") : data.blockResource().models().entrySet().iterator().next().getValue()
        );

        if (data.isFuel()) {
            Fuel fuel = this.blockData.behaviour().get(Constants.Behaviours.FUEL);
            FuelRegistry.add(this, fuel.value);
        }
    }

    public BlockData getBlockData() {
        return this.blockData;
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, class_3222 player) {
        return this.polymerModel.item();
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, class_3222 player) {
        return this.polymerModel.value();
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        var res = super.method_7836(level, user, hand);

        if (res.method_5467() != class_1269.field_21466 && this.blockData.isCosmetic()) {
            res = this.method_48576(this, level, user, hand);
        }

        return res;
    }

    @Override
    @NotNull
    public class_1304 method_7685() {
        if (blockData.isCosmetic()) {
            Cosmetic cosmetic = blockData.behaviour().get(Constants.Behaviours.COSMETIC);
            return cosmetic.slot;
        }
        return class_1304.field_6173;
    }
}
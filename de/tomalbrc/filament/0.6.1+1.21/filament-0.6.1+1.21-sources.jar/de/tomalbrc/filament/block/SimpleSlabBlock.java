package de.tomalbrc.filament.block;

import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import java.util.HashMap;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class SimpleSlabBlock extends class_2482 implements PolymerTexturedBlock {
    private final HashMap<String, class_2680> stateMap;
    private final class_2680 breakEventState;

    public SimpleSlabBlock(class_2251 properties, BlockData data) {
        super(properties.method_9624());
        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        var newState = switch (state.method_11654(field_11501)) {
            case field_12679 -> this.stateMap.get("top");
            case field_12681 -> this.stateMap.get("bottom");
            case field_12682 -> this.stateMap.get("double");
        };
        return newState.method_11657(class_2482.field_11502, state.method_11654(class_2482.field_11502));
    }
}

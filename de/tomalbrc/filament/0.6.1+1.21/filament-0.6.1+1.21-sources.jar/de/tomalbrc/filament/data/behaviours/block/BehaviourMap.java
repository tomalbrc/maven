package de.tomalbrc.filament.data.behaviours.block;

import com.google.gson.*;
import de.tomalbrc.filament.api.registry.BehaviourRegistry;
import de.tomalbrc.filament.behaviour.Behaviour;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.lang.reflect.Type;
import java.util.Map;
import net.minecraft.class_2960;

public class BehaviourMap {
    private final Map<class_2960, Behaviour> behaviourMap = new Object2ObjectOpenHashMap<>();
    public <T> void put(class_2960 resourceLocation, Behaviour behaviour) {
        behaviourMap.put(resourceLocation, behaviour);
    }

    public <T> T get(class_2960 resourceLocation) {
        return (T) behaviourMap.get(resourceLocation);
    }

    public static class Deserializer implements JsonDeserializer<BehaviourMap> {
        @Override
        public BehaviourMap deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonObject object = jsonElement.getAsJsonObject();
            BehaviourMap behaviourMap = new BehaviourMap();
            for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
                class_2960 resourceLocation;
                if (entry.getKey().contains(":"))
                    resourceLocation = class_2960.method_60654(entry.getKey());
                else
                    resourceLocation = class_2960.method_60655("filament", entry.getKey());

                Type clazz = BehaviourRegistry.get(resourceLocation);
                Object deserialized = jsonDeserializationContext.deserialize(entry.getValue(), clazz);
                behaviourMap.put(resourceLocation, (Behaviour) deserialized);
            }
            return behaviourMap;
        }
    }
}

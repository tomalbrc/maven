package de.tomalbrc.filament.registry.filament;

import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import java.util.Map;
import net.minecraft.class_1792;

public class FuelRegistry {
    private static Map<class_1792, Integer> cache = new Reference2ObjectArrayMap<>();

    public static Map<class_1792, Integer> getCache() {
        return cache;
    }

    public static void add(class_1792 item, Integer value) {
        cache.putIfAbsent(item, value);
    }
}

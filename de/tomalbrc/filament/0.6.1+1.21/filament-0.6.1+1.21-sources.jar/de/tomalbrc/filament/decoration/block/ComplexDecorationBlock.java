package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public class ComplexDecorationBlock extends DecorationBlock implements class_2343 {
    public ComplexDecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties, decorationId);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new DecorationBlockEntity(blockPos, blockState);
    }
}

package de.tomalbrc.filament.mixin.polymer;

import ;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.impl.DefaultModelData;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2482;
import net.minecraft.class_2538;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DefaultModelData.class)
public class DefaultModelDataMixin {
    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void filament$additionalBlockModelTypes(CallbackInfo ci) {
        filament$addSlabs(BlockModelType.valueOf("SLAB_BLOCK"));
    }

    @Unique
    private static void filament$addSlabs(BlockModelType modelType) {
        ObjectArrayList<class_2680> list = new ObjectArrayList<>();

        // Generate all permutations
        var b = new class_2771[]{class_2771.field_12679, class_2771.field_12681, class_2771.field_12682};
        for (var s : b) {
            class_2680 state = class_2246.field_10298.method_9564().method_11657(class_2482.field_11501, s);
            list.add(state);
            DefaultModelData.SPECIAL_REMAPS.put(state, class_2246.field_10119.method_9564().method_11657(class_2482.field_11501, s));

            {
                class_2680 state2 = class_2246.field_10298.method_9564().method_11657(class_2482.field_11502, true).method_11657(class_2482.field_11501, s);
                list.add(state2);
                DefaultModelData.SPECIAL_REMAPS.put(state2, class_2246.field_10119.method_9564().method_11657(class_2482.field_11502, true).method_11657(class_2482.field_11501, s));
            }
        }

        addCopperSlab(class_2246.field_27132, class_2246.field_27170, list);
        addCopperSlab(class_2246.field_27131, class_2246.field_27169, list);
        addCopperSlab(class_2246.field_27130, class_2246.field_27168, list);
        addCopperSlab(class_2246.field_27129, class_2246.field_33410, list);

        DefaultModelData.USABLE_STATES.put(modelType, list);
    }

    @Unique
    private static void addCopperSlab(class_2248 to, class_2248 from, ObjectArrayList<class_2680> list) {
        // Generate all permutations
        var b = new class_2771[]{class_2771.field_12679, class_2771.field_12681, class_2771.field_12682};
        for (var s : b) {
            class_2680 state = from.method_9564().method_11657(class_2482.field_11501, s);
            list.add(state);
            DefaultModelData.SPECIAL_REMAPS.put(state, to.method_9564().method_11657(class_2482.field_11501, s));

            {
                class_2680 state2 = from.method_9564().method_11657(class_2482.field_11502, true).method_11657(class_2482.field_11501, s);
                list.add(state2);
                DefaultModelData.SPECIAL_REMAPS.put(state2, to.method_9564().method_11657(class_2482.field_11502, true).method_11657(class_2482.field_11501, s));
            }
        }
    }

    @Unique
    private static void addTripwire(boolean attached, BlockModelType modelType) {
        var tripwire_normal = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_ns"), 0, 0)};

        var tripwire_west = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_n"), 0, 270)};
        var tripwire_south = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_n"), 0, 180)};
        var tripwire_east = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_n"), 0, 90)};
        var tripwire_north = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_n"), 0, 0)};

        var tripwire_sw = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_ne"), 0, 180)};
        var tripwire_nw = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_ne"), 0, 270)};
        var tripwire_ew = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_ns"), 0, 90)};
        var tripwire_es = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_ne"), 0, 90)};
        var tripwire_en = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_ne"), 0, 0)};
        var tripwire_nsw = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_nse"), 0, 180)};
        var tripwire_esw = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_nse"), 0, 90)};
        var tripwire_enw = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_nse"), 0, 270)};
        var tripwire_ens = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_nse"), 0, 0)};

        var tripwire_all = new PolymerBlockModel[]{PolymerBlockModel.of(class_2960.method_60654("minecraft:block/tripwire"+(attached?"_attached":"")+"_nsew"), 0, 0)};

        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11674, true), tripwire_west);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11678, true), tripwire_south);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11673, true), tripwire_east);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11675, true), tripwire_north);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11678, true).method_11657(class_2538.field_11674, true), tripwire_sw);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11674, true), tripwire_nw);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11673, true).method_11657(class_2538.field_11674, true), tripwire_ew);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11673, true).method_11657(class_2538.field_11678, true), tripwire_es);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11678, true).method_11657(class_2538.field_11674, true), tripwire_nsw);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11673, true).method_11657(class_2538.field_11678, true).method_11657(class_2538.field_11674, true), tripwire_esw);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11678, true), tripwire_normal);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11678, true).method_11657(class_2538.field_11673, true).method_11657(class_2538.field_11674, true), tripwire_all);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11673, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11674, true), tripwire_enw);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11673, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11678, true), tripwire_ens);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true).method_11657(class_2538.field_11675, true).method_11657(class_2538.field_11673, true), tripwire_en);
        DefaultModelData.MODELS.put(class_2246.field_10589.method_9564().method_11657(class_2538.field_11683, attached).method_11657(class_2538.field_11679, true), tripwire_normal);

        ObjectArrayList<class_2680> list = new ObjectArrayList<>();

        // Generate all permutations of north, south, east, west being true or false
        var b = new boolean[]{true, false};
        for (boolean north : b) {
            for (boolean south : b) {
                for (boolean east : b) {
                    for (boolean west : b) {
                        class_2680 state = class_2246.field_10589.method_9564()
                                .method_11657(class_2538.field_11683, attached)
                                .method_11657(class_2538.field_11679, true)
                                .method_11657(class_2538.field_11675, north)
                                .method_11657(class_2538.field_11678, south)
                                .method_11657(class_2538.field_11673, east)
                                .method_11657(class_2538.field_11674, west);
                        list.add(state);
                        DefaultModelData.SPECIAL_REMAPS.put(state, state.method_11657(class_2538.field_11679, false));
                    }
                }
            }
        }

        DefaultModelData.USABLE_STATES.put(modelType, list);
    }
}

package de.tomalbrc.filament.decoration.holder;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.behaviours.decoration.Seat;
import de.tomalbrc.filament.data.behaviours.decoration.Showcase;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.util.SeatEntity;
import de.tomalbrc.filament.registry.filament.EntityRegistry;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.elements.BlockDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_6862;
import net.minecraft.class_7833;
import net.minecraft.class_7924;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class DecorationHolder extends ElementHolder {

    DecorationBlockEntity parent;

    // TODO: for block showcases, we need a reference to the original ItemStack the player put in there..!
    Object2ObjectOpenHashMap<Showcase.ShowcaseMeta, DisplayElement> showcases = new Object2ObjectOpenHashMap<>();

    Showcase showcaseDataList;
    Seat seatDataList;

    public DecorationHolder() {
        super();
    }

    public void setBlockEntity(DecorationBlockEntity blockEntity) {
        this.parent = blockEntity;

        if (blockEntity.getDecorationData().hasBlocks()) {
            this.addElement(Util.decorationItemDisplay(this.parent));
        } else if (blockEntity.getDecorationData().size() != null) {
            this.addElement(Util.decorationItemDisplay(this.parent));
            this.addElement(Util.decorationInteraction(this.parent));
        } else {
            // TODO: Why do virtual Item frames show item names?!
            //ItemFrameElement itemFrameElement = new ItemFrameElement(this.parent);
            //this.addElement(itemFrameElement);

            // Just using display+interaction again
            this.addElement(Util.decorationItemDisplay(this.parent));
            this.addElement(Util.decorationInteraction(this.parent));
        }
    }

    public Showcase.ShowcaseMeta getClosestShowcase(class_243 location) {
        if (this.showcaseDataList.size() == 1) {
            return this.showcaseDataList.get(0);
        }
        else {
            double dist = Double.MAX_VALUE;
            Showcase.ShowcaseMeta nearest = null;
            for (Showcase.ShowcaseMeta showcase : this.showcaseDataList) {
                class_243 q = this.parent.method_11016().method_46558().method_1019(new class_243(this.showcaseTranslation(showcase)));
                double distance = q.method_1022(location);

                if (distance < dist) {
                    dist = distance;
                    nearest = showcase;
                }
            }

            return nearest;
        }
    }

    public Seat.SeatMeta getClosestSeat(class_243 location) {
        if (this.seatDataList.size() == 1) {
            return this.seatDataList.get(0);
        }
        else {
            double dist = Double.MAX_VALUE;
            Seat.SeatMeta nearest = null;

            for (Seat.SeatMeta seat : this.seatDataList) {
                class_243 q = this.parent.method_11016().method_46558().method_1019(seatTranslation(seat));
                double distance = q.method_1022(location);

                if (!this.hasSeatedPlayer(seat) && distance < dist) {
                    dist = distance;
                    nearest = seat;
                }
            }

            return nearest;
        }
    }

    public class_243 seatTranslation(Seat.SeatMeta seat) {
        class_243 v3 = new class_243(seat.offset).method_1023(0, 0.3, 0).method_1024((float) Math.toRadians(this.parent.getVisualRotationYInDegrees()+180));
        return new class_243(-v3.field_1352, v3.field_1351, v3.field_1350);
    }

    private Vector3f showcaseTranslation(Showcase.ShowcaseMeta showcase) {
        return new Vector3f(showcase.offset).sub(0, 0.475f, 0).rotate(class_7833.field_40715.rotation(class_3532.field_29847 * this.parent.getVisualRotationYInDegrees()));
    }
    private BlockDisplayElement element(class_1747 blockItem) {
        BlockDisplayElement displayElement = new BlockDisplayElement();
        displayElement.setBlockState(blockItem.method_7711().method_9564());
        return displayElement;
    }
    private ItemDisplayElement element(class_1799 itemStack) {
        ItemDisplayElement displayElement = new ItemDisplayElement();
        displayElement.setItem(itemStack.method_7972());
        return displayElement;
    }
    private DisplayElement createShowcase(Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        DisplayElement element = null;

        switch (showcase.type) {
            case item -> element = this.element(itemStack);
            case block -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem) {
                    element = this.element(blockItem);
                }
            }
            case dynamic -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem) {
                    element = this.element(blockItem);
                } else {
                    element = this.element(itemStack);
                }
            }
        }

        if (element != null) {
            element.setScale(showcase.scale);
            element.setLeftRotation(showcase.rotation);
            Quaternionf rot = class_7833.field_40715.rotationDegrees(this.parent.getVisualRotationYInDegrees()+180).normalize();
            if (element instanceof BlockDisplayElement) {
                element.setTranslation(this.showcaseTranslation(showcase).add(new Vector3f(-.5f, -.5f, -.5f).rotate(rot).mul(showcase.scale)));
            } else {
                element.setTranslation(this.showcaseTranslation(showcase));
            }

            element.setRightRotation(rot);

            this.showcases.put(showcase, element);
        } else {
            Filament.LOGGER.error("In valid showcase type for " + itemStack.method_7909().method_7876());
        }

        return element;
    }

    public void setShowcaseData(Showcase showcaseData) {
        this.showcaseDataList = showcaseData;
    }

    public Showcase getShowcaseData() {
        return this.showcaseDataList;
    }

    public boolean canUseShowcaseItem(Showcase.ShowcaseMeta showcase, class_1799 item) {
        boolean hasFilterItems = showcase.filterItems != null && !showcase.filterItems.isEmpty();
        boolean hasFilterTags = showcase.filterTags != null && !showcase.filterTags.isEmpty();

        if (hasFilterTags) {
            for (var filterTag: showcase.filterTags) {
                class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, filterTag);
                if (item.method_31573(key)) {
                    return true;
                }
            }
        }

        if (hasFilterItems) {
            for (var filterTag: showcase.filterItems) {
                if (item.method_31574(filterTag)) {
                    return true;
                }
            }
        }

        return !(hasFilterItems || hasFilterTags);
    }

    public void setShowcaseItemStack(Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        boolean isBlockItem = itemStack.method_7909() instanceof class_1747;
        boolean hasElement = this.showcases.containsKey(showcase);

        DisplayElement element = this.showcases.get(showcase);
        DisplayElement newElement;

        boolean dynNeedsUpdate = showcase.type == Showcase.ShowcaseType.dynamic && hasElement && !(element instanceof BlockDisplayElement && isBlockItem);

        if (!this.showcases.containsKey(showcase) || dynNeedsUpdate) {
            if (hasElement) { // update dynamic display, remove old
                this.removeElement(element);
                this.showcases.remove(showcase);
            }

            newElement = this.createShowcase(showcase, itemStack);
            this.addElement(newElement);
        } else {
            if (element instanceof BlockDisplayElement blockDisplayElement && itemStack.method_7909() instanceof class_1747 blockItem) {
                blockDisplayElement.setBlockState(blockItem.method_7711().method_9564());
            } else if (element instanceof ItemDisplayElement itemDisplayElement) {
                itemDisplayElement.setItem(itemStack);
            }
        }

        this.tick();
    }

    public class_1799 getShowcaseItemStack(Showcase.ShowcaseMeta showcase) {
        DisplayElement element = this.showcases.get(showcase);
        if (element instanceof ItemDisplayElement itemDisplayElement) {
            return itemDisplayElement.getItem().method_7972();
        } else if (element instanceof BlockDisplayElement itemDisplayElement) {
            return itemDisplayElement.getBlockState().method_26204().method_8389().method_7854();
        }
        return class_1799.field_8037;
    }

    public void setSeatData(Seat seatData) {
        this.seatDataList = seatData;
    }

    public void seatPlayer(Seat.SeatMeta seat, class_3222 player) {
        SeatEntity seatEntity = EntityRegistry.SEAT_ENTITY.method_5883(player.method_37908());
        seatEntity.method_33574(this.seatTranslation(seat).method_1019(this.getPos()));
        player.method_37908().method_8649(seatEntity);
        player.method_5804(seatEntity);
        seatEntity.method_36456((this.parent.getVisualRotationYInDegrees()-180));
    }

    public boolean hasSeatedPlayer(Seat.SeatMeta seat) {
        return !this.getAttachment().getWorld().method_8390(SeatEntity.class, class_238.method_30048(seatTranslation(seat).method_1019(this.getPos()), 0.2, 0.2, 0.2), x -> true).isEmpty();
    }

    public boolean isSeat() {
        return this.seatDataList != null && !this.seatDataList.isEmpty();
    }

    public boolean isShowcase() {
        return this.showcaseDataList != null && !this.showcaseDataList.isEmpty();
    }

    @Override
    protected void notifyElementsOfPositionUpdate(class_243 newPos, class_243 delta) {
    }

    @Override
    public class_243 getPos() {
        return this.getAttachment() != null ? this.getAttachment().getPos() : null;
    }
}

package de.tomalbrc.filament.block;

import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import java.util.HashMap;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5819;

public class PowerlevelBlock extends SimpleBlock implements PolymerTexturedBlock {
    public static final class_2758 POWER = class_2758.method_11867("power", 0, 15);

    private final HashMap<String, class_2680> stateMap;
    private final class_2680 breakEventState;

    public PowerlevelBlock(class_2251 properties, BlockData data) {
        super(properties, data);
        this.method_9590(this.field_10647.method_11664().method_11657(POWER, 0));

        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(POWER);
    }

    @Override
    public class_2680 method_9605(class_1750 blockPlaceContext) {
        int signal = blockPlaceContext.method_8045().method_49804(blockPlaceContext.method_8037());
        return this.method_9564().method_11657(POWER, signal);
    }

    public void method_9612(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_2338 blockPos2, boolean bl) {
        if (!level.field_9236) {
            int power = blockState.method_11654(POWER);
            int signal = level.method_49804(blockPos);
            if (signal > this.stateMap.size()-1)
                signal = this.stateMap.size()-1;

            if (signal != power) {
                level.method_39279(blockPos, this, 1);
            }
        }
    }

    @Override
    public void method_9588(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        int signal = serverLevel.method_49804(blockPos);
        if (signal > this.stateMap.size()-1)
            signal = this.stateMap.size()-1;

        if (signal != blockState.method_11654(POWER)) {
            serverLevel.method_8652(blockPos, blockState.method_11657(POWER, signal), 2); // what does the 2 do..?
        }
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        int power = state.method_11654(POWER);
        if (power > this.stateMap.size()-1)
            power = this.stateMap.size()-1;

        return this.stateMap.get(String.valueOf(power));
    }
}

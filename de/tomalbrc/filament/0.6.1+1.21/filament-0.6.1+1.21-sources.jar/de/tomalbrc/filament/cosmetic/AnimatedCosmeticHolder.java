package de.tomalbrc.filament.cosmetic;

import Z;
import de.tomalbrc.bil.core.holder.entity.EntityHolder;
import de.tomalbrc.bil.core.holder.wrapper.DisplayWrapper;
import de.tomalbrc.bil.core.model.Model;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3532;

public class AnimatedCosmeticHolder extends EntityHolder {
    private final class_3222 player;
    private double prevX = 0;
    private double prevZ = 0;

    private float bodyYaw;

    public AnimatedCosmeticHolder(class_3222 player, Model model) {
        super(player, model);

        this.player = player;
    }

    @Override
    protected void updateElement(DisplayWrapper<?> display) {
        display.element().ignorePositionUpdates();
        super.updateElement(display);

        display.element().setYaw(this.bodyYaw);

        this.prevX = this.player.method_23317();
        this.prevZ = this.player.method_23321();
    }

    @Override
    public class_2168 createCommandSourceStack() {
        return this.player.method_5671();
    }

    private void tickMovement(final class_3222 player) {
        float yaw = this.player.method_36454();
        double i = player.method_23317() - this.prevX;
        double d = player.method_23321() - this.prevZ;
        float f = (float)(i * i + d * d);
        float g = this.bodyYaw;
        if (f > 0.0025f) {
            // Using internal Mojang math utils here
            float l = (float) class_3532.method_15349(d, i) * class_3532.field_29848 - 90.0F;
            float m = class_3532.method_15379(class_3532.method_15393(yaw) - l);
            if (95.f < m && m < 265.f) {
                g = l - 180.f;
            } else {
                g = l;
            }
        }

        this.turnBody(g, yaw);
    }

    public void turnBody(float bodyRotation, float yaw) {
        float f = class_3532.method_15393(bodyRotation - this.bodyYaw);
        this.bodyYaw += f * 0.3F;
        float g = class_3532.method_15393(yaw - this.bodyYaw);
        if (g < -75.0F) {
            g = -75.0F;
        }

        if (g >= 75.0F) {
            g = 75.0F;
        }

        this.bodyYaw = yaw - g;
        if (g * g > 2500.0F) {
            this.bodyYaw += g * 0.2F;
        }
    }

    @Override
    public boolean startWatching(class_3244 player) {
        var ret = super.startWatching(player);

        player.method_14364(VirtualEntityUtils.createRidePacket(this.player.method_5628(), this.getDisplayIds()));

        return ret;
    }

    @Override
    public void onTick() {
        super.onTick();

        this.tickMovement(this.player);

        // manual ticking
        //this.onAsyncTick();
    }
}

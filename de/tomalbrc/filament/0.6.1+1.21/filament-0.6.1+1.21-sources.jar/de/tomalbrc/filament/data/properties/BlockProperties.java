package de.tomalbrc.filament.data.properties;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_4970;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings({"FieldCanBeLocal", "FieldMayBeFinal"})
public class BlockProperties extends ItemProperties {
    @NotNull
    public class_2248 blockBase = class_2246.field_10340;
    @NotNull
    public class_1792 itemBase = class_1802.field_8407;

    private boolean requiresTool = false;
    private float explosionResistance = Integer.MIN_VALUE;
    private float destroyTime = Integer.MIN_VALUE;
    private boolean redstoneConductor = true;

    public class_4970.class_2251 toBlockProperties() {
        class_4970.class_2251 props = class_4970.class_2251.method_9630(this.blockBase);

        if (this.destroyTime != Integer.MIN_VALUE) props.method_36557(this.destroyTime);
        if (this.explosionResistance != Integer.MIN_VALUE) props.method_36558(this.explosionResistance);
        if (this.isLightSource()) props.method_9631((state) -> this.lightEmission);
        if (this.isLightSource()) props.method_9631((state) -> this.lightEmission);
        props.method_26236((a,b,c) -> this.redstoneConductor);
        if (this.requiresTool) props.method_29292();

        return props;
    }
}

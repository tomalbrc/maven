package de.tomalbrc.filament.util;

import de.tomalbrc.filament.data.BlockData;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import java.nio.file.Path;

public class Constants {
    public static final String MOD_ID = "filament";
    public static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir();


    public static class Behaviours {
        public static final class_2960 FUEL = class_2960.method_60655("filament", "fuel");

        // Blocks
        public static final class_2960 POWERSOURCE = class_2960.method_60655("filament", "powersource");
        public static final class_2960 REPEATER = class_2960.method_60655("filament", "repeater");
        public static final class_2960 STRIPPABLE = class_2960.method_60655("filament", "strippable");

        // Items
        public static final class_2960 COSMETIC = class_2960.method_60655("filament", "cosmetic");
        public static final class_2960 FOOD = class_2960.method_60655("filament", "food");
        public static final class_2960 ARMOR = class_2960.method_60655("filament", "armor");

        public static final class_2960 SHOOT = class_2960.method_60655("filament", "shoot");
        public static final class_2960 INSTRUMENT = class_2960.method_60655("filament", "instrument");
        public static final class_2960 TRAP = class_2960.method_60655("filament", "trap");
        public static final class_2960 EXECUTE = class_2960.method_60655("filament", "execute");

        // decoration
        public static final class_2960 ANIMATION = class_2960.method_60655("filament", "animation");
        public static final class_2960 CONTAINER = class_2960.method_60655("filament", "container");
        public static final class_2960 LOCK = class_2960.method_60655("filament", "lock");
        public static final class_2960 SEAT = class_2960.method_60655("filament", "seat");
        public static final class_2960 SHOWCASE = class_2960.method_60655("filament", "showcase");
    }

    public static class BlockTypes {
        public static final BlockData.BlockType BLOCK = BlockData.BlockType.ofFilament("block");
        public static final BlockData.BlockType COUNT = BlockData.BlockType.ofFilament("count");
        public static final BlockData.BlockType COLUMN = BlockData.BlockType.ofFilament("column");
        public static final BlockData.BlockType DIRECTIONAL = BlockData.BlockType.ofFilament("directional");
        public static final BlockData.BlockType HORIZONTAL_DIRECTIONAL = BlockData.BlockType.ofFilament("horizontal_directional");
        public static final BlockData.BlockType POWERED_DIRECTIONAL = BlockData.BlockType.ofFilament("powered_directional");
        public static final BlockData.BlockType POWERLEVEL = BlockData.BlockType.ofFilament("powerlevel");
        public static final BlockData.BlockType SLAB = BlockData.BlockType.ofFilament("slab");
    }
}

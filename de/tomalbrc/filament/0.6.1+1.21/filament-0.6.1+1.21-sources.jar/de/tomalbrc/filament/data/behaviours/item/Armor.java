package de.tomalbrc.filament.data.behaviours.item;

import de.tomalbrc.filament.behaviour.item.ItemBehaviour;
import net.minecraft.class_1304;
import net.minecraft.class_2960;

/**
 * Armor item behaviours, using fancypants shader via polymer
 */
public class Armor implements ItemBehaviour {
    /**
     * The equipment slot for the armor piece (e.g., head, chest, legs, or feet).
     */
    public class_1304 slot;

    /**
     * The resource location of the texture associated with the armor.
     */
    public class_2960 texture;
}

package de.tomalbrc.filament.item;

import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.data.behaviours.item.Instrument;
import de.tomalbrc.filament.util.Constants;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5712;
import org.jetbrains.annotations.NotNull;

public class InstrumentItem extends SimpleItem {
    public InstrumentItem(class_1793 properties, ItemData itemData) {
        super(properties, itemData);
    }

    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 interactionHand) {
        var res = super.method_7836(level, player, interactionHand);

        class_1799 itemStack = player.method_5998(interactionHand);

        if (itemData.isInstrument()) {
            assert itemData.behaviour() != null;
            Instrument instrument = itemData.behaviour().get(Constants.Behaviours.INSTRUMENT);
            player.method_6019(interactionHand);
            play(level, player, instrument);
            if (instrument.useDuration > 0) player.method_7357().method_7906(this, instrument.useDuration);
            if (res.method_5467() == class_1269.field_21466) player.method_7259(class_3468.field_15372.method_14956(this));
            return class_1271.method_22428(itemStack);
        } else {
            return class_1271.method_22431(itemStack);
        }
    }

    private static void play(class_1937 level, class_1657 player, Instrument instrument) {
        float f = instrument.range / 25.0F;
        level.method_43129(null, player, class_3414.method_47908(instrument.sound), class_3419.field_15247, f, 1.0F);
        level.method_32888(class_5712.field_39415, player.method_19538(), class_5712.class_7397.method_43285(player));
    }
}

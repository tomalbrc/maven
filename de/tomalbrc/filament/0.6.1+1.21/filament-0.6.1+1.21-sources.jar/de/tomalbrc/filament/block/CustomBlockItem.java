package de.tomalbrc.filament.block;

import de.tomalbrc.filament.util.Util;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class CustomBlockItem extends class_1747 {
    public CustomBlockItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    protected boolean method_7708(class_1750 context, class_2680 state) {
        if (!super.method_7708(context, state)) {
            return false;
        }

        if (context.method_8036() instanceof class_3222 player) {
            Util.handleBlockPlaceEffects(player, context.method_20287(), context.method_8037(), state.method_26231());
        }

        return true;
    }
}

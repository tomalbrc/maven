package de.tomalbrc.filament.util;

import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3259;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import java.io.IOException;
import java.util.Set;
import java.util.function.Consumer;

public class FilamentAssetReloadListener implements SimpleSynchronousResourceReloadListener {
    Consumer<ResourcePackBuilder> lastConsumer = null;

    @Override
    public class_2960 getFabricId() {
        return class_2960.method_60655("filament", "assets");
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        // ok lets just hope capturing resourceManager like this works in java™
        Consumer<ResourcePackBuilder> consumer = resourcePackBuilder -> {
            resourceManager.method_29213().forEach(resources -> {
                Set<String> clientResources = resources.method_14406(class_3264.field_14188);
                if (resources instanceof class_3259 pathPackResources) {
                    for (var namespace : clientResources) {
                        pathPackResources.method_14408(class_3264.field_14188, "", namespace, (resourceLocation,ioSupplier) -> {
                            try {
                                resourcePackBuilder.addData("assets/" + resourceLocation.method_12832(), ioSupplier.get().readAllBytes());
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                }
            });
        };

        if (lastConsumer != null) {
            PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.unregister(lastConsumer);
        }

        lastConsumer = consumer;
        PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(consumer);
    }
}
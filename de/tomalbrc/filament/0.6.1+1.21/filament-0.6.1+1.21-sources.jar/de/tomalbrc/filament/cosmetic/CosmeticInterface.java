package de.tomalbrc.filament.cosmetic;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public interface CosmeticInterface {
    void filament$addHolder(class_3222 serverPlayer, class_1792 item, class_1799 itemStack);

    void filament$destroyHolder();
}

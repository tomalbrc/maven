package de.tomalbrc.filament.gen;

import de.tomalbrc.filament.data.resource.ItemResource;
import net.minecraft.class_2960;

public class ItemModelGenerator {
    public static class_2960 generate(ItemResource itemResource) {
        return null;
    }
}

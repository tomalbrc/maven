package de.tomalbrc.filament.data.behaviours.item;

import de.tomalbrc.filament.behaviour.item.ItemBehaviour;
import net.minecraft.class_2960;

public class Instrument implements ItemBehaviour {
    public class_2960 sound = null;

    public int range = 0;

    public int useDuration = 0;
}

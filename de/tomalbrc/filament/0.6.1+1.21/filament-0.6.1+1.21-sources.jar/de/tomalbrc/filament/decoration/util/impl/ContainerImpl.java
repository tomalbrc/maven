package de.tomalbrc.filament.decoration.util.impl;

import de.tomalbrc.filament.data.behaviours.decoration.Container;
import de.tomalbrc.filament.util.FilamentContainer;
import net.minecraft.class_1262;
import net.minecraft.class_2487;
import net.minecraft.class_3917;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

/**
 * Container implementation
 * @param name
 * @param container
 * @param menuType
 * @param purge
 */
public record ContainerImpl(
        String name,
        FilamentContainer container,
        class_3917<?> menuType,

        boolean purge
) {
    public void write(class_2487 compoundTag, class_7225.class_7874 provider) {
        compoundTag.method_10566("Container", new class_2487().method_10543(class_1262.method_5426(new class_2487(), this.container.field_5828, provider)));
    }

    public void read(class_2487 compoundTag, class_7225.class_7874 provider) {
        class_2487 compoundTag2 = compoundTag.method_10562("Container");
        if (!compoundTag2.method_33133()) {
            class_1262.method_5429(compoundTag2, container.field_5828, provider);
        }
    }

    public static class_3917<?> getMenuType(@NotNull Container containerData) {
        return switch (containerData.size) {
            case 9 -> class_3917.field_18664;
            case 2 * 9 -> class_3917.field_18665;
            case 3 * 9 -> class_3917.field_17326;
            case 4 * 9 -> class_3917.field_18666;
            case 5 * 9 -> class_3917.field_18667;
            case 6 * 9 -> class_3917.field_17327;
            case 5 -> class_3917.field_17337;
            default ->
                    throw new IllegalStateException("Unexpected container size: " + containerData.name + " " + containerData.size);
        };
    }
}

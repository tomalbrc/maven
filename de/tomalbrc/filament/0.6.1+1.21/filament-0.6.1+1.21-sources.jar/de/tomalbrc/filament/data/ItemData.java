package de.tomalbrc.filament.data;

import de.tomalbrc.filament.data.behaviours.block.BehaviourMap;
import de.tomalbrc.filament.data.properties.ItemProperties;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_9323;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("unused")
public record ItemData(
        @NotNull class_2960 id,
        @Nullable class_1792 vanillaItem,
        @Nullable ItemResource itemResource,
        @Nullable BehaviourMap behaviour,
        @Nullable ItemProperties properties,
        @Nullable class_9323 components
) {
    @SuppressWarnings({"FieldCanBeLocal"})

    public Object2ObjectOpenHashMap<String, PolymerModelData> requestModels() {
        Object2ObjectOpenHashMap<String, PolymerModelData> map = new Object2ObjectOpenHashMap<>();
        if (itemResource != null) {
            itemResource.models().forEach((key, value) -> map.put(key, PolymerResourcePackUtils.requestModel(vanillaItem, value)));
        }
        return map.isEmpty() ? null : map;
    }

    public boolean isFood() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.FOOD) != null;
    }

    public boolean isArmor() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.ARMOR) != null;
    }

    public boolean isCosmetic() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.COSMETIC) != null;
    }

    public boolean isFuel() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.FUEL) != null;
    }

    public boolean canShoot() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.SHOOT) != null;
    }
    public boolean isInstrument() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.INSTRUMENT) != null;
    }

    public boolean isTrap() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.TRAP) != null;
    }

    public boolean canExecute() {
        return this.behaviour != null && this.behaviour.get(Constants.Behaviours.EXECUTE) != null;
    }
}

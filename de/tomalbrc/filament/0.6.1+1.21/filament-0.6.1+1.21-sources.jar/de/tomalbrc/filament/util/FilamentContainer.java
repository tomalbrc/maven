package de.tomalbrc.filament.util;

import net.minecraft.class_1277;
import net.minecraft.class_1657;

public class FilamentContainer extends class_1277 {
    private boolean valid = true;

    private final boolean purge;

    private int watcher = 0;

    private Runnable closeCallback;
    private Runnable openCallback;

    public FilamentContainer(int size, boolean purge) {
        super(size);
        this.purge = purge;
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return this.valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    @Override
    public void method_5435(class_1657 player) {
        super.method_5435(player);
        if (this.watcher == 0 && this.openCallback != null) {
            this.openCallback.run();
        }
        this.watcher++;
    }

    @Override
    public void method_5432(class_1657 player) {
        super.method_5432(player);
        this.watcher--;
        if (this.purge && this.watcher == 0)
            this.method_5448();

        if (this.watcher == 0 && this.closeCallback != null) {
            this.closeCallback.run();
        }
    }

    public void setCloseCallback(Runnable closeCallback) {
        this.closeCallback = closeCallback;
    }

    public void setOpenCallback(Runnable openCallback) {
        this.openCallback = openCallback;
    }
}

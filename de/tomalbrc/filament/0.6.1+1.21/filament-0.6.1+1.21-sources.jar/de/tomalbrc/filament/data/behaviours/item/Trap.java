package de.tomalbrc.filament.data.behaviours.item;

import de.tomalbrc.filament.behaviour.item.ItemBehaviour;
import java.util.List;
import net.minecraft.class_2960;

/**
 * Mob trap
 */
public class Trap implements ItemBehaviour {
    // allowed util types to trap
    public List<class_2960> types = null;

    public List<class_2960> requiredEffects = null;

    public int chance = 50;

    public int useDuration = 0;
}

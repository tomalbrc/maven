package de.tomalbrc.filament.block;

import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.PolymerTexturedBlock;
import java.util.HashMap;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3222;

public class CountBlock extends SimpleBlock implements PolymerTexturedBlock {
    public static final class_2758 COUNT = class_2758.method_11867("count", 1, 4);

    private final HashMap<String, class_2680> stateMap;
    private final class_2680 breakEventState;

    public CountBlock(class_2251 properties, BlockData data) {
        super(properties, data);
        this.method_9590(this.field_10647.method_11664().method_11657(COUNT, 1));

        this.stateMap = data.createStateMap();
        this.breakEventState = data.properties().blockBase.method_9564();
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(COUNT);
    }

    @Override
    public boolean method_9616(class_2680 blockState, class_1750 blockPlaceContext) {
        return !blockPlaceContext.method_8046() && blockPlaceContext.method_8041().method_7909() == this.method_8389() && blockState.method_11654(COUNT) < 4 || super.method_9616(blockState, blockPlaceContext);
    }

    @Override
    public class_2680 method_9605(class_1750 blockPlaceContext) {
        class_2680 blockState = blockPlaceContext.method_8045().method_8320(blockPlaceContext.method_8037());
        if (blockState.method_27852(this)) {
            return blockState.method_28493(COUNT);
        }
        return super.method_9605(blockPlaceContext);
    }

    @Override
    public class_2680 getPolymerBreakEventBlockState(class_2680 state, class_3222 player) {
        return this.breakEventState;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return switch (state.method_11654(COUNT)) {
            case 2 -> this.stateMap.get("2");
            case 3 -> this.stateMap.get("3");
            case 4 -> this.stateMap.get("4");
            default -> this.stateMap.get("1");
        };
    }
}

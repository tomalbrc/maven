package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1657.class)
public abstract class PlayerMixin {
    @ModifyExpressionValue(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;"))
    public class_1799 bl4(class_1799 original) {
        if (original.method_7909() instanceof SimpleItem simpleItem && simpleItem.getItemData().components().method_57832(class_9334.field_50077)) {
            return class_1802.field_8091.method_7854();
        }
        return original;
    }
}

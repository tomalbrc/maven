package de.tomalbrc.filament.data.behaviours.item;

import de.tomalbrc.filament.behaviour.item.ItemBehaviour;
import net.minecraft.class_2960;

public class Execute implements ItemBehaviour {
    public boolean consumes;

    public String command;

    public class_2960 sound;
}

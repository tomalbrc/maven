package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.registry.filament.FuelRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_2609;

// Fuel behaviour support
@Mixin(class_2609.class)
public class AbstractFurnaceBlockEntityMixin {
    @Inject(method = "getFuel", at = @At("RETURN"))
    private static void getFuelCache(CallbackInfoReturnable<Map<class_1792, Integer>> cir) {
        cir.getReturnValue().putAll(FuelRegistry.getCache());
    }
}

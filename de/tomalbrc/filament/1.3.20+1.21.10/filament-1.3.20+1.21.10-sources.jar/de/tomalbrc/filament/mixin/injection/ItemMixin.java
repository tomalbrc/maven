package de.tomalbrc.filament.mixin.injection;

import de.tomalbrc.filament.injection.FilamentItemExtension;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1792.class)
public class ItemMixin implements FilamentItemExtension {

}

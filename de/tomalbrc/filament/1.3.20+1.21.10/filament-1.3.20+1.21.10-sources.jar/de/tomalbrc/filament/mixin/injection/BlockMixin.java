package de.tomalbrc.filament.mixin.injection;

import de.tomalbrc.filament.injection.FilamentBlockExtension;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2248.class)
public class BlockMixin implements FilamentBlockExtension {

}

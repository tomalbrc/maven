package de.tomalbrc.filament.mixin.behaviour.oxidizable;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.Oxidizable;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5547;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5547.class)
public interface ChangeOverTimeBlockMixin {
    @WrapOperation(method = "getNextState", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"))
    private class_2680 filament$oxidizableState(class_3218 instance, class_2338 pos, Operation<class_2680> original) {
        var state = original.call(instance, pos);
        if (state.method_26204().isFilamentBlock()) {
            Oxidizable oxidizable;
            if ((oxidizable = state.method_26204().get(Behaviours.OXIDIZABLE)) != null) {
                return switch (oxidizable.getConfig().weatherState) {
                    case field_28704 -> class_2246.field_27119.method_9564();
                    case field_28705 -> class_2246.field_27118.method_9564();
                    case field_28706 -> class_2246.field_27117.method_9564();
                    case field_28707 -> class_2246.field_27116.method_9564();
                };
            }
        }

        return state;
    }
}

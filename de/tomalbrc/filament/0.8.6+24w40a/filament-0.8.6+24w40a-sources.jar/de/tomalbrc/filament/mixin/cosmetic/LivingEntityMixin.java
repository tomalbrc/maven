package de.tomalbrc.filament.mixin.cosmetic;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.cosmetic.AnimatedCosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.cosmetic.CosmeticUtil;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.registry.ModelRegistry;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value = class_1309.class)
public class LivingEntityMixin implements CosmeticInterface {
    @Unique
    private CosmeticHolder filamentCosmeticHolder;

    @Unique
    private AnimatedCosmeticHolder filamentAnimatedCosmeticHolder;

    @Inject(method = "getEquipmentSlotForItem", at = @At(value = "HEAD"), cancellable = true)
    private void filament$customGetEquipmentSlotForItem(class_1799 itemStack, CallbackInfoReturnable<class_1304> cir) {
        Cosmetic.Config cosmetic = CosmeticUtil.getCosmeticData(itemStack);
        if (cosmetic != null) {
            cir.setReturnValue(cosmetic.slot);
        }
    }

    @Inject(method = "onEquipItem", at = @At(value = "HEAD"))
    private void filament$customOnEquipItem(class_1304 equipmentSlot, class_1799 itemStack, class_1799 itemStack2, CallbackInfo ci) {
        if (equipmentSlot == class_1304.field_6174 && (filamentCosmeticHolder != null || filamentAnimatedCosmeticHolder != null)) {
            filament$destroyHolder();
        }

        if (equipmentSlot == class_1304.field_6174 && !itemStack2.method_7960() && CosmeticUtil.isCosmetic(itemStack2) && (Object)this instanceof class_1309 serverPlayer) {
            filament$addHolder(serverPlayer, itemStack2.method_7909(), itemStack2);
        }
    }

    @Inject(method = "doHurtEquipment", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/entity/LivingEntity;getItemBySlot(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;", shift = At.Shift.AFTER), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void filament$customOnDoHurtEquipment(class_1282 damageSource, float f, class_1304[] equipmentSlots, CallbackInfo ci, @Local class_1799 itemStack, @Local class_1304 equipmentSlot) {
        if (!(itemStack.method_7909() instanceof class_1738) && itemStack.method_7909() instanceof SimpleItem && itemStack.method_58407(damageSource)) {
            int i = (int)Math.max(1.0F, f / 4.0F);
            itemStack.method_7970(i, (class_1309)(Object)this, equipmentSlot);
        }
    }

    @Inject(method = "remove", at = @At(value = "HEAD"))
    private void filament$onRemove(class_1297.class_5529 removalReason, CallbackInfo ci) {
        filament$destroyHolder();
    }

    @Unique public void filament$addHolder(class_1309 livingEntity, class_1792 simpleItem, class_1799 itemStack) {
        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(simpleItem);

        if (cosmeticData.model != null) {
            if (filamentAnimatedCosmeticHolder == null) {
                filamentAnimatedCosmeticHolder = new AnimatedCosmeticHolder(livingEntity, ModelRegistry.getModel(cosmeticData.model));
                EntityAttachment.ofTicking(filamentAnimatedCosmeticHolder, livingEntity);

                if (livingEntity instanceof class_3222 serverPlayer)
                    filamentAnimatedCosmeticHolder.startWatching(serverPlayer);

                if (cosmeticData.autoplay != null) {
                    filamentAnimatedCosmeticHolder.getAnimator().playAnimation(cosmeticData.autoplay);
                }
            }
        }
        else {
            if (filamentCosmeticHolder == null) {
                filamentCosmeticHolder = new CosmeticHolder(livingEntity, itemStack);
                EntityAttachment.ofTicking(filamentCosmeticHolder, livingEntity);

                if (livingEntity instanceof class_3222 serverPlayer)
                    filamentCosmeticHolder.startWatching(serverPlayer);
            }
        }
    }

    @Unique
    public void filament$destroyHolder() {
        if (filamentAnimatedCosmeticHolder != null) {
            filamentAnimatedCosmeticHolder.getAttachment().destroy();
            filamentAnimatedCosmeticHolder.destroy();
            filamentAnimatedCosmeticHolder = null;
        }
        if (filamentCosmeticHolder != null) {
            filamentCosmeticHolder.getAttachment().destroy();
            filamentCosmeticHolder.destroy();
            filamentCosmeticHolder = null;
        }
    }
}

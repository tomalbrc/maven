package de.tomalbrc.filament.data;

import com.google.gson.JsonParseException;
import com.google.gson.annotations.SerializedName;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.data.properties.BlockProperties;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceArrayMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2259;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9323;


public record BlockData(
        @NotNull class_2960 id,
        @Nullable class_1792 vanillaItem,
        @NotNull BlockResource blockResource,
        @Nullable ItemResource itemResource,
        @Nullable BlockModelType blockModelType,
        @Nullable BlockProperties properties,
        @SerializedName("behaviour")
        @Nullable BehaviourConfigMap behaviourConfig,
        @Nullable class_9323 components,
        @SerializedName("group")
        @Nullable class_2960 itemGroup
) {
    @Override
    @NotNull
    public BlockProperties properties() {
        if (properties == null) {
            return BlockProperties.EMPTY;
        }
        return properties;
    }

    @Override
    @NotNull
    public class_9323 components() {
        if (components == null) {
            return class_9323.field_49584;
        }
        return components;
    }

    @Override
    @NotNull
    public class_1792 vanillaItem() {
        if (vanillaItem == null) {
            return class_1802.field_8407;
        }
        return vanillaItem;
    }

    public Map<class_2680, BlockStateMeta> createStandardStateMap() {
        Reference2ReferenceArrayMap<class_2680, BlockStateMeta> val = new Reference2ReferenceArrayMap<>();

        if (blockResource.couldGenerate()) {
            //val = BlockModelGenerator.generate(blockResource);
            throw new UnsupportedOperationException("Not implemented");
        } else if (blockResource.models() != null && this.blockModelType != null) {
            for (Map.Entry<String, class_2960> entry : this.blockResource.models().entrySet()) {
                PolymerBlockModel blockModel = PolymerBlockModel.of(entry.getValue());

                BlockModelType finalType = this.blockModelType;
                boolean weAreInTrouble = false;
                if (PolymerBlockResourceUtils.getBlocksLeft(finalType) <= 0) {
                    finalType = BlockModelType.FULL_BLOCK;
                    if (PolymerBlockResourceUtils.getBlocksLeft(finalType) <= 0) {
                        weAreInTrouble = true;
                        Filament.LOGGER.error("Filament: Ran out of blockModelTypes to use AND FULL_BLOCK ran out too! Using Bedrock block temporarily. Fix your Block-Config for "+id()+"!");
                    } else
                        Filament.LOGGER.error("Filament: Ran out of blockModelTypes to use! Using FULL_BLOCK");
                }
                class_2680 requestedState = weAreInTrouble ? null : PolymerBlockResourceUtils.requestBlock(finalType, blockModel);

                if (entry.getKey().equals("default")) {
                    val.put(class_7923.field_41175.method_10223(id).orElseThrow().comp_349().method_9564(), BlockStateMeta.of(weAreInTrouble ? class_2246.field_9987.method_9564() : requestedState, blockModel));
                }
                else {
                    class_2259.class_7211 parsed;
                    String str = String.format("%s[%s]", id, entry.getKey());
                    try {
                        parsed = class_2259.method_41957(class_7923.field_41175, str, false);
                    } catch (CommandSyntaxException e) {
                        e.printStackTrace();
                        throw new JsonParseException("Invalid BlockState value: " + str);
                    }

                    val.put(parsed.comp_622(), BlockStateMeta.of(weAreInTrouble ? class_2246.field_9987.method_9564() : requestedState, blockModel));
                }
            }
        }

        return val;
    }

    public record BlockStateMeta(class_2680 blockState, PolymerBlockModel polymerBlockModel) {
        public static BlockStateMeta of(class_2680 blockState, PolymerBlockModel blockModel) {
            return new BlockStateMeta(blockState, blockModel);
        }
    }
}

package de.tomalbrc.filament;

import com.mojang.logging.LogUtils;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.command.FilamentCommand;
import de.tomalbrc.filament.data.ItemGroupData;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.*;
import de.tomalbrc.filament.sound.SoundFix;
import de.tomalbrc.filament.util.*;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7659;
import net.minecraft.class_7780;
import org.slf4j.Logger;

public class Filament implements ModInitializer {
    public static final Logger LOGGER = LogUtils.getLogger();
    public static class_7780<class_7659> REGISTRY_ACCESS;

    @Override
    public void onInitialize() {
        PolymerResourcePackUtils.markAsRequired();
        FilamentComponents.register();
        Behaviours.register();
        SkinUtil.registerEventHandler();
        Translations.registerEventHandler();
        EntityRegistry.register();

        if (FilamentConfig.getInstance().soundModule) SoundFix.init();

        if (FilamentConfig.getInstance().commands) {
            CommandRegistrationCallback.EVENT.register((dispatcher, context, selection) -> FilamentCommand.register(dispatcher));
        }

        PolymerBlockUtils.BREAKING_PROGRESS_UPDATE.register(VirtualDestroyStage::updateState);
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (state.method_26204() instanceof DecorationBlock && !world.method_8608()) {
                ((VirtualDestroyStage.ServerGamePacketListenerExtF) ((class_3222)player).field_13987).filament$getVirtualDestroyStage().setState(-1);
            }
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.method_8608() && hand == class_1268.field_5808) {
                class_2338 pos = hitResult.method_17777();
                class_2680 blockState = world.method_8320(pos);
                if (DecorationRegistry.isDecoration(blockState) && world.method_8321(pos) instanceof DecorationBlockEntity decorationBlockEntity) {
                    return decorationBlockEntity.decorationInteract((class_3222) player, hand, hitResult.method_17784());
                }
            }

            return class_1269.field_5811;
        });

        ItemGroupRegistry.register(new ItemGroupData(Constants.ITEM_GROUP_ID, class_2960.method_60656("diamond"), "<c:blue>Filament Items"));
        ItemGroupRegistry.register(new ItemGroupData(Constants.BLOCK_GROUP_ID, class_2960.method_60656("furnace"), "<c:blue>Filament Blocks"));
        ItemGroupRegistry.register(new ItemGroupData(Constants.DECORATION_GROUP_ID, class_2960.method_60656("lantern"), "<c:blue>Filament Decorations"));

        FilamentReloadUtil.registerEarlyReloadListener(new FilamentAssetReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ModelRegistry.AjModelReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ItemRegistry.ItemDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new BlockRegistry.BlockDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new DecorationRegistry.DecorationDataReloadListener());
        if (FilamentConfig.getInstance().entityModule)
            FilamentReloadUtil.registerEarlyReloadListener(new EntityRegistry.EntityDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ItemGroupRegistry.ItemGroupDataReloadListener());

        VirtualDestroyStage.destroy(null);

        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            FilamentClient.init();
        }

        if (FilamentConfig.getInstance().debug) {
            LOGGER.info("Available Polymer block model types:");
            for (BlockModelType blockModelType : BlockModelType.values()) {
                LOGGER.info("\t{} = {}", blockModelType.name(), PolymerBlockResourceUtils.getBlocksLeft(blockModelType));
            }
        }
    }
}

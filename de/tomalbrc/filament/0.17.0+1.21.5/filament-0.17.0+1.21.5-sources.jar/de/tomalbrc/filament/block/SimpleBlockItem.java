package de.tomalbrc.filament.block;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.item.FilamentItem;
import de.tomalbrc.filament.item.FilamentItemDelegate;
import de.tomalbrc.filament.util.BlockUtil;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_6903;
import net.minecraft.class_7699;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import java.util.function.Consumer;

public class SimpleBlockItem extends class_1747 implements PolymerItem, FilamentItem, BehaviourHolder {
    private final Data data;

    protected final BehaviourMap behaviours = new BehaviourMap();
    protected final FilamentItemDelegate delegate;

    public SimpleBlockItem(class_1793 properties, class_2248 block, Data data) {
        super(block, properties);
        this.data = data;
        this.initBehaviours(data.behaviour());

        this.delegate = new FilamentItemDelegate(this);
    }

    @Override
    public Data getData() {
        return this.data;
    }

    @Override
    public FilamentItemDelegate getDelegate() {
        return this.delegate;
    }

    @Override
    @NotNull
    public class_7699 method_45322() {
        return this.method_7711().method_45322();
    }

    @Override
    protected boolean method_7708(class_1750 context, class_2680 state) {
        if (!super.method_7708(context, state)) {
            return false;
        }

        if (context.method_8036() instanceof class_3222 player) {
            BlockUtil.handleBlockPlaceEffects(player, context.method_20287(), context.method_8037(), state.method_26231());
        }

        return true;
    }


    @Override
    public BehaviourMap getBehaviours() {
        return this.behaviours;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void method_7860(class_1799 itemStack) {
        super.method_7860(itemStack);

        if (this.getData() != null) {
            for (Map.Entry<class_9331<?>, JsonObject> entry : this.getData().getAdditionalComponents().entrySet()) {
                var codec = entry.getKey().method_57875();
                assert codec != null;

                class_6903.class_7863 registryInfoLookup = Json.DataComponentsDeserializer.createContext(Filament.REGISTRY_ACCESS.method_45926());
                var result = codec.decode(class_6903.method_40414(JsonOps.INSTANCE, registryInfoLookup), entry.getValue());
                if (result.hasResultOrPartial()) {
                    class_9331 type = entry.getKey();
                    itemStack.method_57379(type, (Object) result.getOrThrow().getFirst());
                }
            }
        }
    }

    @Override
    public void method_7852(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
        this.delegate.onUseTick(level, livingEntity, itemStack, i);
    }

    @Override
    public boolean method_7840(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        return this.delegate.releaseUsing(itemStack, level, livingEntity, useDuration, () -> super.method_7840(itemStack, level, livingEntity, useDuration));
    }

    @Override
    public boolean method_7838(class_1799 itemStack) {
        return this.delegate.useOnRelease(itemStack, () -> super.method_7838(itemStack));
    }

    @Override
    public int method_7881(class_1799 itemStack, class_1309 livingEntity) {
        return this.delegate.getUseDuration(itemStack, livingEntity, () -> super.method_7881(itemStack, livingEntity));
    }

    @Override
    @NotNull
    public class_1839 method_7853(class_1799 itemStack) {
        return this.delegate.getUseAnimation(itemStack, () -> super.method_7853(itemStack));
    }

    @Override
    public void method_59978(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        this.delegate.postHurtEnemy(itemStack, livingEntity, livingEntity2);
    }

    @Override
    public void method_67187(class_1799 itemStack, class_9635 tooltipContext, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 tooltipFlag) {
        this.delegate.appendHoverText(itemStack, tooltipContext, tooltipDisplay, consumer, tooltipFlag);
        this.data.properties().appendHoverText(consumer);
        super.method_67187(itemStack, tooltipContext, tooltipDisplay, consumer, tooltipFlag);
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, PacketContext packetContext) {
        return this.getData().vanillaItem();
    }

    @Override
    public final class_1799 getPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, PacketContext packetContext) {
        return Util.filamentItemStack(itemStack, tooltipType, packetContext, this);
    }

    @Override
    @NotNull
    public class_1269 method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        return this.delegate.use(this, level, user, hand, () -> super.method_7836(level, user, hand));
    }

    @Override
    @NotNull
    public class_1269 method_7884(class_1838 useOnContext) {
        return this.delegate.useOn(useOnContext, () -> {
            if (this.method_7711() instanceof SimpleBlock) {
                var res = super.method_7884(useOnContext);
                if (res.method_23665()) {
                    return res;
                }
                return class_1269.field_5814;
            }

            return useOnContext.method_8041().method_57826(class_9334.field_53964) ? super.method_7836(useOnContext.method_8045(), useOnContext.method_8036(), useOnContext.method_20287()) : class_1269.field_5814;
        });
    }

    @Override
    public boolean method_7879(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_1309 livingEntity) {
        return this.delegate.mineBlock(itemStack, level, blockState, blockPos, livingEntity, () -> super.method_7879(itemStack, level, blockState, blockPos, livingEntity));
    }

    /// Entity Damaging behaviours
    @Override
    public float method_58403(class_1297 entity, float f, class_1282 damageSource) {
        return this.delegate.getAttackDamageBonus(entity, f, damageSource, () -> super.method_58403(entity, f, damageSource));
    }

    @Override
    @Nullable
    public class_1282 method_64193(class_1309 livingEntity) {
        return this.delegate.getDamageSource(livingEntity, () -> super.method_64193(livingEntity));
    }
}
package de.tomalbrc.filament.data.resource;

import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import net.minecraft.class_2960;

public record BlockResource(Map<String, PolymerBlockModel> models,
                           Map<String, class_2960> textures,
                           Map<String, class_2960> vanilla) implements ResourceProvider {

    public boolean couldGenerate() {
        return this.textures != null;
    }

    @Override
    public Map<String, class_2960> getModels() {
        var map = new Object2ObjectOpenHashMap<String, class_2960>();
        for (Map.Entry<String, PolymerBlockModel> entry : models.entrySet()) {
            var model = entry.getValue().model();
            var itemPath = "item/";
            if (model.method_12832().startsWith(itemPath))
                model = model.method_45136(model.method_12832().substring(0, itemPath.length()));
            map.put(entry.getKey(), model);
        }
        return map;
    }
}

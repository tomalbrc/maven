package de.tomalbrc.filament.behaviour.block;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.AbstractBlockData;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.properties.BlockProperties;
import eu.pb4.polymer.blocks.impl.BlockExtBlockMapper;
import eu.pb4.polymer.blocks.impl.DefaultModelData;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import eu.pb4.polymer.resourcepack.extras.api.format.blockstate.BlockStateAsset;
import eu.pb4.polymer.resourcepack.extras.api.format.blockstate.StateModelVariant;
import eu.pb4.polymer.resourcepack.extras.api.format.blockstate.StateMultiPartDefinition;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceArrayMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_10225;
import net.minecraft.class_10774;
import net.minecraft.class_10776;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2358;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_6895;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class Fire implements BlockBehaviour<Fire.Config> {
    private static final List<FireModelEntry> FIRE_MODELS = ObjectArrayList.of(FireModelEntry.DEFAULT);
    private static final class_2358 FIRE_BLOCK = (class_2358) class_2246.field_10036;
    private static final Map<class_2248, JsonArray> holderData = new Reference2ObjectArrayMap<>();

    public static Map<class_2248, class_2248> MATERIAL_BLOCKS;

    private final Config config;

    public Fire(Config config) {
        this.config = config;
    }

    public static class_2248 getMaterialFire(class_2680 blockState) {
        if (MATERIAL_BLOCKS == null) {
            var setCodec = class_6895.method_40340(class_7924.field_41254);

            var map = new Reference2ReferenceArrayMap<class_2248, class_2248>();
            for (Map.Entry<class_2248, JsonArray> entry : holderData.entrySet()) {
                var arr = entry.getValue();
                for (JsonElement element : arr) {
                    var holderSet = setCodec.decode(class_6903.method_46632(JsonOps.INSTANCE, Filament.REGISTRY_ACCESS.method_45926()), element);
                    holderSet.ifSuccess(x -> {
                        for (class_6880<class_2248> holder : x.getFirst()) {
                            map.put(holder.comp_349(), entry.getKey());
                        }
                    });
                }
            }

            MATERIAL_BLOCKS = map;
        }

        return MATERIAL_BLOCKS.get(blockState.method_26204());
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        JsonArray arr = new JsonArray();
        if (config.blocks != null) {
            for (class_2960 location : config.blocks) {
                arr.add(location.toString());
            }
        }
        if (config.blockTags != null) {
            for (class_2960 location : config.blockTags) {
                arr.add("#" + location.toString());
            }
        }

        holderData.put(block, arr);
    }

    @Override
    @NotNull
    public Fire.Config getConfig() {
        return this.config;
    }

    public static class Config {
        public boolean hurt = true;
        public boolean tick = true;
        public boolean lightPortal = true;
        public float damage = 1.f;
        public List<class_2960> blocks;
        public List<class_2960> blockTags;
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(class_2358.field_11096, false).method_11657(class_2358.field_11094, false).method_11657(class_2358.field_11089, false).method_11657(class_2358.field_11088, false).method_11657(class_2358.field_11093, false).method_11657(class_2358.field_11092, 0);
    }

    @Override
    public void playerWillDestroy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        FIRE_BLOCK.method_9576(level, blockPos, blockState, player);
    }

    @Override
    public void entityInside(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1297 entity, class_10774 insideBlockEffectApplier) {
        if (config.hurt) {
            insideBlockEffectApplier.method_67638(class_10776.field_56643);
            insideBlockEffectApplier.method_67640(class_10776.field_56643, (e) -> e.method_64419(e.method_37908().method_48963().method_48794(), config.damage));
        }
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        return blockState.method_26204().method_34725(FIRE_BLOCK.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource));
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 blockState, class_1750 blockPlaceContext) {
        return blockState.method_26204().method_34725(FIRE_BLOCK.method_10198(blockPlaceContext.method_8045(), blockPlaceContext.method_8037()));
    }

    @Override
    public boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return FIRE_BLOCK.method_9558(blockState, levelReader, blockPos);
    }

    @Override
    public void tick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        FIRE_BLOCK.method_9588(blockState, serverLevel, blockPos, randomSource);
    }

    @Override
    public void onPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        FIRE_BLOCK.method_9615(blockState, level, blockPos, blockState2, bl);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        FIRE_BLOCK.method_9515(builder);
    }

    @Override
    public class_2680 modifyPolymerBlockState(class_2680 originalBlockState, class_2680 blockState) {
        return blockState.method_11657(class_2358.field_11092, 0);
    }

    @Override
    public boolean modifyStateMap(Map<class_2680, BlockData.BlockStateMeta> map, AbstractBlockData<? extends BlockProperties> data) {
        var m = data.blockResource().models();
        var l1 = m.entrySet().stream().map(entry -> entry.getKey().startsWith("up") ? entry.getValue().model() : null).filter(Objects::nonNull).toList();
        var l2 = m.entrySet().stream().map(entry -> entry.getKey().startsWith("side") ? entry.getValue().model() : null).filter(Objects::nonNull).toList();
        var l3 = m.entrySet().stream().map(entry -> entry.getKey().startsWith("floor") ? entry.getValue().model() : null).filter(Objects::nonNull).toList();
        int id = FIRE_MODELS.size();
        FIRE_MODELS.add(new FireModelEntry(data.id(), FIRE_MODELS.size(), l1, l2, l3));

        var customBlock = class_7923.field_41175.method_63535(data.id());
        for (class_2680 possibleState : customBlock.method_9595().method_11662()) {
            if (possibleState.method_11654(class_2358.field_11092) == 0)
                map.put(possibleState, BlockData.BlockStateMeta.of(FIRE_BLOCK.method_34725(possibleState).method_11657(class_2358.field_11092, id), null));
        }

        return true;
    }



    public static void addRemap() {
        for (class_2680 possibleState : class_2246.field_10036.method_9595().method_11662()) {
            if (possibleState.method_11654(class_2358.field_11092) > 0) {
                DefaultModelData.SPECIAL_REMAPS.put(possibleState, possibleState.method_11657(class_2358.field_11092, 0));
                BlockExtBlockMapper.INSTANCE.stateMap.put(possibleState, possibleState.method_11657(class_2358.field_11092, 0));
            }
        }
    }

    public static void init(ResourcePackBuilder resourcePackBuilder) {
        if (FIRE_MODELS.size() <= 1)
            return;

        var firepath = "assets/minecraft/blockstates/fire.json";
        var data = resourcePackBuilder.getStringDataOrSource(firepath);
        if (data == null) {
            Filament.LOGGER.error("Could not load fire block state definition!");
            return;
        }

        var dec = BlockStateAsset.CODEC.decode(JsonOps.INSTANCE, JsonParser.parseString(data));

        dec.ifSuccess(pair -> {
            BlockStateAsset blockStateAsset = pair.getFirst();
            if (blockStateAsset.multipart().isPresent()) {
                List<StateMultiPartDefinition> list = new ObjectArrayList<>();
                for (FireModelEntry model : FIRE_MODELS) {
                    list.addAll(fireSelection(blockStateAsset, model));
                }

                var newAsset = new BlockStateAsset(Optional.empty(), Optional.of(list));
                resourcePackBuilder.addStringData(firepath, BlockStateAsset.CODEC.encodeStart(JsonOps.INSTANCE, newAsset).getOrThrow().toString());
            }
        });
    }

    private static List<StateMultiPartDefinition> fireSelection(BlockStateAsset fireAsset, FireModelEntry modelEntry) {
        List<StateMultiPartDefinition> list = new ObjectArrayList<>();
        if (fireAsset.multipart().isPresent()) {
            for (StateMultiPartDefinition partDefinition : fireAsset.multipart().get()) {
                var currVar = partDefinition.apply().getFirst();
                List<class_2960> models;
                if (currVar.model().method_12832().contains("block/fire_floor")) {
                    models = modelEntry.floor;
                } else if (currVar.model().method_12832().contains("block/fire_side")) {
                    models = modelEntry.side;
                } else {
                    models = modelEntry.up;
                }

                List<StateModelVariant> newVariants = new ObjectArrayList<>();
                for (class_2960 model : models) {
                    newVariants.add(new StateModelVariant(model, currVar.x(), currVar.y(), currVar.uvlock(), currVar.weigth()));
                }

                var when = partDefinition.when();

                Map<String, String> base = null;
                if (when.base().isPresent()) {
                    base = new Object2ObjectArrayMap<>();
                    base.put("age", String.valueOf(modelEntry.age));
                    base.putAll(when.base().get());
                }

                List<Map<String, String>> or = null;
                if (when.or().isPresent()) {
                    or = new ObjectArrayList<>();
                    for (Map<String, String> stringMap : when.or().get()) {
                        var orMap = new Object2ObjectArrayMap<>(stringMap);
                        orMap.put("age", String.valueOf(modelEntry.age));
                        or.add(orMap);
                    }
                }

                var newWhen = new StateMultiPartDefinition.When(Optional.ofNullable(or), Optional.empty(), Optional.ofNullable(base));
                list.add(new StateMultiPartDefinition(newWhen, newVariants));
            }
        }
        return list;
    }

    record FireModelEntry(@Nullable class_2960 id, int age, List<class_2960> up, List<class_2960> side, List<class_2960> floor) {
        public static FireModelEntry DEFAULT = new FireModelEntry(
                null,
                0,
                List.of(class_2960.method_60656("block/fire_up0"), class_2960.method_60656("block/fire_up1"), class_2960.method_60656("block/fire_up_alt0"), class_2960.method_60656("block/fire_up_alt1")),
                List.of(class_2960.method_60656("block/fire_side0"), class_2960.method_60656("block/fire_side1"), class_2960.method_60656("block/fire_side_alt0"), class_2960.method_60656("block/fire_side_alt1")),
                List.of(class_2960.method_60656("block/fire_floor0"), class_2960.method_60656("block/fire_floor1"))
        );
    }
}
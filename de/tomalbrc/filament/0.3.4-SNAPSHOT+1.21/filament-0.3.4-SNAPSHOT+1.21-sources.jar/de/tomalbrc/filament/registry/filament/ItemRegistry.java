package de.tomalbrc.filament.registry.filament;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.item.InstrumentItem;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.item.ThrowingItem;
import de.tomalbrc.filament.item.TrapItem;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_124;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_7923;
import org.apache.commons.io.FileUtils;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Json;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Map;

public class ItemRegistry {
    public static int REGISTERED_ITEMS = 0;

    public static final File DIR = Constants.CONFIG_DIR.resolve("item").toFile();

    public static final Object2ObjectLinkedOpenHashMap<class_2960, class_1792> CUSTOM_ITEMS = new Object2ObjectLinkedOpenHashMap<>();
    public static final Object2ObjectLinkedOpenHashMap<class_2960, class_1792> CUSTOM_BLOCK_ITEMS = new Object2ObjectLinkedOpenHashMap<>();
    public static final Object2ObjectLinkedOpenHashMap<class_2960, class_1792> CUSTOM_DECORATIONS = new Object2ObjectLinkedOpenHashMap<>();
    public static final class_1761 ITEM_GROUP = new class_1761.class_7913(null, -1)
            .method_47321(class_2561.method_43470("Filament Items").method_27692(class_124.field_1075))
            .method_47320(class_1802.field_8477::method_7854)
            .method_47317((parameters, output) -> CUSTOM_ITEMS.forEach((key, value) -> output.method_45421(value)))
            .method_47324();

    public static final class_1761 BLOCK_ITEM_GROUP = new class_1761.class_7913(null, -1)
            .method_47321(class_2561.method_43470("Filament Blocks").method_27692(class_124.field_1058))
            .method_47320(class_1802.field_8732::method_7854)
            .method_47317((parameters, output) -> CUSTOM_BLOCK_ITEMS.forEach((key, value) -> output.method_45421(value)))
            .method_47324();

    public static final class_1761 DECORATION_ITEM_GROUP = new class_1761.class_7913(null, -1)
            .method_47321(class_2561.method_43470("Filament Decoration").method_27692(class_124.field_1064))
            .method_47320(class_1802.field_16539::method_7854)
            .method_47317((parameters, output) -> CUSTOM_DECORATIONS.forEach((key, value) -> output.method_45421(value)))
            .method_47324();

    @SuppressWarnings("ResultOfMethodCallIgnored")
    public static void register() {

        if (!DIR.exists() || !DIR.isDirectory()) {
            DIR.mkdirs();
            return;
        }

        Collection<File> files = FileUtils.listFiles(DIR, new String[]{"json"}, true);
        if (files != null) {
            for (File file : files) {
                try (Reader reader = new FileReader(file)) {
                    ItemData data = Json.GSON.fromJson(reader, ItemData.class);
                    register(data);
                } catch (Throwable throwable) {
                    Filament.LOGGER.error("Error reading item JSON file: {}", file.getAbsolutePath(), throwable);
                }
            }
        }
    }

    public static void register(InputStream inputStream) throws IOException {
        register(Json.GSON.fromJson(new InputStreamReader(inputStream, StandardCharsets.UTF_8), ItemData.class));
    }

    static public void register(ItemData data) {
        if (class_7923.field_41178.method_10250(data.id())) return;

        class_1792.class_1793 properties = data.properties() != null ? data.properties().toItemProperties(data.vanillaItem(), data.behaviour()) : new class_1792.class_1793();
        class_1792 item;
        if (data.canShoot()) {
            item = new ThrowingItem(properties, data);
        } else if (data.isInstrument()) {
            item = new InstrumentItem(properties, data);
        } else if (data.isTrap()) {
            item = new TrapItem(properties, data);
        } else {
            item = new SimpleItem(properties, data);
        }

        ItemRegistry.registerItem(data.id(), item, CUSTOM_ITEMS);
        REGISTERED_ITEMS++;
    }

    public static void registerItem(class_2960 identifier, class_1792 item, Object2ObjectLinkedOpenHashMap<class_2960, class_1792> CAT) {
        class_2378.method_10230(class_7923.field_41178, identifier, item);
        CAT.putIfAbsent(identifier, item);
    }

    public static class ItemDataReloadListener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655("filament", "items");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/item", path -> path.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
                try (var reader = new InputStreamReader(entry.getValue().method_14482())) {
                    ItemData data = Json.GSON.fromJson(reader, ItemData.class);
                    ItemRegistry.register(data);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load item resource \"" + entry.getKey() + "\".");
                }
            }

            Filament.LOGGER.info("filament items registered: " + ItemRegistry.REGISTERED_ITEMS);

            PolymerItemGroupUtils.registerPolymerItemGroup(class_2960.method_60655(Constants.MOD_ID, "item"), ITEM_GROUP);
            PolymerItemGroupUtils.registerPolymerItemGroup(class_2960.method_60655(Constants.MOD_ID, "block"), BLOCK_ITEM_GROUP);
            PolymerItemGroupUtils.registerPolymerItemGroup(class_2960.method_60655(Constants.MOD_ID, "decoration"), DECORATION_ITEM_GROUP);

        }
    }
}

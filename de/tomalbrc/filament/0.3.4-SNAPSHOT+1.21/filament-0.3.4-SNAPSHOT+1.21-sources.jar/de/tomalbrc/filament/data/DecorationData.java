package de.tomalbrc.filament.data;

import de.tomalbrc.filament.data.properties.DecorationProperties;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;
import org.joml.Vector3f;
import de.tomalbrc.filament.data.behaviours.decoration.DecorationBehaviourList;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2680;
import net.minecraft.class_2960;

public record DecorationData(
        @NotNull class_2960 id,
        @NotNull class_2960 model,

        @Nullable class_1792 vanillaItem,

        @Nullable List<BlockConfig> blocks,

        @Nullable Vector2f size,

        @Nullable DecorationProperties properties,

        @Nullable DecorationBehaviourList behaviour
) {
    public PolymerModelData requestModel() {
        return PolymerResourcePackUtils.requestModel(vanillaItem != null ? vanillaItem : class_1802.field_8054, model);
    }

    public boolean isSeat() {
        return this.behaviour != null && this.behaviour.seat != null;
    }

    public boolean isContainer() {
        return this.behaviour != null && this.behaviour.container != null;
    }

    public boolean hasAnimation() {
        return this.behaviour != null && this.behaviour.animation != null;
    }

    public boolean hasBlocks() {
        return this.blocks != null;
    }

    public boolean isShowcase() {
        return this.behaviour != null && this.behaviour.showcase != null;
    }

    public boolean isLock() {
        return this.behaviour != null && this.behaviour.lock != null;
    }

    public boolean isSimple() {
        return false;
        // TODO: itemStack is not correct/missing data since we get in from the decoration data id...
        // so dyed color will be missing from the displayed item
        //return ((!this.hasBlocks() || Util.barrierDimensions(this.blocks(), 0).equals(1, 1)) && this.behaviour() == null) || this.size != null;
    }

    public record BlockConfig(Vector3f origin,
                       Vector3f size,
                       class_2680 block) { }
}

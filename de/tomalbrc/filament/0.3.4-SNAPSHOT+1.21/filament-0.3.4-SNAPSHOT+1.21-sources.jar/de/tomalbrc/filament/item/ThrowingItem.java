package de.tomalbrc.filament.item;

import de.tomalbrc.filament.data.behaviours.item.Shoot;
import de.tomalbrc.filament.data.ItemData;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;
import de.tomalbrc.filament.registry.filament.EntityRegistry;

public class ThrowingItem extends SimpleItem implements PolymerItem {
    private final Shoot shootBehaviour;

    public ThrowingItem(class_1792.class_1793 properties, ItemData itemData) {
        super(properties, itemData);
        assert itemData.behaviour() != null;
        this.shootBehaviour = itemData.behaviour().shoot;
    }

    @Override
    @NotNull
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 user, class_1268 hand) {
        user.method_7357().method_7906(this, 10);
        class_1799 itemStack = user.method_5998(hand);

        if (!level.field_9236) {
            BaseProjectileEntity projectile = EntityRegistry.BASE_PROJECTILE.method_5883(level);
            if (projectile != null) {
                projectile.method_33574(user.method_19538().method_1031(0, user.method_5751(), 0));
                itemStack.method_7974(itemStack.method_7919()+1);

                float pitch = user.method_36455();
                float yaw = user.method_36454();
                double speed = this.shootBehaviour.speed; // Adjust the speed as needed

                Vector3f deltaMovement = new Vector3f(
                        -(float) Math.sin(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch)),
                        -(float) Math.sin(Math.toRadians(pitch)),
                        (float) Math.cos(Math.toRadians(yaw)) * (float) Math.cos(Math.toRadians(pitch))
                ).mul((float) speed);

                projectile.method_36456(user.method_36454());
                projectile.method_36457(user.method_36455());
                projectile.method_18800(deltaMovement.x, deltaMovement.y, deltaMovement.z);
                projectile.setProjectileStack(class_1802.field_8475.method_7854());
                projectile.setPickupStack(itemStack);
                projectile.method_7432(user);
                projectile.method_7438(this.shootBehaviour.baseDamage);

                if (user.method_7337()) {
                    projectile.field_7572 = class_1665.class_1666.field_7594;
                }
            }

            level.method_8649(projectile);
            level.method_43129((class_1657) null, (class_1297) projectile, (class_3414) class_3417.field_15001, class_3419.field_15248, 1.0F, 1.0F);
            if (!user.method_7337() && this.shootBehaviour.consumes) {
                user.method_31548().method_7378(itemStack);
            }
        }

        user.method_7259(class_3468.field_15372.method_14956(this));
        return class_1271.method_22428(itemStack);
    }
}

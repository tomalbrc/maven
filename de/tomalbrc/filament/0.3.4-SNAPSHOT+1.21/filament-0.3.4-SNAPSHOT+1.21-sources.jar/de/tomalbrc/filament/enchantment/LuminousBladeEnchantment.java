package de.tomalbrc.filament.enchantment;

import java.util.Optional;
/*
public class LuminousBladeEnchantment extends Enchantment implements PolymerEnchantment {
    public LuminousBladeEnchantment() {
        super(new EnchantmentDefinition(ItemTags.WEAPON_ENCHANTABLE, Optional.empty(), 5, 5, Enchantment.dynamicCost(4, 12), Enchantment.dynamicCost(4, 12), 3, FeatureFlagSet.of(), new EquipmentSlot[]{EquipmentSlot.MAINHAND}));
    }

    @Override
    public void doPostAttack(LivingEntity user, Entity target, int level) {
        if (target instanceof LivingEntity livingEntity) {
            livingEntity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 5 * level, 0));
        }

        super.doPostAttack(user, target, level);
    }

    @Override
    public Enchantment getPolymerReplacement(ServerPlayer player) {
        return null;
    }
}
 */
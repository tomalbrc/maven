package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.registry.*;
import de.tomalbrc.filament.util.FilamentReloadUtil;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2170;
import net.minecraft.class_3300;
import net.minecraft.class_5350;
import net.minecraft.class_7659;
import net.minecraft.class_7699;
import net.minecraft.class_7780;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Mixin(class_5350.class)
public class ReloadableServerResourcesMixin {
    @Inject(at = @At("HEAD"), method = "loadResources")
    private static void filament$loadResources(class_3300 resourceManager, class_7780<class_7659> layeredRegistryAccess, class_7699 featureFlagSet, class_2170.class_5364 commandSelection, int i, Executor executor, Executor executor2, CallbackInfoReturnable<CompletableFuture<class_5350>> cir) {
        ((RegistryUnfreezer)class_7923.field_41175).filament$unfreeze();
        ((RegistryUnfreezer)class_7923.field_41178).filament$unfreeze();
        ((RegistryUnfreezer)class_7923.field_41181).filament$unfreeze();
        ((RegistryUnfreezer)class_7923.field_44687).filament$unfreeze();

        for (SimpleSynchronousResourceReloadListener listener : FilamentReloadUtil.getReloadListeners()) {
            listener.method_14491(resourceManager);
        }

        PolymerItemGroupUtils.invalidateItemGroupCache();
    }
}
package de.tomalbrc.filament.item;

import de.tomalbrc.filament.data.behaviours.item.Trap;
import de.tomalbrc.filament.data.ItemData;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_3730;
import net.minecraft.class_5761;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class TrapItem extends SimpleItem {
    public TrapItem(class_1793 properties, ItemData itemData) {
        super(properties, itemData);
    }

    @Override
    public void method_7851(class_1799 itemStack, class_9635 tooltipContext, List<class_2561> list, class_1836 tooltipFlag) {
        if (itemStack.method_57824(class_9334.field_49609).method_57450("Type")) {
            class_1299<?> type = class_7923.field_41177.method_10223(class_2960.method_60654(itemStack.method_57824(class_9334.field_49609).method_57461().method_10558("Type")));
            list.add(class_2561.method_43470("Contains ").method_10852(class_2561.method_43471(type.method_5882()))); // todo: make "Contains " translateable?
        }
        super.method_7851(itemStack, tooltipContext, list, tooltipFlag);
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, @Nullable class_3222 player) {
        return this.modelData != null ? canSpawn(itemStack) ? this.modelData.get("trapped").value() : this.modelData.get("default").value() : -1;
    }

    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        if (this.itemData.isTrap()) {
            this.use(player, interactionHand);
            return class_1271.method_22428(itemStack);
        } else {
            return class_1271.method_22431(itemStack);
        }
    }

    public void use(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        itemStack.method_7970(1, player, hand == class_1268.field_5808 ? class_1304.field_6173:class_1304.field_6171);

        Trap trap = this.itemData.behaviour().trap;
        player.method_6019(hand);

        if (trap.useDuration > 0) player.method_7357().method_7906(this, trap.useDuration);

        player.method_7259(class_3468.field_15372.method_14956(this));
    }

    public class_1269 method_7884(class_1838 useOnContext) {
        // TODO: maybe check for lava / safe ground?
        if (useOnContext.method_8036() != null && canSpawn(useOnContext.method_8041()) && useOnContext.method_8045() instanceof class_3218 serverLevel) {
            this.spawn(serverLevel, useOnContext.method_8041(), useOnContext.method_8037());
            use(useOnContext.method_8036(), useOnContext.method_20287());
        }

        return class_1269.field_5811;
    }

    private static boolean canSpawn(class_1799 useOnContext) {
        return useOnContext.method_57824(class_9334.field_49609).method_57450("Type");
    }

    private void spawn(class_3218 serverLevel, class_1799 itemStack, class_2338 blockPos) {
        var compoundTag = itemStack.method_57824(class_9334.field_49609).method_57461();

        class_1299<?> entityType = class_7923.field_41177.method_10223(class_2960.method_60654(compoundTag.method_10558("Type")));
        class_1297 entity = entityType.method_47821(serverLevel, blockPos.method_10086(1), class_3730.field_16473);
        if (entity instanceof class_1308 mob) {
            this.loadFromTag(mob, compoundTag);
        }

        int damage = itemStack.method_7919();
        itemStack.method_57381(class_9334.field_49609);
        itemStack.method_7974(damage);
    }

    public boolean canUseOn(class_1308 mob) {
        Trap trap = this.itemData.behaviour().trap;
        class_2960 mobType = class_7923.field_41177.method_10221(mob.method_5864());
        return trap.types.contains(mobType);
    }

    public boolean canSave(class_1308 mob) {
        if (mob.method_6059(class_1294.field_5899) || mob.method_6059(class_1294.field_5911) || mob.method_6059(class_1294.field_5909)) {
            return mob.method_59922().method_43048(100) > 75;
        }

        return mob.method_59922().method_43048(10_000) == 420;
    }

    public void saveToTag(class_1308 mob, class_1799 itemStack) {
        // todo: read additional nbt, Bucketable not good enough
        class_5761.method_35167(mob, itemStack);

        class_2960 resourceLocation = class_7923.field_41177.method_10221(mob.method_5864());

        class_2487 compoundTag = new class_2487();
        compoundTag.method_10582("Type", resourceLocation.toString());
        itemStack.method_57825(class_9334.field_49609, class_9279.method_57456(compoundTag));
    }

    public void loadFromTag(class_1308 mob, class_2487 compoundTag) {
        // todo: write additional nbt, Bucketable not good enough
        class_5761.method_35168(mob, compoundTag);
    }
}

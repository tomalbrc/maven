package de.tomalbrc.filament.mixin.behaviour.fire;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.Fire;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.class_2424;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2424.class)
public abstract class PortalShapeMixin {
    @Inject(method = "isEmpty", at = @At(value = "RETURN"), cancellable = true)
    private static void filament$isEmpty(class_2680 blockState, CallbackInfoReturnable<Boolean> cir) {
        Fire f;
        if (!cir.getReturnValue() && blockState.method_26204() instanceof SimpleBlock simpleBlock && (f = simpleBlock.get(Behaviours.FIRE)) != null && f.getConfig().lightPortal) {
            cir.setReturnValue(true);
        }
    }
}

package de.tomalbrc.filament.gui;

import eu.pb4.sgui.api.gui.SlotGuiInterface;
import eu.pb4.sgui.virtual.inventory.VirtualScreenHandler;
import eu.pb4.sgui.virtual.inventory.VirtualSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import org.jetbrains.annotations.NotNull;

public class VirtualChestMenu extends VirtualScreenHandler {
    private final SlotGuiInterface gui;
    private final class_1263 container;

    int lockSlot;

    public VirtualChestMenu(class_3917<?> type, int syncId, SlotGuiInterface gui, class_1657 player, class_1263 container, int lockSlot) {
        super(type, syncId, gui, player);
        this.gui = gui;
        this.container = container;
        this.lockSlot = lockSlot;
        setupSlots(player);

        gui.beforeOpen();
        gui.onOpen();
        if (gui instanceof PaginatedContainerGui paginatedContainerGui) {
            paginatedContainerGui.setScreenHandler(this);
        }

        container.method_5435(player);
    }

    @Override
    public void method_37420() {

    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int i) {
        return this.gui.quickMove(i);
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return container.method_5443(player);
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        this.container.method_5432(player);
    }

    protected void addInventoryHotbarSlots(class_1263 container, int x, int y) {
        if (lockSlot == -1) {
            for (int slot = 0; slot < 9; ++slot) {
                this.method_7621(new class_1735(container, slot, x + slot * 18, y));
            }
        } else {
            for (int slot = 0; slot < 9; ++slot) {
                this.method_7621(new BackpackHotbarSlot(container, lockSlot, slot, x + slot * 18, y));
            }
        }
    }

    @Override
    protected void setupSlots(class_1657 player) {
        if (this.gui == null) // fails when called from VirtualScreenHandler ctor
            return;

        int n;
        int m;

        for (n = 0; n < this.gui.getVirtualSize(); ++n) {
            class_1735 slot = this.gui.getSlotRedirect(n);
            if (slot != null) {
                this.method_7621(slot);
            } else {
                this.method_7621(new VirtualSlot(gui, n, 0, 0));
            }
        }

        if (gui.isIncludingPlayer()) {
            int size = this.gui.getHeight() * this.gui.getWidth();
            for (n = 0; n < 4; ++n) {
                for (m = 0; m < 9; ++m) {
                    this.method_7621(new VirtualSlot(gui, m + n * 9 + size, 0, 0));
                }
            }
        } else {
            class_1661 playerInventory = player.method_31548();
            for (n = 0; n < 3; ++n) {
                for (m = 0; m < 9; ++m) {
                    this.method_7621(new class_1735(playerInventory, m + n * 9 + 9, 0, 0));
                }
            }

            addInventoryHotbarSlots(playerInventory, n, 0);
        }
    }
}
package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.util.BlockUtil;
import net.fabricmc.fabric.api.registry.VillagerInteractionRegistries;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

// todo: ravager interaction, bee interaction, villager interaction!
public class Crop implements BlockBehaviour<Crop.Config>, class_2256 {
    public static final class_2758[] AGES = {
            class_2758.method_11867("age", 0,1),
            class_2758.method_11867("age", 0,2),
            class_2758.method_11867("age", 0,3),
            class_2758.method_11867("age", 0,4),
            class_2758.method_11867("age", 0,5),
            class_2758.method_11867("age", 0,6),
            class_2758.method_11867("age", 0,7),
            class_2758.method_11867("age", 0,8),
            class_2758.method_11867("age", 0,9),
            class_2758.method_11867("age", 0,10),
            class_2758.method_11867("age", 0,11),
            class_2758.method_11867("age", 0,12),
            class_2758.method_11867("age", 0,13),
            class_2758.method_11867("age", 0,14),
            class_2758.method_11867("age", 0,15)
    };

    private final Config config;

    public Crop(Config config) {
        this.config = config;
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        BlockBehaviour.super.init(item, block, behaviourHolder);

        if (config.villagerInteraction) {
            VillagerInteractionRegistries.registerCollectable(item);
        }
    }

    @Override
    @NotNull
    public Crop.Config getConfig() {
        return this.config;
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AGES[Math.max(0, config.maxAge-1)]);
    }

    @Override
    public boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return hasSufficientLight(levelReader, blockPos);
    }

    @Override
    public boolean isRandomlyTicking(class_2680 blockState) {
        return blockState.method_11654(AGES[Math.max(0, config.maxAge-1)]) < this.config.maxAge-1;
    }

    @Override
    public void randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        if (serverLevel.method_22335(blockPos, 0) >= 9) {
            int i = this.getAge(blockState);
            if (i < this.config.maxAge-1) {
                float f = getGrowthSpeed(blockState.method_26204(), serverLevel, blockPos);
                if (randomSource.method_43048((int) (25.f / f) + 1) == 0) {
                    serverLevel.method_8652(blockPos, blockState.method_11657(AGES[Math.max(0, config.maxAge-1)], i + 1), class_2248.field_31028);
                }
            }
        }
    }

    private int getAge(class_2680 state) {
        return state.method_11654(AGES[Math.max(0, config.maxAge-1)]);
    }

    public void growCrops(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        int i = this.getAge(blockState) + this.getBonemealAgeIncrease(level);
        int j = this.config.maxAge-1;
        if (i > j) {
            i = j;
        }

        level.method_8652(blockPos, blockState.method_11657(AGES[Math.max(0, config.maxAge-1)], i), class_2248.field_31028);
    }

    public class_2680 incrementedAge(class_2680 blockState) {
        var prop = AGES[Math.max(0, config.maxAge-1)];
        return blockState.method_11657(prop, blockState.method_11654(prop));
    }

    public boolean isMaxAge(class_2680 blockState) {
        var prop = AGES[Math.max(0, config.maxAge-1)];
        return blockState.method_11654(prop) == config.maxAge-1;
    }

    protected int getBonemealAgeIncrease(class_1937 level) {
        return class_3532.method_15395(level.field_9229, 2, 5);
    }

    protected float getGrowthSpeed(class_2248 block, class_1922 blockGetter, class_2338 blockPos) {
        float bonus = 1.0F;
        class_2338 blockPos2 = blockPos.method_10074();

        for(int i = -config.bonusRadius; i <= config.bonusRadius; ++i) {
            for(int j = -config.bonusRadius; j <= config.bonusRadius; ++j) {
                float localBonus = 0.f;
                class_2680 blockState = blockGetter.method_8320(blockPos2.method_10069(i, 0, j));
                if (blockState.method_27852(config.bonusBlock)) {
                    localBonus = 1.f;
                    if (blockState.method_28498(class_2344.field_11009) && blockState.method_11654(class_2344.field_11009) > 0) {
                        localBonus = 3.f;
                    }
                }

                if (i != 0 || j != 0) {
                    localBonus /= 4.f;
                }

                bonus += localBonus;
            }
        }

        class_2338 northed = blockPos.method_10095();
        class_2338 southed = blockPos.method_10072();
        class_2338 wested = blockPos.method_10067();
        class_2338 easted = blockPos.method_10078();
        boolean bl = isCrop(blockGetter.method_8320(wested).method_26204()) || isCrop(blockGetter.method_8320(easted).method_26204());
        boolean bl2 = isCrop(blockGetter.method_8320(northed).method_26204()) || isCrop(blockGetter.method_8320(southed).method_26204());
        if (bl && bl2) {
            bonus /= 2.0F;
        } else {
            boolean bl3 = isCrop(blockGetter.method_8320(wested.method_10095()).method_26204()) || isCrop(blockGetter.method_8320(easted.method_10095()).method_26204()) || isCrop(blockGetter.method_8320(easted.method_10072()).method_26204()) || isCrop(blockGetter.method_8320(wested.method_10072()).method_26204());
            if (bl3) {
                bonus /= 2.0F;
            }
        }

        return bonus;
    }

    private boolean isCrop(class_2248 block1) {
        return block1 instanceof SimpleBlock simpleBlock && simpleBlock.has(Behaviours.CROP) && Objects.requireNonNull(simpleBlock.get(Behaviours.CROP)).config == config;
    }

    protected boolean hasSufficientLight(class_4538 levelReader, class_2338 blockPos) {
        return levelReader.method_22335(blockPos, 0) >= config.minLightLevel;
    }

    @Override
    public boolean method_9651(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return this.getAge(blockState) < config.maxAge-1;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        return true;
    }

    @Override
    public void method_9652(class_3218 serverLevel, class_5819 randomSource, class_2338 blockPos, class_2680 blockState) {
        if (blockState.method_26204() instanceof SimpleBlock polymerBlock && !(polymerBlock.getPolymerBlockState(blockState, null).method_26204() instanceof class_2256)) {
            BlockUtil.handleBoneMealEffects(serverLevel, blockPos);
        }

        this.growCrops(serverLevel, blockPos, blockState);
    }

    public static class Config {
        public int maxAge = 4;
        public int minLightLevel = 8;

        public int bonusRadius = 1;
        public class_2248 bonusBlock = class_2246.field_10362;

        public boolean villagerInteraction = true;
        public boolean beeInteraction = true;
    }
}

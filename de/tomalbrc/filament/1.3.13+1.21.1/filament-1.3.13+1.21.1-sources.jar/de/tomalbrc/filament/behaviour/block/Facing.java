package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import org.jetbrains.annotations.NotNull;

public class Facing implements BlockBehaviour<Facing.Config> {
    private final Config config;

    public Facing(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Facing.Config getConfig() {
        return this.config;
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(class_2741.field_12525, class_2350.field_11035);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12525);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 selfDefault, class_1750 blockPlaceContext) {
        return selfDefault.method_11657(class_2741.field_12525, blockPlaceContext.method_7715().method_10153().method_10153());
    }

    @Override
    public class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return blockState.method_11657(class_2741.field_12525, rotation.method_10503(blockState.method_11654(class_2741.field_12525)));
    }

    @Override
    public class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return blockState.method_26186(mirror.method_10345(blockState.method_11654(class_2741.field_12525)));
    }

    public static class Config {}
}
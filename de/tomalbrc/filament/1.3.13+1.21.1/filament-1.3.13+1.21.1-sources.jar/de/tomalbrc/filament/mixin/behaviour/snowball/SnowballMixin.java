package de.tomalbrc.filament.mixin.behaviour.snowball;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1299;
import net.minecraft.class_1680;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_3857;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1680.class)
public abstract class SnowballMixin extends class_3857 {
    @Unique private boolean filament$didExec = false;

    public SnowballMixin(class_1299<? extends class_3857> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "onHit", at = @At("RETURN"))
    private void filament$onHit(class_239 result, CallbackInfo ci) {
        if (!filament$didExec && this.method_7495().method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.SNOWBALL)) {
            var b = simpleItem.getOrThrow(Behaviours.SNOWBALL);
            b.run(((class_1680)(Object)this), result.method_17784());
            filament$didExec = true;
        }
    }

    @Inject(method = "onHitEntity", at = @At("RETURN"))
    private void filament$onHitEntity(class_3966 result, CallbackInfo ci) {
        if (!filament$didExec && this.method_7495().method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.SNOWBALL)) {
            var b = simpleItem.getOrThrow(Behaviours.SNOWBALL);
            b.runEntity(((class_1680)(Object)this), result.method_17784(), result.method_17782());
            filament$didExec = true;
        }
    }
}

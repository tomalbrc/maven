package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.BlockUtil;
import de.tomalbrc.filament.util.DecorationUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

/**
 * For interactive lamps
 */
public class Lamp implements BlockBehaviour<Lamp.Config> {

    private final Config config;

    public Lamp(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Lamp.Config getConfig() {
        return this.config;
    }

    @Override
    public class_2680 modifyPolymerBlockState(class_2680 originalBlockState, class_2680 blockState) {
        return config.models == Boolean.TRUE ? blockState : blockState.method_11657(BlockUtil.LIGHT_LEVEL, 0);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 blockState, class_1750 blockPlaceContext) {
        blockState.method_11657(BlockUtil.LIGHT_LEVEL, config.cycle != null && !config.cycle.isEmpty() ? config.cycle.getFirst() : config.defaultValue == null ? config.off : config.defaultValue);
        return BlockBehaviour.super.getStateForPlacement(blockState, blockPlaceContext);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(BlockUtil.LIGHT_LEVEL);
    }

    @Override
    public net.minecraft.class_4970.class_2251 modifyBlockProperties(net.minecraft.class_4970.class_2251 props) {
        props.method_9631((state) -> state.method_28498(BlockUtil.LIGHT_LEVEL) ? state.method_11654(BlockUtil.LIGHT_LEVEL) : 0);
        return props;
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        var lightLevel = blockState.method_11654(BlockUtil.LIGHT_LEVEL);
        if (config.cycle != null && !config.cycle.isEmpty() && level != null) {
            var currentIndex = config.cycle.indexOf(lightLevel);
            var next = config.cycle.get((currentIndex+1) % config.cycle.size());
            level.method_8501(blockPos, blockState.method_11657(BlockUtil.LIGHT_LEVEL, next));
            if (level.method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity && decorationBlockEntity.getMainBlockEntity().getDecorationData().hasBlocks() && decorationBlockEntity.getMainBlockEntity().getDecorationData().countBlocks() > 1) {
                DecorationUtil.forEachRotated(decorationBlockEntity.getMainBlockEntity().getDecorationData().blocks(), blockPos, decorationBlockEntity.getMainBlockEntity().rotation, pos -> {
                    level.method_8501(blockPos, blockState.method_11657(BlockUtil.LIGHT_LEVEL, next));
                });
            }
            playSound(level, blockPos, blockState);
            return class_1269.field_21466;
        } else if (level != null) {
            if (lightLevel == config.on) {
                level.method_8501(blockPos, blockState.method_11657(BlockUtil.LIGHT_LEVEL, config.off));
            } else {
                level.method_8501(blockPos, blockState.method_11657(BlockUtil.LIGHT_LEVEL, config.on));
            }
            playSound(level, blockPos, blockState);
            return class_1269.field_21466;
        }

        return class_1269.field_5811;
    }

    private void playSound(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        if (config.sound != null)
            level.method_45447(null, blockPos, class_3414.method_47908(config.sound.getValue(blockState)), class_3419.field_15245);
    }

    public static class Config {
        int on = 15;
        int off = 0;
        Integer defaultValue = 0;
        List<Integer> cycle;
        Boolean models;

        public BlockStateMappedProperty<class_2960> sound;
    }
}
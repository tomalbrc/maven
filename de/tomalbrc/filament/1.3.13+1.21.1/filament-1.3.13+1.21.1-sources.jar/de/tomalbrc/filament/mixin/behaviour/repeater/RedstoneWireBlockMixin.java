package de.tomalbrc.filament.mixin.behaviour.repeater;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.Repeater;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.class_2350;
import net.minecraft.class_2457;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2457.class)
public class RedstoneWireBlockMixin {
    @Inject(method = "shouldConnectTo(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;isSignalSource()Z"), cancellable = true)
    private static void filament$redstoneConnect(class_2680 state, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        if (state.method_26204() instanceof SimpleBlock simpleBlock) {
            var repeater = simpleBlock.get(Behaviours.REPEATER);
            if (repeater != null) {
                cir.setReturnValue(state.method_11654(Repeater.FACING) == direction);
            }
        }
    }
}

package de.tomalbrc.filament.decoration.util;

import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class DecorationItemDisplayElement extends ItemDisplayElement {
    public DecorationItemDisplayElement(class_1799 stack) {
        super(stack);
    }

    public DecorationItemDisplayElement() {super();}

    public DecorationItemDisplayElement(class_1792 item) {
        super(item);
    }
}

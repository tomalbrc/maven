package de.tomalbrc.filament.mixin.component.backpack;

import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2586;
import net.minecraft.class_2624;
import net.minecraft.class_7225;
import net.minecraft.class_9323;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2624.class)
public class BaseContainerBlockEntityMixin {
    @Unique
    FilamentComponents.BackpackOptions filament$backpackOptions;

    @Inject(method = "applyImplicitComponents", at = @At(value = "TAIL"))
    private void filament$backpackApplyImplicitComponents(class_2586.class_9473 dataComponentGetter, CallbackInfo ci) {
        var bp = dataComponentGetter.method_58694(FilamentComponents.BACKPACK);
        if (bp != null)
            filament$backpackOptions = bp;
    }

    @Inject(method = "collectImplicitComponents", at = @At(value = "TAIL"))
    private void filament$backpackCollectImplicitComponents(class_9323.class_9324 builder, CallbackInfo ci) {
        if (filament$backpackOptions != null)
            builder.method_57840(FilamentComponents.BACKPACK, filament$backpackOptions);
    }

    @Inject(method = "removeComponentsFromTag", at = @At(value = "TAIL"))
    private void filament$backpackRemoveComponentsFromTag(class_2487 compoundTag, CallbackInfo ci) {
        compoundTag.method_10551("Backpack");
    }

    @Inject(method = "loadAdditional", at = @At(value = "TAIL"))
    private void filament$backpackLoadAdditional(class_2487 compoundTag, class_7225.class_7874 provider, CallbackInfo ci) {
        if (compoundTag.method_10545("Backpack")) {
            this.filament$backpackOptions = FilamentComponents.BackpackOptions.CODEC.decode(provider.method_57093(class_2509.field_11560), compoundTag.method_10580("Backpack")).getOrThrow().getFirst();
        }
    }

    @Inject(method = "saveAdditional", at = @At(value = "TAIL"))
    private void filament$backpackSaveAdditional(class_2487 compoundTag, class_7225.class_7874 provider, CallbackInfo ci) {
        if (this.filament$backpackOptions != null) {
            compoundTag.method_10566("Backpack", FilamentComponents.BackpackOptions.CODEC.encodeStart(provider.method_57093(class_2509.field_11560), filament$backpackOptions).getOrThrow());
        }
    }
}

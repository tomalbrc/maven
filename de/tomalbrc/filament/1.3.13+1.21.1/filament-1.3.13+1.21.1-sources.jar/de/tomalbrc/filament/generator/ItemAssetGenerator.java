package de.tomalbrc.filament.generator;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.util.Json;
import eu.pb4.polymer.resourcepack.api.AssetPaths;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import org.jetbrains.annotations.NotNull;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import net.minecraft.class_2960;

public class ItemAssetGenerator {
    public static void createBow(ResourcePackBuilder builder, class_2960 id, ItemResource itemResource, boolean dye) {
        var defaultModel = itemResource.getModels().get("default");
        var pulling_0 = itemResource.getModels().get("pulling_0");
        var pulling_1 = itemResource.getModels().get("pulling_1");
        var pulling_2 = itemResource.getModels().get("pulling_2");

        JsonObject bowModel = new JsonObject();
        bowModel.addProperty("parent", defaultModel.toString()); // Use "default" as parent

        JsonArray overrides = new JsonArray();

        overrides.add(createOverride(1, pulling_0.toString(), null));
        overrides.add(createOverride(1, pulling_1.toString(), 0.65));
        overrides.add(createOverride(1, pulling_2.toString(), 0.9));

        bowModel.add("overrides", overrides);

        builder.addData(AssetPaths.itemModel(id), bowModel.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static void createCrossbow(ResourcePackBuilder builder, class_2960 id, ItemResource itemResource, boolean dye) {
        var defaultModel = itemResource.getModels().get("default");
        var rocket = itemResource.getModels().get("rocket");
        var arrow = itemResource.getModels().get("arrow");
        var pulling_0 = itemResource.getModels().get("pulling_0");
        var pulling_1 = itemResource.getModels().get("pulling_1");
        var pulling_2 = itemResource.getModels().get("pulling_2");

        JsonObject crossbowModel = new JsonObject();
        crossbowModel.addProperty("parent", defaultModel.toString()); // Use "default" as parent

        JsonArray overrides = new JsonArray();

        overrides.add(createOverride(1, pulling_0.toString(), null));
        overrides.add(createOverride(1, pulling_1.toString(), 0.58));
        overrides.add(createOverride(1, pulling_2.toString(), 1.0));
        overrides.add(createOverride("charged", rocket.toString(), 1));
        overrides.add(createOverride("charged", arrow.toString(), 1));

        crossbowModel.add("overrides", overrides);

        builder.addData(AssetPaths.itemModel(id), crossbowModel.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static void createShield(ResourcePackBuilder builder, class_2960 id, ItemResource itemResource) {
        var defaultModel = itemResource.getModels().get("default");
        var blocking = itemResource.getModels().get("blocking");

        JsonObject shieldModel = new JsonObject();
        shieldModel.addProperty("parent", defaultModel.toString()); // Use "default" as parent

        JsonArray overrides = new JsonArray();

        overrides.add(createOverride("blocking", blocking.toString(), 1));

        shieldModel.add("overrides", overrides);

        builder.addData(AssetPaths.itemModel(id), shieldModel.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static void createFishingRod(ResourcePackBuilder builder, class_2960 id, ItemResource itemResource, boolean dye) {
        var defaultModel = itemResource.getModels().get("default");
        var cast = itemResource.getModels().get("cast");

        JsonObject rodModel = new JsonObject();
        rodModel.addProperty("parent", defaultModel.toString()); // Use "default" as parent

        JsonArray overrides = new JsonArray();

        overrides.add(createOverride("cast", cast.toString(), 1));

        rodModel.add("overrides", overrides);

        builder.addData(AssetPaths.itemModel(id), rodModel.toString().getBytes(StandardCharsets.UTF_8));
    }

    private static JsonObject createOverride(int pulling, String model, Double pull) {
        JsonObject predicate = new JsonObject();
        predicate.addProperty("pulling", pulling);
        if (pull != null) {
            predicate.addProperty("pull", pull);
        }

        JsonObject override = new JsonObject();
        override.add("predicate", predicate);
        override.addProperty("model", model);

        return override;
    }

    private static JsonObject createOverride(String predicateKey, String model, int value) {
        JsonObject predicate = new JsonObject();
        predicate.addProperty(predicateKey, value);

        JsonObject override = new JsonObject();
        override.add("predicate", predicate);
        override.addProperty("model", model);

        return override;
    }

    public static void createItemModels(class_2960 id, ItemResource itemResource) {
        if (itemResource.couldGenerate()) {
            for (Map.Entry<String, Map<String, class_2960>> entry : itemResource.textures().entrySet()) {
                final var modelId = id.method_45138("item/").method_48331("_" + entry.getKey());
                PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(builder -> {
                    JsonObject object = new JsonObject();
                    object.add("parent", new JsonPrimitive(itemResource.parent().method_12836().equals(class_2960.field_33381) ? itemResource.parent().method_12832() : itemResource.parent().toString()));

                    JsonObject textures = new JsonObject();
                    for (Map.Entry<String, class_2960> texturesMapEntry : entry.getValue().entrySet()) {
                        textures.add(texturesMapEntry.getKey(), new JsonPrimitive(texturesMapEntry.getValue().method_12836().equals(class_2960.field_33381) ? texturesMapEntry.getValue().method_12832() : texturesMapEntry.getValue().toString()));
                    }
                    object.add("textures", textures);

                    builder.addData("assets/" + modelId.method_12836() + "/models/" + modelId.method_12832() + ".json", Json.GSON.toJson(object).getBytes(StandardCharsets.UTF_8));
                });
                itemResource.getModels().put(entry.getKey(), modelId);
            }
        }
    }

    public static void createTrident(ResourcePackBuilder resourcePackBuilder, @NotNull class_2960 id, ItemResource itemResource, boolean b) {
        // TODO: 1.21.1 maybe?
    }
}
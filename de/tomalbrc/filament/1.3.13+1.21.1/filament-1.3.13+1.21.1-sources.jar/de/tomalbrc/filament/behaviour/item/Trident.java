package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import de.tomalbrc.filament.item.TridentEntity;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1685;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_9334;
import net.minecraft.class_9701;

/**
 * Trident behaviour
 */
public class Trident implements ItemBehaviour<Trident.Config>, ItemPredicateModelProvider {
    private final Config config;

    public Trident(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Trident.Config getConfig() {
        return this.config;
    }

    @Override
    public Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.of(72000);
    }

    @Override
    public void releaseUsing(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int i) {
        if (livingEntity instanceof class_1657 player) {
            int j = this.getUseDuration(itemStack, livingEntity).orElseThrow() - i;
            if (j >= 10) {
                float f = class_1890.method_60123(itemStack, player);
                if (!(f > 0.0F) || player.method_5721()) {
                    if (itemStack.method_7919() >= itemStack.method_7936() - 1) {
                        class_6880<class_3414> holder = class_1890.method_60165(itemStack, class_9701.field_51654).orElse(class_3417.field_15001);
                        if (!level.field_9236) {
                            itemStack.method_7970(1, player, class_1309.method_56079(livingEntity.method_6058()));
                            if (f == 0.0F) {
                                class_1685 thrownTrident = new class_1685(level, player, itemStack);
                                thrownTrident.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, 2.5F, 1.0F);
                                if (player.method_56992()) {
                                    thrownTrident.field_7572 = class_1665.class_1666.field_7594;
                                }

                                level.method_8649(thrownTrident);
                                level.method_43129(null, thrownTrident, holder.comp_349(), class_3419.field_15248, 1.0F, 1.0F);
                                if (!player.method_56992()) {
                                    player.method_31548().method_7378(itemStack);
                                }
                            }
                        }

                        player.method_7259(class_3468.field_15372.method_14956(itemStack.method_7909()));
                        if (f > 0.0F) {
                            float g = player.method_36454();
                            float h = player.method_36455();
                            float k = -class_3532.method_15374(g * ((float)Math.PI / 180F)) * class_3532.method_15362(h * ((float)Math.PI / 180F));
                            float l = -class_3532.method_15374(h * ((float)Math.PI / 180F));
                            float m = class_3532.method_15362(g * ((float)Math.PI / 180F)) * class_3532.method_15362(h * ((float)Math.PI / 180F));
                            float n = class_3532.method_15355(k * k + l * l + m * m);
                            k *= f / n;
                            l *= f / n;
                            m *= f / n;
                            player.method_5762((double)k, (double)l, (double)m);
                            player.method_40126(20, 8.0F, itemStack);
                            if (player.method_24828()) {
                                float o = 1.1999999F;
                                player.method_5784(class_1313.field_6308, new class_243((double)0.0F, (double)1.1999999F, (double)0.0F));
                            }

                            level.method_43129((class_1657)null, player, (class_3414)holder.comp_349(), class_3419.field_15248, 1.0F, 1.0F);
                        }

                    }
                }
            }
        }
    }

    public class_1271<class_1799> use(class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        if (itemStack.method_7919() >= itemStack.method_7936() - 1) {
            return class_1271.method_22431(itemStack);
        } else if (class_1890.method_60123(itemStack, player) > 0.0F && !player.method_5721()) {
            return class_1271.method_22431(itemStack);
        } else {
            player.method_6019(interactionHand);
            return class_1271.method_22428(itemStack);
        }
    }

    @Override
    public void generate(Data<?> data) {
        PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(resourcePackBuilder ->
                ItemAssetGenerator.createTrident(
                        resourcePackBuilder, data.id(),
                        Objects.requireNonNull(data.itemResource()),
                        data.components().method_57832(class_9334.field_49644) || data.vanillaItem().method_57347().method_57832(class_9334.field_49644)
                )
        );
    }

    @Override
    public List<String> requiredModels() {
        return List.of("throwing");
    }

    public static class Config {

    }
}
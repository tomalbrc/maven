package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.item.FilamentItem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import net.minecraft.class_9334;

public class ComplexDecorationBlock extends DecorationBlock implements class_2343 {
    public ComplexDecorationBlock(class_2251 properties, DecorationData decorationData) {
        super(properties, decorationData);
    }

    @Override
    public class_1799 visualItemStack(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        var be = ((DecorationBlockEntity) Objects.requireNonNull(levelReader.method_8321(blockPos)));
        var item = be.visualItemStack(blockState);

        if (stateMap != null && cmdMap != null && be.getItem().method_7909() instanceof FilamentItem filamentItem) {
            var val = stateMap.get(behaviourModifiedBlockState(blockState, blockState));
            if (val != null && cmdMap.containsKey(val)) {
                var v = filamentItem.getModelData().get(cmdMap.get(val));
                if (v != null) item.method_57379(class_9334.field_49637, v.asComponent());
            }
        }

        return item;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new DecorationBlockEntity(blockPos, blockState);
    }

    @Override
    @NotNull
    public class_1799 method_9574(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        class_1799 stack;
        class_2586 blockEntity = levelReader.method_8321(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            stack = decorationBlockEntity.getMainBlockEntity().getItem();
            for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : decorationBlockEntity.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                    stack = decorationBehaviour.getCloneItemStack(stack, levelReader, blockPos, blockState, false);
                }
            }
        } else {
            stack = super.method_9574(levelReader, blockPos, blockState);
        }
        return stack;
    }
}

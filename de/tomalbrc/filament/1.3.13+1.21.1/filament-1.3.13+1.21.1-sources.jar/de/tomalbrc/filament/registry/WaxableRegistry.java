package de.tomalbrc.filament.registry;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class WaxableRegistry {
    private static final BiMap<class_2248, class_2960> waxables = HashBiMap.create();
    private static final Supplier<BiMap<class_2960, class_2248>> waxables_prev = Suppliers.memoize(waxables::inverse);

    public static class_2248 getWaxed(class_2248 block) {
        return class_7923.field_41175.method_10223(waxables.get(block));
    }

    public static class_2248 getPrevious(class_2248 block) {
        return waxables_prev.get().get(class_7923.field_41175.method_10221(block));
    }

    public static void add(class_2248 block, class_2960 replacement) {
        waxables.putIfAbsent(block, replacement);
    }
}

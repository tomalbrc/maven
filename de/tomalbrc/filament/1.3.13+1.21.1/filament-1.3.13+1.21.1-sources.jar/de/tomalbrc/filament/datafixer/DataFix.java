package de.tomalbrc.filament.datafixer;

import com.mojang.datafixers.DataFixer;
import com.mojang.datafixers.DataFixerBuilder;
import com.mojang.datafixers.schemas.Schema;
import de.tomalbrc.filament.datafixer.fix.ChangeVersionAndRotationState;
import de.tomalbrc.filament.datafixer.schema.FilamentNamedspacedSchema;
import de.tomalbrc.filament.datafixer.schema.Version1;
import net.minecraft.class_2350;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DataFix {
    @Nullable
    public static DataFixer DATA_FIXER;

    public static int VERSION = 2;

    public static float getVisualRotationYInDegrees(class_2350 direction, int rotation) {
        int i = direction.method_10166().method_10178() ? 90 * direction.method_10171().method_10181() : 0;
        return (float) class_3532.method_15392(180 + direction.method_10161() * 90 + rotation * 45 + i);
    }

    public static @NotNull DataFixer getDataFixer() {
        if (DATA_FIXER != null)
            return DATA_FIXER;

        DataFixerBuilder builder = new DataFixerBuilder(VERSION);
        builder.addSchema(1, Version1::new);
        Schema schema1 = builder.addSchema(2, FilamentNamedspacedSchema::new);
        builder.addFixer(ChangeVersionAndRotationState.create(schema1));
        DATA_FIXER = builder.build().fixer();

        return DATA_FIXER;
    }
}

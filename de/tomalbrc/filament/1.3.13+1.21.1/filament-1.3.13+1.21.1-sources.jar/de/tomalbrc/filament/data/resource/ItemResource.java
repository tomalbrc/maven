package de.tomalbrc.filament.data.resource;

import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import java.util.Map;
import net.minecraft.class_2960;

public class ItemResource implements ResourceProvider {
    private Map<String, class_2960> models = new Object2ObjectArrayMap<>();
    private class_2960 parent;
    private Map<String, Map<String, class_2960>> textures;

    public ItemResource() {}

    public ItemResource(Map<String, class_2960> models, class_2960 parent, Map<String, Map<String, class_2960>> textures) {
        this.models = models;
        this.parent = parent;
        this.textures = textures;
    }

    public class_2960 parent() {
        if (parent == null)
            parent = class_2960.method_60656("item/generated");
        return parent;
    }

    public Map<String, Map<String, class_2960>> textures() {
        return textures;
    }

    public boolean couldGenerate() {
        return (models == null || models.isEmpty()) && textures != null;
    }

    @Override
    public Map<String, class_2960> getModels() {
        return this.models;
    }
}

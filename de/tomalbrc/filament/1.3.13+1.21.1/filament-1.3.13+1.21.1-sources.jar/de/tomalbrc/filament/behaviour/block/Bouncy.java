package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;

/**
 * Bouncy blocks
 */
public class Bouncy implements BlockBehaviour<Bouncy.Config> {
    private final Config config;

    public Bouncy(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Bouncy.Config getConfig() {
        return this.config;
    }

    @Override
    public boolean fallOn(class_1937 level, class_2680 blockState, class_2338 blockPos, class_1297 entity, double d) {
        if (!entity.method_21750()) {
            entity.method_5747((float) d, 0.0F, level.method_48963().method_48827());
        }

        return true;
    }

    @Override
    public boolean updateEntityMovementAfterFallOn(class_1922 blockGetter, class_1297 entity) {
        class_243 deltaMovement = entity.method_18798();
        if (deltaMovement.field_1351 < -0.4 && !entity.method_21750()) {
            if (config.bounciness > 0) setVel(entity, new class_243(deltaMovement.field_1352, class_3532.method_15350(0, -deltaMovement.field_1351 * config.bounciness, config.max), deltaMovement.field_1350));
        } else if (deltaMovement.field_1351 < -0.08 && !entity.method_21750()) {
            double rebounce = entity instanceof class_1309 ? 1.0 : 0.8;
            setVel(entity, new class_243(deltaMovement.field_1352, -deltaMovement.field_1351 * rebounce, deltaMovement.field_1350));
        } else {
            setVel(entity, deltaMovement.method_18805(1.0, 0.0, 1.0));
        }

        return true;
    }

    @Override
    public void stepOn(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1297 entity) {
        double absY = Math.abs(entity.method_18798().field_1351);
        if (absY < 0.1 && !entity.method_21749()) {
            setVel(entity, entity.method_18798().method_18805(0.0, 1.0, 0.0));
        }
    }

    private void setVel(class_1297 entity,class_243 vel) {
        entity.method_18799(vel);
        entity.field_6037 = true;
    }

    public static class Config {
        public double bounciness = 0;
        public double max = 10;
    }
}
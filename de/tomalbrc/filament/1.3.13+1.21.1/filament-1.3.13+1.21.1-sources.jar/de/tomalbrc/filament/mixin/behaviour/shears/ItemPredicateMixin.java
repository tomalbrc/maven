package de.tomalbrc.filament.mixin.behaviour.shears;

import de.tomalbrc.filament.util.mixin.ItemPredicateCustomCheck;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_2073;

@Mixin(class_2073.class)
public class ItemPredicateMixin implements ItemPredicateCustomCheck {
    @Unique Predicate<class_1799> filament$customCheck;

    @Override
    public void setCustomCheck(Predicate<class_1799> itemStackPredicate) {
        filament$customCheck = itemStackPredicate;
    }

    @Inject(method = "test(Lnet/minecraft/world/item/ItemStack;)Z", at = @At("RETURN"), cancellable = true)
    private void filament$shearsCheck(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        if (filament$customCheck != null && !cir.getReturnValue()) {
            cir.setReturnValue(filament$customCheck.test(itemStack));
        }
    }
}

package de.tomalbrc.filament.mixin.behaviour.shears;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import de.tomalbrc.filament.behaviour.item.Shears;
import net.minecraft.class_2073;
import net.minecraft.class_223;
import net.minecraft.class_5341;
import net.minecraft.class_7788;
import net.minecraft.class_7791;
import net.minecraft.class_9360;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_7788.class)
public abstract class BlockLootSubProviderMixin implements class_7791 {
    @ModifyReturnValue(method = "hasShearsOrSilkTouch", at = @At(value = "RETURN"))
    private class_5341.class_210 filament$customShears(class_5341.class_210 original) {
        if (original instanceof class_5341.class_210) {
            return original.method_893(class_223.method_945(class_2073.class_2074.method_8973().method_58179(new class_9360.class_8745<>(null), Shears::is)));
        }
        return original;
    }
}

package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import org.jetbrains.annotations.NotNull;

/**
 * Block behaviourConfig for flammable blocks and decorations. (Uses filament registration events + fabric flammable registry)
 */
public class Flammable implements BlockBehaviour<Flammable.Config> {
    private final Config config;

    public Flammable(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Flammable.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        FlammableBlockRegistry.getDefaultInstance().add(block, config.burn, config.spread);
    }

    public static class Config {
        public int spread = 20;
        public int burn = 5;
    }
}
package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1792.class)
public interface ItemInvoker {
    @Invoker("getPlayerPOVHitResult")
    static class_3965 invokeGetPlayerPOVHitResult(
            class_1937 level,
            class_1657 player,
            class_3959.class_242 fluid
    ) {
        throw new AssertionError();
    }
}
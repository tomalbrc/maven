package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.FilamentItem;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_4865;
import net.minecraft.class_5168;
import net.minecraft.class_5712;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import org.jetbrains.annotations.NotNull;

/**
 * Shears behaviour
 */
public class Shears implements ItemBehaviour<Shears.Config> {
    private final Config config;

    public Shears(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Shears.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, BehaviourHolder behaviourHolder) {
        ItemBehaviour.super.init(item, behaviourHolder);
        class_2315.method_10009(item, new class_5168());
    }

    @Override
    public boolean mineBlock(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_1309 livingEntity) {
        class_9424 tool = itemStack.method_57824(class_9334.field_50077);
        if (tool == null) {
            return false;
        } else {
            if (!level.method_8608() && !blockState.method_26164(class_3481.field_21952) && tool.comp_2500() > 0) {
                itemStack.method_7970(tool.comp_2500(), livingEntity, class_1304.field_6173);
            }

            return true;
        }
    }

    public class_1269 useOn(class_1838 useOnContext) {
        class_1937 level = useOnContext.method_8045();
        class_2338 blockPos = useOnContext.method_8037();
        class_2680 blockState = level.method_8320(blockPos);
        class_2248 block = blockState.method_26204();
        if (block instanceof class_4865 growingPlantHeadBlock) {
            if (!growingPlantHeadBlock.method_38233(blockState)) {
                class_1657 player = useOnContext.method_8036();
                class_1799 itemStack = useOnContext.method_8041();
                if (player instanceof class_3222) {
                    class_174.field_24478.method_23889((class_3222)player, blockPos, itemStack);
                }

                level.method_8396(null, blockPos, class_3414.method_47908(config.sound), class_3419.field_15245, 1.0F, 1.0F);
                class_2680 blockState2 = growingPlantHeadBlock.method_38232(blockState);
                level.method_8501(blockPos, blockState2);
                level.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(useOnContext.method_8036(), blockState2));
                if (player != null) {
                    itemStack.method_7970(1, player, class_1309.method_56079(useOnContext.method_20287()));
                }

                return class_1269.field_5812;
            }
        }

        return class_1269.field_5814;
    }

    public static boolean is(class_1799 itemStack) {
        return itemStack.method_7909() instanceof FilamentItem filamentItem && filamentItem.has(Behaviours.SHEARS);
    }

    public static class Config {
        public class_2960 sound = class_3417.field_34896.method_14833();
    }
}
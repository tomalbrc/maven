package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.decoration.AnimatedChest;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.OxidizableRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.class_5955;
import org.jetbrains.annotations.NotNull;

/**
 * Block behaviourConfig for oxidizing blocks (like copper)
 * Copies blockstate properties if applicable
 */
public class Oxidizable implements BlockBehaviour<Oxidizable.Config>, class_5955 {
    private final Config config;

    public Oxidizable(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Oxidizable.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        if (config.replacement != null)
            OxidizableRegistry.add(block, config.replacement);
    }

    @Override
    public @NotNull class_5811 method_33622() {
        return this.config.weatherState;
    }

    @Override
    public boolean isRandomlyTicking(class_2680 blockState) {
        return this.method_33622() != class_5811.field_28707 && config.replacement != null;
    }

    @Override
    public void randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        var rightSideChest = blockState.method_28498(class_2281.field_10770) && blockState.method_11654(class_2281.field_10770) == class_2745.field_12571;
        if (blockState.method_28498(class_2281.field_10770)) {
            DecorationBlockEntity decorationBlockEntity = (DecorationBlockEntity) serverLevel.method_8321(blockPos);
            if (decorationBlockEntity != null) {
                AnimatedChest animatedChest = decorationBlockEntity.get(Behaviours.ANIMATED_CHEST);
                if (animatedChest != null && animatedChest.container.hasViewers()) return;
            }
        }

        if (!rightSideChest && (!blockState.method_28498(class_2323.field_10946) || blockState.method_11654(class_2323.field_10946) == class_2756.field_12607)) {
            this.method_54764(blockState, serverLevel, blockPos, randomSource);
        }
    }

    public static class Config {
        /**
         * Replacement block
         */
        public class_2960 replacement;

        /**
         * Weather state, can be `unaffected`, `exposed`, `weathered`, `oxidized`
         */
        public class_5811 weatherState = class_5811.field_28704;
    }
}
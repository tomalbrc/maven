package de.tomalbrc.filament.mixin.component.skin;

import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow public abstract boolean isDamageableItem();

    @Shadow public abstract int getDamageValue();

    @Shadow public abstract int getMaxDamage();

    @Inject(method = "hurtAndBreak(ILnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/EquipmentSlot;)V", at = @At(value = "TAIL"))
    private void filament$dontDestroySkin(int i, class_1309 livingEntity, class_1304 equipmentSlot, CallbackInfo ci) {
        var self = class_1799.class.cast(this);
        var b = this.isDamageableItem() && this.getDamageValue() >= this.getMaxDamage();
        if (b && self.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var skinItem = self.method_57824(FilamentComponents.SKIN_DATA_COMPONENT);
            if (skinItem != null && !skinItem.method_7960()) {
                self.method_57381(FilamentComponents.SKIN_DATA_COMPONENT);

                if (livingEntity instanceof class_1657 serverPlayer) {
                    if (!serverPlayer.method_7270(skinItem))
                        serverPlayer.method_5775(skinItem);
                } else {
                    livingEntity.method_5775(skinItem);
                }

            }
        }
    }


}

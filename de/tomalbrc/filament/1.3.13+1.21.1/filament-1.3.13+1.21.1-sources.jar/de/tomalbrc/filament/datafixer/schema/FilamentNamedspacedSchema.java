package de.tomalbrc.filament.datafixer.schema;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.templates.TypeTemplate;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1208;
import net.minecraft.class_1220;

public class FilamentNamedspacedSchema extends class_1220 {
	public FilamentNamedspacedSchema(int versionKey, Schema parent) {
		super(versionKey, parent);
	}

	@Override
	public void registerTypes(Schema schema, Map<String, Supplier<TypeTemplate>> entityTypes, Map<String, Supplier<TypeTemplate>> blockEntityTypes) {
		super.registerTypes(schema, entityTypes, blockEntityTypes);
		schema.registerType(false, class_1208.field_5726, () -> DSL.optionalFields("block_entities", DSL.remainder(), "sections", DSL.remainder()));
	}

	@Override
    public Map<String, Supplier<TypeTemplate>> registerBlockEntities(final Schema schema) {
		Map<String, Supplier<TypeTemplate>> map = super.registerBlockEntities(schema);
		return map;
    }
}
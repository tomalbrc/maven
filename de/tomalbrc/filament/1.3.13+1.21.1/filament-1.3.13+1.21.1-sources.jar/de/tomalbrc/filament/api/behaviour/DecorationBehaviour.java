package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.holder.FilamentDecorationHolder;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4538;
import net.minecraft.class_7225;
import net.minecraft.class_9323;

@SuppressWarnings("unused")
public interface DecorationBehaviour<T> extends Behaviour<T> {
    default void init(DecorationBlockEntity blockEntity) {
    }

    default FilamentDecorationHolder createHolder(DecorationBlockEntity blockEntity) {
        return null;
    }

    default void onHolderAttach(DecorationBlockEntity blockEntity, FilamentDecorationHolder holder) {
    }

    default class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        return class_1269.field_5811;
    }

    default void read(class_2487 output, class_7225.class_7874 lookup, DecorationBlockEntity blockEntity) {
    }

    default void write(class_2487 input, class_7225.class_7874 lookup, DecorationBlockEntity blockEntity) {
    }

    default void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
    }

    default void modifyDrop(DecorationBlockEntity decorationBlockEntity, class_1799 itemStack) {
    }

    // Allows to change the visual item stack
    default class_1799 visualItemStack(DecorationBlockEntity decorationBlockEntity, class_1799 adjusted, class_2680 blockState) {
        return adjusted;
    }

    default class_2680 updateShape(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        return blockState;
    }

    default class_1799 getCloneItemStack(class_1799 stack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        return stack;
    }

    default void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_2586.class_9473 dataComponentGetter) {}

    default void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {}

    default void removeComponentsFromTag(DecorationBlockEntity decorationBlockEntity, class_2487 valueOutput, class_7225.class_7874 lookup) {}

    default void postBreak(DecorationBlockEntity decorationBlockEntity, class_2338 blockPos, class_1657 player) {

    }
}
package de.tomalbrc.filament.gui;

import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class BackpackHotbarSlot extends class_1735 {
    final int selectedSlot;

    public BackpackHotbarSlot(class_1263 container, int selectedSlot, int slot, int x, int y) {
        super(container, slot, x, y);
        this.selectedSlot = selectedSlot;
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return this.selectedSlot != method_34266() && super.method_7674(player);
    }

    @Override
    public boolean method_7680(class_1799 itemStack) {
        return this.selectedSlot != method_34266() && super.method_7680(itemStack);
    }

    @Override
    public boolean method_32754(class_1657 player) {
        return this.selectedSlot != method_34266();
    }

    @Override
    public Optional<class_1799> method_34264(int count, int decrement, class_1657 player) {
        return super.method_34264(count, decrement, player);
    }
}

package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.DecorationRotationProvider;
import de.tomalbrc.filament.util.BlockUtil;
import de.tomalbrc.filament.util.Util;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import org.jetbrains.annotations.NotNull;

public class Rotating implements BlockBehaviour<Rotating.Config>, DecorationRotationProvider {
    private final Config config;

    public Rotating(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Rotating.Config getConfig() {
        return this.config;
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(BlockUtil.ROTATION);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 selfDefault, class_1750 blockPlaceContext) {
        if (config.smooth) {
            return selfDefault.method_11657(BlockUtil.ROTATION, Util.SEGMENTED_ANGLE8.method_48125(blockPlaceContext.method_8044()));
        } else {
            return selfDefault.method_11657(BlockUtil.ROTATION, Util.SEGMENTED_ANGLE8.method_48124(blockPlaceContext.method_8042()));
        }
    }

    public class_2680 rotate(class_2680 state, class_2470 rotation) {
        return state.method_11657(BlockUtil.ROTATION, rotation.method_10502(state.method_11654(BlockUtil.ROTATION), 8));
    }

    public class_2680 mirror(class_2680 state, class_2415 mirror) {
        return state.method_11657(BlockUtil.ROTATION, mirror.method_10344(state.method_11654(BlockUtil.ROTATION), 8));
    }

    @Override
    public float getVisualRotationYInDegrees(class_2680 blockState) {
        return Util.SEGMENTED_ANGLE8.method_48126(blockState.method_11654(BlockUtil.ROTATION));
    }

    public static class Config {
        public boolean smooth;
    }
}
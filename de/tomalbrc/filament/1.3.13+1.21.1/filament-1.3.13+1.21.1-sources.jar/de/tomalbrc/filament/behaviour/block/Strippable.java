package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.registry.StrippableRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import org.jetbrains.annotations.NotNull;

/**
 * Block behaviourConfig for strippable blocks (with an axe)
 * Copies blockstate properties if applicable
 */
public class Strippable implements BlockBehaviour<Strippable.Config> {
    private final Config config;

    public Strippable(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Strippable.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        StrippableRegistry.add(block, config.replacement, config.lootTable);
    }

    public static class Config {
        /**
         * Replacement block
         */
        public class_2960 replacement;
        /**
         * Loot to drop when a block is stripped
         */
        public class_2960 lootTable;

        /**
         * Copper-like scrape particles
         */
        public boolean scrape = false;

        /**
         * Wax-scrape particles
         */
        public boolean scrapeWax = false;

        /**
         * Sound to play
         */
        public class_2960 sound = class_3417.field_14675.method_14833();
    }
}
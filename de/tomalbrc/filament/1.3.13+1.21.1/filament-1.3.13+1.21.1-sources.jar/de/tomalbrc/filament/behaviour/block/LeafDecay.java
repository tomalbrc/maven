package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.OptionalInt;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3612;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class LeafDecay implements BlockBehaviour<LeafDecay.Config> {
    private final Config config;

    public LeafDecay(Config config) {
        this.config = config;
        if (this.config.blockTag != null) {
            this.config.supportBlock = class_6862.method_40092(class_7924.field_41254, this.config.blockTag);
        }
    }

    @Override
    @NotNull
    public LeafDecay.Config getConfig() {
        return this.config;
    }

    @Override
    public int getLightBlock(class_2680 state) {
        return 1;
    }

    @Override
    public class_2680 modifyPolymerBlockState(class_2680 original, class_2680 blockState) {
        return blockState.method_11657(class_2741.field_12541, 7).method_11657(class_2741.field_12514, false);
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(class_2741.field_12541, 7).method_11657(class_2741.field_12514, false);
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12541, class_2741.field_12514);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 selfDefault, class_1750 context) {
        class_2680 blockState = (selfDefault.method_11657(class_2741.field_12514, true));
        return updateDistance(blockState, context.method_8045(), context.method_8037());
    }


    @Override
    public class_265 getBlockSupportShape(class_2680 state, class_1922 level, class_2338 pos) {
        return class_259.method_1073();
    }

    @Override
    public boolean isRandomlyTicking(class_2680 state) {
        return state.method_11654(class_2741.field_12541) == 7 && !state.method_11654(class_2741.field_12514);
    }

    @Override
    public void randomTick(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (this.decaying(state) && random.method_43057() <= config.decayChance) {
            class_2248.method_9497(state, level, pos);
            level.method_8650(pos, false);
        }
    }

    protected boolean decaying(class_2680 state) {
        return !state.method_11654(class_2741.field_12514) && state.method_11654(class_2741.field_12541) == 7;
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        if (blockState.method_28498(class_2741.field_12508) && blockState.method_11654(class_2741.field_12508)) {
            levelAccessor.method_39281(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelAccessor));
        }
        int dist = getDistanceAt(blockState2) + 1;
        if (dist != 1 || blockState.method_11654(class_2741.field_12541) != dist) {
            levelAccessor.method_39279(blockPos, blockState.method_26204(), 1);
        }
        return blockState;
    }

    @Override
    public void tick(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        level.method_8652(pos, updateDistance(state, level, pos), class_2248.field_31036);
    }

    private class_2680 updateDistance(class_2680 state, class_1936 level, class_2338 pos) {
        int dist = 7;
        class_2338.class_2339 mutableBlockPos = new class_2338.class_2339();

        for (class_2350 direction : class_2350.values()) {
            mutableBlockPos.method_25505(pos, direction);
            dist = Math.min(dist, getDistanceAt(level.method_8320(mutableBlockPos)) + 1);
            if (dist == 1) {
                break;
            }
        }

        return state.method_11657(class_2741.field_12541, dist);
    }

    private int getDistanceAt(class_2680 neighbor) {
        return getOptionalDistanceAt(neighbor).orElse(7);
    }

    public OptionalInt getOptionalDistanceAt(class_2680 blockState) {
        if (blockState.method_26164(config.supportBlock))
            return OptionalInt.of(0);
        else
            return blockState.method_28498(class_2741.field_12541) ? OptionalInt.of(blockState.method_11654(class_2741.field_12541)) : OptionalInt.empty();
    }

    public static class Config {
        class_2960 blockTag;
        float decayChance = 1.f;

        transient private class_6862<class_2248> supportBlock = class_3481.field_15475;
    }
}
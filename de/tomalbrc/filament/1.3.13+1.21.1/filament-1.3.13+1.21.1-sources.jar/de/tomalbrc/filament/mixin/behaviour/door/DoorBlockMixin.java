package de.tomalbrc.filament.mixin.behaviour.door;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2323.class)
public class DoorBlockMixin {
    @WrapOperation(method = "updateShape", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;", ordinal = 0))
    private class_2248 filament$onUpdateShape(class_2680 instance, Operation<class_2248> original) {
        if (instance.method_26204() instanceof SimpleBlock) {
            return class_2246.field_10149;
        }

        return original.call(instance);
    }
}

package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.NotNull;

public class IgniteEntity implements BlockBehaviourWithEntity<IgniteEntity.Config> {
    private final Config config;

    public IgniteEntity(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public IgniteEntity.Config getConfig() {
        return this.config;
    }

    @Override
    public void entityInside(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1297 entity) {
        if (!entity.method_5753()) {
            entity.method_20803(entity.method_20802() + 1);
            if (entity.method_20802() == 0) {
                entity.method_5639(8.0F);
            }
        }

        entity.method_5643(level.method_48963().method_48794(), this.config.fireDamage);
    }

    public static class Config {
        float fireDamage = 1;
    }
}
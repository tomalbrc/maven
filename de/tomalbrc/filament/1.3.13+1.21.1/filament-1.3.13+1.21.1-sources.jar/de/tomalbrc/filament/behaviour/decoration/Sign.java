package de.tomalbrc.filament.behaviour.decoration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.item.FilamentItem;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.elements.TextDisplayElement;
import eu.pb4.sgui.api.gui.SignGui;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_5253;
import net.minecraft.class_6088;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_8104;
import net.minecraft.class_8113;
import net.minecraft.class_8824;
import net.minecraft.class_9279;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class Sign implements DecorationBehaviour<Sign.Config> {
    Config config;

    Map<ConfiguredSignElement, SignData> signData = new Reference2ObjectOpenHashMap<>();
    boolean isWaxed = false;
    UUID editingPlayer = null;

    public Sign(Config config) {
        this.config = config;
    }

    @Override
    public @NotNull Config getConfig() {
        return config;
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        var e = getClosestTextElement(decorationBlockEntity, location);
        var sd = getSignData(e);

        if (config.canEdit) {
            var itemStack = player.method_5998(hand);
            if (config.waxable && !isWaxed && (itemStack.method_31574(class_1802.field_20414) || itemStack.method_7909() instanceof FilamentItem filamentItem && filamentItem.has(Behaviours.WAX))) {
                class_174.field_24478.method_23889(player, decorationBlockEntity.method_11016(), itemStack);
                player.method_37908().method_8444(null, class_6088.field_31156, decorationBlockEntity.method_11016(), 0);

                if (!itemStack.method_7963())
                    itemStack.method_57008(1, player);
                else itemStack.method_7970(1, player, class_1309.method_56079(hand));

                this.isWaxed = true;
                decorationBlockEntity.method_5431();

                return class_1269.field_21466;
            }

            var empty = sd.isEmpty();

            if (config.dyeable && !empty && itemStack.method_7909() instanceof class_1769 dyeItem && apply(player.method_37908(), decorationBlockEntity, e, dyeItem.method_7802(), sd.glow)) {
                if (!itemStack.method_7963())
                    itemStack.method_57008(1, player);
                else itemStack.method_7970(1, player, class_1309.method_56079(hand));

                return class_1269.field_21466;
            }

            if (!empty && itemStack.method_31574(class_1802.field_28410) && !sd.glow) {
                sd.glow = true;
                player.method_37908().method_8396(null, decorationBlockEntity.method_11016(), class_3417.field_28392, class_3419.field_15245, 1.0F, 1.0F);
                changed(decorationBlockEntity, e);

                if (!itemStack.method_7963())
                    itemStack.method_57008(1, player);
                else itemStack.method_7970(1, player, class_1309.method_56079(hand));

                return class_1269.field_21466;
            }

            if (!isWaxed && !player.method_21823() && (editingPlayer == null || Filament.SERVER.method_3760().method_14602(editingPlayer) == null)) {
                if (e != null) {
                    editingPlayer = player.method_5667();
                    var signGui = new SignGui(player) {
                        @Override
                        public void onClose() {
                            for (int i = 0; i < e.lines; i++) {
                                sd.text[i] = getLine(i);
                            }
                            changed(decorationBlockEntity, e);
                            editingPlayer = null;
                            super.onClose();
                        }
                    };

                    for (int i = 0; i < e.lines; i++) {
                        signGui.setLine(i, getLine(e, i));
                    }

                    signGui.setSignType(config.block);
                    signGui.open();
                    return class_1269.field_21466;
                }
            }
        }

        if (executeClickCommandsIfPresent(player.method_51469(), player, decorationBlockEntity.method_11016(), sd.text)) {
            return class_1269.field_21466;
        }

        return DecorationBehaviour.super.interact(player, hand, location, decorationBlockEntity);
    }


    public boolean executeClickCommandsIfPresent(class_3218 level, class_1657 player, class_2338 blockPos, class_2561[] components) {
        boolean bl2 = false;

        for(class_2561 component : components) {
            class_2583 style = component.method_10866();
            class_2558 clickEvent = style.method_10970();
            if (clickEvent != null && clickEvent.method_10845() == class_2558.class_2559.field_11750) {
                player.method_5682().method_3734().method_44252(createCommandSourceStack(player, level, blockPos), clickEvent.method_10844());
                bl2 = true;
            }
        }

        return bl2;
    }

    private static class_2168 createCommandSourceStack(@Nullable class_1657 player, class_3218 serverLevel, class_2338 blockPos) {
        String string = player == null ? "Decoration" : player.method_5477().getString();
        class_2561 component = player == null ? class_2561.method_43470("Decoration") : player.method_5476();
        return new class_2168(class_2165.field_17395, class_243.method_24953(blockPos), class_241.field_1340, serverLevel, 2, string, component, serverLevel.method_8503(), player);
    }

    @Override
    public void read(class_2487 output, class_7225.class_7874 lookup, DecorationBlockEntity blockEntity) {
        this.isWaxed = output.method_10545("IsWaxed") && output.method_10577("IsWaxed");

        if (output.method_10545("SignData")) {
            var tag = output.method_10580("SignData");
            var dec = SignData.CODEC.listOf().decode(lookup.method_57093(class_2509.field_11560), tag);
            dec.ifSuccess(pair -> {
                var x = pair.getFirst();
                for (int i = 0; i < config.elements.size(); i++) {
                    ConfiguredSignElement signElement = config.elements.get(i);
                    this.signData.put(signElement, x.get(i));
                    changed(blockEntity, signElement);
                }
            });
        }
    }

    @Override
    public void write(class_2487 input, class_7225.class_7874 lookup, DecorationBlockEntity blockEntity) {
        input.method_10556("IsWaxed", this.isWaxed);
        List<SignData> data = new ObjectArrayList<>();
        for (int i = 0; i < this.config.elements.size(); i++) {
            ConfiguredSignElement signElement = config.elements.get(i);
            data.add(i, getSignData(signElement));
        }
        input.method_10566("SignData", SignData.CODEC.listOf().encodeStart(lookup.method_57093(class_2509.field_11560), data).getOrThrow());
    }

    @Override
    public void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_2586.class_9473 dataComponentGetter) {
        var data = dataComponentGetter.method_58694(class_9334.field_49628);
        if (data != null) {
            if (data.method_57450("SignData")) {
                var t = data.method_57461();
                var sd = t.method_10580("SignData");
                SignData.CODEC.listOf().decode(class_6903.method_46632(class_2509.field_11560, Filament.SERVER.method_30611()), sd).ifSuccess(pair -> {
                    var res = pair.getFirst();
                    for (int i = 0; i < config.elements.size(); i++) {
                        ConfiguredSignElement signElement = config.elements.get(i);
                        this.signData.put(signElement, res.get(i));
                        changed(decorationBlockEntity, signElement);
                    }
                });
            }

        } else {
            for (int i = 0; i < config.elements.size(); i++) {
                ConfiguredSignElement signElement = config.elements.get(i);
                changed(decorationBlockEntity, signElement);
            }
        }
    }

    @Override
    public void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {
        List<SignData> data = new ObjectArrayList<>();
        for (int i = 0; i < this.config.elements.size(); i++) {
            ConfiguredSignElement signElement = config.elements.get(i);
            data.add(i, getSignData(signElement));
        }

        builder.method_57840(class_9334.field_49628, class_9279.field_49302.method_57451(x -> {
            SignData.CODEC.listOf().encodeStart(class_2509.field_11560, data).ifSuccess(res -> {
                x.method_10566("SignData", res);
            });
        }));
    }

    private class_2561 getLine(ConfiguredSignElement element, int i) {
        return getSignData(element).text[i];
    }

    private SignData getSignData(ConfiguredSignElement element) {
        return this.signData.computeIfAbsent(element, x -> new SignData());
    }

    private void changed(DecorationBlockEntity decorationBlockEntity, ConfiguredSignElement configuredSignElement) {
        decorationBlockEntity.method_5431();
        var sd = getSignData(configuredSignElement);

        class_5250 c = class_2561.method_43473();
        if (sd.isEmpty() && configuredSignElement.text != null) {
            for (int i = 0; i < configuredSignElement.text.length; i++) {
                c.method_27693("\n").method_10852(configuredSignElement.text[i]);
            }
        } else {
            for (int i = 0; i < configuredSignElement.lines; i++) {
                c.method_27693("\n").method_10852(getLine(configuredSignElement, i));
            }
        }

        Matrix4f matrix4f = new Matrix4f();
        matrix4f.rotate(configuredSignElement.rotation);
        matrix4f.scale(configuredSignElement.scale);

        if (sd.display == null) {
            sd.display = new SignLikeTextDisplay();
        }
        var element = sd.display;
        element.setOffset(new class_243(configuredSignElement.offset.rotateY(class_3532.field_29847 * (-decorationBlockEntity.getVisualRotationYInDegrees()), new Vector3f())));
        element.setSeeThrough(configuredSignElement.seeThrough);
        element.setBackground(configuredSignElement.backgroundColor);
        element.setYaw(decorationBlockEntity.getVisualRotationYInDegrees() + 180);
        element.setDisplaySize(3, 3);
        element.setTransformation(matrix4f);
        element.setBillboardMode(configuredSignElement.billboardMode);
        element.setTextAlignment(configuredSignElement.alignment);

        if (element.getHolder() == null)
            decorationBlockEntity.getOrCreateHolder().addElement(element);

        element.setText(c, sd.color, sd.glow);
        decorationBlockEntity.getOrCreateHolder().tick();
    }

    public Sign.ConfiguredSignElement getClosestTextElement(DecorationBlockEntity decorationBlockEntity, class_243 location) {
        if (config.elements.size() == 1) {
            return config.elements.getFirst();
        } else {
            double dist = Double.MAX_VALUE;
            ConfiguredSignElement nearest = null;
            for (var element : config.elements) {
                class_243 q = decorationBlockEntity.method_11016().method_46558().method_1019(new class_243(this.getTranslation(element).rotateY((-decorationBlockEntity.getVisualRotationYInDegrees() + 180) * class_3532.field_29847)));
                double distance = q.method_1022(location);

                if (distance < dist) {
                    dist = distance;
                    nearest = element;
                }
            }

            return nearest;
        }
    }

    private Vector3f getTranslation(ConfiguredSignElement element) {
        return new Vector3f(element.offset).sub(0, 0.475f, 0).rotate(element.rotation).rotateY(class_3532.field_29844);
    }

    public boolean apply(class_1937 level, DecorationBlockEntity blockEntity, ConfiguredSignElement element, class_1767 color, boolean glow) {
        boolean changedColor = false;
        var sd = getSignData(element);
        if (color != null && sd.color != color) {
            sd.color = color;
            changedColor = true;
            level.method_8396(null, blockEntity.method_11016(), class_3417.field_28391, class_3419.field_15245, 1.0F, 1.0F);
        }

        sd.glow = glow;

        changed(blockEntity, element);

        return changedColor;
    }

    public static class Config {
        public boolean canEdit = true;
        public boolean waxable = true;
        public boolean dyeable = true;
        public class_2248 block = class_2246.field_10121;
        public List<ConfiguredSignElement> elements = List.of();
    }

    public static class ConfiguredSignElement {
        public Vector3f offset = new Vector3f(0, 0, 0.5f);
        public Vector3f scale = new Vector3f(0.5f);
        public Quaternionf rotation = new Quaternionf();
        public int lines = 4;
        public class_2561[] text;
        public class_8113.class_8114 billboardMode = class_8113.class_8114.field_42406;
        public int backgroundColor = 0x00_000000;
        public boolean seeThrough = false;
        public class_8113.class_8123.class_8124 alignment = class_8113.class_8123.class_8124.field_42450;
    }

    public static class SignData {
        public class_2561[] text = new class_2561[]{class_2561.method_43473(), class_2561.method_43473(), class_2561.method_43473(), class_2561.method_43473()};
        public SignLikeTextDisplay display;
        public boolean glow = false;
        public class_1767 color = class_1767.field_7952;

        public static final Codec<SignData> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        class_8824.field_46597.listOf().fieldOf("text").forGetter(signData -> List.of(signData.text)),
                        Codec.BOOL.fieldOf("glow").forGetter(signData -> signData.glow),
                        class_1767.field_41600.fieldOf("color").forGetter(signData -> signData.color)
                ).apply(instance, (textList, glow, color) -> {
                    SignData data = new SignData();
                    data.text = textList.toArray(new class_2561[0]);
                    data.glow = glow;
                    data.color = color;
                    return data;
                })
        );

        private boolean isEmpty() {
            for (class_2561 line : text) {
                if (line != null && !line.method_44746().isEmpty())
                    return false;
            }

            return true;
        }
    }

    public static class SignLikeTextDisplay extends TextDisplayElement {
        private static final int CENTER = 4;
        private final TextDisplayElement[] displayText = new TextDisplayElement[9];

        private boolean glow = false;
        private Matrix4f transformation;

        public SignLikeTextDisplay() {
            for (int i = 0; i < this.displayText.length; i++) {
                var text = new TextDisplayElement();
                text.setBackground(0);
                text.setInvisible(true);
                this.displayText[i] = text;
            }
        }

        public void setText(class_2561 text, class_1767 color, boolean glow) {
            var brightness = glow ? class_8104.field_42264 : null;
            this.displayText[CENTER].setText(class_2561.method_43473().method_10852(text).method_54663(color.method_7787()));
            this.displayText[CENTER].setBrightness(brightness);

            if (glow) {
                var background = class_2561.method_43473().method_10852(text).method_54663(getOutlineColor(color));
                for (int i = 0; i < this.displayText.length; i++) {
                    if (i != CENTER) {
                        this.displayText[i].setText(background);
                        this.displayText[i].setBrightness(brightness);
                        if (!this.glow && this.getHolder() != null) {
                            this.getHolder().addElement(this.displayText[i]);
                        }
                    }
                }
            } else if (this.glow && this.getHolder() != null) {
                for (int i = 0; i < this.displayText.length; i++) {
                    if (i != CENTER) {
                        this.getHolder().removeElement(this.displayText[i]);
                    }
                }
            }
            this.glow = glow;
        }

        public static int getOutlineColor(class_1767 color) {
            if (color == class_1767.field_7963) {
                return -988212;
            } else {
                int i = color.method_7787();
                int j = (int) ((double) class_5253.class_5254.method_27765(i) * 0.4);
                int k = (int) ((double) class_5253.class_5254.method_27766(i) * 0.4);
                int l = (int) ((double) class_5253.class_5254.method_27767(i) * 0.4);
                return class_5253.class_5254.method_27764(0, j, k, l);
            }
        }

        @Override
        public void setHolder(ElementHolder holder) {
            var old = this.getHolder();
            super.setHolder(holder);
            if (holder != null) {
                if (this.glow) {
                    holder.addElement(this.displayText[CENTER]);
                } else {
                    for (var x : this.displayText) {
                        holder.addElement(x);
                    }
                }
            } else if (old != null) {
                for (var x : this.displayText) {
                    old.removeElement(x);
                }
            }
        }

        @Override
        public void startWatching(class_3222 serverPlayer, Consumer<class_2596<class_2602>> consumer) {

        }

        @Override
        public void stopWatching(class_3222 serverPlayer, Consumer<class_2596<class_2602>> consumer) {

        }

        @Override
        public void tick() {
            if (this.glow) {
                for (var x : this.displayText) {
                    x.tick();
                }
            } else {
                this.displayText[CENTER].tick();
            }
        }

        public void setYaw(float yaw) {
            for (var x : this.displayText) {
                x.setYaw(yaw);
            }

            if (transformation != null) this.setTransformation(transformation);
        }

        public void setDisplaySize(int x, int y) {
            for (var e : this.displayText) {
                e.setDisplaySize(x, y);
            }
        }

        @Override
        public IntList getEntityIds() {
            return IntList.of();
        }

        @Override
        public void notifyMove(class_243 oldPos, class_243 currentPos, class_243 delta) {

        }

        public void setSeeThrough(boolean seeThrough) {
            for (var e : this.displayText) e.setSeeThrough(seeThrough);
        }

        public void setBackground(int backgroundColor) {
            for (var e : this.displayText) e.setBackground(backgroundColor);
        }

        public void setTransformation(Matrix4f matrix4f) {
            this.transformation = matrix4f;
            for (int i = 0; i < this.displayText.length; i++) {
                var mat = new Matrix4f(matrix4f);

                if (CENTER == i) {
                    this.displayText[i].setTransformation(mat.translate(new Vector3f(0, 0, 0.002f)));
                } else {
                    int x = i % 3 - 1;
                    int y = i / 3 - 1;
                    this.displayText[i].setTransformation(mat.translate(new Vector3f(x / 40f, y / 40f, 0)));
                }
            }
        }

        public void setBillboardMode(class_8113.class_8114 billboardMode) {
            for (var e : this.displayText) e.setBillboardMode(billboardMode);
        }

        public void setTextAlignment(class_8113.class_8123.class_8124 alignment) {
            for (var e : this.displayText) e.setTextAlignment(alignment);
        }

        public void setOffset(class_243 offset) {
            for (var e : this.displayText) e.setOffset(offset);
        }
    }
}

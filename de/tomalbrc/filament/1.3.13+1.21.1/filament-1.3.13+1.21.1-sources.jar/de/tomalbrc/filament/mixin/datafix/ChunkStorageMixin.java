package de.tomalbrc.filament.mixin.datafix;

import com.mojang.serialization.MapCodec;
import de.tomalbrc.filament.datafixer.DataFix;
import de.tomalbrc.filament.util.FilamentConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_2794;
import net.minecraft.class_3977;
import net.minecraft.class_4284;
import net.minecraft.class_5321;

@Mixin(class_3977.class)
public class ChunkStorageMixin {
    @Inject(method = "upgradeChunkTag", at = @At(value = "RETURN"), cancellable = true)
    private void filament$addChunkFixer(class_5321<class_1937> levelKey, Supplier<class_26> storage, class_2487 chunkData, Optional<class_5321<MapCodec<? extends class_2794>>> chunkGeneratorKey, CallbackInfoReturnable<class_2487> cir) {
        if (FilamentConfig.getInstance().version < DataFix.VERSION) {
            var res = class_4284.field_19214.method_48131(DataFix.getDataFixer(), chunkData, 1, DataFix.VERSION);
            cir.setReturnValue(res);
        }
    }
}

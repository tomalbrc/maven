package de.tomalbrc.filament.command.subcommand;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2509;
import net.minecraft.class_2512;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_6903;
import net.minecraft.class_9323;

public class ServerItemCommand {
    public static LiteralCommandNode<class_2168> register() {
        var node = class_2170
                .method_9247("server-item").requires(Permissions.require("filament.command.server-item", 2));

        return node.executes(ServerItemCommand::execute).build();
    }

    private static int execute(CommandContext<class_2168> context) {
        var player = context.getSource().method_44023();
        if (player != null) {
            var handItem = player.method_5998(class_1268.field_5808);
            class_1799.field_24671.encodeStart(class_6903.method_46632(class_2509.field_11560, player.method_56673()), handItem).ifSuccess(tag -> context.getSource().method_9226(() -> class_2561.method_43470("Server Item: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1061)).method_10852(class_2512.method_32270(tag)), false));
            class_9323.field_50234.encodeStart(class_6903.method_46632(class_2509.field_11560, player.method_56673()), handItem.method_57353()).ifSuccess(tag -> context.getSource().method_9226(() -> class_2561.method_43470("Components: ").method_10862(class_2583.field_24360.method_10977(class_124.field_1061)).method_10852(class_2512.method_32270(tag)), false));
        }
        return 0;
    }
}

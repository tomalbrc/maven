package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.registry.BiomeModifications;
import de.tomalbrc.filament.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_6860;
import net.minecraft.class_7237;
import net.minecraft.class_7659;
import net.minecraft.class_7780;

@Mixin(class_7237.class)
public class WorldLoaderMixin {
    @Inject(method = "load", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/RegistryLayer;createRegistryAccess()Lnet/minecraft/core/LayeredRegistryAccess;", shift = At.Shift.BEFORE))
    private static void filament$loadEarly(class_7237.class_6906 initConfig, class_7237.class_6907 worldDataSupplier, class_7237.class_7239 resultFactory, Executor executor, Executor executor2, CallbackInfoReturnable<CompletableFuture> cir, @Local class_6860 closeableResourceManager) {
        Util.loadDatapackContents(closeableResourceManager);
    }

    @Inject(method = "load", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/ReloadableServerResources;loadResources(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/LayeredRegistryAccess;Lnet/minecraft/world/flag/FeatureFlagSet;Lnet/minecraft/commands/Commands$CommandSelection;ILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;)Ljava/util/concurrent/CompletableFuture;"))
    private static <D, R> void filament$almostDone(class_7237.class_6906 initConfig, class_7237.class_6907<D> worldDataSupplier, class_7237.class_7239<D, R> resultFactory, Executor executor, Executor executor2, CallbackInfoReturnable<CompletableFuture<R>> cir, @Local(ordinal = 1) class_7780<class_7659> layeredRegistryAccess) {
        BiomeModifications.addAll(layeredRegistryAccess);
    }
}
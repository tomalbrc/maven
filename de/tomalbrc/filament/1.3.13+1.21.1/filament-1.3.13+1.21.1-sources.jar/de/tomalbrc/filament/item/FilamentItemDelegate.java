package de.tomalbrc.filament.item;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.class_9334;

// shared behaviour delegate for SimpleItem and SimpleBlockItem - DecorationItem just inherits SimpleItem
public class FilamentItemDelegate {
    private final BehaviourHolder holder;

    public FilamentItemDelegate(BehaviourHolder holder) {
        this.holder = holder;
    }

    public void onUseTick(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.onUseTick(level, livingEntity, itemStack, i);
            }
        }
    }

    public void releaseUsing(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.releaseUsing(itemStack, level, livingEntity, useDuration);
            }
        }
    }

    public boolean useOnRelease(class_1799 itemStack, Supplier<Boolean> fallback) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                if (itemBehaviour.useOnRelease(itemStack)) {
                    return true;
                }
            }
        }
        return fallback.get();
    }

    public int getUseDuration(class_1799 itemStack, class_1309 livingEntity, Supplier<Integer> fallback) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                Optional<Integer> val = itemBehaviour.getUseDuration(itemStack, livingEntity);
                if (val.isPresent()) return val.get();
            }
        }
        return fallback.get();
    }

    public boolean hurtEnemy(class_1799 itemStack, class_1309 attacker, class_1309 target) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.hurtEnemy(itemStack, attacker, target);
            }
        }

        return true;
    }

    public void postHurtEnemy(class_1799 itemStack, class_1309 attacker, class_1309 target) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.postHurtEnemy(itemStack, attacker, target);
            }
        }
        if (itemStack.method_57826(class_9334.field_50077))
            itemStack.method_7970(1, target, attacker.method_32326(itemStack));
    }

    public void appendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, List<class_2561> consumer, class_1836 tooltipFlag) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.appendHoverText(itemStack, tooltipContext, consumer, tooltipFlag);
            }
        }
    }

    public void modifyPolymerItemStack(Map<String, class_2960> modelMap, class_1799 original, class_1799 polymer, class_1836 tooltipFlag, class_7225.class_7874 lookup, class_3222 player) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.modifyPolymerItemStack(modelMap, original, polymer, tooltipFlag, lookup, player);
            }
        }
    }

    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 hand, Supplier<class_1271<class_1799>> fallback) {
        class_1271<class_1799> result = fallback.get();
        if (result.method_5467().method_23665()) {
            return result;
        }

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                result = itemBehaviour.use(item, level, player, hand);
                if (result.method_5467().method_23665()) {
                    return result;
                }
            }
        }
        return result;
    }

    public class_1269 useOn(class_1838 context, Supplier<class_1269> fallback) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                class_1269 result = itemBehaviour.useOn(context);
                if (result.method_23665()) {
                    return result;
                }
            }
        }
        return fallback.get();
    }

    public boolean mineBlock(class_1799 itemStack, class_1937 level, class_2680 state, class_2338 pos, class_1309 entity, Supplier<Boolean> fallback) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                if (itemBehaviour.mineBlock(itemStack, level, state, pos, entity)) {
                    return true;
                }
            }
        }
        return fallback.get();
    }

    public float getAttackDamageBonus(class_1297 entity, float base, class_1282 source, Supplier<Float> fallback) {
        float bonus = fallback.get();
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                bonus += itemBehaviour.getAttackDamageBonus(entity, base, source);
            }
        }
        return bonus;
    }

    public class_1282 getDamageSource(class_1309 livingEntity, Supplier<class_1282> fallback) {
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : holder.getBehaviours()) {
            if (entry.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                class_1282 ds = itemBehaviour.getDamageSource(livingEntity);
                if (ds != null) return ds;
            }
        }
        return fallback.get();
    }
}
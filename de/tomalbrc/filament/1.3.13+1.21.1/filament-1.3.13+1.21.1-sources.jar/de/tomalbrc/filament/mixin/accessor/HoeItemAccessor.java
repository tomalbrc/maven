package de.tomalbrc.filament.mixin.accessor;

import com.mojang.datafixers.util.Pair;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1794;
import net.minecraft.class_1838;
import net.minecraft.class_2248;

@Mixin(class_1794.class)
public interface HoeItemAccessor {
    @Accessor
    static Map<class_2248, Pair<Predicate<class_1838>, Consumer<class_1838>>> getTILLABLES() {
        throw new AssertionError();
    }
}

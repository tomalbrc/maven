package de.tomalbrc.filament.util.mixin;

import java.util.function.Predicate;
import net.minecraft.class_1799;

public interface ItemPredicateCustomCheck {
    void setCustomCheck(Predicate<class_1799> itemStackPredicate);
}

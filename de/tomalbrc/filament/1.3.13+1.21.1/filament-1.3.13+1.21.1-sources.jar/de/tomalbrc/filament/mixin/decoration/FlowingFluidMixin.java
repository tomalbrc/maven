package de.tomalbrc.filament.mixin.decoration;

import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.DecorationRegistry;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_3609.class)
public class FlowingFluidMixin {

    @Inject(method = "canSpreadTo", at = @At("TAIL"), cancellable = true)
    private void filament$canSpreadTo(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_3610 fluidState, class_3611 fluid, CallbackInfoReturnable<Boolean> cir) {
        if (DecorationRegistry.isDecoration(blockState2)) {
            boolean isWaterloggable = this.filament$isWaterloggable((DecorationBlock) blockState2.method_26204()) && direction != class_2350.field_11033;
            boolean isSolid = this.filament$isSolid((DecorationBlock) blockState2.method_26204()) && direction != class_2350.field_11033;
            cir.setReturnValue(isWaterloggable || !isSolid);
        }
    }

    @Inject(method = "spreadTo", at = @At("TAIL"))
    protected void filament$spreadTo(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_3610 fluidState, CallbackInfo ci) {
        if (DecorationRegistry.isDecoration(blockState) && !filament$isWaterloggable((DecorationBlock) blockState.method_26204()) && !filament$isSolid((DecorationBlock) blockState.method_26204())) {
            if (levelAccessor.method_8321(blockPos) instanceof DecorationBlockEntity decorationBlockEntity) {
                decorationBlockEntity.destroyStructure(true);
            }

            // let it overflow with liquid
            levelAccessor.method_8652(blockPos, fluidState.method_15759(), 3);
        }
    }

    @Inject(method = "canPassThrough", at = @At("TAIL"), cancellable = true)
    private void filament$canPassThrough(class_1922 blockGetter, class_3611 fluid, class_2338 blockPos, class_2680 blockState, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_3610 fluidState, CallbackInfoReturnable<Boolean> cir) {
        // pass-thu but only non-waterloggable blocks and non-solid
        if (DecorationRegistry.isDecoration(blockState2) && !filament$isWaterloggable((DecorationBlock) blockState2.method_26204()) && !filament$isSolid((DecorationBlock) blockState2.method_26204()))
            cir.setReturnValue(this.filament$canFlowThrough(blockState2));
    }
    @Inject(method = "canPassThroughWall", at = @At("TAIL"), cancellable = true)
    private void filament$canPassThroughWall(class_2350 direction, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2338 blockPos2, class_2680 blockState2, CallbackInfoReturnable<Boolean> cir) {
        if (DecorationRegistry.isDecoration(blockState) || DecorationRegistry.isDecoration(blockState2))
            cir.setReturnValue(true);
    }

    @Unique
    private boolean filament$canFlowThrough(class_2680 blockState) {
        if (DecorationRegistry.isDecoration(blockState)) {
            DecorationBlock decorationBlock = (DecorationBlock) blockState.method_26204();

            if (decorationBlock.getDecorationData() != null && !blockState.method_28498(class_2741.field_12508)) {
                return !decorationBlock.getDecorationData().hasBlocks() && !decorationBlock.getDecorationData().properties().solid;
            }
        }

        return false;
    }

    @Unique
    private boolean filament$isWaterloggable(DecorationBlock decorationBlock) {
        if (decorationBlock.getDecorationData() != null) {
            return decorationBlock.method_9564().method_28498(class_2741.field_12508);
        }

        return false;
    }

    @Unique
    private boolean filament$isSolid(DecorationBlock decorationBlock) {
        if (decorationBlock.getDecorationData() != null) {
            return decorationBlock.getDecorationData().properties().solid;
        }

        return false;
    }
}
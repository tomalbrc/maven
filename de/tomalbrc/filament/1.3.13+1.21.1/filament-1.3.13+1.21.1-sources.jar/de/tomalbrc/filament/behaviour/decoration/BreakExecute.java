package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.ExecuteUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3222;

/**
 * Lock behaviour for decoration
 */
public class BreakExecute implements DecorationBehaviour<BreakExecute.Config> {
    public Config config;

    public BreakExecute(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Config getConfig() {
        return this.config;
    }

    @Override
    public void postBreak(DecorationBlockEntity decorationBlockEntity, class_2338 blockPos, class_1657 player) {
        var commands = commands();
        boolean hasCommands = commands != null;
        if (hasCommands && player instanceof class_3222 serverPlayer) {
            var pos = config.atBlock ? blockPos.method_46558() : null;
            if (getConfig().console) {
                ExecuteUtil.asConsole(serverPlayer, pos, commands.toArray(new String[0]));
            }
            else {
                ExecuteUtil.asPlayer(serverPlayer, pos, commands.toArray(new String[0]));
            }
        }
    }

    private List<String> commands() {
        return getConfig().commands == null ? this.getConfig().command == null ? null : List.of(this.getConfig().command) : getConfig().commands;
    }

    public static class Config {
        public String command = null;
        public List<String> commands = null;
        public boolean atBlock = false;
        public boolean console;
    }
}
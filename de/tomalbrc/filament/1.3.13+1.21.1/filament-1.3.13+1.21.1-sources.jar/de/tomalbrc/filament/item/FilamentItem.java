package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.Data;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5151;

public interface FilamentItem extends BehaviourHolder, class_5151 {
    FilamentItemDelegate getDelegate();

    Data<?> getData();

    default Map<String, class_2960> getModelMap() {
        var resource = this.getData().preferredResource();
        var defaultResource = this.getData().itemResource();
        return resource != null ? resource.getModels() : defaultResource != null ? defaultResource.getModels() : null;
    }

    void verifyComponentsAfterLoad(class_1799 itemStack);

    default class_1792 asItem() {
        return (class_1792) this;
    }

    void requestModels();

    Map<String, PolymerModelData> getModelData();
}

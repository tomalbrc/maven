package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.registry.WaxableRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

/**
 * Block behaviourConfig for waxing blocks (like copper)
 * Copies blockstate properties if applicable
 */
public class Waxable implements BlockBehaviour<Waxable.Config> {
    private final Config config;

    public Waxable(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Waxable.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {
        WaxableRegistry.add(block, config.replacement);
    }

    public static class Config {
        /**
         * Replacement block
         */
        public class_2960 replacement;
    }
}
package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1309;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1764.class)
public interface CrossbowItemInvoker {
    @Invoker
    static float invokeGetPowerForTime(int i, class_1799 itemStack, class_1309 livingEntity) {
        throw new AssertionError();
    }
}

package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1665;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1665.class)
public interface AbstractArrowAccessor {
    @Accessor
    double getBaseDamage();

    @Accessor
    void setFiredFromWeapon(class_1799 weapon);
}

package de.tomalbrc.filament.util;

import de.tomalbrc.filament.Filament;
import eu.pb4.placeholders.api.ParserContext;
import eu.pb4.placeholders.api.parsers.TagParser;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.minecraft.class_2561;

public class TextUtil {
    public static class_2561 formatText(String text) {
        if (text == null || text.isBlank())
            return class_2561.method_43473();

        if (FilamentConfig.getInstance().minimessage) {
            var parsed = MiniMessage.miniMessage().deserialize(text);
            return Filament.adventure().toNative(parsed);
        }
        else
            return TagParser.SIMPLIFIED_TEXT_FORMAT.parseText(text, ParserContext.of());
    }
}

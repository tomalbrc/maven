package de.tomalbrc.filament.mixin.behaviour.animated_chest;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1373;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1373.class)
public class CatSitOnBlockGoalMixin {
    @Inject(method = "isValidTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/world/level/block/Block;)Z", ordinal = 0), cancellable = true)
    private void filament$chest(class_4538 levelReader, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir, @Local class_2680 blockState) {
        if (blockState.method_26204() instanceof DecorationBlock decorationBlock && decorationBlock.has(Behaviours.ANIMATED_CHEST)) {
            var decorationBlockEntity = levelReader.method_8321(blockPos);
            if (decorationBlockEntity != null) {
                var ac = ((DecorationBlockEntity) decorationBlockEntity).getOrThrow(Behaviours.ANIMATED_CHEST);
                if (!ac.container.hasViewers()) {
                    cir.setReturnValue(true);
                }
            }
        }
    }
}

package de.tomalbrc.filament.decoration.util;

import de.tomalbrc.filament.decoration.holder.FilamentDecorationHolder;
import net.minecraft.class_2818;

public interface BlockEntityWithElementHolder {

    void attach(class_2818 chunk);

    FilamentDecorationHolder getOrCreateHolder();
}

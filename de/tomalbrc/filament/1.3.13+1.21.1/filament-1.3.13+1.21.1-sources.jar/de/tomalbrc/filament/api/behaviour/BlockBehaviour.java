package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.AbstractBlockData;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.properties.BlockProperties;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1540;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;

@SuppressWarnings({"unused", "UnusedReturnValue"})
public interface BlockBehaviour<T> extends Behaviour<T> {
    /**
     * Called after the block and item were registered
     * @param item Item of the block
     * @param block The block
     * @param behaviourHolder filament behaviour holder (usually the block)
     */
    default void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {

    }

    /**
     * Allows to modify the blockstate to block-model map used by filament/polymer for the client-side representation of a blockstate (might be filtered)
     * @param map current default blockstate to model map
     * @param blockData block data
     * @return true when the state-map was modified
     */
    default boolean modifyStateMap(Map<class_2680, BlockData.BlockStateMeta> map, AbstractBlockData<? extends BlockProperties> blockData) {
        return false;
    }

    /**
     * Allows to modify the default blockstate of the block holding this behaviour
     * @param blockState the current default blockstate
     * @return the new default blockstate
     */
    default class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState;
    }

    /**
     * Allows to modify the blocks' vanilla properties
     * @param properties the current properties
     * @return the modified block properties
     */
    default net.minecraft.class_4970.class_2251 modifyBlockProperties(net.minecraft.class_4970.class_2251 properties) {
        return properties;
    }

    /**
     * Allows to add block-state-properties to the block holding this behaviour
     * @param builder state-definition builder
     */
    default void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
    }

    /**
     *
     * @param blockState the blockstate
     * @return optional wether to use the blockstates shape for light occlusion
     */
    default Optional<Boolean> useShapeForLightOcclusion(class_2680 blockState) {
        return Optional.empty();
    }

    /**
     * Allows to modify the blockstate for a given placement, before being placed.
     * @param blockState default blockstate (or modified one by a different behaviour)
     * @param blockPlaceContext context
     * @return new blockstate for placement
     */
    default class_2680 getStateForPlacement(class_2680 blockState, class_1750 blockPlaceContext) {
        return blockState;
    }

    /**
     * Whether the block can be replaced like grass when placing another block in its place
     * @param blockState blockstate to replace
     * @param blockPlaceContext context
     * @return optional flag
     */
    default Optional<Boolean> canBeReplaced(class_2680 blockState, class_1750 blockPlaceContext) {
        return Optional.empty();
    }

    /**
     * Shape update
     */
    default class_2680 updateShape(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        return blockState;
    }

    /**
     *
     */
    default void neighborChanged(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_2338 blockPos2, boolean bl) {

    }

    /**
     *
     */
    default void playerWillDestroy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
    }

    /**
     *
     */
    default Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
        return Optional.empty();
    }

    /**
     *
     */
    @Nullable
    default class_3610 getFluidState(class_2680 blockState) {
        return null;
    }

    /**
     *
     */
    default void onExplosionHit(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
    }

    /**
     *
     */
    default boolean dropFromExplosion(class_1927 explosion) {
        return true;
    }

    /**
     *
     */
    default class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return null;
    }

    /**
     *
     */
    default class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return null;
    }

    /**
     *
     */
    default boolean isSignalSource(class_2680 blockState) {
        return false;
    }

    /**
     *
     */
    default int getDirectSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return 0;
    }

    /**
     *
     */
    default int getSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return 0;
    }

    /**
     *
     */
    default void onPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
    }

    /**
     *
     */
    default void setPlacedBy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1309 livingEntity, class_1799 itemStack) {
    }

    /**
     * Called on removal to update neighbours
     */
    default void affectNeighborsAfterRemoval(class_2680 state, class_1937 level, class_2338 pos, class_2680 blockState2, boolean movedByPiston) {
    }

    /**
     *
     */
    default void spawnAfterBreak(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean bl) {
    }

    /**
     *
     */
    default boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return true;
    }

    /**
     *
     */
    default boolean isRandomlyTicking(class_2680 blockState) {
        return false;
    }

    /**
     *
     */
    default void randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
    }

    /**
     * Tick on scheduled ticks through ServerLevels blockTicker
     * @param blockState state of ticking block
     * @param serverLevel level
     * @param blockPos position
     * @param randomSource random source
     */
    default void tick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
    }

    /**
     * In some cases your block behaviour may need block states that visually look the same on clients.
     * This method allows to change block state properties before being passed on to getPolymerBlockState
     */
    default class_2680 modifyPolymerBlockState(class_2680 originalBlockState, class_2680 blockState) {
        return blockState;
    }

    /**
     * Allows to change the clone item-stack of the block
     *
     * @param itemStack The item of the block
     * @param levelReader The level(-reader)
     * @param blockPos Position of the block in world
     * @param blockState State of the picked block
     * @param includeData Include extra data
     * @return The clone (pick) itemstack of the block
     */
    default class_1799 getCloneItemStack(class_1799 itemStack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        return itemStack;
    }

    /**
     * Called when interacted with, with empty hands
     *
     * @param blockState State of the block interacted with
     * @param level World of the player/block
     * @param blockPos position of the block in the world
     * @param player Player that interacted with the block
     * @param blockHitResult Block-hit information
     * @return The result of the interaction with this block
     */
    default class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        return class_1269.field_5811;
    }

    /**
     * Called when interacted with, with an item in hand.
     *
     * @param itemStack Item that was held by the player / used for the interaction
     * @param blockState State of the block that was interacted with
     * @param level level
     * @param blockPos block pos of interaction
     * @param player Player that interacted with the block
     * @param interactionHand interaction hand
     * @param blockHitResult Block-hit information
     * @return The result of the interaction with this block with the item
     */
    @Nullable
    default class_1269 useItemOn(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        return null;
    }

    /**
     * Called when a player "attacks" the block
     */
    default void attack(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player) {
    }

    /**
     * Called when a projectile hits the block.
     *
     * @param level level
     * @param blockState state of the hit block
     * @param blockHitResult Block-hit information
     * @param projectile Projectile entity
     */
    default void onProjectileHit(class_1937 level, class_2680 blockState, class_3965 blockHitResult, class_1676 projectile) {
    }

    /**
     * Seed for blockstate at blockpos
     */
    default Optional<Long> getSeed(class_2680 blockState, class_2338 blockPos) {
        return Optional.empty();
    }

    /**
     * Damage source that is used for fall damage
     * @param entity damaged entity
     * @return the source of damage
     */
    @Nullable
    default class_1282 getFallDamageSource(class_1297 entity) {
        return null;
    }

    /**
     * Called when a falling block lands
     */
    default void onLand(class_1937 level, class_2338 blockPos, class_2680 blockState, class_2680 blockState2, class_1540 fallingBlockEntity) {
    }

    /**
     * Callback on broken after fall
     */
    default void onBrokenAfterFall(class_1937 level, class_2338 blockPos, class_1540 fallingBlockEntity) {
    }

    /**
     * Called when a block was exploded. Used for tnt behaviour for example to ignite the block
     */
    default void wasExploded(class_3218 serverLevel, class_2338 blockPos, class_1927 explosion) {
    }

    default Optional<Boolean> hasAnalogOutputSignal(class_2680 blockState) {
        return Optional.empty();
    }

    default int getAnalogOutputSignal(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return 0;
    }

    default void entityInside(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1297 entity) {
    }

    default int getLightBlock(class_2680 state) {
        return -1;
    }

    default class_265 getBlockSupportShape(class_2680 state, class_1922 level, class_2338 pos) {
        return null;
    }

    default boolean updateEntityMovementAfterFallOn(class_1922 blockGetter, class_1297 entity) {
        return false;
    }

    default boolean fallOn(class_1937 level, class_2680 blockState, class_2338 blockPos, class_1297 entity, double d) {
        return false;
    }

    default void stepOn(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1297 entity) {
        // noop
    }
}
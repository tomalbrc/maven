package de.tomalbrc.filament.mixin.behaviour;

import de.tomalbrc.filament.registry.FuelRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_2609;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Fuel behaviourConfig support
@Mixin(class_2609.class)
public class FuelValuesMixin {
    @Inject(method = "isFuel", at = @At("RETURN"), cancellable = true)
    private static void filament$isCustomFuel(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        if (FuelRegistry.getCache().containsKey(itemStack.method_7909()))
            cir.setReturnValue(true);
    }

    @Inject(method = "getBurnDuration", at = @At("RETURN"), cancellable = true)
    public void filament$customBurnDuration(class_1799 itemStack, CallbackInfoReturnable<Integer> cir) {
        if (FuelRegistry.getCache().containsKey(itemStack.method_7909()))
            cir.setReturnValue(FuelRegistry.getCache().get(itemStack.method_7909()));
    }
}

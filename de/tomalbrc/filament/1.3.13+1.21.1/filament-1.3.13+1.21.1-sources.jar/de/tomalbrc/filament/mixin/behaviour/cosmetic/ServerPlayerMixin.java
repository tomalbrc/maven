package de.tomalbrc.filament.mixin.behaviour.cosmetic;

import de.tomalbrc.filament.api.event.FilamentCosmeticEvents;
import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.cosmetic.CosmeticUtil;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_9274;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_3222.class)
public abstract class ServerPlayerMixin implements CosmeticInterface {
    @Inject(method = "initInventoryMenu", at = @At(value = "TAIL"))
    private void filament$onInitInventoryMenu(CallbackInfo ci) {
        if ((Object)this instanceof class_3222 serverPlayer) {
            for (class_1304 slot : class_1304.values()) {
                if (!class_9274.field_49224.method_57286(slot))
                    continue;

                if (slot == class_1304.field_6169) {
                    continue;
                }

                var item = serverPlayer.method_6118(slot);
                if (!item.method_7960() && CosmeticUtil.isCosmetic(item)) {
                    filament$destroyHolder(serverPlayer.method_32326(item).method_5923());
                    FilamentCosmeticEvents.UNEQUIPPED.invoker().onChange(class_1309.class.cast(this), item, class_1799.field_8037);
                    filament$addHolder(serverPlayer, item.method_7909(), item, serverPlayer.method_32326(item).method_5923());
                    FilamentCosmeticEvents.EQUIPPED.invoker().onChange(class_1309.class.cast(this), class_1799.field_8037, item);
                }
            }
        }
    }

    @Inject(method = "hasChangedDimension", at = @At("TAIL"))
    private void filament$onChangeDimension(CallbackInfo ci) {
        if ((Object)this instanceof class_3222 serverPlayer) {
            for (class_1304 slot : class_1304.values()) {
                if (!class_9274.field_49224.method_57286(slot))
                    continue;

                if (slot == class_1304.field_6169) {
                    continue;
                }

                var item = serverPlayer.method_6118(slot);

                if (!item.method_7960() && CosmeticUtil.isCosmetic(item)) {
                    filament$destroyHolder(serverPlayer.method_32326(item).method_5923());
                    FilamentCosmeticEvents.UNEQUIPPED.invoker().onChange(class_1309.class.cast(this), item, class_1799.field_8037);
                    filament$addHolder(serverPlayer, item.method_7909(), item, serverPlayer.method_32326(item).method_5923());
                    FilamentCosmeticEvents.EQUIPPED.invoker().onChange(class_1309.class.cast(this), class_1799.field_8037, item);
                }
            }
        }
    }
}

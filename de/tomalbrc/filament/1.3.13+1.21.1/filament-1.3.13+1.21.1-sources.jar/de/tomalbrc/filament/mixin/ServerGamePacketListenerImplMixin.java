package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.util.VirtualDestroyStage;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;


@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerImplMixin implements VirtualDestroyStage.ServerGamePacketListenerExtF {

    @Unique
    private final VirtualDestroyStage filament$virtualDestroyStageF = new VirtualDestroyStage();

    @Override
    public VirtualDestroyStage filament$getVirtualDestroyStage() {
        return this.filament$virtualDestroyStageF;
    }


}
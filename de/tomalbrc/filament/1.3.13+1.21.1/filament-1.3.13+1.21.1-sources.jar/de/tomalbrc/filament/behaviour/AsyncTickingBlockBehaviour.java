package de.tomalbrc.filament.behaviour;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

public interface AsyncTickingBlockBehaviour {
    /**
     * Async tick
     * @param blockState state of ticking block
     * @param serverLevel level
     * @param blockPos position
     * @param randomSource random source
     */
    void tickAsync(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource);
}

package de.tomalbrc.filament.item;

import de.tomalbrc.filament.mixin.behaviour.trident.ThrownTridentAccessor;
import de.tomalbrc.filament.registry.EntityRegistry;
import eu.pb4.polymer.core.api.entity.PolymerEntity;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import eu.pb4.polymer.virtualentity.mixin.accessors.DisplayEntityAccessor;
import eu.pb4.polymer.virtualentity.mixin.accessors.ItemDisplayEntityAccessor;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1685;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2743;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;

public class TridentEntity extends class_1685 implements PolymerEntity {
    protected final ElementHolder holder = new ElementHolder();
    protected final InteractionElement interactionElement = new InteractionElement();

    @Override
    public void method_36457(float x) {
        class_243 delta = this.method_18798();
        if (delta.method_1033() == 0) return;
        var xr = (float)(class_3532.method_15349(delta.field_1351, delta.method_37267()) * class_3532.field_29848);
        super.method_36457(xr);
    }
    @Override
    public void method_36456(float y) {
        class_243 delta = this.method_18798();
        if (delta.method_1033() == 0) return;
        var yr = (float)(class_3532.method_15349(delta.field_1352, -delta.field_1350) * class_3532.field_29848);
        super.method_36456(yr);
    }


    @Override
    public void method_57313(class_1799 stack) {
        super.method_57313(stack);
    }

    public TridentEntity(class_1299<? extends class_1297> entityType, class_1937 world) {
        super((class_1299<? extends class_1685>) entityType, world);
        initHolder();
    }

    public TridentEntity(class_1937 level, class_1309 livingEntity, class_1799 itemStack) {
        this(EntityRegistry.FILAMENT_TRIDENT, level);
        this.method_33574(livingEntity.method_33571());
        this.method_7432(livingEntity);
        method_57313(itemStack);

        this.field_6011.method_12778(ThrownTridentAccessor.getID_LOYALTY(), this.method_59960(itemStack));
        this.field_6011.method_12778(ThrownTridentAccessor.getID_FOIL(), itemStack.method_7958());
    }

    private byte method_59960(class_1799 itemStack) {
        class_1937 var3 = this.method_37908();
        if (var3 instanceof class_3218 serverLevel) {
            return (byte) class_3532.method_15340(class_1890.method_60169(serverLevel, itemStack, this), 0, 127);
        } else {
            return 0;
        }
    }

    private void initHolder() {
        EntityAttachment.of(this.holder, this);

        this.interactionElement.setSize(0.5f, 0.5f);
        this.interactionElement.ignorePositionUpdates();
        this.holder.addElement(this.interactionElement);
        VirtualEntityUtils.addVirtualPassenger(this, this.interactionElement.getEntityId());
    }

    @Override
    public class_1299<?> getPolymerEntityType(class_3222 packetContext) {
        return class_1299.field_42456;
    }

    @Override
    public void modifyRawTrackedData(List<class_2945.class_7834<?>> data, class_3222 player, boolean initial) {
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.FLAGS, (byte) (1 << EntityTrackedData.INVISIBLE_FLAG_INDEX)));
        data.add(class_2945.class_7834.method_46360(ItemDisplayEntityAccessor.getITEM(), method_7445()));
        data.add(class_2945.class_7834.method_46360(DisplayEntityAccessor.getTELEPORT_DURATION(), 2));
        data.add(class_2945.class_7834.method_46360(DisplayEntityAccessor.getLEFT_ROTATION(), new Quaternionf().rotateZ(class_3532.field_29845).rotateX(-class_3532.field_29845).rotateY(class_3532.field_29844).normalize()));
        data.add(class_2945.class_7834.method_46360(DisplayEntityAccessor.getTRANSLATION(), new Vector3f(0.f, -1.0f, 0.f).rotateX(-class_3532.field_29845)));
    }

    @Override
    public void onEntityPacketSent(Consumer<class_2596<?>> consumer, class_2596<?> packet) {
        PolymerEntity.super.onEntityPacketSent(consumer, packet);
        consumer.accept(new class_2743(method_5628(), method_18798()));
    }

    public ElementHolder holder() {
        return this.holder;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!field_7588)
            method_26962();
    }

    @Override
    public void method_5749(class_2487 input) {
        super.method_5749(input);
        super.method_36457(input.method_10545("TridentXRot") ? input.method_10583("TridentXRot"):0);
        super.method_36456(input.method_10545("TridentYRot") ? input.method_10583("TridentYRot"):0);
    }

    @Override
    public void method_5652(class_2487 output) {
        super.method_5652(output);
        output.method_10548("TridentXRot", method_36455());
        output.method_10548("TridentYRot", method_36454());
    }
}
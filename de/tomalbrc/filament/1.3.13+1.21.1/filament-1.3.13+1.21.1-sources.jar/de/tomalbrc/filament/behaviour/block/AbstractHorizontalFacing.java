package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.DecorationRotationProvider;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import org.jetbrains.annotations.NotNull;

public class AbstractHorizontalFacing<T> implements BlockBehaviour<T>, DecorationRotationProvider {
    private final T config;

    public AbstractHorizontalFacing(T config) {
        this.config = config;
    }

    @Override
    @NotNull
    public T getConfig() {
        return this.config;
    }

    @Override
    public void createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12481);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 selfDefault, class_1750 blockPlaceContext) {
        return selfDefault.method_11657(class_2741.field_12481, blockPlaceContext.method_8042().method_10153());
    }

    @Override
    public class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return blockState.method_11657(class_2741.field_12481, rotation.method_10503(blockState.method_11654(class_2741.field_12481)));
    }

    @Override
    public class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return blockState.method_26186(mirror.method_10345(blockState.method_11654(class_2741.field_12481)));
    }

    @Override
    public float getVisualRotationYInDegrees(class_2680 blockState) {
        return blockState.method_11654(class_2741.field_12481).method_10153().method_10144();
    }

    public static class Config {}
}
package de.tomalbrc.filament.mixin.component.backpack;

import de.tomalbrc.filament.registry.FilamentComponents;
import de.tomalbrc.filament.util.FilamentContainer;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1736;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1736.class)
public abstract class ShulkerBoxSlotMixin extends class_1735 {
    public ShulkerBoxSlotMixin(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Inject(method = "mayPlace", at = @At("RETURN"), cancellable = true)
    protected void filament$containerFix(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        if (itemStack.method_57826(FilamentComponents.BACKPACK) || FilamentContainer.isPickUpContainer(field_7871)) cir.setReturnValue(false);
    }
}

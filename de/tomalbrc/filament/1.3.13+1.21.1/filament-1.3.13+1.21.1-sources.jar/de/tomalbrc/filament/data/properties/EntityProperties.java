package de.tomalbrc.filament.data.properties;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Set;
import net.minecraft.class_1311;
import net.minecraft.class_2960;

public class EntityProperties {
    public @Nullable List<Float> size;
    public @Nullable class_1311 category;
    public @Nullable Sounds sounds;
    public @Nullable Set<class_2960> food;
    public @Nullable class_2960 offspring;
    public int ambientSoundInterval = 80;
    public int xpReward = 5;
    public boolean isSunSensitive = false;
    public boolean canPickupLoot = false;
    public boolean shouldDespawnInPeaceful = true;
    public boolean invulnerable = false;
    public boolean fireImmune = false;
    public boolean noPhysics = false;
    public boolean noSave = false;
    public boolean noSummon = false;
    public boolean canUsePortal = false;
    public boolean canBeLeashed = false;
    public boolean despawnWhenFarAway = false;
    public boolean forceEnemy = false;

    public record FallSounds(class_2960 small, class_2960 big) {

    }
    public record Sounds(class_2960 ambient, class_2960 swim, class_2960 swimSplash, class_2960 hurt, class_2960 death, FallSounds fall) {

    }
}

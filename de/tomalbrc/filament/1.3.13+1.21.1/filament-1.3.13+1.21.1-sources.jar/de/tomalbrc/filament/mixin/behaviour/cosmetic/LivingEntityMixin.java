package de.tomalbrc.filament.mixin.behaviour.cosmetic;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentCosmeticEvents;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.cosmetic.AnimatedCosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticHolder;
import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.cosmetic.CosmeticUtil;
import de.tomalbrc.filament.registry.FilamentComponents;
import de.tomalbrc.filament.registry.ModelRegistry;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import eu.pb4.polymer.virtualentity.impl.EntityExt;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_9274;

@Mixin(value = class_1309.class)
public abstract class LivingEntityMixin implements CosmeticInterface {
    @Shadow public abstract class_1799 getItemBySlot(class_1304 equipmentSlot);

    @Shadow public abstract class_1304 getEquipmentSlotForItem(class_1799 itemStack);

    @Unique
    private final Map<String, ElementHolder> filamentCosmeticHolder = new Object2ObjectOpenHashMap<>();

    @Unique
    private double filamentPrevX = 0;
    @Unique
    private double filamentPrevZ = 0;
    @Unique
    private double filamentBodyYaw;

    @Unique
    boolean filamentEquipAfterLoad = true;

    // COSMETIC, ARMOR, ELYTRA
    @Inject(method = "getEquipmentSlotForItem", at = @At(value = "HEAD"), cancellable = true)
    private void filament$customGetEquipmentSlotForItem(class_1799 itemStack, CallbackInfoReturnable<class_1304> cir) {
        if (itemStack.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var wrapped = itemStack.method_57824(FilamentComponents.SKIN_DATA_COMPONENT);
            var es = getEquipmentSlotForItem(wrapped);
            if (es != class_1304.field_6173) {
                cir.setReturnValue(es);
                return;
            }
        }

        Cosmetic.Config cosmetic = CosmeticUtil.getCosmeticData(itemStack);
        if (cosmetic != null) {
            cir.setReturnValue(cosmetic.slot);
        }
    }

    @Inject(method = "onEquipItem", at = @At(value = "HEAD"))
    private void filament$customOnEquipItem(class_1304 equipmentSlot, class_1799 oldItemStack, class_1799 newItemStack, CallbackInfo ci) {
        if (equipmentSlot == class_1304.field_6169 || equipmentSlot == class_1304.field_6171 || equipmentSlot == class_1304.field_6173) {
            return;
        }

        if (CosmeticUtil.isCosmetic(oldItemStack)) {
            var slot = this.getEquipmentSlotForItem(oldItemStack);
            if (slot == equipmentSlot) {
                filament$destroyHolder(slot.method_5923());
                FilamentCosmeticEvents.UNEQUIPPED.invoker().onChange(class_1309.class.cast(this), oldItemStack, newItemStack);
            }
        }

        // hotswap case
        {
            if (oldItemStack.method_7960() && !CosmeticUtil.isCosmetic(this.getItemBySlot(this.getEquipmentSlotForItem(newItemStack)))) {
                var slot = this.getEquipmentSlotForItem(newItemStack);
                if (slot.method_46643()) {
                    filament$destroyHolder(slot.method_5923());
                    FilamentCosmeticEvents.UNEQUIPPED.invoker().onChange(class_1309.class.cast(this), oldItemStack, newItemStack);
                }
            }
        }

        if (CosmeticUtil.isCosmetic(newItemStack)) {
            var slot = this.getEquipmentSlotForItem(newItemStack);
            if (slot == equipmentSlot || oldItemStack.method_7960()) {
                filament$destroyHolder(slot.method_5923());
                FilamentCosmeticEvents.UNEQUIPPED.invoker().onChange(class_1309.class.cast(this), oldItemStack, newItemStack);
                filament$addHolder(class_1309.class.cast(this), newItemStack.method_7909(), newItemStack, slot.method_5923());
                FilamentCosmeticEvents.EQUIPPED.invoker().onChange(class_1309.class.cast(this), oldItemStack, newItemStack);
            }
        }
    }

    @Inject(method = "remove", at = @At(value = "HEAD"))
    private void filament$onRemove(class_1297.class_5529 removalReason, CallbackInfo ci) {
        var self = class_1309.class.cast(this);
        for(class_1304 equipmentSlot : class_1304.values()) {
            if (!class_9274.field_49224.method_57286(equipmentSlot))
                continue;


            class_1799 itemStack = this.getItemBySlot(equipmentSlot);
            if (CosmeticUtil.isCosmetic(itemStack)) {
                filament$destroyHolder(self.method_32326(itemStack).method_5923());
                FilamentCosmeticEvents.UNEQUIPPED.invoker().onChange(class_1309.class.cast(this), itemStack, class_1799.field_8037);
            }
        }
    }

    @Unique
    @Override
    public void filament$addHolder(class_1309 livingEntity, class_1792 simpleItem, class_1799 itemStack, String slot) {
        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(itemStack);

        ElementHolder holder = null;

        if (cosmeticData.model != null && !filamentCosmeticHolder.containsKey(slot)) {
            holder = new AnimatedCosmeticHolder(livingEntity, ModelRegistry.getModel(cosmeticData.model));
        }
        else if (!filamentCosmeticHolder.containsKey(slot)) {
            holder = new CosmeticHolder(livingEntity, itemStack);
        }

        if (holder == null) {
            Filament.LOGGER.error("Could not create cosmetic holder");
            return;
        }

        EntityAttachment.ofTicking(holder, livingEntity);

        if (livingEntity instanceof class_3222 serverPlayer)
            holder.startWatching(serverPlayer);

        VirtualEntityUtils.addVirtualPassenger(livingEntity, holder.getEntityIds().toIntArray());

        var packet = VirtualEntityUtils.createRidePacket(livingEntity.method_5628(), ((EntityExt)livingEntity).polymerVE$getVirtualRidden());
        if (livingEntity instanceof class_3222 serverPlayer)
            serverPlayer.field_13987.method_14364(packet);

        if (cosmeticData.autoplay != null && holder instanceof AnimatedCosmeticHolder animatedHolder) {
            animatedHolder.getAnimator().playAnimation(cosmeticData.autoplay);
        }

        filamentCosmeticHolder.put(slot, holder);
    }

    @Unique
    @Override
    public void filament$destroyHolder(String slot) {
        if (filamentCosmeticHolder.containsKey(slot)) {
            var holder = filamentCosmeticHolder.get(slot);

            VirtualEntityUtils.removeVirtualPassenger(class_1309.class.cast(this), holder.getEntityIds().toIntArray());

            var attachment = filamentCosmeticHolder.get(slot).getAttachment();
            if (attachment != null) {
                attachment.destroy();
            }
            filamentCosmeticHolder.get(slot).destroy();
            filamentCosmeticHolder.remove(slot);
        }
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void rotationTick(CallbackInfo ci) {
        var self = class_1309.class.cast(this);
        var isPlayer = (self instanceof class_1657);

        if (filamentEquipAfterLoad && !isPlayer) {
            for (class_1304 slot : class_1304.values()) {
                if (!class_9274.field_49224.method_57286(slot))
                    continue;

                var stack = this.getItemBySlot(slot);
                if (CosmeticUtil.isCosmetic(stack) && slot != class_1304.field_6169) {
                    filament$addHolder(self, stack.method_7909(), stack, slot.method_5923());
                    FilamentCosmeticEvents.EQUIPPED.invoker().onChange(class_1309.class.cast(this), class_1799.field_8037, stack);
                }
            }
            filamentEquipAfterLoad = false;
        }

        if (!filamentCosmeticHolder.isEmpty() && (filamentPrevX != 0 && filamentPrevZ != 0) && isPlayer)
            filament$tickMovement(self);
        else
            this.filamentBodyYaw = self.field_6283;

        filamentPrevX = self.method_23317();
        filamentPrevZ = self.method_23321();
    }

    @Unique
    private void filament$tickMovement(final class_1309 entity) {
        double yaw = entity.method_36454();
        double i = entity.method_23317() - this.filamentPrevX;
        double d = entity.method_23321() - this.filamentPrevZ;
        double f = (float)(i * i + d * d);
        double g = this.filamentBodyYaw;
        if (f > 0.0025) {
            double l = Math.atan2(d, i) * (double)class_3532.field_29848 - 90.;
            double m = Math.abs(class_3532.method_15338(yaw) - l);
            if (95. < m && m < 265.) {
                g = l - 180.;
            } else {
                g = l;
            }
        }

        this.filament$turnBody(g, yaw);
    }

    @Unique
    public void filament$turnBody(double bodyRotation, double yaw) {
        double f = class_3532.method_15338(bodyRotation - this.filamentBodyYaw);
        this.filamentBodyYaw += f * 0.3F;
        double g = class_3532.method_15338(yaw - this.filamentBodyYaw);
        if (g < -75.) {
            g = -75.;
        }

        if (g >= 75.) {
            g = 75.;
        }

        this.filamentBodyYaw = yaw - g;
        if (g * g > 2500.) { // > 50°
            this.filamentBodyYaw += g * 0.25;
        }
    }

    @Override
    @Unique
    public float filament$bodyYaw() {
        return (float) filamentBodyYaw;
    }
}

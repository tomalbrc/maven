package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.item.FilamentItem;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_9335;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1799.class)
public class ItemStackMixin {
    @Inject(method = "<init>(Lnet/minecraft/world/level/ItemLike;ILnet/minecraft/core/component/PatchedDataComponentMap;)V", at = @At("TAIL"))
    private void filament$val(class_1935 item, int count, class_9335 components, CallbackInfo ci) {
        if (item instanceof FilamentItem filamentItem) {
            filamentItem.verifyComponentsAfterLoad((class_1799)((Object) this));
        }
    }
}

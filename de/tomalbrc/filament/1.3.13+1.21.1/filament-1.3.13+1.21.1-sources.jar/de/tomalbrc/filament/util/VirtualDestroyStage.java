package de.tomalbrc.filament.util;

import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.BlockBoundAttachment;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_9280;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class VirtualDestroyStage extends ElementHolder {
    public static final class_1799[] DESTROY_STAGE_MODELS = new class_1799[10];
    private final List<ItemDisplayElement> destroyElements = new ObjectArrayList<>();
    private int state;

    public static void init() {
        PolymerBlockUtils.BREAKING_PROGRESS_UPDATE.register(VirtualDestroyStage::updateState);
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (state.method_26204() instanceof DecorationBlock && !world.method_8608()) {
                ((VirtualDestroyStage.ServerGamePacketListenerExtF) ((class_3222) player).field_13987).filament$getVirtualDestroyStage().setState(-1);
            }
        });
        VirtualDestroyStage.destroy(null);
    }

    public VirtualDestroyStage() {
        for (int i = 0; i < 32; i++) {
            var element = new ItemDisplayElement();
            element.setInvisible(true);
            element.setItem(DESTROY_STAGE_MODELS[0]);
            element.setScale(new Vector3f(1.01f));
            this.destroyElements.add(element);
        }
    }

    private List<ItemDisplayElement> destroyElements() {
        return this.destroyElements;
    }

    @Override
    public void destroy() {
        this.destroyElements.forEach(this::removeElement);
        super.destroy();
    }

    public void setState(int i) {
        if (this.state == i) {
            return;
        }

        this.state = i;
        this.destroyElements.forEach(x -> x.setItem(i < 0 ? class_1799.field_8037 : DESTROY_STAGE_MODELS[Math.min(i, DESTROY_STAGE_MODELS.length - 1)]));
        this.tick();
    }

    public static void updateState(class_3222 player, class_2338 pos, class_2680 state, int i) {
        final VirtualDestroyStage self = ((ServerGamePacketListenerExtF) player.field_13987).filament$getVirtualDestroyStage();

        if (i == -1 || (!(state.method_26204() instanceof Marker && (state.method_26204() instanceof DecorationBlock decorationBlock && decorationBlock.getDecorationData().hasBlocks())))) {
            self.setState(-1);
            if (self.getAttachment() != null) {
                self.destroy();
            }
            return;
        }

        var vecPos = class_243.method_24953(pos);

        if (self.getAttachment() == null || !self.getAttachment().getPos().equals(vecPos)) {
            // init display list
            BlockBoundAttachment.of(self, player.method_51469(), vecPos);
            self.destroyElements().getFirst().setTranslation(new Vector3f());

            if (state.method_26204() instanceof DecorationBlock decorationBlock1 && decorationBlock1.getDecorationData().hasBlocks()) {
                for (int i1 = 0; i1 < decorationBlock1.getDecorationData().countBlocks(); i1++) {
                    self.addElement(self.destroyElements().get(i1));
                }

                class_2586 blockEntity = player.method_37908().method_8321(pos);
                if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
                    final AtomicInteger index = new AtomicInteger();
                    final DecorationBlockEntity finalDecorationBlockEntity = decorationBlockEntity.isMain() ? decorationBlockEntity : decorationBlockEntity.getMainBlockEntity();
                    if (finalDecorationBlockEntity != null) {
                        DecorationUtil.forEachRotated(finalDecorationBlockEntity.getDecorationData().blocks(), finalDecorationBlockEntity.method_11016(), finalDecorationBlockEntity.getVisualRotationYInDegrees(), rotPos -> {
                            class_2338 op = rotPos.method_10059(pos);
                            self.destroyElements.get(index.getAndIncrement()).setTranslation(new Vector3f(op.method_10263(), op.method_10264(), op.method_10260()));
                        });
                    }
                }
            }
        }

        self.setState(i);

    }

    public static void destroy(@Nullable class_3222 player) {
        if (player != null && !player.method_14239()) {
            ((ServerGamePacketListenerExtF) player.field_13987).filament$getVirtualDestroyStage().destroy();
        }
    }

    static {
        for (int i = 0; i < DESTROY_STAGE_MODELS.length; i++) {
            class_1799 stack = class_1802.field_8600.method_7854();
            stack.method_57379(class_9334.field_49637, new class_9280(PolymerResourcePackUtils.requestModel(stack.method_7909(), class_2960.method_60655(Constants.MOD_ID, "item/special/destroy_stage_" + i)).value()));
            DESTROY_STAGE_MODELS[i] = stack;
        }

        var model =  """
                {
                  "parent": "minecraft:block/cube_all",
                  "textures": {
                    "all": "minecraft:block/destroy_stage_|ID|"
                  }
                }
                """;

        var itemModel =  """
                {
                  "model": {
                    "type": "minecraft:model",
                    "model": "filament:item/special/destroy_stage_|ID|"
                  }
                }
                """;

        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(x -> {
            for (var i = 0; i < DESTROY_STAGE_MODELS.length; i++) {
                x.addData("assets/filament/models/item/special/destroy_stage_" + i + ".json", model.replace("|ID|", "" + i).getBytes(StandardCharsets.UTF_8));
                //x.addData("assets/filament/items/special/destroy_stage_" + i + ".json", itemModel.replace("|ID|", "" + i).getBytes(StandardCharsets.UTF_8));
            }
        });
    }

    public interface Marker {}

    public interface ServerGamePacketListenerExtF {
        VirtualDestroyStage filament$getVirtualDestroyStage();
    }
}
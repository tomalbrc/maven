package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.mixin.accessor.ItemInvoker;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;

/**
 * Item behaviour to enable place action on water
 */
public class PlaceOnWater implements ItemBehaviour<PlaceOnWater.Config> {
    private final Config config;

    public PlaceOnWater(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public PlaceOnWater.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_3965 blockHitResult = ItemInvoker.invokeGetPlayerPOVHitResult(level, player, class_3959.class_242.field_1345);
        class_3965 blockHitResult2 = blockHitResult.method_29328(blockHitResult.method_17777().method_10084());
        if (item instanceof class_1747 blockItem) {
            var c = blockItem.method_7884(new class_1838(player, interactionHand, blockHitResult2));
            return new class_1271<>(c, player.method_5998(interactionHand));
        }

        return class_1271.method_22430(player.method_5998(interactionHand));
    }

    public static class Config {
    }
}
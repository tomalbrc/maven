package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.util.ExecuteUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_6088;
import net.minecraft.class_9463;

/**
 * Item behaviour for simple snowball shooting
 */
public class Snowball implements ItemBehaviour<Snowball.Config> {
    private final Config config;

    public Snowball(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Snowball.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, BehaviourHolder behaviourHolder) {
        ItemBehaviour.super.init(item, behaviourHolder);
        if (config.dispenserSupport) class_2315.method_10009(item, new SnowballDispenseBehavior(item, class_9463.class_9464.field_50147));
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_14873, class_3419.field_15254, 0.5F, 0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F));
        if (!level.field_9236) {
            net.minecraft.class_1680 snowball = new net.minecraft.class_1680(level, player);
            snowball.method_16940(itemStack);
            snowball.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, config.power, config.inaccuracy);
            level.method_8649(snowball);
        }

        player.method_7259(class_3468.field_15372.method_14956(item));
        itemStack.method_57008(1, player);
        return class_1271.method_29237(itemStack, level.method_8608());
    }

    public class_1676 asProjectile(class_1937 level, class_2374 pos, class_1799 stack, class_2350 direction) {
        var sb = new net.minecraft.class_1680(level, pos.method_10216(), pos.method_10214(), pos.method_10215());
        sb.method_16940(stack);
        return sb;
    }

    public List<String> commands() {
        return config.hitCommands == null ? this.config.hitCommand == null ? null : List.of(this.config.hitCommand) : config.hitCommands;
    }

    public List<String> entityHitCommands() {
        return config.entityHitCommands == null ? this.config.entityHitCommand == null ? null : List.of(this.config.entityHitCommand) : config.entityHitCommands;
    }

    public void run(net.minecraft.class_1680 snowball, class_243 pos) {
        if (config.hitCommand == null && config.hitCommands == null)
            return;

        var owner = snowball.method_24921();
        if (owner instanceof class_3222 serverPlayer) {
            var cmd = commands();
            if (cmd != null)
                ExecuteUtil.asPlayer(serverPlayer, config.executeAtHit ? pos : null, cmd.toArray(new String[0]));
        }
    }

    public void runEntity(net.minecraft.class_1680 snowball, class_243 pos, class_1297 entity) {
        if (config.entityHitCommand == null && config.entityHitCommands == null && config.hitCommand == null && config.hitCommands == null)
            return;

        var owner = snowball.method_24921();
        if (owner instanceof class_3222 serverPlayer) {
            var cmd = commands();
            var hitCmd = entityHitCommands();

            if (hitCmd == null) {
                hitCmd = cmd;
            }

            if (hitCmd == null)
                return;

            for (int i = 0; i < hitCmd.size(); i++) {
                hitCmd.set(i, hitCmd.get(i).replace("%target%", entity.method_5845()));
            }

            ExecuteUtil.asPlayer(serverPlayer, config.executeAtHit ? pos : null, hitCmd.toArray(new String[0]));
        }
    }

    public static class Config {
        public float inaccuracy = 1.f;
        public float power = 1.5f;

        public boolean dispenserSupport = false;

        public String hitCommand;
        public List<String> hitCommands;

        public String entityHitCommand;
        public List<String> entityHitCommands;

        public boolean executeAtHit = true;
    }

    public static class SnowballDispenseBehavior extends class_2347 {
        private final SimpleItem projectileItem;
        private final class_9463.class_9464 dispenseConfig;

        public SnowballDispenseBehavior(class_1792 projectileItem, class_9463.class_9464 dispenseConfig) {
            this.projectileItem = (SimpleItem)projectileItem;
            this.dispenseConfig = dispenseConfig;
        }

        @Override
        public @NotNull class_1799 method_10135(class_2342 blockSource, class_1799 itemStack) {
            class_1937 level = blockSource.comp_1967();
            class_2350 direction = blockSource.comp_1969().method_11654(class_2315.field_10918);
            class_2374 position = this.dispenseConfig.comp_2544().getDispensePosition(blockSource, direction);
            class_1676 projectile = this.projectileItem.getOrThrow(Behaviours.SNOWBALL).asProjectile(level, position, itemStack, direction);
            projectile.method_7485(direction.method_10148(), direction.method_10164(), direction.method_10165(), this.dispenseConfig.comp_2546(), this.dispenseConfig.comp_2545());
            level.method_8649(projectile);
            itemStack.method_7934(1);
            return itemStack;
        }

        @Override
        protected void method_10136(class_2342 blockSource) {
            blockSource.comp_1967().method_20290(this.dispenseConfig.comp_2547().orElse(class_6088.field_31160), blockSource.comp_1968(), 0);
        }
    }
}

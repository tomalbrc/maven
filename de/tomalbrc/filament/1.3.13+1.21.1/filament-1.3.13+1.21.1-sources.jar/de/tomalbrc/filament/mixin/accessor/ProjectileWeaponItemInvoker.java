package de.tomalbrc.filament.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1811;

@Mixin(class_1811.class)
public interface ProjectileWeaponItemInvoker {
    @Invoker
    static List<class_1799> invokeDraw(class_1799 itemStack, class_1799 itemStack2, class_1309 livingEntity) {
        throw new AssertionError();
    }
}

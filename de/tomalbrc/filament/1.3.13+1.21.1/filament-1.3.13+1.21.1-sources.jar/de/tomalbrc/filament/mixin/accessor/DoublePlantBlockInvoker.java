package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2320;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2320.class)
public interface DoublePlantBlockInvoker {
    @Invoker
    static void invokePreventDropFromBottomPart(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        throw new AssertionError();
    }
}

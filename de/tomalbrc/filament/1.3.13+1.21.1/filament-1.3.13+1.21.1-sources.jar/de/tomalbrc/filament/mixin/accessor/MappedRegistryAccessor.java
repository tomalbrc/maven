package de.tomalbrc.filament.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_6862;
import net.minecraft.class_6885;

@Mixin(class_2370.class)
public interface MappedRegistryAccessor<T> {
    @Accessor
    Map<class_6862<T>, class_6885.class_6888<T>> getTags();
}

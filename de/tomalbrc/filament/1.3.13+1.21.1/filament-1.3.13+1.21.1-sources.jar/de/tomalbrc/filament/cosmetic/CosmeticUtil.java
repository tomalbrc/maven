package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.item.FilamentItem;
import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_1799;

public class CosmeticUtil {
    public static boolean isCosmetic(class_1799 itemStack) {
        return getCosmeticData(itemStack) != null;
    }

    public static Cosmetic.Config getCosmeticData(class_1799 item) {
        Cosmetic.Config cosmeticData = null;
        if (item.method_7909() instanceof FilamentItem filamentItem && filamentItem.has(Behaviours.COSMETIC)) {
            cosmeticData = filamentItem.get(Behaviours.COSMETIC).getConfig();
        }
        if (item.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var wrapped = item.method_57824(FilamentComponents.SKIN_DATA_COMPONENT);
            if (wrapped != null && wrapped.method_7909() instanceof FilamentItem wrappedItem && wrappedItem.has(Behaviours.COSMETIC)) {
                cosmeticData = wrappedItem.get(Behaviours.COSMETIC).getConfig();
            }
        }
        return cosmeticData;
    }
}

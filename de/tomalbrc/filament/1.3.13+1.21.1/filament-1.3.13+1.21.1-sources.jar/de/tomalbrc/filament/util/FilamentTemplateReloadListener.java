package de.tomalbrc.filament.util;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.registry.Templates;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

public class FilamentTemplateReloadListener implements FilamentSynchronousResourceReloadListener {
    @Override
    public class_2960 getFabricId() {
        return class_2960.method_60655(Constants.MOD_ID, "template");
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        load("filament/template", null, resourceManager, (id, inputStream) -> {
            try {
                Templates.add(inputStream);
            } catch (Exception e) {
                Filament.LOGGER.error("Failed to load template \"{}\".", id, e);
            }
        });
    }
}
package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_5712;
import net.minecraft.class_5953;
import net.minecraft.class_6088;
import org.jetbrains.annotations.NotNull;

public class Wax implements ItemBehaviour<Wax.Config> {
    private final Config config;

    public Wax(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Wax.Config getConfig() {
        return config;
    }

    @Override
    public class_1269 useOn(class_1838 useOnContext) {
        class_1937 level = useOnContext.method_8045();
        class_2338 blockPos = useOnContext.method_8037();
        class_2680 blockState = level.method_8320(blockPos);
        return class_5953.method_34720(blockState).map((blockStatex) -> {
            class_1657 player = useOnContext.method_8036();
            class_1799 itemStack = useOnContext.method_8041();
            if (player instanceof class_3222 serverPlayer) {
                class_174.field_24478.method_23889(serverPlayer, blockPos, itemStack);
            }

            if (config.reduceDurability && player != null)
                itemStack.method_7970(1, player, class_1309.method_56079(useOnContext.method_20287()));
            else itemStack.method_7934(1);

            level.method_8652(blockPos, blockStatex,  class_2248.field_31022);
            level.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(player, blockStatex));
            level.method_8444(player,  class_6088.field_31156, blockPos, 0);
            return (class_1269) class_1269.field_5812;
        }).orElse(class_1269.field_5811);
    }

    public static class Config {
        public boolean reduceDurability = false;
    }
}

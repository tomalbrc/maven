package de.tomalbrc.filament.util;

import com.google.common.reflect.TypeToken;
import com.google.gson.*;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.BehaviourList;
import de.tomalbrc.filament.behaviour.decoration.Showcase;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.data.properties.RangedValue;
import de.tomalbrc.filament.data.properties.RangedVector3f;
import de.tomalbrc.filament.data.resource.BlockResource;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.yaml.snakeyaml.Yaml;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1267;
import net.minecraft.class_1304;
import net.minecraft.class_1311;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_3619;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5699;
import net.minecraft.class_5955;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import net.minecraft.class_9323;

public class Json {
    public static Codec<Vector2f> VECTOR2F = Codec.FLOAT.listOf().comapFlatMap((list) -> class_156.method_33141(list, 2).map((listx) -> new Vector2f(listx.get(0), listx.get(1))), (vector2f) -> List.of(vector2f.x(), vector2f.y()));

    public static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
            .registerTypeHierarchyAdapter(class_2680.class, new BlockStateDeserializer())
            .registerTypeHierarchyAdapter(Vector3f.class, new SimpleCodecDeserializer<>(class_5699.field_40723))
            .registerTypeHierarchyAdapter(Vector2f.class, new SimpleCodecDeserializer<>(VECTOR2F))
            .registerTypeHierarchyAdapter(Quaternionf.class, new QuaternionfDeserializer())
            .registerTypeAdapter(class_2960.class, new SimpleCodecDeserializer<>(class_2960.field_25139))
            .registerTypeHierarchyAdapter(class_2561.class, new ComponentDeserializer())
            .registerTypeHierarchyAdapter(class_9323.class, new DataComponentsDeserializer())
            .registerTypeHierarchyAdapter(class_8113.class_8114.class, new SimpleCodecDeserializer<>(class_8113.class_8114.field_42410))
            .registerTypeHierarchyAdapter(class_1304.class, new SimpleCodecDeserializer<>(class_1304.field_45739))
            .registerTypeHierarchyAdapter(BlockModelType.class, new LowercaseEnumDeserializer<>(BlockModelType.class))
            .registerTypeHierarchyAdapter(class_1267.class, new SimpleCodecDeserializer<>(class_1267.field_41668))
            .registerTypeHierarchyAdapter(class_1311.class, new SimpleCodecDeserializer<>(class_1311.field_24655))
            .registerTypeHierarchyAdapter(class_811.class, new SimpleCodecDeserializer<>(class_811.field_42468))
            .registerTypeHierarchyAdapter(class_3619.class, new LowercaseEnumDeserializer<>(class_3619.class))
            .registerTypeHierarchyAdapter(class_5955.class_5811.class, new SimpleCodecDeserializer<>(class_5955.class_5811.field_46493))
            .registerTypeHierarchyAdapter(RangedValue.class, new SimpleCodecDeserializer<>(RangedValue.CODEC))
            .registerTypeHierarchyAdapter(RangedVector3f.class, new SimpleCodecDeserializer<>(RangedVector3f.CODEC))
            .registerTypeHierarchyAdapter(class_2248.class, new RegistryDeserializer<>(class_7923.field_41175))
            .registerTypeHierarchyAdapter(class_1792.class, new RegistryDeserializer<>(class_7923.field_41178))
            .registerTypeHierarchyAdapter(class_3414.class, new RegistryDeserializer<>(class_7923.field_41172))
            .registerTypeHierarchyAdapter(BehaviourConfigMap.class, new BehaviourConfigMap.Deserializer())
            .registerTypeHierarchyAdapter(BehaviourList.class, new BehaviourList.Deserializer())
            .registerTypeHierarchyAdapter(BlockStateMappedProperty.class, new BlockStateMappedPropertyDeserializer<>())
            .registerTypeHierarchyAdapter(PolymerBlockModel.class, new PolymerBlockModelDeserializer())
            .registerTypeHierarchyAdapter(BlockResource.TextureBlockModel.class, new TextureBlockModelDeserializer())
            // special case to support old format
            // TODO: allow behaviours to specify codec/deserializer
            .registerTypeHierarchyAdapter(Showcase.Config.class, new Showcase.Config.ConfigDeserializer())

            .create();

    public static List<InputStream> yamlToJson(InputStream inputStream) {
        Yaml yaml = new Yaml();
        var documents = yaml.loadAll(inputStream);
        List<InputStream> list = new ObjectArrayList<>();
        for (Object document : documents) {
            if (document instanceof Map) {
                @SuppressWarnings("unchecked")
                var documentMap = (Map<String, Object>) document;
                document = Json.camelToSnakeCase(documentMap);
            }
            String jsonString = Json.GSON.toJson(document);
            InputStream stream = new ByteArrayInputStream(jsonString.getBytes(StandardCharsets.UTF_8));
            list.add(stream);
        }
        return list;
    }


    public static InputStream camelToSnakeCase(InputStream inputStream) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
        var json = JsonParser.parseReader(new InputStreamReader(inputStream));
        InputStream stream;
        if (json.isJsonObject()) {
            Type mapType = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> document = gson.fromJson(json, mapType);
            if (document != null) {
                document = Json.camelToSnakeCase(document);
            }
            stream = new ByteArrayInputStream(gson.toJson(document).getBytes(StandardCharsets.UTF_8));
        } else {
            stream = new ByteArrayInputStream(gson.toJson(json).getBytes(StandardCharsets.UTF_8));
        }

        return stream;
    }

    public static Map<String, Object> camelToSnakeCase(Map<String, Object> map) {
        Map<String, Object> result = new HashMap<>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = camelToSnakeCaseKey(entry.getKey());
            Object value = entry.getValue();
            if (value instanceof Map<?, ?> map1) {
                @SuppressWarnings("unchecked")
                Map<String, Object> nestedMap = (Map<String, Object>) map1;
                value = camelToSnakeCase(nestedMap);
            }
            result.put(key, value);
        }
        return result;
    }

    @NotNull
    private static String camelToSnakeCaseKey(String key) {
        StringBuilder snakeCase = new StringBuilder();
        for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);
            if (Character.isUpperCase(c) && i > 0) {
                snakeCase.append('_');
            }
            snakeCase.append(Character.toLowerCase(c));
        }
        return snakeCase.toString();
    }

    public static class BlockStateMappedPropertyDeserializer<T> implements JsonDeserializer<BlockStateMappedProperty<T>> {
        @Override
        public BlockStateMappedProperty<T> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonPrimitive()) {
                JsonPrimitive primitive = json.getAsJsonPrimitive();
                Type propertyType = ((ParameterizedType) typeOfT).getActualTypeArguments()[0];
                T t = context.deserialize(primitive, propertyType);
                return new BlockStateMappedProperty<>(t);
            } else if (json.isJsonObject()) {
                ParameterizedType mapType = getParameterizedType((ParameterizedType) typeOfT);
                Map<String, T> map = context.deserialize(json, mapType);
                return new BlockStateMappedProperty<>(map);
            }

            throw new JsonParseException("Invalid format for MappedProperty");
        }

        @NotNull
        private static ParameterizedType getParameterizedType(ParameterizedType typeOfT) {
            Type propertyType = typeOfT.getActualTypeArguments()[0];
            return new ParameterizedType() {
                @Override
                public Type @NotNull [] getActualTypeArguments() {
                    return new Type[]{String.class, propertyType};
                }

                @Override
                @NotNull
                public Type getRawType() {
                    return Map.class;
                }

                @Override
                public Type getOwnerType() {
                    return null;
                }
            };
        }
    }

    public static class BlockStateDeserializer implements JsonDeserializer<class_2680> {
        @Override
        public class_2680 deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String name = json.getAsString().toLowerCase();

            class_2259.class_7211 parsed;
            try {
                parsed = class_2259.method_41957(class_7923.field_41175.method_46771(), name, false);
            } catch (CommandSyntaxException e) {
                throw new JsonParseException("Invalid BlockState value: " + name);
            }

            return parsed.comp_622();
        }
    }

    public static class LowercaseEnumDeserializer<T extends Enum<T>> implements JsonDeserializer<T> {

        private final Class<T> enumClass;

        public LowercaseEnumDeserializer(Class<T> enumClass) {
            this.enumClass = enumClass;
        }

        @Override
        public T deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String value = json.getAsString().toLowerCase();
            for (T constant : enumClass.getEnumConstants()) {
                if (constant.name().equalsIgnoreCase(value)) {
                    return constant;
                }
            }

            throw new JsonParseException("Invalid " + enumClass.getSimpleName() + " value: " + value);
        }
    }

    public static class PolymerBlockModelDeserializer implements JsonDeserializer<PolymerBlockModel> {
        @Override
        public PolymerBlockModel deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonPrimitive()) {
                JsonPrimitive primitive = json.getAsJsonPrimitive();
                if (primitive.isString()) {
                    return PolymerBlockModel.of(class_2960.method_12829(primitive.getAsString()));
                }
            } else if (json.isJsonObject()) {
                JsonObject object = json.getAsJsonObject();
                class_2960 model = class_2960.method_60654(object.get("model").getAsString());
                int x = object.has("x") ? object.get("x").getAsInt() : 0;
                int y = object.has("y") ? object.get("y").getAsInt() : 0;
                boolean uvLock = object.has("uvLock") && object.get("uvLock").getAsBoolean();
                int weight = object.has("weight") ? object.get("weight").getAsInt() : 1;
                return PolymerBlockModel.of(model, x, y, uvLock, weight);
            }

            throw new JsonParseException("Invalid PolymerBlockModel value: " + json);
        }
    }

    public static class TextureBlockModelDeserializer implements JsonDeserializer<BlockResource.TextureBlockModel> {
        @Override
        public BlockResource.TextureBlockModel deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonObject()) {
                JsonObject object = json.getAsJsonObject();

                Map<String, class_2960> map;
                Type mapType = new TypeToken<Map<String, class_2960>>() {}.getType();
                if (object.has("textures")) {
                    map = context.deserialize(object.get("textures").getAsJsonObject(), mapType);
                } else {
                    map = context.deserialize(object, mapType);
                }

                int x = object.has("x") ? object.get("x").getAsInt() : 0;
                int y = object.has("y") ? object.get("y").getAsInt() : 0;
                boolean uvLock = object.has("uvLock") && object.get("uvLock").getAsBoolean();
                int weight = object.has("weight") ? object.get("weight").getAsInt() : 1;
                return new BlockResource.TextureBlockModel(map, x, y, uvLock, weight);
            }

            throw new JsonParseException("Invalid TextureBlockModel value: " + json);
        }
    }

    public static class QuaternionfDeserializer implements JsonDeserializer<Quaternionf> {
        @Override
        public Quaternionf deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonArray jsonArray = jsonElement.getAsJsonArray();

            if (jsonArray.size() < 3) {
                throw new JsonParseException("Array size should be at least 3 for euler angle deserialization.");
            }

            float x = jsonArray.get(0).getAsFloat();
            float y = jsonArray.get(1).getAsFloat();
            float z = jsonArray.get(2).getAsFloat();

            return new Quaternionf().rotateXYZ(x * class_3532.field_29847, y * class_3532.field_29847, z * class_3532.field_29847);
        }
    }

    private record RegistryDeserializer<T>(class_2378<T> registry) implements JsonDeserializer<T> {
        @Override
        public T deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            return this.registry.method_10223(class_2960.method_60654(element.getAsString()));
        }
    }

    private record ComponentDeserializer() implements JsonDeserializer<class_2561> {
        @Override
        public class_2561 deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            return TextUtil.formatText(element.getAsString());
        }
    }

    public static class DataComponentsDeserializer implements JsonDeserializer<class_9323> {
        @Override
        public class_9323 deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            class_6903.class_7863 registryInfoLookup = createContext(class_5455.method_40302(class_7923.field_41167));
            DataResult<Pair<class_9323, JsonElement>> result = class_9323.field_50234.decode(class_6903.method_40414(JsonOps.INSTANCE, registryInfoLookup), jsonElement);

            if (result.resultOrPartial().isEmpty()) {
                return null;
            }

            return result.resultOrPartial().get().getFirst();
        }

        public static class_6903.class_7863 createContext(class_5455 registryAccess) {
            final Map<class_5321<? extends class_2378<?>>, class_6903.class_7862<?>> map = new HashMap<>();
            registryAccess.method_40311().forEach((registryEntry) -> map.put(registryEntry.comp_350(), createInfoForContextRegistry(registryEntry.comp_351())));
            return new class_6903.class_7863() {
                public <T> Optional<class_6903.class_7862<T>> method_46623(class_5321<? extends class_2378<? extends T>> resourceKey) {
                    return Optional.ofNullable((class_6903.class_7862<T>)map.get(resourceKey));
                }
            };
        }

        private static <T> class_6903.class_7862<T> createInfoForContextRegistry(class_2378<T> registry) {
            return new class_6903.class_7862<>(registry.method_46771(), registry.method_46772(), registry.method_31138());
        }
    }
}

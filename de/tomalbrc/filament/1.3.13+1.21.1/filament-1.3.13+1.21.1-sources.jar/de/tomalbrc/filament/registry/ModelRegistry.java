package de.tomalbrc.filament.registry;

import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.file.loader.AjBlueprintLoader;
import de.tomalbrc.bil.file.loader.AjModelLoader;
import de.tomalbrc.bil.file.loader.BbModelLoader;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.FilamentSynchronousResourceReloadListener;
import it.unimi.dsi.fastutil.objects.Object2ReferenceArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceMap;
import org.apache.commons.io.FilenameUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

public class ModelRegistry {
    private static final String BBMODEL_SUFFIX = ".bbmodel";
    private static final String AJMODEL_SUFFIX = ".ajmodel";
    private static final String AJBP_SUFFIX = ".ajblueprint";

    private static final Object2ReferenceMap<class_2960, Model> ajmodels = new Object2ReferenceArrayMap<>();

    public static Model getModel(class_2960 model) {
        return ajmodels.get(model);
    }

    public static class AjModelReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "model");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/model", path -> path.method_12832().endsWith(".ajmodel") || path.method_12832().endsWith(".ajblueprint") || path.method_12832().endsWith(".bbmodel"));

            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
                try (var inputStream = entry.getValue().method_14482()) {
                    String path = entry.getKey().method_12832();
                    Model model;
                    if (path.endsWith(".ajmodel")) {
                        model = new AjModelLoader().load(inputStream, FilenameUtils.getBaseName(path));
                    } else if (path.endsWith(".ajblueprint")) {
                        model = new AjBlueprintLoader().load(inputStream, FilenameUtils.getBaseName(path));
                    } else {
                        model = new BbModelLoader().load(inputStream, FilenameUtils.getBaseName(path));
                    }

                    ajmodels.put(sanitize(entry.getKey()), model);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"{}\".", entry.getKey());
                }
            }

            Filament.LOGGER.info("filament models registered: {}", ajmodels.size());
        }
    }

    public static class_2960 sanitize(class_2960 resourceLocation) {
        String path = resourceLocation.method_12832();
        String customPath = path.substring(path.contains("/") ? path.lastIndexOf('/')+1 : 0, path.lastIndexOf('.'));
        return class_2960.method_60655(resourceLocation.method_12836(), customPath);
    }

    public static void registerAjModel(InputStream inputStream, class_2960 resourceLocation) throws IOException {
        ajmodels.put(sanitize(resourceLocation), new AjModelLoader().load(inputStream, resourceLocation.method_12832()));
    }

    public static void registerBbModel(InputStream inputStream, class_2960 resourceLocation) throws IOException {
        ajmodels.put(sanitize(resourceLocation), new BbModelLoader().load(inputStream, resourceLocation.method_12832()));
    }

    public static void registerAjBlueprintModel(InputStream inputStream, class_2960 resourceLocation) throws IOException {
        ajmodels.put(sanitize(resourceLocation), new AjBlueprintLoader().load(inputStream, resourceLocation.method_12832()));
    }
}

package de.tomalbrc.filament.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public class FilamentCosmeticEvents {
    public static final Event<CosmeticEquipmentChange> EQUIPPED = EventFactory.createArrayBacked(CosmeticEquipmentChange.class, (callbacks) -> (entity, itemStack, itemStack2) -> {
        for (CosmeticEquipmentChange callback : callbacks) {
            callback.onChange(entity, itemStack, itemStack2);
        }
    });

    public static final Event<CosmeticEquipmentChange> UNEQUIPPED = EventFactory.createArrayBacked(CosmeticEquipmentChange.class, (callbacks) -> (entity, itemStack, itemStack2) -> {
        for (CosmeticEquipmentChange callback : callbacks) {
            callback.onChange(entity, itemStack, itemStack2);
        }
    });

    @FunctionalInterface
    public interface CosmeticEquipmentChange {
        void onChange(class_1309 entity, class_1799 itemStack, class_1799 itemStack2);
    }
}

package de.tomalbrc.filament.api.behaviour;

import net.minecraft.class_2680;

public interface DecorationRotationProvider {
    float getVisualRotationYInDegrees(class_2680 blockState);
}

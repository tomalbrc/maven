package de.tomalbrc.filament.datafixer.schema;

import com.google.common.collect.Maps;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.templates.TypeTemplate;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1208;
import net.minecraft.class_1220;

public class Version1 extends class_1220 {
	public Version1(int versionKey, Schema parent) {
		super(versionKey, parent);
	}

	@Override
	public void registerTypes(Schema schema, Map<String, Supplier<TypeTemplate>> entityTypes, Map<String, Supplier<TypeTemplate>> blockEntityTypes) {
		schema.registerType(true, class_1208.field_5726, () -> DSL.remainderType().template());
	}

	@Override
	public Map<String, Supplier<TypeTemplate>> registerEntities(Schema schema) {
        return Maps.newHashMap();
	}

	@Override
	public Map<String, Supplier<TypeTemplate>> registerBlockEntities(Schema schema) {
        return Maps.newHashMap();
	}

}
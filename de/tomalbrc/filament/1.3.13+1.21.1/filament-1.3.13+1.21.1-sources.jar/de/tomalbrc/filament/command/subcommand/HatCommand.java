package de.tomalbrc.filament.command.subcommand;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class HatCommand {
    public static LiteralCommandNode<class_2168> register() {
        var hatNode = class_2170
                .method_9247("hat").requires(Permissions.require("filament.command.hat", 2));

        return hatNode.executes(HatCommand::execute).build();
    }

    private static int execute(CommandContext<class_2168> context) {
        var player = context.getSource().method_44023();
        if (player != null) {
            var handItem = player.method_5998(class_1268.field_5808);
            var headItem = player.method_6118(class_1304.field_6169);
            player.method_5673(class_1304.field_6169, handItem);
            player.method_6122(class_1268.field_5808, headItem);
        }
        return 0;
    }
}

package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1936;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2281.class)
public interface ChestBlockInvoker {
    @Invoker("isCatSittingOnChest")
    static boolean isCatSittingOnChest(class_1936 levelAccessor, class_2338 blockPos) {
        throw new AssertionError();
    }
}
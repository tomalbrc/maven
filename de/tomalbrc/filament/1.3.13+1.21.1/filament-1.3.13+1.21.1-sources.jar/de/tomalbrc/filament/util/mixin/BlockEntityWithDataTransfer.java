package de.tomalbrc.filament.util.mixin;

import net.minecraft.class_2487;

public interface BlockEntityWithDataTransfer {
    class_2487 getDataAndClear();

    void setData(class_2487 compoundTag);
}

package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.mixin.accessor.MaceItemAccessor;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2350;
import net.minecraft.class_2743;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_9362;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Mace-like behaviour
 */
public class Mace implements ItemBehaviour<Mace.Config> {
    private final Config config;

    public Mace(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Mace.Config getConfig() {
        return this.config;
    }

    @Override
    public boolean hurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        if (livingEntity2 instanceof class_3222 serverPlayer) {
            if (class_9362.method_58659(serverPlayer)) {
                class_3218 serverLevel = (class_3218) livingEntity2.method_37908();
                if (serverPlayer.method_61165() && serverPlayer.field_49989 != null) {
                    if (serverPlayer.field_49989.field_1351 > serverPlayer.method_19538().field_1351) {
                        serverPlayer.field_49989 = serverPlayer.method_19538();
                    }
                } else {
                    serverPlayer.field_49989 = serverPlayer.method_19538();
                }

                serverPlayer.method_60984(true);
                serverPlayer.method_18799(serverPlayer.method_18798().method_38499(class_2350.class_2351.field_11052, (double) 0.01F));
                serverPlayer.field_13987.method_14364(new class_2743(serverPlayer));
                if (livingEntity.method_24828()) {
                    serverPlayer.method_58143(true);
                    class_3414 soundEvent = serverPlayer.field_6017 > 5.0F ? class_3417.field_49924 : class_3417.field_49785;
                    serverLevel.method_43128(null, serverPlayer.method_23317(), serverPlayer.method_23318(), serverPlayer.method_23321(), soundEvent, serverPlayer.method_5634(), 1.0F, 1.0F);
                } else {
                    serverLevel.method_43128(null, serverPlayer.method_23317(), serverPlayer.method_23318(), serverPlayer.method_23321(), class_3417.field_49784, serverPlayer.method_5634(), 1.0F, 1.0F);
                }

                MaceItemAccessor.invokeKnockback(serverLevel, serverPlayer, livingEntity);
            }
        }

        return true;
    }


    @Override
    public void postHurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        itemStack.method_7970(1, livingEntity2, class_1304.field_6173);
        if (class_9362.method_58659(livingEntity2)) {
            livingEntity2.method_38785();
        }

    }

    @Override
    public float getAttackDamageBonus(class_1297 entity, float f, class_1282 damageSource) {
        class_1297 damageSourceDirectEntity = damageSource.method_5526();
        if (damageSourceDirectEntity instanceof class_1309 livingEntity) {
            if (!class_9362.method_58659(livingEntity)) {
                return 0.0F;
            } else {
                float fallDistance = livingEntity.field_6017;
                float fallDistanceMul;
                if (fallDistance <= 3.0F) {
                    fallDistanceMul = 4.0F * fallDistance;
                } else if (fallDistance <= 8.0F) {
                    fallDistanceMul = 12.0F + 2.0F * (fallDistance - 3.0F);
                } else {
                    fallDistanceMul = 22.0F + fallDistance - 8.0F;
                }

                if (livingEntity.method_37908() instanceof class_3218 serverLevel) {
                    return (fallDistanceMul + class_1890.method_60160(serverLevel, livingEntity.method_59958(), entity, damageSource, 0.0F) * fallDistance) * config.damageMultiplier;
                } else {
                    return fallDistanceMul * config.damageMultiplier;
                }
            }
        } else {
            return 0.0F;
        }
    }

    // TODO: 1.21.1?
//    @Override
//    @Nullable
//    public DamageSource getDamageSource(LivingEntity livingEntity) {
//        return MaceItem.canSmashAttack(livingEntity) ? livingEntity.damageSources().mace(livingEntity) : null;
//    }

    public static class Config {
        public float damageMultiplier = 1.0f;
    }
}
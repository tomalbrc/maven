package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.block.SimpleBlock;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Function;
import net.minecraft.class_2246;
import net.minecraft.class_2688;
import net.minecraft.class_2689;

@Mixin(class_2689.class_2690.class)
public class StateDefinitionBuilderMixin<O, S extends class_2688<O, S>> {
    @Shadow @Final private O owner;

    @SuppressWarnings("unchecked")
    @Inject(method = "create", at = @At("HEAD"), cancellable = true)
    void filament$abortCreate(Function<O, S> function, class_2689.class_2691<O, S> factory, CallbackInfoReturnable<class_2689<O, S>> cir) {
        // we have to prevent the code from creating a StateDefinition since it won't contain the properties form the behaviours yet
        if (this.owner instanceof SimpleBlock simpleBlock && !simpleBlock.hasData()) { // only if the block doesn't have data set-up yet
            cir.setReturnValue((class_2689<O, S>) class_2246.field_10340.method_9595());
        }
    }
}

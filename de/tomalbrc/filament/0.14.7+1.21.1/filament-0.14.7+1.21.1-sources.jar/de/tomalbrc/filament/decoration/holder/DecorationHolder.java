package de.tomalbrc.filament.decoration.holder;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import net.minecraft.class_243;

public class DecorationHolder extends ElementHolder {
    private final DecorationBlockEntity parent;

    public DecorationHolder(DecorationBlockEntity blockEntity) {
        super();
        this.parent = blockEntity;
        this.setup(blockEntity);
    }

    private void setup(DecorationBlockEntity blockEntity) {
        if (blockEntity.getDecorationData().hasBlocks()) {
            this.addElement(Util.decorationItemDisplay(this.parent));
        } else if (blockEntity.getDecorationData().size() != null) {
            this.addElement(Util.decorationItemDisplay(this.parent));
            this.addElement(Util.decorationInteraction(this.parent));
        } else {
            // TODO: Why do virtual Item frames show item names?!
            //ItemFrameElement itemFrameElement = new ItemFrameElement(this.parent);
            //this.addElement(itemFrameElement);

            // Just using display+interaction again
            this.addElement(Util.decorationItemDisplay(this.parent));
            this.addElement(Util.decorationInteraction(this.parent));
        }
    }

    @Override
    protected void notifyElementsOfPositionUpdate(class_243 newPos, class_243 delta) {
    }

    @Override
    public class_243 getPos() {
        return this.getAttachment() != null ? this.getAttachment().getPos() : null;
    }
}

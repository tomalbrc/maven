package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5712;
import org.jetbrains.annotations.NotNull;

public class FishingRod implements ItemBehaviour<FishingRod.Config>, ItemPredicateModelProvider {
    private final Config config;

    public FishingRod(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public FishingRod.Config getConfig() {
        return config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);
        if (player.field_7513 != null) {
            if (!level.field_9236) {
                int i = player.field_7513.method_6957(itemStack);
                itemStack.method_7970(i, player, class_1309.method_56079(interactionHand));
            }

            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_15093, class_3419.field_15254, 1.0F, 0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F));
            player.method_32876(class_5712.field_28146);
        } else {
            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_14596, class_3419.field_15254, 0.5F, 0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F));
            if (level instanceof class_3218 serverLevel) {
                int lureSpeed = (int) (class_1890.method_60158(serverLevel, itemStack, player) * 20.0F);
                int luck = class_1890.method_8223(serverLevel, itemStack, player);
                level.method_8649(new class_1536(player, level, luck, lureSpeed));
            }

            player.method_7259(class_3468.field_15372.method_14956(item));
            player.method_32876(class_5712.field_28145);
        }

        return class_1271.method_22427(itemStack);
    }

    @Override
    public void generate(class_2960 id, ItemResource itemResource) {
        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(resourcePackBuilder ->
            ItemAssetGenerator.createFishingRod(
                resourcePackBuilder, id,
                itemResource
            )
        );
    }

    public static class Config {}
}

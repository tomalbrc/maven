package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.minecraft.class_9062;

public class Execute implements ItemBehaviour<Execute.ExecuteConfig>, BlockBehaviour<Execute.ExecuteConfig> {
    private final ExecuteConfig config;

    public Execute(ExecuteConfig config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ExecuteConfig getConfig() {
        return config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 user, class_1268 hand) {
        var cmds = commands();

        if (cmds != null && user.method_5682() != null && user instanceof class_3222 serverPlayer) {
            for (String cmd : cmds) {
                user.method_5682().method_3734().method_44252(
                        serverPlayer.method_5671().method_36321(user.method_5682()).method_9230(4), cmd);
            }

            user.method_7259(class_3468.field_15372.method_14956(item));

            if (this.config.sound != null) {
                var sound = this.config.sound;
                level.method_43129(null, user, class_7923.field_41172.method_10223(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                user.method_5998(hand).method_7934(1);
            }
            return class_1271.method_22428(user.method_5998(hand));
        }

        return ItemBehaviour.super.use(item, level, user, hand);
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (player instanceof class_3222 serverPlayer) {
            runCommandBlock(serverPlayer, blockPos);
            return class_1269.field_5812;
        }
        return BlockBehaviour.super.useWithoutItem(blockState, level, blockPos, player, blockHitResult);
    }

    @Override
    public @Nullable class_9062 useItemOn(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        if (player instanceof class_3222 serverPlayer) {
            runCommandBlock(serverPlayer, blockPos);
            return class_9062.field_47728;
        }
        return BlockBehaviour.super.useItemOn(itemStack, blockState, level, blockPos, player, interactionHand, blockHitResult);
    }

    private void runCommandBlock(class_3222 user, class_2338 blockPos) {
        var cmds = commands();
        if (cmds != null && user.method_5682() != null) {
            for (String cmd : cmds) {
                var css = user.method_5671().method_36321(user.method_5682()).method_9230(4);
                if (config.atBlock)
                    css = css.method_9208(blockPos.method_46558());

                user.method_5682().method_3734().method_44252(css, cmd);
            }
            if (this.config.sound != null) {
                var sound = this.config.sound;
                user.method_51469().method_43129(null, user, class_7923.field_41172.method_10223(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                user.method_51469().method_8651(blockPos, config.dropBlock, user);
            }
        }
    }

    private List<String> commands() {
        return config.commands == null ? this.config.command == null ? null : List.of(this.config.command) : config.commands;
    }

    public static class ExecuteConfig {
        public boolean consumes;

        public String command;
        public List<String> commands;

        public boolean atBlock = false;

        public boolean dropBlock = false;

        public class_2960 sound;
    }
}

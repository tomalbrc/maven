package de.tomalbrc.filament.behaviour;

import de.tomalbrc.filament.data.resource.ItemResource;
import net.minecraft.class_2960;

public interface ItemPredicateModelProvider {
    void generate(class_2960 id, ItemResource itemResource);
}

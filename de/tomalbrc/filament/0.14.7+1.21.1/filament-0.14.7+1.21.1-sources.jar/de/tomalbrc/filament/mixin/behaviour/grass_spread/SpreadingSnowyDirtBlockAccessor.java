package de.tomalbrc.filament.mixin.behaviour.grass_spread;

import net.minecraft.class_2338;
import net.minecraft.class_2500;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2500.class)
public interface SpreadingSnowyDirtBlockAccessor {
    @Invoker
    static boolean invokeCanBeGrass(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        throw new UnsupportedOperationException();
    }

    @Invoker
    static boolean invokeCanPropagate(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        throw new UnsupportedOperationException();
    }
}

package de.tomalbrc.filament.util;

import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceArrayMap;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_2680;

public final class FilamentBlockResourceUtils {
    private static final Map<BlockModelType, Map<PolymerBlockModel, class_2680>> MODEL_CACHE = new Object2ObjectArrayMap<>();

    public static @Nullable class_2680 requestBlock(BlockModelType type, PolymerBlockModel model) {
        var list = MODEL_CACHE.computeIfAbsent(type,  x -> new Object2ReferenceArrayMap<>());
        for (Map.Entry<PolymerBlockModel, class_2680> entry : list.entrySet()) {
            if (entry.getKey().equals(model)) {
                return entry.getValue();
            }
        }

        var state = PolymerBlockResourceUtils.requestBlock(type, model);
        list.put(model, state);
        return state;
    }
}
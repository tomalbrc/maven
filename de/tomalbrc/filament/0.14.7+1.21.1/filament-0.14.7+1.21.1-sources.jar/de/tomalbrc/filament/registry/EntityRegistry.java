package de.tomalbrc.filament.registry;

import de.tomalbrc.filament.decoration.util.SeatEntity;
import de.tomalbrc.filament.item.BaseProjectileEntity;
import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class EntityRegistry {
    public static final class_1299<BaseProjectileEntity> BASE_PROJECTILE = class_1299.class_1300.method_5903(BaseProjectileEntity::new, class_1311.field_17715).method_17687(2.f, 3.3f).method_5905("base_projectile");

    public static final class_1299<SeatEntity> SEAT_ENTITY =  class_1299.class_1300.method_5903(SeatEntity::new, class_1311.field_17715).method_5901().method_5904().method_5905("seat");

    public static void register() {
        registerEntity(class_2960.method_60655(Constants.MOD_ID, "projectile"), BASE_PROJECTILE);
        registerEntity(class_2960.method_60655(Constants.MOD_ID, "decoration_seat"), SEAT_ENTITY);
    }

    private static void registerEntity(class_2960 id, class_1299<?> type) {
        class_2378.method_10230(class_7923.field_41177, id, type);
        PolymerEntityUtils.registerType(type);
    }

    public static void registerBlockEntity(class_2960 id, class_2591<?> type) {
        class_2378.method_10230(class_7923.field_41181, id, type);
        PolymerBlockUtils.registerBlockEntity(type);
    }
}

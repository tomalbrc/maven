package de.tomalbrc.filament.decoration.util;

import eu.pb4.polymer.virtualentity.api.ElementHolder;
import net.minecraft.class_2818;
import net.minecraft.class_3218;

public interface BlockEntityWithElementHolder {
    // for already placed decorations
    void attach(class_2818 chunk);

    // for just-placed ones
    void attach(class_3218 level);

    ElementHolder getOrCreateHolder();

    ElementHolder getDecorationHolder();

    void setDecorationHolder(ElementHolder holder);
}
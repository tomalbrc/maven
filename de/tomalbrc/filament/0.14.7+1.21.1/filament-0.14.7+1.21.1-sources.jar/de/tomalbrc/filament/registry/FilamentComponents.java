package de.tomalbrc.filament.registry;

import de.tomalbrc.filament.util.Constants;
import eu.pb4.polymer.core.api.other.PolymerComponent;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

public class FilamentComponents {
    public static final class_9331<class_1799> SKIN_DATA_COMPONENT = new class_9331.class_9332<class_1799>().method_57881(class_1799.field_24671).method_57882(class_1799.field_48349).method_57880();
    public static final class_9331<class_6885<class_1792>> SKIN_COMPONENT = new class_9331.class_9332<class_6885<class_1792>>().method_57881(class_6895.method_40340(class_7924.field_41197)).method_57882(class_9135.method_58001(class_7924.field_41197)).method_57880();

    public static void register() {
        class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Constants.MOD_ID, "skin_data"),
                SKIN_DATA_COMPONENT
        );

        class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Constants.MOD_ID, "skin"),
                SKIN_COMPONENT
        );

        PolymerComponent.registerDataComponent(SKIN_COMPONENT);
        PolymerComponent.registerDataComponent(SKIN_DATA_COMPONENT);
    }
}

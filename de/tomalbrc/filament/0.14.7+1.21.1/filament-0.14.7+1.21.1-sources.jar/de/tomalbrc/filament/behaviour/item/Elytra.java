package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;

/**
 * Elytra behaviour
 */
public class Elytra implements ItemBehaviour<Elytra.Config> {
    private final Config config;

    public Elytra(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Elytra.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(class_1792 item, BehaviourHolder behaviourHolder) {
        class_2315.method_10009(item, class_1738.field_7879);
    }

    @Override
    public boolean isValidRepairItem(class_1799 itemStack, class_1799 itemStack2) {
        return itemStack2.method_31574(config.repairItem);
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        return Cosmetic.swapWithEquipmentSlot(item, level, player, interactionHand);
    }

    public class_6880<class_3414> getEquipSound() {
        return class_7923.field_41172.method_55841(config.sound).orElseThrow();
    }

    public @NotNull class_1304 getEquipmentSlot() {
        return class_1304.field_6174;
    }

    public static class Config {
        public class_2960 sound = class_2960.method_60656("item.armor.equip_elytra");
        public class_1792 repairItem = class_1802.field_8614;
    }
}
package de.tomalbrc.filament.mixin.behaviour.banner;

import com.google.common.collect.ImmutableList;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.SimpleItem;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1726;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2582;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

@Mixin(class_1726.class)
public abstract class LoomMenuMixin extends class_1703 {

    @Shadow @Final private class_7871<class_2582> patternGetter;

    protected LoomMenuMixin(@Nullable class_3917<?> menuType, int i) {
        super(menuType, i);
    }

    @Shadow public abstract class_1735 getDyeSlot();

    @Shadow public abstract class_1735 getBannerSlot();

    @Shadow public abstract class_1735 getPatternSlot();

    @Inject(method = "getSelectablePatterns(Lnet/minecraft/world/item/ItemStack;)Ljava/util/List;", at = @At("RETURN"), cancellable = true)
    private void filament$onGetSelectablePatterns(class_1799 itemStack, CallbackInfoReturnable<List<class_6880<class_2582>>> cir) {
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.getBehaviours().has(Behaviours.BANNER_PATTERN)) {
            class_2960 resourceLocation = simpleItem.getBehaviours().get(Behaviours.BANNER_PATTERN).getConfig().id;
            class_6880<class_2582> res = this.patternGetter.method_46746(class_5321.method_29179(class_7924.field_41252, resourceLocation)).orElseThrow();
            cir.setReturnValue(ImmutableList.of(res));
        }
    }

    @Inject(method = "quickMoveStack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;copy()Lnet/minecraft/world/item/ItemStack;", shift = At.Shift.AFTER), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
    void filament$onQuickMoveStack(class_1657 player, int i, CallbackInfoReturnable<class_1799> cir, class_1799 itemStack, class_1735 slot, class_1799 itemStack2) {
        boolean canMove = !(i == this.getDyeSlot().field_7874 || i == this.getBannerSlot().field_7874 || i == this.getPatternSlot().field_7874);
        if (canMove && itemStack2.method_7909() instanceof SimpleItem simpleItem && simpleItem.getBehaviours().has(Behaviours.BANNER_PATTERN)) {
            if (!this.method_7616(itemStack2, this.getPatternSlot().field_7874, this.getPatternSlot().field_7874 + 1, false)) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            if (itemStack2.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (itemStack2.method_7947() == itemStack.method_7947()) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            cir.setReturnValue(itemStack2.method_7972());
        }
    }
}

package de.tomalbrc.filament.util;

import de.tomalbrc.filament.registry.FilamentComponents;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_9290;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public class SkinUtil {
    private static final List<class_9331<?>> COMPONENTS_TO_COPY = List.of(class_9334.field_50239, class_9334.field_49631, class_9334.field_49636, class_9334.field_49632, class_9334.field_49629, class_9334.field_50072, class_9334.field_50071, class_9334.field_49630, class_9334.field_49649, class_9334.field_50077, class_9334.field_49633, class_9334.field_49641);

    public static void registerEventHandler() {
        PolymerItemUtils.ITEM_CHECK.register(x -> x.method_57826(FilamentComponents.SKIN_DATA_COMPONENT));
        PolymerItemUtils.ITEM_MODIFICATION_EVENT.register((orig,mod,player) -> {
            var newStack = SkinUtil.wrap(orig, mod, player);
            if (mod == newStack) return mod;
            newStack.method_57379(class_9334.field_49628, mod.method_57824(class_9334.field_49628));
            return newStack;
        });
    }

    public static class_1799 wrap(class_1799 itemStack, class_1799 mod, class_3222 player) {
        if (itemStack.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var wrappedItemStack = itemStack.method_57824(FilamentComponents.SKIN_DATA_COMPONENT).method_7972();
            if (!wrappedItemStack.method_7960()) {
                // important
                var oldWrapped = wrappedItemStack;
                if (wrappedItemStack.method_7909() instanceof PolymerItem polymerItem) {
                    wrappedItemStack = polymerItem.getPolymerItemStack(wrappedItemStack, class_1836.field_41070, player.method_56673(), player);
                }
                else wrappedItemStack = wrappedItemStack.method_7972();

                for (class_9331 type : COMPONENTS_TO_COPY) {
                    wrappedItemStack.method_57379(type, itemStack.method_57824(type));
                }

                if (itemStack.method_7909() instanceof class_1738 armorItem) {
                    // todo: merge with existing attributes..?!
                    wrappedItemStack.method_57379(class_9334.field_49636, armorItem.method_7844());
                }

                wrappedItemStack.method_57379(class_9334.field_50239, mod.method_7964());

                // modify lore
                var lore = itemStack.method_57824(class_9334.field_49632);
                if (lore == null || lore.comp_2400().isEmpty()) {
                    lore = new class_9290(ObjectArrayList.of());
                }
                var component = class_2561.method_43470("Skin: ").method_10862(class_2583.field_24360.method_10978(false).method_10977(class_124.field_1080)).method_10852(oldWrapped.method_7964());
                lore.method_57499(component);

                wrappedItemStack.method_57379(class_9334.field_49632, lore);
                wrappedItemStack.method_7939(itemStack.method_7947());

                return wrappedItemStack;
            }
        }
        return mod;
    }

    public static void playRemoveOneSound(class_1297 entity) {
        entity.method_5783(class_3417.field_34377, 0.8F, 0.8F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }

    public static void playInsertSound(class_1297 entity) {
        entity.method_5783(class_3417.field_34376, 0.8F, 0.8F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }
}

package de.tomalbrc.filament.mixin.behaviour.elytra;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.cosmetic.CosmeticInterface;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value = class_1309.class)
public abstract class LivingEntityMixin implements CosmeticInterface {
    @ModifyExpressionValue(method = "updateFallFlying", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
    private boolean filament$elytraUpdateFallFlying(boolean original, @Local class_1799 itemStack) {
        return original || itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.ELYTRA);
    }
}

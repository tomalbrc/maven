package de.tomalbrc.filament.api.behaviour;

import java.lang.reflect.InvocationTargetException;
import net.minecraft.class_2960;

public record BehaviourType<T extends Behaviour<C>, C>(class_2960 id, Class<T> type, Class<C> configType) {
    public T createInstance(C object) {
        try {
            return type.getDeclaredConstructor(this.configType()).newInstance(object);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException |
                 NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }
}

package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * For interactive lamps
 */
public class Lamp implements DecorationBehaviour<Lamp.Config> {

    private final Config config;

    public Lamp(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Lamp.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        var blockState = decorationBlockEntity.method_11010();
        var lightLevel = blockState.method_11654(DecorationBlock.LIGHT_LEVEL);
        var level = decorationBlockEntity.method_10997();
        if (config.cycle != null && !config.cycle.isEmpty() && level != null) {
            var currentIndex = config.cycle.indexOf(lightLevel);
            var next = config.cycle.get((currentIndex+1) % config.cycle.size());
            level.method_8501(decorationBlockEntity.method_11016(), blockState.method_11657(DecorationBlock.LIGHT_LEVEL, next));
        } else if (level != null) {
            if (lightLevel == config.on) {
                level.method_8501(decorationBlockEntity.method_11016(), blockState.method_11657(DecorationBlock.LIGHT_LEVEL, config.off));
            } else {
                level.method_8501(decorationBlockEntity.method_11016(), blockState.method_11657(DecorationBlock.LIGHT_LEVEL, config.on));
            }
        }

        return class_1269.field_5811;
    }

    public static class Config {
        int on = 15;
        int off = 0;
        List<Integer> cycle;
    }
}
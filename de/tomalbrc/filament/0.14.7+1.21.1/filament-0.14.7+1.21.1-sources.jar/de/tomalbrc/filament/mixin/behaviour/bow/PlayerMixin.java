package de.tomalbrc.filament.mixin.behaviour.bow;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.SimpleItem;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Predicate;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1811;

@Mixin(class_1657.class)
public abstract class PlayerMixin {

    @Shadow @Final class_1661 inventory;

    @Shadow @Final private class_1656 abilities;

    @Inject(method = "getProjectile", at = @At("HEAD"), cancellable = true)
    private void filament$onGetProjectile(class_1799 itemStack, CallbackInfoReturnable<class_1799> cir) {
        if (filament$bowOrCrossbow(itemStack)) {
            Predicate<class_1799> predicate = filament$getHeldPred(itemStack);
            class_1799 projectile = class_1811.method_18815(class_1657.class.cast(this), predicate);
            if (!projectile.method_7960()) {
                cir.setReturnValue(projectile);
            } else {
                predicate = filament$getPred(itemStack);
                for (int i = 0; i < this.inventory.method_5439(); ++i) {
                    class_1799 itemStack3 = this.inventory.method_5438(i);
                    if (predicate.test(itemStack3)) {
                        cir.setReturnValue(itemStack3);
                        return;
                    }
                }

                cir.setReturnValue(this.abilities.field_7477 ? new class_1799(class_1802.field_8107) : class_1799.field_8037);
            }
        }
    }

    @Unique
    private Predicate<class_1799> filament$getPred(class_1799 itemStack) {
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.BOW)) {
            return simpleItem.get(Behaviours.BOW).supportedProjectiles();
        }
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.CROSSBOW)) {
            return simpleItem.get(Behaviours.CROSSBOW).supportedProjectiles();
        }

        return (itemStack1) -> false;
    }

    @Unique
    private Predicate<class_1799> filament$getHeldPred(class_1799 itemStack) {
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.BOW)) {
            return simpleItem.get(Behaviours.BOW).supportedHeldProjectiles();
        }
        if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.CROSSBOW)) {
            return simpleItem.get(Behaviours.CROSSBOW).supportedHeldProjectiles();
        }

        return (itemStack1) -> false;
    }

    @Unique
    private boolean filament$bowOrCrossbow(class_1799 itemStack) {
        return itemStack.method_7909() instanceof SimpleItem simpleItem && (simpleItem.has(Behaviours.BOW) || simpleItem.has(Behaviours.CROSSBOW));
    }
}

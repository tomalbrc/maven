package de.tomalbrc.filament.mixin.behaviour.trim;

import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.trim.FilamentTrimPatterns;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1799;
import net.minecraft.class_8062;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8062.class)
public class SmithingTrimRecipeMixin {
    @Inject(method = "isBaseIngredient", at = @At("HEAD"), cancellable = true)
    public void filament$isBaseIngredient(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        boolean isChainArmor = !itemStack.method_7960() && itemStack.method_7909() instanceof class_1738 armorItem && armorItem.method_7686() == class_1740.field_7887;
        if ((FilamentTrimPatterns.overwriteChainMail() && isChainArmor && !(itemStack.method_7909() instanceof PolymerItem)) || itemStack.method_7909() instanceof SimpleItem) {
            cir.setReturnValue(false);
        }
    }
}

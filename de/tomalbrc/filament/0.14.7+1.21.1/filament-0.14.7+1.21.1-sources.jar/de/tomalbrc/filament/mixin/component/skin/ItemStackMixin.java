package de.tomalbrc.filament.mixin.component.skin;

import de.tomalbrc.filament.registry.FilamentComponents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow public abstract void hurtAndBreak(int i, class_1309 livingEntity, class_1304 equipmentSlot);

    @Inject(method = "hurtAndBreak(ILnet/minecraft/server/level/ServerLevel;Lnet/minecraft/server/level/ServerPlayer;Ljava/util/function/Consumer;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;shrink(I)V"))
    private void filament$dontDestroySkin(int i, class_3218 serverLevel, class_3222 serverPlayer, Consumer<class_1792> consumer, CallbackInfo ci) {
        var self = class_1799.class.cast(this);
        if (self.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            var skinItem = self.method_57824(FilamentComponents.SKIN_DATA_COMPONENT);
            if (skinItem != null && !skinItem.method_7960()) {
                if (!serverPlayer.method_7270(skinItem))
                    serverPlayer.method_5775(skinItem);

                self.method_57381(FilamentComponents.SKIN_DATA_COMPONENT);
            }
        }
    }
}

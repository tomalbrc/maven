package de.tomalbrc.filament.data.properties;

import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.Behaviours;
import eu.pb4.placeholders.api.TextParserUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_4174;

// For shared properties that make sense for both, item, blocks *and* decoration
public class ItemProperties {
    public static final ItemProperties EMPTY = new ItemProperties();

    public int durability = Integer.MIN_VALUE;
    public int stackSize = 64;
    public List<String> lore;
    public boolean fireResistant;
    public boolean copyComponents;

    public void appendHoverText(List<class_2561> tooltip) {
        if (this.lore != null)
            this.lore.forEach(line -> tooltip.add(TextParserUtils.formatText(line)));
    }

    public class_1792.class_1793 toItemProperties() {
        return toItemProperties(null);
    }

    public class_1792.class_1793 toItemProperties(@Nullable BehaviourConfigMap behaviourConfigs) {
        class_1792.class_1793 props = new class_1792.class_1793();
        props.method_7889(stackSize);

        if (durability != Integer.MIN_VALUE)
            props.method_7895(durability);

        if (fireResistant)
            props.method_24359();

        if (behaviourConfigs != null && behaviourConfigs.has(Behaviours.FOOD)) {
            var food = behaviourConfigs.get(Behaviours.FOOD);

            class_4174.class_4175 builder = new class_4174.class_4175();
            if (food.canAlwaysEat) builder.method_19240();
            if (food.fastfood) builder.method_19241();
            builder.method_19237(food.saturation);
            builder.method_19238(food.hunger);

            props.method_19265(builder.method_19242());
        }

        return props;
    }
}

package de.tomalbrc.filament.behaviour;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.minecraft.class_1792;
import net.minecraft.class_2248;

public class BehaviourUtil {
    public static void postInitItem(class_1792 item, BehaviourHolder behaviourHolder, BehaviourConfigMap configMap) {
        if (configMap == null || item == null)
            return;

        for (var e : behaviourHolder.getBehaviours()) {
            if (e.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.init(item, behaviourHolder);
            }
        }
    }

    public static void postInitBlock(class_1792 blockItem, class_2248 block, BehaviourHolder behaviourHolder, BehaviourConfigMap configMap) {
        if (configMap == null)
            return;

        for (var e : behaviourHolder.getBehaviours()) {
            if (e.getValue() instanceof BlockBehaviour<?> blockBehaviour) {
                blockBehaviour.init(blockItem, block, behaviourHolder);
            }
        }
    }
}

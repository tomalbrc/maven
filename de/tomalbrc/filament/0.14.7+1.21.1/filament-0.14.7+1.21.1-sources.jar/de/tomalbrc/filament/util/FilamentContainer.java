package de.tomalbrc.filament.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public class FilamentContainer extends class_1277 {
    List<class_3222> menus = new ObjectArrayList<>();

    private boolean valid = true;

    private final boolean purge;

    private Runnable closeCallback;
    private Runnable openCallback;

    public FilamentContainer(int size, boolean purge) {
        super(size);
        this.purge = purge;
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return this.valid;
    }

    @Override
    public boolean method_49104(class_1263 target, int slot, class_1799 stack) {
        return this.valid;
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return this.valid;
    }

    public void setValid(boolean valid) {
        if (!valid) {
            for (class_3222 player : this.menus) {
                player.method_7346();
            }
        }
        this.valid = valid;
    }

    @Override
    public void method_5435(class_1657 player) {
        super.method_5435(player);
        if (player.method_7325())
            return;

        if (this.menus.isEmpty() && this.openCallback != null) {
            this.openCallback.run();
        }

        if (player instanceof class_3222 serverPlayer)
            this.menus.add(serverPlayer);
    }

    @Override
    public void method_5432(class_1657 player) {
        super.method_5432(player);
        if (player instanceof class_3222)
            this.menus.remove(player);
        if (this.purge && this.menus.isEmpty())
            this.method_5448();

        if (this.menus.isEmpty() && this.closeCallback != null) {
            this.closeCallback.run();
        }
    }

    public void setCloseCallback(Runnable closeCallback) {
        this.closeCallback = closeCallback;
    }

    public void setOpenCallback(Runnable openCallback) {
        this.openCallback = openCallback;
    }
}

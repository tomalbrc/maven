package de.tomalbrc.filament.data;

import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("unused")
public record ItemGroupData(
        @NotNull class_2960 id,
        @NotNull class_2960 item,
        @Nullable String literal
) {

}

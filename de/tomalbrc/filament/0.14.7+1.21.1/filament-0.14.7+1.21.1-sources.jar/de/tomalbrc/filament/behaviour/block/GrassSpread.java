package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.mixin.behaviour.grass_spread.SpreadingSnowyDirtBlockAccessor;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3737;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class GrassSpread implements BlockBehaviour<GrassSpread.Config>, class_3737 {
    private final Config config;

    public GrassSpread(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public GrassSpread.Config getConfig() {
        return this.config;
    }

    @Override
    public boolean isRandomlyTicking(class_2680 blockState) {
        return true;
    }

    @Override
    public void randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        if (!SpreadingSnowyDirtBlockAccessor.invokeCanBeGrass(blockState, serverLevel, blockPos)) {
            serverLevel.method_8501(blockPos, config.decayBlockState);
        } else {
            if (serverLevel.method_22339(blockPos.method_10084()) >= 9) {
                class_2680 defaultBlockState = blockState.method_26204().method_9564();

                for (int i = 0; i < 4; ++i) {
                    class_2338 blockPos2 = blockPos.method_10069(randomSource.method_43048(3) - 1, randomSource.method_43048(5) - 3, randomSource.method_43048(3) - 1);
                    class_2680 blockState2 = serverLevel.method_8320(blockPos2);
                    var canReplace = false;
                    for (class_2248 block : config.propagatesToBlocks) {
                        canReplace |= blockState2.method_27852(block);
                        if (canReplace) break;
                    }
                    if (!canReplace && config.propagatesToBlocks != null && !config.propagatesToBlockTags.isEmpty()) {
                        for (class_2960 tag : config.propagatesToBlockTags) {
                            canReplace |= blockState2.method_26164(class_6862.method_40092(class_7924.field_41254, tag));
                            if (canReplace) break;
                        }
                    }

                    if (canReplace && SpreadingSnowyDirtBlockAccessor.invokeCanPropagate(defaultBlockState, serverLevel, blockPos2)) {
                        serverLevel.method_8501(blockPos2, defaultBlockState);
                    }
                }
            }
        }
    }

    public static class Config {
        public class_2680 decayBlockState = class_2246.field_10566.method_9564();
        public List<class_2248> propagatesToBlocks = List.of(class_2246.field_10566);
        public List<class_2960> propagatesToBlockTags = List.of();
    }
}
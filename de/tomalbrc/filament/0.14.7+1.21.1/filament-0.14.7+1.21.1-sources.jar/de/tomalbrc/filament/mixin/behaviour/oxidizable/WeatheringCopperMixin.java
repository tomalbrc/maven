package de.tomalbrc.filament.mixin.behaviour.oxidizable;

import de.tomalbrc.filament.registry.OxidizableRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_5955;

@Mixin(class_5955.class)
public interface WeatheringCopperMixin {
    @Inject(method = "getPrevious(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/Optional;", at = @At("RETURN"), cancellable = true)
    private static void filament$onGetPrevious(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (OxidizableRegistry.hasPrevious(blockState.method_26204())) {
            var v = OxidizableRegistry.getPrevious(blockState.method_26204()).method_34725(blockState);
            cir.setReturnValue(Optional.of(v));
        }
    }

    @Inject(method = "getFirst(Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/state/BlockState;", at = @At("RETURN"), cancellable = true)
    private static void filament$onFirst(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (OxidizableRegistry.hasPrevious(blockState.method_26204())) {
            class_2248 prev = OxidizableRegistry.getPrevious(blockState.method_26204());
            while (class_5955.method_34732(prev).isPresent()) {
                prev = class_5955.method_34732(prev).get();
            }
            cir.setReturnValue(Optional.of(prev.method_34725(blockState)));
        }
    }

    @Inject(method = "getNext(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/Optional;", at = @At("RETURN"), cancellable = true)
    private void filament$onGetNext(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (OxidizableRegistry.hasNext(blockState.method_26204())) {
            var v = OxidizableRegistry.getNext(blockState.method_26204()).method_34725(blockState);
            cir.setReturnValue(Optional.of(v));
        }
    }
}

package de.tomalbrc.filament.mixin.behaviour.trap;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.Trap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public class MobMixin {
    @Inject(at= @At("HEAD"), method = "interact", cancellable = true)
    public void filament$trapItemInteract(class_1657 player, class_1268 interactionHand, CallbackInfoReturnable<class_1269> cir) {
        class_1799 itemStack = player.method_5998(interactionHand);

        class_1308 mob = class_1308.class.cast(this);
        if (itemStack.method_7909() instanceof BehaviourHolder behaviourHolder && behaviourHolder.getBehaviours().has(Behaviours.TRAP) && !player.method_7357().method_7904(itemStack.method_7909())) {
            Trap trap = behaviourHolder.get(Behaviours.TRAP);
            boolean canUse = trap.canUseOn(mob);

            if (itemStack.method_7936() - itemStack.method_7919() > 1 && canUse && trap.canSave(mob)) {
                trap.saveToTag(mob, itemStack);

                if (player.method_37908() instanceof class_3218 serverLevel) {
                    serverLevel.method_14199(class_2398.field_23956, mob.method_19538().field_1352, mob.method_19538().field_1351, mob.method_19538().field_1350, 20, 0.125, 0.25, 0.125, 0.1);
                }

                mob.method_31472();
            }

            itemStack.method_7909().method_7836(player.method_37908(), player, interactionHand);

            cir.setReturnValue(class_1269.field_21466);
            cir.cancel();
        }
    }
}

package de.tomalbrc.filament.data.misc;

import net.minecraft.class_2960;

// Big TODO, for armor etc

@SuppressWarnings("unused")
public record Effect(
        class_2960 effect,
                     int duration,
                     int level,
                     int delay
) {}

package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.util.RegistryUnfreezer;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_6880;

@Mixin(class_2370.class)
public class MappedRegistryMixin<T> implements RegistryUnfreezer {
    @Shadow
    @Nullable
    private Map<T, class_6880.class_6883<T>> unregisteredIntrusiveHolders;

    @Shadow
    private boolean frozen;

    public void filament$unfreeze() {
        this.unregisteredIntrusiveHolders = new Reference2ObjectOpenHashMap<>();
        this.frozen = false;
    }
}

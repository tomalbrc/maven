package de.tomalbrc.filament.util;

import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Set;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import net.minecraft.class_2960;
import net.minecraft.class_3255;
import net.minecraft.class_3258;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_7367;

public class FilamentAssetReloadListener implements FilamentSynchronousResourceReloadListener {
    Consumer<ResourcePackBuilder> lastConsumer = null;

    @Override
    public class_2960 getFabricId() {
        return class_2960.method_60655(Constants.MOD_ID, "assets");
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        if (lastConsumer == null) {
            Consumer<ResourcePackBuilder> consumer = resourcePackBuilder -> resourceManager.method_29213().forEach(packResources -> {
                Set<String> clientResources = packResources.method_14406(class_3264.field_14188);
                if (packResources instanceof class_3255 abstractPackResources) {
                    boolean isZip = packResources instanceof class_3258;
                    for (String namespace : clientResources) {
                        if (isZip) {
                            listResources((class_3258)packResources, class_3264.field_14188, namespace, "", (resourceLocation,ioSupplier) -> {
                                try {
                                    resourcePackBuilder.addData("assets/" + resourceLocation.method_12836() + "/" + resourceLocation.method_12832(), ioSupplier.get().readAllBytes());
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                }
                            });
                        }

                        abstractPackResources.method_14408(class_3264.field_14188, isZip ? namespace : "", !isZip ? namespace : "", (resourceLocation,ioSupplier) -> {
                            try {
                                resourcePackBuilder.addData("assets/" + resourceLocation.method_12832(), ioSupplier.get().readAllBytes());
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                }
            });

            lastConsumer = consumer;
            PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(consumer);
        }
    }

    public void listResources(class_3258 resources, class_3264 packType, String string, String string2, class_3262.class_7664 resourceOutput) {
        ZipFile zipFile = resources.field_45038.method_52426();
        if (zipFile != null) {
            Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
            String var10001 = packType.method_14413();
            String string3 = resources.method_52422(var10001 + "/" + string + "/");
            String string4 = string3 + string2;

            while(enumeration.hasMoreElements()) {
                ZipEntry zipEntry = enumeration.nextElement();
                if (!zipEntry.isDirectory()) {
                    String string5 = zipEntry.getName();
                    if (string5.startsWith(string4)) {
                        String string6 = string5.substring(string3.length());
                        class_2960 resourceLocation = class_2960.method_43902(string, string6);
                        if (resourceLocation != null) {
                            resourceOutput.accept(resourceLocation, class_7367.create(zipFile, zipEntry));
                        }
                    }
                }
            }
        }
    }
}
package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_6860;
import net.minecraft.class_7237;

@Mixin(class_7237.class)
public class WorldLoaderMixin {
    @Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/server/WorldLoader;loadAndReplaceLayer(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/LayeredRegistryAccess;Lnet/minecraft/server/RegistryLayer;Ljava/util/List;)Lnet/minecraft/core/LayeredRegistryAccess;", shift = At.Shift.BEFORE), method = "load")
    private static void filament$loadEarly(class_7237.class_6906 initConfig, class_7237.class_6907 worldDataSupplier, class_7237.class_7239 resultFactory, Executor executor, Executor executor2, CallbackInfoReturnable<CompletableFuture> cir, @Local class_6860 closeableResourceManager) {
        Util.loadDatapackContents(closeableResourceManager);
    }
}
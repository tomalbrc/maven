package de.tomalbrc.filament.mixin.behaviour.tnt;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.block.SimpleBlock;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1541;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_5362;

@Mixin(class_1541.class)
public abstract class PrimedTntMixin extends class_1297 {
    public PrimedTntMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Shadow public abstract class_2680 getBlockState();

    @Shadow private boolean usedPortal;

    @Shadow @Final private static class_5362 USED_PORTAL_DAMAGE_CALCULATOR;

    @Inject(method = "explode", at = @At("HEAD"), cancellable = true)
    private void filament$customExplode(CallbackInfo ci) {
        if (this.getBlockState().method_26204() instanceof SimpleBlock simpleBlock && simpleBlock.has(Behaviours.TNT)) {
            var conf = Objects.requireNonNull(simpleBlock.get(Behaviours.TNT)).getConfig();
            this.method_37908().method_55117(this, class_1927.method_55108(this.method_37908(), this), this.usedPortal ? USED_PORTAL_DAMAGE_CALCULATOR : null, this.method_23317(), this.method_23323(0.0625F), this.method_23321(), conf.explosionPower.getValue(getBlockState()), false, class_1937.class_7867.field_40891);
            ci.cancel();
        }
    }
}

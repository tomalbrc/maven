package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Repairable behaviour
 */
public class Repairable implements ItemBehaviour<Repairable.Config> {
    private final Config config;

    List<class_6862<class_1792>> compiledTags = new ObjectArrayList<>();
    List<class_2960> compiledItems = new ObjectArrayList<>();

    public Repairable(Config config) {
        this.config = config;
    }

    @Override
    public void init(class_1792 item, BehaviourHolder behaviourHolder) {
        for (String string : config.items) {
            if (string.startsWith("#")) {
                var key = string.substring(1);
                this.compiledTags.add(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654(key)));
            } else {
                this.compiledItems.add(class_2960.method_60654(string));
            }
        }
    }

    @Override
    @NotNull
    public Repairable.Config getConfig() {
        return this.config;
    }

    @Override
    @NotNull
    public boolean isValidRepairItem(class_1799 itemStack, class_1799 itemStack2) {
        for (class_6862<class_1792> tag : compiledTags) {
            if (itemStack2.method_31573(tag)) return true;
        }

        for (var id : compiledItems) {
            if (itemStack2.method_31574(class_7923.field_41178.method_10223(id))) return true;
        }

        return false;
    }

    public static class Config {
        public List<String> items = List.of();
    }
}
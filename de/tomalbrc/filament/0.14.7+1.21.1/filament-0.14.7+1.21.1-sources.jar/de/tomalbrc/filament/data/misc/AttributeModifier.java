package de.tomalbrc.filament.data.misc;

import net.minecraft.class_1304;

// BIG TODO, for armor etc

@SuppressWarnings("unused")
public record AttributeModifier(
        String attribute,
        float value,
        class_1304 slot
) {}

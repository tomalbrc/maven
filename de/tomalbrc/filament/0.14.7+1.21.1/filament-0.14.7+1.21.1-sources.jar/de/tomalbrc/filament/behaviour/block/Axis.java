package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import org.jetbrains.annotations.NotNull;

import static net.minecraft.class_2741.field_12496;

public class Axis implements BlockBehaviour<Axis.Config> {
    private final Config config;

    public Axis(Config config) {
        this.config = config;
    }

    @Override
    public class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return class_2465.method_36377(blockState, rotation);
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(field_12496, class_2350.class_2351.field_11052);
    }

    @Override
    @NotNull
    public Axis.Config getConfig() {
        return this.config;
    }

    @Override
    public boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_12496);
        return true;
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 self, class_1750 blockPlaceContext) {
        return self.method_11657(field_12496, blockPlaceContext.method_8038().method_10166());
    }

    public static class Config {}
}
package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.fabricmc.fabric.mixin.content.registry.ShovelItemAccessor;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3922;
import net.minecraft.class_5712;
import org.jetbrains.annotations.NotNull;

/**
 * Shovel behaviour
 */
public class Shovel implements ItemBehaviour<Shovel.Config> {
    private final Config config;

    public Shovel(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Shovel.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1269 useOn(class_1838 useOnContext) {
        class_1937 level = useOnContext.method_8045();
        class_2338 blockPos = useOnContext.method_8037();
        class_2680 blockState = level.method_8320(blockPos);
        if (useOnContext.method_8038() == class_2350.field_11033) {
            return class_1269.field_5811;
        } else {
            class_1657 player = useOnContext.method_8036();
            class_2680 blockState2 = ShovelItemAccessor.getPathStates().get(blockState.method_26204());
            class_2680 blockState3 = null;
            if (blockState2 != null && level.method_8320(blockPos.method_10084()).method_26215()) {
                level.method_8396(player, blockPos, class_3414.method_47908(config.sound), class_3419.field_15245, 1.0F, 1.0F);
                blockState3 = blockState2;
            } else if (blockState.method_26204() instanceof class_3922 && blockState.method_11654(class_3922.field_17352)) {
                if (!level.method_8608()) {
                    level.method_8444(null, 1009, blockPos, 0);
                }

                class_3922.method_29288(useOnContext.method_8036(), level, blockPos, blockState);
                blockState3 = blockState.method_11657(class_3922.field_17352, false);
            }

            if (blockState3 != null) {
                if (!level.field_9236) {
                    level.method_8652(blockPos, blockState3, 11);
                    level.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(player, blockState3));
                    if (player != null) {
                        useOnContext.method_8041().method_7970(1, player, class_1309.method_56079(useOnContext.method_20287()));
                    }
                }

                return class_1269.field_5812;
            } else {
                return class_1269.field_5811;
            }
        }
    }

    public static class Config {
        public class_2960 sound = class_3417.field_14616.method_14833();
    }
}
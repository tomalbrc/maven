package de.tomalbrc.filament.mixin.behaviour.falling_block;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.FallingBlock;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1540;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1540.class)
public abstract class FallingBlockEntityMixin extends class_1297 {
    @Shadow private class_2680 blockState;

    @Shadow private boolean cancelDrop;

    public FallingBlockEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "causeFallDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z"), cancellable = true)
    private void filament$damageChangeBlockState(float f, float g, class_1282 damageSource, CallbackInfoReturnable<Boolean> cir) {
        if (this.blockState.method_26204() instanceof SimpleBlock simpleBlock && simpleBlock.has(Behaviours.FALLING_BLOCK)) {
            FallingBlock behaviour = simpleBlock.get(Behaviours.FALLING_BLOCK);
            assert behaviour != null;

            var conf = behaviour.getConfig();
            if (conf.canBeDamaged.getValue(this.blockState)) {
                int value = class_3532.method_15386(f - 1.0F);
                float h = (float)Math.min(class_3532.method_15375((float)value * conf.damagePerDistance.getValue(this.blockState)), conf.maxDamage.getValue(this.blockState));

                if (h > 0.0F && this.field_5974.method_43057() < conf.baseBreakChance.getValue(this.blockState) + (float)value * conf.breakChancePerDistance.getValue(this.blockState)) {
                    if (conf.damagedBlock == null) {
                        this.cancelDrop = true;
                    } else {
                        this.blockState = class_7923.field_41175.method_10223(conf.damagedBlock.getValue(this.blockState)).method_34725(this.blockState);
                    }
                    cir.setReturnValue(false);
                }
            }
        }
    }
}

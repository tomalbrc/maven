package de.tomalbrc.filament.mixin.behaviour.elytra;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 {
    @Shadow public abstract void startFallFlying();

    protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "tryToStartFallFlying", at = @At("RETURN"), cancellable = true)
    private void filament$elytraTryToStartFallFlying(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) {
            if (!this.method_24828() && !this.method_6128() && !this.method_5799() && !this.method_6059(class_1294.field_5902)) {
                class_1799 itemStack = this.method_6118(class_1304.field_6174);
                if (itemStack.method_7909() instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.ELYTRA) && class_1770.method_7804(itemStack)) {
                    this.startFallFlying();
                    cir.setReturnValue(true);
                }
            }
        }
    }
}

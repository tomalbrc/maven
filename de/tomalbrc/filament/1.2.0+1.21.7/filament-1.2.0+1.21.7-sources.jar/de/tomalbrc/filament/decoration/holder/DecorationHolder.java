package de.tomalbrc.filament.decoration.holder;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.util.ItemFrameElement;
import de.tomalbrc.filament.util.DecorationUtil;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.BlockAwareAttachment;
import eu.pb4.polymer.virtualentity.api.attachment.BlockBoundAttachment;
import eu.pb4.polymer.virtualentity.api.attachment.ChunkAttachment;
import eu.pb4.polymer.virtualentity.api.attachment.HolderAttachment;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3738;

public class DecorationHolder extends ElementHolder implements FilamentDecorationHolder {
    private final Supplier<class_1799> pickResult;

    public DecorationHolder(Supplier<class_1799> pickResult) {
        super();
        this.pickResult = pickResult;
    }

    @Override
    @SuppressWarnings("all")
    protected void onAttachmentSet(HolderAttachment attachment, @Nullable HolderAttachment oldAttachment) {
        BlockBoundAttachment boundAttachment;
        if (attachment != null && (boundAttachment = (BlockBoundAttachment) attachment).getBlockState().method_26204() instanceof ComplexDecorationBlock) {
            Filament.SERVER.method_63588(new class_3738(0, () -> {
                boundAttachment.setBlockState(boundAttachment.getBlockState());
            }));
        }
    }

    @Override
    public void updateVisualItem(class_1799 newItem) {
        for (VirtualElement element : this.getElements()) {
            if (element instanceof ItemDisplayElement itemDisplayElement) {
                itemDisplayElement.setItem(newItem);
            }
        }

        this.tick();
    }

    @Override
    public void playAnimation(class_3222 serverPlayer, String animation, int priority, Consumer<class_3222> onFinish) {
        if (onFinish != null)
            onFinish.accept(serverPlayer);
    }

    @Override
    public <T extends VirtualElement> T addElement(T element) {
        T res = super.addElement(element);
        if (element instanceof InteractionElement interactionElement) {
            DecorationUtil.VIRTUAL_ENTITY_PICK_MAP.put(interactionElement.getEntityId(), this::getPickResult);
        }
        if (element instanceof ItemFrameElement itemFrameElement) {
            DecorationUtil.VIRTUAL_ENTITY_PICK_MAP.put(itemFrameElement.getEntityId(), this::getPickResult);
        }
        return res;
    }

    @Override
    protected void onAttachmentRemoved(HolderAttachment oldAttachment) {
        for (VirtualElement element : this.getElements()) {
            if (element instanceof InteractionElement interactionElement) {
                DecorationUtil.VIRTUAL_ENTITY_PICK_MAP.remove(interactionElement.getEntityId());
            }
            if (element instanceof ItemFrameElement interactionElement) {
                DecorationUtil.VIRTUAL_ENTITY_PICK_MAP.remove(interactionElement.getEntityId());
            }
        }

        super.onAttachmentRemoved(oldAttachment);
    }

    @Override
    public void notifyUpdate(HolderAttachment.UpdateType updateType) {
        super.notifyUpdate(updateType);

        if (updateType == BlockBoundAttachment.BLOCK_STATE_UPDATE && getAttachment() != null) {
            this.update(((BlockAwareAttachment)this.getAttachment()).getBlockState());
        }
    }

    @Override
    public boolean isAnimated() {
        return false;
    }

    @Override
    public class_1799 getPickResult() {
        return this.pickResult.get();
    }
}
package de.tomalbrc.filament.behaviour.block;

import com.google.common.collect.ImmutableList;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2960;
import net.minecraft.class_4538;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class CanSurvive implements BlockBehaviour<CanSurvive.Config> {
    private final Config config;

    public CanSurvive(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public CanSurvive.Config getConfig() {
        return this.config;
    }

    public boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        class_2350.class_2351 axis = getAxisOrNull(blockState);
        if (axis != null) {
            return test(axis, blockPos, levelReader, blockState);
        }

        class_2350 direction = getFacing(blockState);
        return test(direction, blockPos, levelReader, blockState);
    }

    private boolean test(class_2350 direction, class_2338 blockPos, class_4538 levelReader, class_2680 blockState) {
        var belowState = levelReader.method_8320(blockPos.method_10093(direction));
        if (this.config.blocks != null && this.config.blocks.contains(belowState.method_26204()))
            return true;
        if (this.config.tags != null) {
            for (class_2960 tag : this.config.tags) {
                var tagKey = class_6862.method_40092(class_7924.field_41254, tag);
                if (belowState.method_26164(tagKey))
                    return true;
            }
        }

        return this.config.solidOnly && blockState.method_51367();
    }

    private boolean test(class_2350.class_2351 axis, class_2338 blockPos, class_4538 levelReader, class_2680 blockState) {
        for (class_2350 direction : axis.method_10180()) {
            if (test(direction, blockPos, levelReader, blockState)) {
                return true;
            }
        }

        return false;
    }

    private class_2350.class_2351 getAxisOrNull(class_2680 blockState) {
        List<class_2754<class_2350.class_2351>> props2 = ImmutableList.of(class_2741.field_12496, class_2741.field_12529);
        for (var prop: props2) {
            if (blockState.method_28498(prop)) {
                return blockState.method_11654(prop);
            }
        }

        return null;
    }

    private class_2350 getFacing(class_2680 blockState) {
        List<class_2754<class_2350>> props = ImmutableList.of(class_2741.field_12525, class_2741.field_12481, class_2741.field_28062, class_2741.field_12545);
        for (var prop: props) {
            if (blockState.method_28498(prop)) {
                return blockState.method_11654(prop);
            }
        }
        return class_2350.field_11033;
    }


    @Override
    public class_2680 updateShape(class_2680 blockState, class_2350 direction, class_2680 blockState2, class_1936 levelAccessor, class_2338 blockPos, class_2338 blockPos2) {
        return !blockState.method_26184(levelAccessor, blockPos) ? class_2246.field_10124.method_9564() : blockState;
    }

    public static class Config {
        public List<class_2248> blocks;
        public List<class_2960> tags;
        public boolean solidOnly = true;
    }
}

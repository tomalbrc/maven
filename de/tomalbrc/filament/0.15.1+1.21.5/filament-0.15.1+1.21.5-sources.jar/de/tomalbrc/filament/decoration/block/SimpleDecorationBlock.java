package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.holder.SimpleHolder;
import de.tomalbrc.filament.util.DecorationUtil;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;

public class SimpleDecorationBlock extends DecorationBlock implements BlockWithElementHolder {
    public static final class_2758 ROTATION = class_2758.method_11867("rotation", 0, 7);

    public SimpleDecorationBlock(class_2251 properties, class_2960 decorationId) {
        super(properties, decorationId);
        this.method_9590(this.method_9564().method_11657(ROTATION, 0));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(ROTATION);
    }

    @Nullable
    public ElementHolder createElementHolder(class_3218 world, class_2338 pos, class_2680 initialBlockState) {
        return new SimpleHolder();
    }

    public List<class_1799> getDrops() {
        if (this.getDecorationData().properties().drops) {
            return List.of(class_7923.field_41178.method_63535(this.decorationId).method_7854());
        }
        return List.of();
    }

    @Override
    protected void method_9565(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean bl) {
        if (!bl && !blockState.method_27852(serverLevel.method_8320(blockPos).method_26204())) {
            DecorationData data = this.getDecorationData();
            if (!data.hasBlocks()) {
                class_3414 breakSound = data.properties().blockBase.method_9564().method_26231().method_10595();
                serverLevel.method_8396(null, blockPos,  breakSound, class_3419.field_15245, 1.0F, 1.0F);
            }

            if (data.properties().showBreakParticles)
                DecorationUtil.showBreakParticle(serverLevel, data.properties().useItemParticles ? class_7923.field_41178.method_63535(this.decorationId).method_7854() : this.getDecorationData().properties().blockBase.method_8389().method_7854(), (float) blockPos.method_46558().method_10216(), (float) blockPos.method_46558().method_10214(), (float) blockPos.method_46558().method_10215());

            if (data.properties().drops && blockState.method_26204() instanceof SimpleDecorationBlock) {
                for (class_1799 drop : this.getDrops()) {
                    Util.spawnAtLocation(serverLevel, blockPos.method_46558(), drop);
                }
            }
        }

        super.method_9565(blockState, serverLevel, blockPos, itemStack, bl);
    }
}

package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1540;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;

@SuppressWarnings({"unused", "UnusedReturnValue"})
public interface BlockBehaviour<T> extends Behaviour<T> {
    default void init(class_1792 item, class_2248 block, BehaviourHolder behaviourHolder) {

    }

    default boolean modifyStateMap(Map<class_2680, BlockData.BlockStateMeta> map, BlockData blockData) {
        return false;
    }

    default class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState;
    }

    default boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        return false;
    }

    default Optional<Boolean> useShapeForLightOcclusion(class_2680 blockState) {
        return Optional.empty();
    }

    default class_2680 getStateForPlacement(class_2680 block, class_1750 blockPlaceContext) {
        return block;
    }

    default Optional<Boolean> canBeReplaced(class_2680 blockState, class_1750 blockPlaceContext) {
        return Optional.empty();
    }

    default class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        return blockState;
    }

    default void neighborChanged(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_9904 orientation, boolean bl) {
    }

    default void playerWillDestroy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
    }

    default Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
        return Optional.empty();
    }

    @Nullable
    default class_3610 getFluidState(class_2680 blockState) {
        return null;
    }

    default void onExplosionHit(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
    }

    default boolean dropFromExplosion(class_1927 explosion) {
        return true;
    }

    default class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return null;
    }

    default class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return null;
    }

    default boolean isSignalSource(class_2680 blockState) {
        return false;
    }

    default int getDirectSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return 0;
    }

    default int getSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return 0;
    }

    default void onPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
    }

    default void setPlacedBy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1309 livingEntity, class_1799 itemStack) {
    }

    default void spawnAfterBreak(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean bl) {
    }

    default boolean canSurvive(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return true;
    }

    default boolean isRandomlyTicking(class_2680 blockState) {
        return false;
    }

    default void randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
    }

    default void tick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
    }

    default class_2680 getCustomPolymerBlockState(Map<class_2680, BlockData.BlockStateMeta> stateMap, class_2680 blockState) {
        return null;
    }

    default class_1799 getCloneItemStack(class_1799 itemStack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        return null;
    }

    default class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        return class_1269.field_5811;
    }

    @Nullable
    default class_1269 useItemOn(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        return null;
    }

    default void onProjectileHit(class_1937 level, class_2680 blockState, class_3965 blockHitResult, class_1676 projectile) {
    }

    default Optional<Long> getSeed(class_2680 blockState, class_2338 blockPos) {
        return Optional.empty();
    }

    @Nullable
    default class_1282 getFallDamageSource(class_1297 entity) {
        return null;
    }

    default void onLand(class_1937 level, class_2338 blockPos, class_2680 blockState, class_2680 blockState2, class_1540 fallingBlockEntity) {
    }

    default void onBrokenAfterFall(class_1937 level, class_2338 blockPos, class_1540 fallingBlockEntity) {
    }

    default void wasExploded(class_3218 serverLevel, class_2338 blockPos, class_1927 explosion) {

    }
}
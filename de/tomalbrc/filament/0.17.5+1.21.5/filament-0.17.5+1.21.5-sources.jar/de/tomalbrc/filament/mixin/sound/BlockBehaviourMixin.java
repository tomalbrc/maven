package de.tomalbrc.filament.mixin.sound;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import de.tomalbrc.filament.sound.SoundFix;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_2498;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4970.class)
public class BlockBehaviourMixin {
    @ModifyReturnValue(method = "getSoundType", at = @At("RETURN"))
    private class_2498 filament$modifySoundType(class_2498 original) {
        if (FilamentConfig.getInstance().soundModule && SoundFix.REMIXES.containsKey(original))
            return SoundFix.REMIXES.get(original);

        return original;
    }
}

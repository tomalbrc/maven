package de.tomalbrc.filament.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1569;
import net.minecraft.class_1937;

public class FilamentEnemyMob extends FilamentMob implements class_1569 {
    public FilamentEnemyMob(class_1299<? extends class_1297> entityType, class_1937 level) {
        super(entityType, level);
    }
}

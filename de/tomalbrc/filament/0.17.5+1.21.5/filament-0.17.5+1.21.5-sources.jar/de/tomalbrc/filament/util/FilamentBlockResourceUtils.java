package de.tomalbrc.filament.util;

import de.tomalbrc.filament.sound.SoundFix;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceArrayMap;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_2680;

public final class FilamentBlockResourceUtils {
    private static final Map<BlockModelType, Map<PolymerBlockModel, class_2680>> MODEL_CACHE = new Object2ObjectArrayMap<>();

    public static @Nullable class_2680 requestBlock(BlockModelType type, PolymerBlockModel model, boolean virtual) {
        Map<PolymerBlockModel, class_2680> polymerBlockModelBlockStateMap = MODEL_CACHE.computeIfAbsent(type,  x -> new Object2ReferenceArrayMap<>());
        if (!virtual) {
            for (Map.Entry<PolymerBlockModel, class_2680> entry : polymerBlockModelBlockStateMap.entrySet()) {
                if (entry.getKey().equals(model)) {
                    return entry.getValue();
                }
            }
        }

        class_2680 state;
        if (virtual) {
            state = PolymerBlockResourceUtils.requestEmpty(type);
        } else {
            state = PolymerBlockResourceUtils.requestBlock(type, model);
        }

        if (!virtual)
            polymerBlockModelBlockStateMap.put(model, state);

        if (state != null)
            SoundFix.SOUND_TYPES.add(state.method_26231());

        return state;
    }
}
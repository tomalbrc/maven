package de.tomalbrc.filament.mixin.sound;

import de.tomalbrc.filament.sound.PolymerSoundBlock;
import de.tomalbrc.filament.sound.SoundFix;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2248.class)
public class BlockMixin {
    @Inject(method = "spawnDestroyParticles", at = @At("TAIL"))
    private void filament$spawnDestroyParticles(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState, CallbackInfo ci) {
        if (!FilamentConfig.getInstance().soundModule)
            return;

        class_2498 soundType = null;
        if (blockState.method_26204() instanceof PolymerSoundBlock) {
            soundType = blockState.method_26231();
        }
        else if (SoundFix.REMIXES.containsValue(blockState.method_26231())) {
            soundType = blockState.method_26231();
        }

        if (soundType != null)
            level.method_8396(null, blockPos, soundType.method_10595(), class_3419.field_15245, (soundType.method_10597() + 1.0f) / 2.0f, soundType.method_10599() * 0.8f);
    }
}

package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import net.minecraft.class_2680;
import org.jetbrains.annotations.NotNull;

/**
 * RemoveBlockGoal
 */
public class RemoveBlockGoal implements EntityBehaviour<RemoveBlockGoal.Config> {
    private final Config config;

    public RemoveBlockGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1382(config.block.method_26204(), mob, config.speedModifier, config.verticalSearchRange));
    }

    @Override
    @NotNull
    public RemoveBlockGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        class_2680 block;
        float speedModifier = 1.f;
        int verticalSearchRange = 3;
    }
}

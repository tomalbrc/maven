package de.tomalbrc.filament.entity;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.api.AnimatedEntityHolder;
import de.tomalbrc.bil.core.holder.entity.living.LivingEntityHolder;
import de.tomalbrc.filament.registry.ModelRegistry;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;

public class AnimatedFilamentMob extends FilamentMob implements AnimatedEntity {
    private final LivingEntityHolder<AnimatedFilamentMob> holder;

    public AnimatedFilamentMob(class_1299<? extends class_1297> entityType, class_1937 level) {
        super(entityType, level);

        this.holder = new LivingEntityHolder<>(this, ModelRegistry.getModel(Objects.requireNonNull(data.animation()).model()));
        EntityAttachment.ofTicking(this.holder, this);
    }

    @Override
    public AnimatedEntityHolder getHolder() {
        return this.holder;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.field_6012 % 2 == 0) {
            AnimationHelper.updateWalkAnimation(this, this.holder, data.animation());
            AnimationHelper.updateHurtColor(this, this.holder);
        }
    }
}

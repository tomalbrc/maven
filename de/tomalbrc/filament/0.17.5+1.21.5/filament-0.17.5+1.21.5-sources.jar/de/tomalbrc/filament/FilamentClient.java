package de.tomalbrc.filament;

import de.tomalbrc.filament.registry.BlockRegistry;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.registry.ItemRegistry;
import eu.pb4.polymer.resourcepack.impl.PolymerResourcePackMod;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_310;

public class FilamentClient {
    public static void init() {
        ServerPlayConnectionEvents.JOIN.register((serverGamePacketListener, sender, server) -> {
            if (!server.method_3816() && (!ItemRegistry.ITEMS_TAGS.isEmpty() || !BlockRegistry.BLOCKS_TAGS.isEmpty() || DecorationRegistry.REGISTERED_DECORATIONS > 0)) {
                PolymerResourcePackMod.generateAndCall(server, true, message -> {}, () -> class_310.method_1551().method_1521());
            }
        });
    }
}

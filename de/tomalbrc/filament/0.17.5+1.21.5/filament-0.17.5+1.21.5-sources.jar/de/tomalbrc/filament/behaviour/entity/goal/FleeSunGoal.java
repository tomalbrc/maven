package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import org.jetbrains.annotations.NotNull;

/**
 * FleeSunGoal
 */
public class FleeSunGoal implements EntityBehaviour<FleeSunGoal.Config> {
    private final Config config;

    public FleeSunGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1344(mob, config.speedModifier));
    }

    @Override
    @NotNull
    public FleeSunGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        float speedModifier = 1.f;
    }
}
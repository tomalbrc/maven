package de.tomalbrc.filament.mixin.component.skin;

import de.tomalbrc.filament.registry.FilamentComponents;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_9274;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public abstract class ItemMixin {
    @Inject(method = "overrideStackedOnOther", at = @At(value = "HEAD"), cancellable = true)
    private void filament$stackedOnOther(class_1799 itemStack, class_1735 slot, class_5536 clickAction, class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        if (!slot.method_32754(player)) return;

        var itemStack2 = slot.method_7677();
        // take out by clicking empty slot
        if (!itemStack2.method_7960() && !itemStack2.method_57826(FilamentComponents.SKIN_DATA_COMPONENT) && !itemStack.method_7960() && (itemStack.method_57826(FilamentComponents.SKIN_COMPONENT) && itemStack2.method_53187(itemStack.method_58694(FilamentComponents.SKIN_COMPONENT)))) { // overlay / add as skin
            itemStack2.method_57379(FilamentComponents.SKIN_DATA_COMPONENT, itemStack.method_46651(1));

            if (filament$isWearing(player, itemStack2)) {
                player.method_6116(player.method_32326(itemStack2), itemStack, itemStack2);
            }

            itemStack.method_57008(1, player);

            cir.setReturnValue(itemStack.method_7960());
        } else if (clickAction == class_5536.field_27014 && itemStack2.method_7960() && itemStack.method_57826(FilamentComponents.SKIN_DATA_COMPONENT)) {
            slot.method_7673(itemStack.method_58694(FilamentComponents.SKIN_DATA_COMPONENT));
            var old = itemStack.method_57381(FilamentComponents.SKIN_DATA_COMPONENT);

            if (filament$isWearing(player, itemStack)) {
                player.method_6116(player.method_32326(itemStack), old, itemStack2);
            }

            cir.setReturnValue(true);
        }
    }

    @Inject(method = "overrideOtherStackedOnMe", at = @At(value = "HEAD"), cancellable = true)
    private void filament$stackedOnMe(class_1799 itemStack, class_1799 itemStack2, class_1735 slot, class_5536 clickAction, class_1657 player, class_5630 slotAccess, CallbackInfoReturnable<Boolean> cir) {
        if (!slot.method_32754(player)) return;

        if (clickAction == class_5536.field_27014) {
            // insert or swap

            if (itemStack.method_57826(FilamentComponents.SKIN_DATA_COMPONENT) && itemStack2.method_7960()) {
                // Remove skin
                var stack = itemStack.method_58694(FilamentComponents.SKIN_DATA_COMPONENT).method_7972();
                var old = itemStack.method_57381(FilamentComponents.SKIN_DATA_COMPONENT);

                if (filament$isWearing(player, itemStack)) {
                    player.method_6116(player.method_32326(itemStack), old, itemStack2);
                }

                slotAccess.method_32332(stack);
                cir.setReturnValue(true);
            } else if (!itemStack.method_7960() && (itemStack.method_57826(FilamentComponents.SKIN_COMPONENT) && itemStack2.method_53187(itemStack.method_58694(FilamentComponents.SKIN_COMPONENT)))) {
                if (itemStack2.method_57826(FilamentComponents.SKIN_DATA_COMPONENT) && itemStack2.method_7947() == 1 && itemStack.method_7947() == 1) {
                    // swap skin of slot with that on the carried item
                    var itemStack2Copy = itemStack2.method_7972();
                    var old = itemStack2Copy.method_58694(FilamentComponents.SKIN_DATA_COMPONENT).method_7972();
                    itemStack2Copy.method_57379(FilamentComponents.SKIN_DATA_COMPONENT, itemStack.method_46651(1));
                    slot.method_7673(old);
                    slotAccess.method_32332(itemStack2Copy);

                    if (filament$isWearing(player, itemStack2Copy)) {
                        player.method_6116(player.method_32326(itemStack2Copy), old, itemStack2Copy);
                    }

                    cir.setReturnValue(true);
                } else {
                    // just insert (the item to skin "picks up" the skin by
                    // right-clicking a skin with the item to skin in the cursor slot
                    var old = itemStack2.method_57379(FilamentComponents.SKIN_DATA_COMPONENT, itemStack.method_46651(1));
                    if (filament$isWearing(player, itemStack)) {
                        player.method_6116(player.method_32326(itemStack), old, itemStack2);
                    }

                    itemStack.method_7939(itemStack.method_7947()-1);
                    cir.setReturnValue(true);
                }
            }
        }
    }

    @Unique
    private static boolean filament$isWearing(class_1657 player, class_1799 itemStack) {
        for (class_1304 slot : class_9274.field_49224.method_66665()) {
            class_1799 stack = player.method_6118(slot);
            if (stack == itemStack) {
                return true;
            }
        }
        return false;
    }
}

package de.tomalbrc.filament.api.behaviour;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public interface BlockBehaviourWithEntity<T> extends BlockBehaviour<T> {
    @Nullable
    static <E extends class_2586, A extends class_2586> class_5558<A> createTickerHelper(class_2591<A> blockEntityType, class_2591<E> blockEntityType2, class_5558<? super E> blockEntityTicker) {
        return blockEntityType2 == blockEntityType ? (class_5558<A>) blockEntityTicker : null;
    }

    default @Nullable class_2586 newBlockEntity(class_2338 blockPos, class_2680 blockState) {
        return null;
    }

    @Nullable
    default <A extends class_2586> class_5558<A> getTicker(class_1937 level, class_2680 blockState, class_2591<A> blockEntityType) {
        return null;
    }

    default class_2591<?> blockEntityType() {
        return null;
    }
}

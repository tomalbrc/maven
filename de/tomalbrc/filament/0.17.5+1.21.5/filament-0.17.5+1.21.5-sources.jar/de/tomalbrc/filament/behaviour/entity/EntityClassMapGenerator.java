package de.tomalbrc.filament.behaviour.entity;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class EntityClassMapGenerator {
    private static final Map<class_2960, Class<?>> ENTITY_CLASS_MAP = new HashMap<>();

    // not sure if there is a better way but this works for now
    static {
        Field[] fields = class_1299.class.getDeclaredFields();

        for (Field field : fields) {
            if (class_1299.class.isAssignableFrom(field.getType())) {
                try {
                    field.setAccessible(true);
                    class_1299<?> entityType = (class_1299<?>) field.get(null);
                    class_2960 id = class_7923.field_41177.method_10221(entityType);

                    Type genericType = field.getGenericType();
                    if (genericType instanceof ParameterizedType) {
                        Type actualType = ((ParameterizedType) genericType).getActualTypeArguments()[0];
                        if (actualType instanceof Class<?>) {
                            ENTITY_CLASS_MAP.put(id, (Class<?>) actualType);
                        }
                    }
                } catch (Exception e) {
                    throw new RuntimeException("Error extracting entity class from field: " + field.getName(), e);
                }
            }
        }
    }

    public static Class<?> getEntityClass(class_2960 id) {
        return ENTITY_CLASS_MAP.get(id);
    }

    public static Map<class_2960, Class<?>> getAllEntityClasses() {
        return ENTITY_CLASS_MAP;
    }
}


package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * TemptGoal
 */
public class TemptGoal implements EntityBehaviour<TemptGoal.Config> {
    private final Config config;

    public TemptGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1391(mob, config.speedModifier, x -> {
            if (config.items != null) {
                for (class_2960 resourceLocation : config.items) {
                    if (x.method_31574(class_7923.field_41178.method_63535(resourceLocation)))
                        return true;
                }
            }
            if (config.itemTags != null) {
                for (class_2960 resourceLocation : config.itemTags) {
                    if (x.method_31573(class_6862.method_40092(class_7924.field_41197, resourceLocation)))
                        return true;
                }
            }
            return false;
        }, config.canScare));
    }

    @Override
    @NotNull
    public TemptGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        float speedModifier = 1.f;
        boolean canScare;
        Set<class_2960> items;
        Set<class_2960> itemTags;
    }
}
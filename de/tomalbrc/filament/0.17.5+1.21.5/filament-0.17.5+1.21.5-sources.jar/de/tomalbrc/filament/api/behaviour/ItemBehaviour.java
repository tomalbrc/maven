package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7225;

public interface ItemBehaviour<T> extends Behaviour<T> {
    default void init(class_1792 item, BehaviourHolder behaviourHolder) {
    }

    default void appendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 tooltipFlag) {
    }

    default class_1269 use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        return class_1269.field_5811;
    }

    default Optional<Integer> getUseDuration(class_1799 itemStack, class_1309 livingEntity) {
        return Optional.empty();
    }

    default class_1839 getUseAnimation(class_1799 itemStack) {
        return class_1839.field_8952;
    }

    default class_1269 useOn(class_1838 useOnContext) {
        return class_1269.field_5811;
    }

    default void onUseTick(class_1937 level, class_1309 livingEntity, class_1799 itemStack, int i) {
    }

    default boolean releaseUsing(class_1799 itemStack, class_1937 level, class_1309 livingEntity, int useDuration) {
        return false;
    }

    default boolean useOnRelease(class_1799 itemStack) {
        return false;
    }

    default void modifyPolymerItemStack(Map<String, class_2960> models, class_1799 original, class_1799 replacement, class_1836 tooltipType, class_7225.class_7874 lookup, @Nullable class_3222 player) {
    }

    default boolean mineBlock(class_1799 itemStack, class_1937 level, class_2680 blockState, class_2338 blockPos, class_1309 livingEntity) {
        return false;
    }

    default void hurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
    }

    default void postHurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {}

    default float getAttackDamageBonus(class_1297 entity, float f, class_1282 damageSource) {
        return 0.f;
    }

    default @Nullable class_1282 getDamageSource(class_1309 livingEntity) {
        return null;
    }
}

package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.Data;
import java.util.Map;
import net.minecraft.class_2960;

public interface FilamentItem extends BehaviourHolder {
    FilamentItemDelegate getDelegate();

    Data getData();

    default Map<String, class_2960> getModelMap() {
        var resource = this.getData().preferredResource();
        var defaultResource = this.getData().itemResource();
        return resource != null ? resource.getModels() : defaultResource != null ? defaultResource.getModels() : null;
    }
}

package de.tomalbrc.filament.registry;

import com.google.common.base.Suppliers;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class OxidizableRegistry {
    private static final BiMap<class_2248, class_2960> oxidizables = HashBiMap.create();

    private static final Supplier<BiMap<class_2248, class_2960>> OXIDIZABLES_NEXT = Suppliers.memoize(() -> oxidizables);
    private static final Supplier<BiMap<class_2960, class_2248>> OXIDIZABLES_PREVIOUS = Suppliers.memoize(() -> OXIDIZABLES_NEXT.get().inverse());

    public static class_2248 getNext(class_2248 block) {
        return class_7923.field_41175.method_63535(oxidizables.get(block));
    }

    public static class_2248 getPrevious(class_2248 block) {
        return OXIDIZABLES_PREVIOUS.get().get(class_7923.field_41175.method_10221(block));
    }

    public static boolean hasNext(class_2248 block) {
        return OXIDIZABLES_NEXT.get().containsKey(block);
    }

    public static boolean hasPrevious(class_2248 block) {
        return OXIDIZABLES_PREVIOUS.get().containsKey(class_7923.field_41175.method_10221(block));
    }

    public static void add(class_2248 block, class_2960 replacement) {
        oxidizables.putIfAbsent(block, replacement);
    }
}

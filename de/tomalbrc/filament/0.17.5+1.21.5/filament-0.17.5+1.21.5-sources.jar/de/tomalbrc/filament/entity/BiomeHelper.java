package de.tomalbrc.filament.entity;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_6862;
import java.util.function.Predicate;

public class BiomeHelper {
    public static void addSpawn(class_1299<?> type, int weight, int minGroupSize, int maxGroupSize, Predicate<BiomeSelectionContext> selector) {
        BiomeHelper.addSpawn(type, type.method_5891(), weight, minGroupSize, maxGroupSize, selector);
    }

    public static void addSpawn(class_1299<?> type, class_1311 category, int weight, int minGroupSize, int maxGroupSize, Predicate<BiomeSelectionContext> selector) {
        BiomeModifications.addSpawn(selector, category, type, weight, minGroupSize, maxGroupSize);
    }

    public static Predicate<BiomeSelectionContext> excludeTag(class_6862<class_1959> tag) {
        return context -> !context.hasTag(tag);
    }

    public static Predicate<BiomeSelectionContext> includeTag(class_6862<class_1959> tag) {
        return context -> context.hasTag(tag);
    }
}

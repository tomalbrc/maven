package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface EntityInvoker {
    @Invoker(value = "applyMovementEmissionAndPlaySound")
    void invokeApplyMovementEmissionAndPlaySound(class_1297.class_5799 movementEmission, class_243 vec3, class_2338 blockPos, class_2680 blockState);
}

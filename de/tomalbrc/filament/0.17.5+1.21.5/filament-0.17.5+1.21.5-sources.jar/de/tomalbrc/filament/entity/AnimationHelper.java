package de.tomalbrc.filament.entity;

import de.tomalbrc.bil.api.AnimatedHolder;
import de.tomalbrc.bil.api.Animator;
import de.tomalbrc.filament.data.EntityData;
import net.minecraft.class_1309;

public class AnimationHelper {
    public static void updateWalkAnimation(class_1309 entity, AnimatedHolder holder, EntityData.AnimationInfo animationInfo) {
        Animator animator = holder.getAnimator();
        if (entity.field_42108.method_48571() && entity.field_42108.method_48566() > 0.02) {
            animator.pauseAnimation(animationInfo.idleAnimation());
            animator.playAnimation(animationInfo.walkAnimation(), 0);
        } else {
            animator.pauseAnimation(animationInfo.walkAnimation());
            animator.playAnimation(animationInfo.idleAnimation(), 0);
        }
    }

    public static void updateAquaticWalkAnimation(class_1309 entity, AnimatedHolder holder) {
        Animator animator = holder.getAnimator();
        if (entity.method_5799()) {
            if ((entity.method_18798().method_1033() > 0.05 || entity.field_42108.method_48566() > 0.02)) {
                animator.pauseAnimation("idle");
                animator.pauseAnimation("walk");
                animator.playAnimation("swim");
            } else {
                animator.pauseAnimation("swim");
                animator.pauseAnimation("walk");
                animator.playAnimation("idle");
            }
        } else {
            if (entity.field_42108.method_48571() && entity.field_42108.method_48566() > 0.02) {
                animator.pauseAnimation("idle");
                animator.pauseAnimation("swim");
                animator.playAnimation("walk");
            } else {
                animator.pauseAnimation("swim");
                animator.pauseAnimation("walk");
                animator.playAnimation("idle");
            }
        }
    }

    public static void updateFishAnimation(class_1309 entity, AnimatedHolder holder) {
        Animator animator = holder.getAnimator();
        if (entity.method_5799()) {
            animator.pauseAnimation("idle");
            animator.pauseAnimation("walk");
            animator.playAnimation("swim");
        } else {
            animator.pauseAnimation("idle");
            animator.pauseAnimation("swim");
            animator.playAnimation("walk");
        }
    }

    public static void updateHurtColor(class_1309 entity, AnimatedHolder holder) {
        if (entity.field_6235 > 0 || entity.field_6213 > 0)
            holder.setColor(0xff7e7e);
        else
            holder.clearColor();
    }
}
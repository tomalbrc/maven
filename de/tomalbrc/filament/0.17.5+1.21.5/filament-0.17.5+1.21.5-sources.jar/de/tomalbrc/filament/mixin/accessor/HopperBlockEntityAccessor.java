package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2614;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2614.class)
public interface HopperBlockEntityAccessor {
    @Invoker(value = "isOnCooldown")
    boolean invokeIsOnCooldown();

    @Invoker(value = "inventoryFull")
    boolean invokeInventoryFull();

    @Accessor(value = "cooldownTime")
    int cooldownTime();

    @Accessor(value = "cooldownTime")
    void setCooldownTime(int time);

    @Accessor(value = "tickedGameTime")
    void setTickedGameTime(long time);

    @Invoker(value = "ejectItems")
    static boolean invokeEjectItems(class_1937 level, class_2338 blockPos, class_2614 hopperBlockEntity) {
        throw new UnsupportedOperationException();
    }

    @Invoker(value = "getSlots")
    static int[] invokeGetSlots(class_1263 container, class_2350 direction) {
        throw new UnsupportedOperationException();
    }
}

package de.tomalbrc.filament.mixin.sound;

import de.tomalbrc.filament.sound.PolymerSoundBlock;
import de.tomalbrc.filament.sound.SoundFix;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3225;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// handle mining sounds
@Mixin(class_3225.class)
public class ServerPlayerGameModeMixin {
    @Shadow protected class_3218 level;

    @Shadow private int gameTicks;

    @Inject(method = "incrementDestroyProgress", at = @At("HEAD"))
    private void filament$soundMine(class_2680 blockState, class_2338 blockPos, int startTime, CallbackInfoReturnable<Float> cir) {
        var destroyTicks = (gameTicks - startTime) - 1;
        if (FilamentConfig.getInstance().soundModule && (blockState.method_26204() instanceof PolymerSoundBlock || SoundFix.REMIXES.containsValue(blockState.method_26231())) && destroyTicks % 4 == 0) {
            class_2498 soundType = blockState.method_26231();
            level.method_8396(null, blockPos, soundType.method_10596(), class_3419.field_15245, (soundType.method_10597() + 1.0f) / 8.0f, soundType.method_10599() * 0.5f);
        }
    }
}

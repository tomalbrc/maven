package de.tomalbrc.filament.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1821;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

@Mixin(class_1821.class)
public interface ShovelItemAccessor {
    @Accessor
    static Map<class_2248, class_2680> getFLATTENABLES() {
        throw new UnsupportedOperationException();
    }
}

package de.tomalbrc.filament.behaviour.item;

import com.mojang.datafixers.util.Pair;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1794;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Hoe behaviour
 */
public class Hoe implements ItemBehaviour<Hoe.Config> {
    private final Config config;

    public Hoe(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Hoe.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1269 useOn(class_1838 useOnContext) {
        class_1937 level = useOnContext.method_8045();
        class_2338 blockPos = useOnContext.method_8037();
        Pair<Predicate<class_1838>, Consumer<class_1838>> pair = class_1794.field_8023.get(level.method_8320(blockPos).method_26204());
        if (pair == null) {
            return class_1269.field_5811;
        } else {
            Predicate<class_1838> predicate = pair.getFirst();
            Consumer<class_1838> consumer = pair.getSecond();
            if (predicate.test(useOnContext)) {
                class_1657 player = useOnContext.method_8036();
                level.method_8396(player, blockPos, class_3414.method_47908(config.sound), class_3419.field_15245, 1.0F, 1.0F);
                if (!level.field_9236) {
                    consumer.accept(useOnContext);
                    if (player != null) {
                        useOnContext.method_8041().method_7970(1, player, class_1309.method_56079(useOnContext.method_20287()));
                    }
                }

                return class_1269.field_5812;
            } else {
                return class_1269.field_5811;
            }
        }
    }

    public static class Config {
        public class_2960 sound = class_3417.field_14846.comp_3319();
    }
}
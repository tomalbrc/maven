package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import org.jetbrains.annotations.NotNull;

/**
 * RandomSwimmingGoal
 */
public class RandomSwimmingGoal implements EntityBehaviour<RandomSwimmingGoal.Config> {
    private final Config config;

    public RandomSwimmingGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1378(mob, config.speedModifier, config.interval));
    }

    @Override
    @NotNull
    public RandomSwimmingGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        float speedModifier = 1.f;
        int interval = 240;
    }
}
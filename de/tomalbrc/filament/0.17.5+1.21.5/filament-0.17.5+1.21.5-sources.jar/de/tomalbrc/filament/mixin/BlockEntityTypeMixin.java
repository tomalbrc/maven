package de.tomalbrc.filament.mixin;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import de.tomalbrc.filament.block.SimpleBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

@Mixin(class_2591.class)
public class BlockEntityTypeMixin {
    @Inject(method = "isValid", at = @At(value = "HEAD"), cancellable = true)
    private void filament$isValid(class_2680 blockState, CallbackInfoReturnable<Boolean> cir) {
        if (blockState.method_26204() instanceof SimpleBlock simpleBlock) {
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : simpleBlock.getBehaviours()) {
                if (behaviour.getValue() instanceof BlockBehaviourWithEntity<?> blockBehaviourWithEntity && class_2591.class.cast(this) == blockBehaviourWithEntity.blockEntityType()) {
                    cir.setReturnValue(true);
                    return;
                }
            }
        }
    }
}
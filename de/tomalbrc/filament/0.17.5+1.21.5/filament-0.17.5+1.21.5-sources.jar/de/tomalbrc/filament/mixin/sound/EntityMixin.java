package de.tomalbrc.filament.mixin.sound;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.sound.PolymerSoundBlock;
import de.tomalbrc.filament.sound.SoundFix;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

// actually send step sounds, not just locally or for everyone but the player in case of the Player class
@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Shadow public abstract class_1937 level();

    @Shadow public abstract double getX();
    @Shadow public abstract double getY();
    @Shadow public abstract double getZ();

    @Shadow public abstract class_3419 getSoundSource();

    @WrapOperation(method = "playCombinationStepSounds", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;playSound(Lnet/minecraft/sounds/SoundEvent;FF)V"))
    private void filament$combinationStepSounds(class_1297 instance, class_3414 soundEvent, float f, float g, Operation<Void> original, @Local(ordinal = 0, argsOnly = true) class_2680 blockState) {
        if (FilamentConfig.getInstance().soundModule && (Object)this instanceof class_3222 && blockState.method_26204() instanceof PolymerSoundBlock || SoundFix.REMIXES.containsValue(blockState.method_26231()))
            this.level().method_43128(null, this.getX(), this.getY(), this.getZ(), soundEvent, this.getSoundSource(), f, g);
        else
            original.call(instance, soundEvent, f, g);
    }

    @WrapOperation(method = "playMuffledStepSound", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;playSound(Lnet/minecraft/sounds/SoundEvent;FF)V"))
    private void filament$muffledStepSounds(class_1297 instance, class_3414 soundEvent, float f, float g, Operation<Void> original, @Local(ordinal = 0, argsOnly = true) class_2680 blockState) {
        if (FilamentConfig.getInstance().soundModule && (Object)this instanceof class_3222 && blockState.method_26204() instanceof PolymerSoundBlock || SoundFix.REMIXES.containsValue(blockState.method_26231()))
            this.level().method_43128(null, this.getX(), this.getY(), this.getZ(), soundEvent, this.getSoundSource(), f, g);
        else
            original.call(instance, soundEvent, f, g);
    }

    @WrapOperation(method = "playStepSound", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;playSound(Lnet/minecraft/sounds/SoundEvent;FF)V"))
    private void filament$stepSounds(class_1297 instance, class_3414 soundEvent, float f, float g, Operation<Void> original, @Local(ordinal = 0, argsOnly = true) class_2680 blockState) {
        if (FilamentConfig.getInstance().soundModule && (Object)this instanceof class_3222 && blockState.method_26204() instanceof PolymerSoundBlock || SoundFix.REMIXES.containsValue(blockState.method_26231()))
            this.level().method_43128(null, this.getX(), this.getY(), this.getZ(), soundEvent, this.getSoundSource(), f, g);
        else
            original.call(instance, soundEvent, f, g);
    }
}

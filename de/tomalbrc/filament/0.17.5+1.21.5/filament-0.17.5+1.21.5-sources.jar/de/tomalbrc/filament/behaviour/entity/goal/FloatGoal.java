package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import org.jetbrains.annotations.NotNull;

/**
 * Float goal
 */
public class FloatGoal implements EntityBehaviour<FloatGoal.Config> {
    private final Config config;

    public FloatGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1347(mob));
    }

    @Override
    @NotNull
    public FloatGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
    }
}
package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_1533;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1533.class)
public interface ItemFrameAccessor {
    @Accessor
    static class_2940<Integer> getDATA_ROTATION() {
        throw new UnsupportedOperationException();
    }
}

package de.tomalbrc.filament.mixin.behaviour.trident;

import net.minecraft.class_1685;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1685.class})
public interface ThrownTridentAccessor {
    @Accessor
    static class_2940<Byte> getID_LOYALTY() {
        throw new UnsupportedOperationException();
    }

    @Accessor
    static class_2940<Boolean> getID_FOIL() {
        throw new UnsupportedOperationException();
    }
}
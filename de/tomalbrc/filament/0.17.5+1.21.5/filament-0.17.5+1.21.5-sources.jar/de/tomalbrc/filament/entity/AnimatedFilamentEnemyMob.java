package de.tomalbrc.filament.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;

public class AnimatedFilamentEnemyMob extends FilamentEnemyMob {
    public AnimatedFilamentEnemyMob(class_1299<? extends class_1297> entityType, class_1937 level) {
        super(entityType, level);
    }
}

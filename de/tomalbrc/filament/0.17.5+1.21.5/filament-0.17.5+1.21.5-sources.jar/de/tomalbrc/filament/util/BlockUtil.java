package de.tomalbrc.filament.util;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class BlockUtil {
    public static void handleBoneMealEffects(class_3218 level, class_2338 blockPos) {
        level.method_8396(null, blockPos, class_3417.field_33433, class_3419.field_15245, 1.0f, 1.0f);
        level.method_65096(class_2398.field_11211, blockPos.method_46558().field_1352, blockPos.method_46558().field_1351, blockPos.method_46558().field_1350, 15, 0.25, 0.25, 0.25, 0.15);
    }

    public static void handleBlockPlaceEffects(class_3222 player, class_1268 hand, class_2338 pos, class_2498 type) {
        player.method_23667(hand, true);
        playBlockPlaceSound(player, pos, type);
    }

    public static void playBlockPlaceSound(class_3222 player, class_2338 pos, class_2498 type) {
        player.method_51469().method_8396(null, pos, type.method_10598(), class_3419.field_15245, (type.method_10597() + 1.0F) / 2.0F, type.method_10599() * 0.8F);
    }
}

package de.tomalbrc.filament.mixin.sound;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.sound.PolymerSoundBlock;
import de.tomalbrc.filament.sound.SoundFix;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

// play fall sounds serverside
@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @WrapOperation(method = "playBlockFallSound", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;playSound(Lnet/minecraft/sounds/SoundEvent;FF)V"))
    private void filament$stepSounds(class_1309 instance, class_3414 soundEvent, float vol, float pitch, Operation<Void> original, @Local class_2680 blockState) {
        if (FilamentConfig.getInstance().soundModule && (Object)this instanceof class_3222 && blockState.method_26204() instanceof PolymerSoundBlock || SoundFix.REMIXES.containsValue(blockState.method_26231()))
            this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(), soundEvent, this.method_5634(), vol, pitch);
        else
            original.call(instance, soundEvent, vol, pitch);
    }
}

package de.tomalbrc.filament.mixin.behaviour.execute;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.ExecuteAttackItem;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1799;
import net.minecraft.class_2879;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImplMixin {
    @Shadow public class_3222 player;

    @Inject(method = "handleAnimate", at = @At("TAIL"))
    private void filament$handleSwing(class_2879 serverboundSwingPacket, CallbackInfo ci) {
        class_1799 item = this.player.method_5998(serverboundSwingPacket.method_12512());
        if (item.method_7909() instanceof SimpleItem simpleItem) {
            ExecuteAttackItem ex = simpleItem.get(Behaviours.ITEM_ATTACK_EXECUTE);
            if (ex != null && !ex.getConfig().onEntityAttack) {
                ex.runCommandItem(this.player, simpleItem, serverboundSwingPacket.method_12512());
            }
        }
    }
}

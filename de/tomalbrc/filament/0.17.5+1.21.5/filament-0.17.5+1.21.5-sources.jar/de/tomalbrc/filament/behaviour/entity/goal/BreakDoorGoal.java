package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import net.minecraft.class_1267;

/**
 * BreakDoorGoal
 */
public class BreakDoorGoal implements EntityBehaviour<BreakDoorGoal.Config> {
    private final Config config;

    public BreakDoorGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1339(mob, config.doorBreakTime, difficulty -> {
            if (config.validDifficulties != null) {
                return config.validDifficulties.contains(difficulty);
            }
            return true;
        }));
    }

    @Override
    @NotNull
    public BreakDoorGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        int doorBreakTime = 240;
        Set<class_1267> validDifficulties;
    }
}
package de.tomalbrc.filament.decoration.util;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.mixin.accessor.ItemFrameAccessor;
import eu.pb4.polymer.core.mixin.entity.ItemFrameEntityAccessor;
import eu.pb4.polymer.virtualentity.api.elements.GenericEntityElement;
import eu.pb4.polymer.virtualentity.api.tracker.DataTrackerLike;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import eu.pb4.polymer.virtualentity.api.tracker.SimpleDataTracker;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_3222;

public class ItemFrameElement extends GenericEntityElement {
    final private DecorationBlockEntity parent;

    public ItemFrameElement(DecorationBlockEntity source) {
        super();

        this.parent = source;

        this.sendTrackerUpdates();

        var stack = source.visualItemStack();

        this.dataTracker.set(EntityTrackedData.FLAGS, (byte) 0);
        this.dataTracker.set(ItemFrameEntityAccessor.getITEM_STACK(), stack);
        this.dataTracker.set(ItemFrameAccessor.getDATA_ROTATION(), source.getRotation());
        this.setInvisible(true);

        this.setInteractionHandler(new InteractionHandler() {
            @Override
            public void interact(class_3222 player, class_1268 hand) {
                InteractionHandler.super.interact(player, hand);
                source.interact(player, hand, player.method_19538());
            }

            @Override
            public void attack(class_3222 player) {
                InteractionHandler.super.attack(player);
                source.destroyStructure(true);
            }
        });
    }

    @Override
    protected class_1299<? extends class_1297> getEntityType() {
        return parent.getDecorationData().properties().glow ? class_1299.field_28401 : class_1299.field_6043;
    }

    @Override
    protected class_2596<class_2602> createSpawnPacket(class_3222 player) {
        var pos = Objects.requireNonNull(this.getHolder()).getPos().method_1019(this.getOffset());
        return new class_2604(this.getEntityId(), this.getUuid(), pos.field_1352, pos.field_1351, pos.field_1350, this.getPitch(), this.getYaw(), this.getEntityType(), this.parent.getDirection().method_10146(), class_243.field_1353, this.getYaw());
    }

    @Override
    protected DataTrackerLike createDataTracker() {
        return new SimpleDataTracker(class_1299.field_6043);
    }
}
package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;

/**
 * PanicGoal
 */
public class PanicGoal implements EntityBehaviour<PanicGoal.Config> {
    private final Config config;

    public PanicGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new net.minecraft.class_1374(mob, config.speedModifier, class_6862.method_40092(class_7924.field_42534, config.damageType)));
    }

    @Override
    @NotNull
    public PanicGoal.Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        float speedModifier = 1.f;
        class_2960 damageType = class_8103.field_51990.comp_327();
    }
}
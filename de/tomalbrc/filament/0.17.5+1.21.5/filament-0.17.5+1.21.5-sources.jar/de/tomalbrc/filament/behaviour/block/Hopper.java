package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.mixin.accessor.HopperBlockEntityAccessor;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import net.minecraft.class_10;
import net.minecraft.class_10774;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1278;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2614;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3481;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9904;

public class Hopper implements BlockBehaviourWithEntity<Hopper.Config> {
    private final Config config;

    public Hopper(Config config) {
        this.config = config;
    }

    @Override
    public class_2591<?> blockEntityType() {
        return class_2591.field_11888;
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 blockState, class_1750 blockPlaceContext) {
        class_2350 direction = blockPlaceContext.method_8038().method_10153();
        return blockState.method_11657(class_2741.field_12545, direction.method_10166() == class_2350.class_2351.field_11052 ? class_2350.field_11033 : direction).method_11657(class_2741.field_12515, true);
    }

    @Override
    public class_2586 newBlockEntity(class_2338 blockPos, class_2680 blockState) {
        return new class_2614(blockPos, blockState);
    }

    @Override
    @Nullable
    public <T extends class_2586> class_5558<T> getTicker(class_1937 level, class_2680 blockState, class_2591<T> blockEntityType) {
        return level.field_9236 ? null : BlockBehaviourWithEntity.createTickerHelper(blockEntityType, class_2591.field_11888, Hopper::pushItemsTick);
    }

    public static void pushItemsTick(class_1937 level, class_2338 blockPos, class_2680 blockState, class_2614 hopperBlockEntity) {
        HopperBlockEntityAccessor accessor = ((HopperBlockEntityAccessor) hopperBlockEntity);
        accessor.setCooldownTime(accessor.cooldownTime() - 1);
        accessor.setTickedGameTime(level.method_8510());
        if (!accessor.invokeIsOnCooldown()) {
            accessor.setCooldownTime(0);
            Config conf = get(hopperBlockEntity).config;
            tryMoveItems(level, blockPos, blockState, hopperBlockEntity, () -> suckInItems(level, hopperBlockEntity), conf);
        }
    }

    protected static void setChanged(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        level.method_8524(blockPos);
        if (!blockState.method_26215()) {
            level.method_8455(blockPos, blockState.method_26204());
        }
    }

    private static void tryMoveItems(class_1937 level, class_2338 blockPos, class_2680 blockState, class_2614 hopperBlockEntity, BooleanSupplier booleanSupplier, Config config) {
        if (!level.field_9236) {
            if (!((HopperBlockEntityAccessor) hopperBlockEntity).invokeIsOnCooldown() && blockState.method_11654(class_2377.field_11126)) {
                boolean changed = false;
                if (!hopperBlockEntity.method_5442()) {
                    changed = HopperBlockEntityAccessor.invokeEjectItems(level, blockPos, hopperBlockEntity);
                }

                if (!((HopperBlockEntityAccessor) hopperBlockEntity).invokeInventoryFull()) {
                    changed |= booleanSupplier.getAsBoolean();
                }

                if (changed) {
                    ((HopperBlockEntityAccessor) hopperBlockEntity).setCooldownTime(config.cooldownTime);
                    setChanged(level, blockPos, blockState);
                }
            }
        }
    }

    public static boolean suckInItems(class_1937 level, class_2614 hopper) {
        var conf = get(hopper).config;

        class_2338 blockPos = class_2338.method_49637(hopper.method_11266(), hopper.method_11264() + 1.0, hopper.method_11265());
        class_2680 blockState = level.method_8320(blockPos);
        class_1263 container = class_2614.method_11250(level, blockPos);
        if (container != null && conf.takeFromContainer) {
            class_2350 direction = class_2350.field_11033;
            for (int i : HopperBlockEntityAccessor.invokeGetSlots(container, direction)) {
                if (tryTakeInItemFromSlot(hopper, container, i, direction)) {
                    return true;
                }
            }
        } else if (container == null && conf.pickupItemEntities) {
            boolean fullBlockShape = blockState.method_26234(level, blockPos) && !blockState.method_26164(class_3481.field_49147);
            if (!fullBlockShape) {
                for (class_1542 itemEntity : class_2614.method_11237(level, hopper)) {
                    if (conf.canTake(itemEntity.method_6983()) && class_2614.method_11247(hopper, itemEntity)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean tryTakeInItemFromSlot(class_2614 hopper, class_1263 container, int i, class_2350 direction) {
        class_1799 itemStack = container.method_5438(i);
        if (!itemStack.method_7960() && canTakeItemFromContainer(hopper, container, itemStack, i, direction)) {
            int count = itemStack.method_7947();
            class_1799 itemStack2 = class_2614.method_11260(container, hopper, container.method_5434(i, 1), null);
            if (itemStack2.method_7960()) {
                container.method_5431();
                return true;
            }

            itemStack.method_7939(count);
            if (count == 1) {
                container.method_5447(i, itemStack);
            }
        }

        return false;
    }

    private static boolean canTakeItemFromContainer(class_2614 hopperContainer, class_1263 container2, class_1799 itemStack, int i, class_2350 direction) {
        var self = get(hopperContainer);

        if (!container2.method_49104(hopperContainer, i, itemStack) || !self.config.canTake(itemStack)) {
            return false;
        } else {
            return !(container2 instanceof class_1278 worldlyContainer) || worldlyContainer.method_5493(i, itemStack, direction);
        }
    }

    private static Hopper get(class_2614 hopperBlockEntity) {
        return ((SimpleBlock) hopperBlockEntity.method_11010().method_26204()).get(Behaviours.HOPPER);
    }

    @Override
    public void onPlace(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2680 blockState2, boolean bl) {
        if (!blockState2.method_27852(blockState.method_26204())) {
            this.checkPoweredState(level, blockPos, blockState);
        }
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (!level.field_9236) {
            if (level.method_8321(blockPos) instanceof class_2614 hopperBlockEntity) {
                player.method_17355(hopperBlockEntity);
                player.method_7281(class_3468.field_15366);
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public void neighborChanged(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, @Nullable class_9904 orientation, boolean bl) {
        this.checkPoweredState(level, blockPos, blockState);
    }

    private void checkPoweredState(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        boolean bl = !level.method_49803(blockPos);
        if (bl != blockState.method_11654(class_2741.field_12515)) {
            level.method_8652(blockPos, blockState.method_11657(class_2741.field_12515, bl), class_2248.field_31028);
        }
    }

    @Override
    public void affectNeighborsAfterRemoval(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, boolean bl) {
        class_1264.method_66221(blockState, serverLevel, blockPos);
    }

    @Override
    public Optional<Boolean> hasAnalogOutputSignal(class_2680 blockState) {
        return Optional.of(true);
    }

    @Override
    public int getAnalogOutputSignal(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return class_1703.method_7608(level.method_8321(blockPos));
    }

    @Override
    public class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return blockState.method_11657(class_2741.field_12545, rotation.method_10503(blockState.method_11654(class_2741.field_12545)));
    }

    @Override
    public class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return blockState.method_26186(mirror.method_10345(blockState.method_11654(class_2741.field_12545)));
    }

    @Override
    public boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12545, class_2741.field_12515);
        return true;
    }

    @Override
    public void entityInside(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1297 entity, class_10774 insideBlockEffectApplier) {
        class_2586 blockEntity = level.method_8321(blockPos);
        if (blockEntity instanceof class_2614) {
            class_2614.method_11236(level, blockPos, blockState, entity, (class_2614) blockEntity);
        }
    }

    @Override
    public Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
        return Optional.of(false);
    }

    @Override
    @NotNull
    public Hopper.Config getConfig() {
        return this.config;
    }

    public static class Config {
        public List<String> filterItems;
        public boolean pickupItemEntities = true;
        public boolean takeFromContainer = true;
        public int cooldownTime = 8;

        transient public List<class_1792> itemFilter;
        transient public List<class_6862<class_1792>> itemTagFilter;

        public boolean canTake(class_1799 itemStack) {
            if (this.itemFilter == null) {
                this.itemFilter = new ObjectArrayList<>();
                this.itemTagFilter = new ObjectArrayList<>();
                if (this.filterItems != null) {
                    for (String string : this.filterItems) {
                        if (string.startsWith("#")) {
                            this.itemTagFilter.add(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654(string.substring(1))));
                        } else {
                            this.itemFilter.add(class_7923.field_41178.method_63535(class_2960.method_60654(string)));
                        }
                    }
                }
            }

            for (class_1792 item : this.itemFilter) {
                if (itemStack.method_31574(item)) return true;
            }
            for (class_6862<class_1792> tagKey : this.itemTagFilter) {
                if (itemStack.method_31573(tagKey)) return true;
            }

            return this.itemTagFilter.isEmpty() && this.itemFilter.isEmpty();
        }
    }
}
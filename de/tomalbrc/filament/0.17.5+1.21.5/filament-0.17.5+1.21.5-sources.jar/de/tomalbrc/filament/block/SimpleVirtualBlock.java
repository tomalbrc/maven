package de.tomalbrc.filament.block;

import com.google.common.collect.ImmutableList;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.util.DecorationUtil;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.BlockAwareAttachment;
import eu.pb4.polymer.virtualentity.api.attachment.BlockBoundAttachment;
import eu.pb4.polymer.virtualentity.api.attachment.HolderAttachment;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.mixin.accessors.ItemDisplayEntityAccessor;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import org.apache.http.annotation.Obsolete;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_811;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

public class SimpleVirtualBlock extends SimpleBlock implements BlockWithElementHolder {
    private final Map<BlockData.BlockStateMeta, String> cmdMap = new Reference2ObjectOpenHashMap<>();

    public SimpleVirtualBlock(class_2251 properties, BlockData data) {
        super(properties, data);
    }

    @Obsolete
    public void postRegister() {
        super.postRegister();

        for (Map.Entry<class_2680, BlockData.BlockStateMeta> stateMapEntry : this.stateMap.entrySet()) {
            for (Map.Entry<String, class_2960> blockResourceModelsEntry : this.blockData.blockResource().getModels().entrySet()) {
                boolean same = blockResourceModelsEntry.getValue().equals(stateMapEntry.getValue().polymerBlockModel().model());
                if (same) {
                    this.cmdMap.put(stateMapEntry.getValue(), blockResourceModelsEntry.getKey());
                }
            }
        }
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 blockState, PacketContext packetContext) {
        if (this.blockData.block() != null) {
            return this.blockData.block();
        }

        return super.getPolymerBlockState(blockState, packetContext);
    }

    @Nullable
    public ElementHolder createElementHolder(class_3218 world, class_2338 pos, class_2680 initialBlockState) {
        return new VirtualBlockHolder(initialBlockState);
    }

    public static class VirtualBlockHolder extends ElementHolder {
        @NotNull private final SimpleVirtualBlock virtualBlock;
        @NotNull private final class_1799 displayStack;
        @NotNull private final ItemDisplayElement displayElement;

        public VirtualBlockHolder(class_2680 blockState) {
            this.virtualBlock = (SimpleVirtualBlock) blockState.method_26204();
            this.displayStack = this.virtualBlock.method_8389().method_7854();
            this.displayStack.method_57379(class_9334.field_54199, virtualBlock.blockData.id().method_45138("block/"));

            this.displayElement = new ItemDisplayElement(this.displayStack);
            this.displayElement.setItemDisplayContext(class_811.field_4315);
            this.displayElement.setScale(new Vector3f(1.0001f));
            this.displayElement.setDisplaySize(1.f, 1.f);
            this.displayElement.setInvisible(true);
            update(blockState, false);
            this.addElement(this.displayElement);
        }

        private BlockAwareAttachment attachment() {
            return (BlockAwareAttachment) this.getAttachment();
        }

        public void update(class_2680 blockState, boolean update) {
            var state = this.virtualBlock.behaviourFilteredBlockState(blockState);
            var meta = this.virtualBlock.stateMap.get(state);
            this.displayStack.method_57379(class_9334.field_49637, new class_9280(
                    ImmutableList.of(),
                    ImmutableList.of(),
                    ImmutableList.of(this.virtualBlock.cmdMap.get(meta)),
                    ImmutableList.of()
            ));

            var polymerBlockModel = meta.polymerBlockModel();
            this.displayElement.setLeftRotation(new Quaternionf().rotateX(polymerBlockModel.x() * class_3532.field_29847).rotateY((-polymerBlockModel.y()+180) * class_3532.field_29847));
            if (update) {
                this.displayElement.getDataTracker().setDirty(ItemDisplayEntityAccessor.getITEM(), true);
                this.displayElement.tick();
            }
        }

        @Override
        public void notifyUpdate(HolderAttachment.UpdateType updateType) {
            super.notifyUpdate(updateType);

            var attachment = this.attachment();
            if (updateType == BlockBoundAttachment.BLOCK_STATE_UPDATE && attachment != null) {
                this.update(attachment.getBlockState(), true);
            }
        }
    }

    @Override
    protected void method_33614(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState) {
        var attachment = BlockBoundAttachment.get(player.method_37908(), blockPos);
        if (attachment != null && player.method_37908() instanceof class_3218 serverLevel) {
            var holder = (VirtualBlockHolder)attachment.holder();
            DecorationUtil.showBreakParticleShaped(serverLevel, blockPos, blockState, holder.displayStack);
        }
    }
}
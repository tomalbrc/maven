package de.tomalbrc.filament.mixin.sound;

import com.mojang.authlib.GameProfile;
import de.tomalbrc.filament.mixin.accessor.EntityInvoker;
import de.tomalbrc.filament.util.FilamentConfig;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// enable step sounds
@Mixin(class_3222.class)
public abstract class PlayerMixin extends class_1657 {
    public PlayerMixin(class_1937 level, class_2338 blockPos, float f, GameProfile gameProfile) {
        super(level, blockPos, f, gameProfile);
    }

    @Inject(method = "checkMovementStatistics", at = @At("HEAD"))
    public void filament$checkMovementStatistics(double d, double e, double f, CallbackInfo ci) {
        // run step sound checks etc
        if (FilamentConfig.getInstance().soundModule && !method_5765() && d != 0 && e != 0 && f != 0) ((EntityInvoker)this).invokeApplyMovementEmissionAndPlaySound(class_5799.field_28631, new class_243(d,e,f), this.method_23312(), this.method_25936());
    }
}

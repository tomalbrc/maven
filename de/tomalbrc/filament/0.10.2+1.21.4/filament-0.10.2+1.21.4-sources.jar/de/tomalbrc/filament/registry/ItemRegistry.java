package de.tomalbrc.filament.registry;

import com.google.gson.JsonParser;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import de.tomalbrc.filament.item.SimpleItem;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9336;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;

public class ItemRegistry {
    public static int REGISTERED_ITEMS = 0;

    public static void register(InputStream inputStream) throws IOException {
        var element = JsonParser.parseReader(new InputStreamReader(inputStream));
        ItemData data = Json.GSON.fromJson(element, ItemData.class);

        Util.handleComponentsCustom(element, data);

        register(data);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static public void register(ItemData data) {
        if (class_7923.field_41178.method_10250(data.id())) return;

        class_1792.class_1793 properties = data.properties().toItemProperties(data.behaviour());

        for (class_9336 component : data.components()) {
            properties.method_57349(component.comp_2443(), component.comp_2444());
        }

        var item = ItemRegistry.registerItem(key(data.id()), (newProps) -> new SimpleItem(null, newProps, data, data.vanillaItem()), properties, data.group() != null ? data.group() : Constants.ITEM_GROUP_ID);
        BehaviourUtil.postInitItem(item, item, data.behaviour());

        var itemResources = data.itemResource();
        if (itemResources != null && data.itemModel() == null) {
            PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(resourcePackBuilder ->
                    ItemAssetGenerator.create(resourcePackBuilder, data.id(), itemResources)
            );
        }

        REGISTERED_ITEMS++;
    }

    public static class_5321<class_1792> key(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41197, id);
    }

    public static <T extends class_1792> T registerItem(class_5321<class_1792> identifier, Function<class_1792.class_1793, T> function, class_1792.class_1793 properties, class_2960 itemGroup) {
        T item = function.apply(properties.method_63686(identifier));
        class_2378.method_39197(class_7923.field_41178, identifier, item);
        ItemGroupRegistry.addItem(itemGroup, item);

        return item;
    }

    public static class ItemDataReloadListener implements SimpleSynchronousResourceReloadListener {
        static private boolean printedInfo = false;

        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "items");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/item", path -> path.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
                try (InputStream inputStream = entry.getValue().method_14482()) {
                    ItemRegistry.register(inputStream);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load item resource \"{}\".", entry.getKey(), e);
                }
            }
            if (!printedInfo) {
                for (String s : Arrays.asList("Filament items registered: " + REGISTERED_ITEMS, "Filament blocks registered: " + BlockRegistry.REGISTERED_BLOCKS, "Filament decorations registered: " + DecorationRegistry.REGISTERED_DECORATIONS, "Filament decoration block entities registered: " + DecorationRegistry.REGISTERED_BLOCK_ENTITIES)) {
                    Filament.LOGGER.info(s);
                }
                printedInfo = true;
            }
        }
    }
}
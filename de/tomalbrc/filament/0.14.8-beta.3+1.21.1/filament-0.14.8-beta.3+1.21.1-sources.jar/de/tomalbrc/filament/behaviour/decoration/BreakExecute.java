package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2338;

/**
 * Lock behaviour for decoration
 */
public class BreakExecute implements DecorationBehaviour<BreakExecute.Config> {
    public Config config;
    public String command = null;

    public BreakExecute(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Config getConfig() {
        return this.config;
    }

    @Override
    public void postBreak(DecorationBlockEntity decorationBlockEntity, class_2338 blockPos, class_1657 player) {
        var commands = commands();
        boolean hasCommands = commands != null;
        if (hasCommands && player.method_5682() != null) {
            var css = player.method_5671().method_36321(player.method_5682()).method_9230(4);
            if (getConfig().atBlock)
                css = css.method_9208(decorationBlockEntity.method_11016().method_46558());

            for (String cmd : commands) {
                player.method_5682().method_3734().method_44252(css, cmd);
            }
        }
    }

    private List<String> commands() {
        return getConfig().commands == null ? this.getConfig().command == null ? null : List.of(this.getConfig().command) : getConfig().commands;
    }

    public static class Config {
        public String command = null;
        public List<String> commands = null;
        public boolean atBlock = false;
    }
}
package de.tomalbrc.filament.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_2767;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3300;
import net.minecraft.class_3341;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import net.minecraft.class_8013;
import net.minecraft.class_8104;
import net.minecraft.class_9334;
import org.joml.*;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {
    public static final class_8013 SEGMENTED_ANGLE8 = new class_8013(3); // 3 bits precision = 8

    public static void handleBoneMealEffects(class_3218 level, class_2338 blockPos) {
        level.method_8396(null, blockPos, class_3417.field_33433, class_3419.field_15245, 1.0f, 1.0f);
        level.method_14199(class_2398.field_11211, blockPos.method_46558().field_1352, blockPos.method_46558().field_1351, blockPos.method_46558().field_1350, 15, 0.25, 0.25, 0.25, 0.15);
    }

    public static void handleBlockPlaceEffects(class_3222 player, class_1268 hand, class_2338 pos, class_2498 type) {
        player.method_23667(hand, true);
        Util.playBlockPlaceSound(player, pos, type);
    }

    public static void playBlockPlaceSound(class_3222 player, class_2338 pos, class_2498 type) {
        player.field_13987.method_14364(new class_2767(
                class_6880.method_40223(type.method_10598()),
                class_3419.field_15245,
                pos.method_10263(),
                pos.method_10264(),
                pos.method_10260(),
                (type.method_10597() + 1.0F) / 2.0F,
                type.method_10599() * 0.8F,
                player.method_37908().method_8409().method_43055()
        ));
    }

    public static void showBreakParticle(class_3218 level, class_1799 stack, float x, float y, float z) {
        level.method_14199(new class_2392(class_2398.field_11218, stack), x, y, z, 27, 0.125, 0.125, 0.125, 0.05);
    }

    public static Optional<Integer> validateAndConvertHexColor(String hexColor) {
        // Regular expression pattern to match hex color strings
        Pattern hexColorPattern = Pattern.compile("^#?([A-Fa-f0-9]{6})$|^0x([A-Fa-f0-9]{6})$");

        Matcher matcher = hexColorPattern.matcher(hexColor);

        if (matcher.matches()) {
            String hexDigits = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
            int intValue = Integer.parseInt(hexDigits, 16);
            return Optional.of(intValue);
        } else {
            Filament.LOGGER.warn("Invalid hex color formats");
            return Optional.empty();
        }
    }

    public static void forEachRotated(List<DecorationData.BlockConfig> blockConfigs, class_2338 originBlockPos, float rotation, Consumer<class_2338> consumer) {
        if (blockConfigs != null) {
            for (DecorationData.BlockConfig blockConfig : blockConfigs) {
                Vector3fc origin = blockConfig.origin();
                Vector3fc size = blockConfig.size();
                for (int x = 0; x < size.x(); x++) {
                    for (int y = 0; y < size.y(); y++) {
                        for (int z = 0; z < size.z(); z++) {
                            Vector3f pos = new Vector3f(x, y, z).add(origin);
                            Vector3f offset = pos.mul(rotation % 90 != 0 ? Math.sqrt(2) : 1);
                            offset.rotateY(Math.toRadians(rotation + 180));

                            class_2338 blockPos = new class_2338(originBlockPos).method_10069(-Math.round(offset.x), Math.round(offset.y), Math.round(offset.z));
                            consumer.accept(blockPos);
                        }
                    }
                }
            }
        }
    }

    public static Vector2f barrierDimensions(List<DecorationData.BlockConfig> blockConfigs, float rotation) {
        if (!blockConfigs.isEmpty()) {
            List<class_2338> posList = new ObjectArrayList<>();
            Util.forEachRotated(blockConfigs, class_2338.field_10980, rotation, posList::add);
            Optional<class_3341> boundingBox = class_3341.method_35411(posList);
            if (boundingBox.isPresent()) {
                return new Vector2f(java.lang.Math.max(boundingBox.get().method_35414(), boundingBox.get().method_14663()), boundingBox.get().method_14660());
            }
        }
        return new Vector2f();
    }

    public static InteractionElement decorationInteraction(DecorationBlockEntity blockEntity) {
        InteractionElement element = new InteractionElement();
        element.setHandler(new VirtualElement.InteractionHandler() {
            @Override
            public void interactAt(class_3222 player, class_1268 hand, class_243 pos) {
                if (player.field_13974.method_14257() != class_1934.field_9216)
                    blockEntity.interact(player, hand, blockEntity.method_11016().method_46558().method_1023(0, 0.5f, 0).method_1019(pos));
            }

            @Override
            public void attack(class_3222 player) {
                if (player.field_13974.method_14257() != class_1934.field_9216) {
                    blockEntity.destroyStructure(player != null && !player.method_7337());
                }
            }
        });


        if (blockEntity.getDecorationData() != null && blockEntity.getDecorationData().size() != null) {
            element.setSize(blockEntity.getDecorationData().size().x, blockEntity.getDecorationData().size().y);
        } else {
            element.setSize(1.f, blockEntity.getDirection().equals(class_2350.field_11033) ? 1.f : .5f); // default
        }

        var q = blockEntity.getDirection().method_62675();
        if (blockEntity.getDirection() != class_2350.field_11033 && blockEntity.getDirection() != class_2350.field_11036) {
            element.setOffset(new class_243(q.method_10263(), q.method_10264() + element.getHeight(), q.method_10260()).method_18805(1.f-element.getWidth(), 1, 1.f-element.getWidth()).method_1021(-0.5f));
        } else {
            element.setOffset(new class_243(q.method_10263(), q.method_10264(), q.method_10260()).method_18805(1, blockEntity.getDirection() == class_2350.field_11033 ? 1.f-element.getHeight()/2.f : -1, 1).method_1021(0.5f));
        }

        return element;
    }

    public static InteractionElement decorationInteraction(DecorationBlockEntity decorationBlockEntity, DecorationData decorationData) {
        InteractionElement element = new InteractionElement();
        element.setHandler(new VirtualElement.InteractionHandler() {
            @Override
            public void attack(class_3222 player) {
                if (player.field_13974.method_14257() != class_1934.field_9216) {
                    element.getHolder().getAttachment().getWorld().method_22352(class_2338.method_49638(element.getHolder().getAttachment().getPos()), false);
                }
            }
        });
        element.setSize(1.f, 1.f);

        if (decorationData.size() != null) {
            element.setSize(decorationData.size().x, decorationData.size().y);
        } else {
            element.setSize(1.f, 1.f);
        }

        if (decorationBlockEntity != null) {
            var q = decorationBlockEntity.getDirection().method_62675();
            if (decorationBlockEntity.getDirection() != class_2350.field_11033 && decorationBlockEntity.getDirection() != class_2350.field_11036) {
                element.setOffset(new class_243(q.method_10263(), q.method_10264() + element.getHeight(), q.method_10260()).method_18805(1.f-element.getWidth(), 1, 1.f-element.getWidth()).method_1021(-0.5f));
            } else {
                element.setOffset(new class_243(q.method_10263(), q.method_10264(), q.method_10260()).method_18805(1, decorationBlockEntity.getDirection() == class_2350.field_11033 ? 1.f-element.getHeight()/2.f : -1, 1).method_1021(0.5f));
            }
        }

        return element;
    }

    public static ItemDisplayElement decorationItemDisplay(DecorationBlockEntity blockEntity) {
        ItemDisplayElement display = decorationItemDisplay(blockEntity.getDecorationData(), blockEntity.getDirection(), blockEntity.getVisualRotationYInDegrees());
        display.setItem(blockEntity.getItem().method_46651(1));
        return display;
    }

    public static ItemDisplayElement decorationItemDisplay(DecorationData data, class_2350 direction, float rotation) {
        ItemDisplayElement itemDisplayElement = new ItemDisplayElement(class_7923.field_41178.method_10223(data.id()).orElseThrow().comp_349());
        itemDisplayElement.setTeleportDuration(1);

        if (data != null && data.properties().glow) {
            itemDisplayElement.setBrightness(class_8104.field_42264);
        }

        Vector2f size = new Vector2f(1);
        if (data.hasBlocks()) {
            size = Util.barrierDimensions(data.blocks(), rotation);
        } else if (data.size() != null) {
            size = data.size();
        }

        Matrix4f matrix4f = new Matrix4f().identity();
        matrix4f.scale(0.5f);

        if (direction == class_2350.field_11033 || direction == class_2350.field_11036) {
            matrix4f.setTranslation(0, -0.5f, 0);

            float ang = (float) java.lang.Math.toRadians(rotation + 180);
            double angleRadians = class_3532.method_15349(-class_3532.method_15374(ang), class_3532.method_15362(ang));
            matrix4f.rotate(class_7833.field_40716.rotation((float) angleRadians).normalize());
            matrix4f.rotate(class_7833.field_40714.rotationDegrees(-90));
            if (direction == class_2350.field_11033) {
                matrix4f.rotate(class_7833.field_40714.rotationDegrees(180));
                matrix4f.setTranslation(0, 0.5f, 0);
            }
        } else {
            double angleRadians = class_3532.field_29847 * direction.method_10144();
            Quaternionf rot = class_7833.field_40716.rotation((float) angleRadians).conjugate().normalize();
            matrix4f.rotate(rot);
            matrix4f.setTranslation(new Vector3f(0.f, 0.f, -0.5f).rotate(rot));

        }

        itemDisplayElement.setDisplayWidth(size.x * 2.f);

        itemDisplayElement.setTransformation(matrix4f);
        itemDisplayElement.setModelTransformation(data.properties().display);

        return itemDisplayElement;
    }

    public static void spawnAtLocation(class_1937 level, class_243 pos, class_1799 itemStack) {
        if (!itemStack.method_7960() && !level.field_9236) {
            class_1542 itemEntity = new class_1542(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), itemStack);
            itemEntity.method_6988();
            level.method_8649(itemEntity);
        }
    }

    public static void loadDatapackContents(class_3300 resourceManager) {
        ((RegistryUnfreezer) class_7923.field_41175).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_41178).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_41181).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_44687).filament$unfreeze();

        for (SimpleSynchronousResourceReloadListener listener : FilamentReloadUtil.getReloadListeners()) {
            listener.method_14491(resourceManager);
        }

        ((RegistryUnfreezer)class_7923.field_41175).filament$freeze();
        ((RegistryUnfreezer)class_7923.field_41178).filament$freeze();
        ((RegistryUnfreezer)class_7923.field_41181).filament$freeze();
        ((RegistryUnfreezer)class_7923.field_44687).filament$freeze();
    }

    public static void damageAndBreak(int i, class_1799 itemStack, class_1309 livingEntity, class_1304 slot) {
        int newDamage = itemStack.method_7919() + i;
        itemStack.method_7974(newDamage);

        if (newDamage >= itemStack.method_7936()) {
            class_1792 item = itemStack.method_7909();
            itemStack.method_7934(1);
            livingEntity.method_20235(item, slot);
        }
    }

    public static void handleComponentsCustom(JsonElement element, Data data) {
        if (element.getAsJsonObject().has("components")) {
            JsonObject comp = element.getAsJsonObject().get("components").getAsJsonObject();
            if (comp.has("minecraft:jukebox_playable")) {
                data.putAdditional(class_9334.field_52175, comp.getAsJsonObject("minecraft:jukebox_playable"));
            }
            if (comp.has("jukebox_playable")) {
                data.putAdditional(class_9334.field_52175, comp.getAsJsonObject("jukebox_playable"));
            }
        }
    }
}
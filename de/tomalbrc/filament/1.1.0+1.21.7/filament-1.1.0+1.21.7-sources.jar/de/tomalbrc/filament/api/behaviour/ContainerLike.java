package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.util.FilamentContainer;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

public interface ContainerLike {
    class_2561 customName();

    @Nullable
    FilamentContainer container();

    boolean showCustomName();

    boolean hopperDropperSupport();

    boolean canPickup();
}

package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.ContainerLike;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.holder.FilamentDecorationHolder;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.elements.BlockDisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.tracker.DisplayTrackedData;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4538;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_9288;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.class_9473;

/**
 * For item showcase decoration
 */
public class Showcase implements BlockBehaviour<Showcase.Config>, DecorationBehaviour<Showcase.Config>, ContainerLike {
    private static final String SHOWCASE_KEY = "Showcase";
    private static final String ITEM = "Item";

    private final Config config;

    private final Object2ObjectOpenHashMap<ShowcaseMeta, DisplayElement> showcases = new Object2ObjectOpenHashMap<>();

    private FilamentContainer container;

    public Showcase(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Showcase.Config getConfig() {
        return this.config;
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        this.container = new FilamentContainer(blockEntity, config.size(), false) {
            @Override
            public int getMaxStackSize(int slot) {
                return config.get(slot).maxStackSize;
            }
        };

        this.container.method_5489(x -> {
            for (int i = 0; i < x.method_5439(); i++) {
                var stack = x.method_5438(i);
                setShowcaseItemStack(blockEntity, config.get(i), stack);
            }
        });
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (!player.method_21823() && decorationBlockEntity.getOrCreateHolder() != null) {
            Showcase.ShowcaseMeta showcase = getClosestShowcase(decorationBlockEntity, location);
            class_1799 itemStack = player.method_5998(hand);
            class_1799 showcaseStack = this.getShowcaseItemStack(showcase);

            if (this.canUseShowcaseItem(showcase, itemStack)) {
                boolean changed = false;
                if (!player.method_5998(hand).method_7960()) {
                    changed = true;
                    if (showcaseStack != null && !showcaseStack.method_7960()) {
                        Util.spawnAtLocation(decorationBlockEntity.method_10997(), location, showcaseStack);
                    }

                    var count = container.getMaxStackSize(0);
                    this.container.method_5447(config.indexOf(showcase), itemStack.method_46651(count));
                    itemStack.method_7934(count);
                    player.method_51469().method_43128(null, location.method_10216(), location.method_10214(), location.method_10215(), class_3414.method_47908(showcase.addItemSound), class_3419.field_15254, 1.0f, 1.0f);
                } else if (showcaseStack != null && !showcaseStack.method_7960()) {
                    changed = true;
                    player.method_6122(hand, showcaseStack);
                    this.container.method_5447(config.indexOf(showcase), class_1799.field_8037);
                    player.method_51469().method_43128(null, location.method_10216(), location.method_10214(), location.method_10215(), class_3414.method_47908(showcase.removeItemSound), class_3419.field_15254, 1.0f, 1.0f);
                }

                if (changed) {
                    decorationBlockEntity.method_5431();
                    return class_1269.field_21466;
                }
            }
        }

        return class_1269.field_5811;
    }

    @Override
    public void read(class_11368 output, DecorationBlockEntity blockEntity) {
        var showcaseInput = output.method_71420(SHOWCASE_KEY);
        if (showcaseInput.isPresent() && blockEntity.getOrCreateHolder() != null) {
            class_11368 showcaseTag = showcaseInput.orElseThrow();

            for (int i = 0; i < this.config.size(); i++) {
                String key = ITEM + i;
                if (showcaseTag.method_71420(key).isPresent()) {
                    container.field_5828.set(i, showcaseTag.method_71426(key, class_1799.field_24671).orElseThrow());
                }
            }
            container.method_5431();
        }
    }

    @Override
    public void write(class_11372 output, DecorationBlockEntity blockEntity) {
        if (blockEntity.getOrCreateHolder() != null) {
            class_11372 showcaseTag = output.method_71461(SHOWCASE_KEY);

            for (int i = 0; i < config.size(); i++) {
                Showcase.ShowcaseMeta showcase = config.get(i);
                if (showcase != null && !getShowcaseItemStack(showcase).method_7960())
                    showcaseTag.method_71468(ITEM + i, class_1799.field_24671, getShowcaseItemStack(showcase));
            }
        }
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        if (decorationBlockEntity.getOrCreateHolder() != null) {
            config.forEach(showcase -> {
                class_1799 itemStack = getShowcaseItemStack(showcase);
                if (itemStack != null && !itemStack.method_7960()) {
                    Util.spawnAtLocation(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016().method_46558(), itemStack.method_51164());
                }
            });
        }
    }

    public Showcase.ShowcaseMeta getClosestShowcase(DecorationBlockEntity decorationBlockEntity, class_243 location) {
        if (config.size() == 1) {
            return config.getFirst();
        } else {
            double dist = Double.MAX_VALUE;
            Showcase.ShowcaseMeta nearest = null;
            for (Showcase.ShowcaseMeta showcase : config) {
                class_243 q = decorationBlockEntity.method_11016().method_46558().method_1019(new class_243(this.showcaseTranslation(decorationBlockEntity, showcase).rotateY((-decorationBlockEntity.getVisualRotationYInDegrees() + 180) * class_3532.field_29847)));
                double distance = q.method_1022(location);

                if (distance < dist) {
                    dist = distance;
                    nearest = showcase;
                }
            }

            return nearest;
        }
    }

    private Vector3f showcaseTranslation(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase) {
        return new Vector3f(showcase.offset).sub(0, 0.475f, 0).rotateY(class_3532.field_29844);
    }

    public void setShowcaseItemStack(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        FilamentDecorationHolder holder = decorationBlockEntity.getOrCreateHolder();
        if (holder == null)
            return;

        boolean isBlockItem = itemStack.method_7909() instanceof class_1747 blockItem && !(blockItem.method_7711() instanceof DecorationBlock);

        DisplayElement element = this.showcases.get(showcase);

        DisplayElement newElement;

        boolean dynNeedsUpdate = showcase.type == Showcase.ShowcaseType.dynamic && element != null && !(element instanceof BlockDisplayElement && isBlockItem);

        if (element == null || dynNeedsUpdate) {
            if (element != null) { // update dynamic display, remove old
                decorationBlockEntity.getOrCreateHolder().removeElement(element);
                this.showcases.remove(showcase);
            }

            newElement = this.createShowcase(decorationBlockEntity, showcase, itemStack);
            decorationBlockEntity.getOrCreateHolder().addElement(newElement);
        } else {
            if (element instanceof BlockDisplayElement blockDisplayElement && itemStack.method_7909() instanceof class_1747 blockItem) {
                blockDisplayElement.getDataTracker().set(DisplayTrackedData.Block.BLOCK_STATE, blockItem.method_7711().method_9564(), true);
            } else if (element instanceof ShowcaseItemElement itemDisplayElement) {
                itemDisplayElement.setItemReal(itemStack);
            }

            this.showcases.put(showcase, element);
        }

        decorationBlockEntity.getOrCreateHolder().tick();
    }

    private BlockDisplayElement element(class_1747 blockItem) {
        BlockDisplayElement displayElement = new BlockDisplayElement();
        displayElement.setBlockState(blockItem.method_7711().method_9564());
        return displayElement;
    }

    private ItemDisplayElement element(class_1799 itemStack) {
        ItemDisplayElement displayElement = new ShowcaseItemElement(itemStack.method_7972());
        displayElement.setInvisible(true);
        return displayElement;
    }

    private DisplayElement createShowcase(DecorationBlockEntity decorationBlockEntity, Showcase.ShowcaseMeta showcase, class_1799 itemStack) {
        DisplayElement element = null;

        switch (showcase.type) {
            case item -> element = this.element(itemStack);
            case block -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem && !(blockItem instanceof DecorationItem)) {
                    element = this.element(blockItem);
                }
            }
            case dynamic -> {
                if (itemStack.method_7909().method_8389() instanceof class_1747 blockItem && !(blockItem instanceof DecorationItem)) {
                    element = this.element(blockItem);
                } else {
                    element = this.element(itemStack);
                }
            }
        }

        if (element != null) {
            transform(decorationBlockEntity, element, showcase);
            this.showcases.put(showcase, element);
        } else {
            Filament.LOGGER.error("In valid showcase type for {}", itemStack.method_7909().method_7876());
        }

        return element;
    }

    private void transform(DecorationBlockEntity decorationBlockEntity, DisplayElement element, ShowcaseMeta showcase) {
        if (element != null) {
            element.setScale(showcase.scale);
            element.setLeftRotation(showcase.rotation);
            element.setYaw(decorationBlockEntity.getVisualRotationYInDegrees() + 180);
            if (element instanceof BlockDisplayElement) {
                element.setTranslation(this.showcaseTranslation(decorationBlockEntity, showcase).add(new Vector3f(-.5f, -.5f, -.5f).mul(showcase.scale)));
            } else {
                element.setTranslation(this.showcaseTranslation(decorationBlockEntity, showcase));
            }
        }
    }

    public class_1799 getShowcaseItemStack(Showcase.ShowcaseMeta showcase) {
        var i = config.indexOf(showcase);
        return container.method_5438(i);
    }

    public boolean canUseShowcaseItem(Showcase.ShowcaseMeta showcase, class_1799 item) {
        boolean hasFilterItems = showcase.filterItems != null && !showcase.filterItems.isEmpty();
        boolean hasFilterTags = showcase.filterTags != null && !showcase.filterTags.isEmpty();

        if (hasFilterTags) {
            for (var filterTag : showcase.filterTags) {
                class_6862<class_1792> key = class_6862.method_40092(class_7924.field_41197, filterTag);
                if (item.method_31573(key)) {
                    return true;
                }
            }
        }

        if (hasFilterItems) {
            for (var filterTag : showcase.filterItems) {
                if (item.method_31574(filterTag)) {
                    return true;
                }
            }
        }

        return !(hasFilterItems || hasFilterTags);
    }

    @Override
    public class_1799 getCloneItemStack(class_1799 itemStack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        return DecorationBehaviour.super.getCloneItemStack(itemStack, levelReader, blockPos, blockState, includeData);
    }

    @Override
    public void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9473 dataComponentGetter) {
        dataComponentGetter.method_58695(class_9334.field_49622, class_9288.field_49334).method_57492(container.field_5828);
        container.method_5431();
    }

    @Override
    public void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {
        builder.method_57840(class_9334.field_49622, class_9288.method_57493(container.field_5828));
    }

    @Override
    public class_2561 customName() {
        return null;
    }

    @Override
    public @Nullable FilamentContainer container() {
        return container;
    }

    @Override
    public boolean showCustomName() {
        return false;
    }

    @Override
    public boolean hopperDropperSupport() {
        for (ShowcaseMeta meta : config) {
            if (meta.hopperDropperSupport)
                return true;
        }
        return false;
    }

    @Override
    public boolean canPickup() {
        return false;
    }

    public static class ShowcaseMeta {
        /**
         * Offset for positioning the showcased item
         */
        public Vector3f offset = new Vector3f();

        /**
         * Scale of the showcased item
         */
        public Vector3f scale = new Vector3f(1);

        /**
         * Rotation of the showcased item
         */
        public Quaternionf rotation = new Quaternionf();

        /**
         * Type to display, block for blocks (block display), item for items (item display), dynamic uses blocks if possible, otherwise item (block/item display)
         */
        public ShowcaseType type = ShowcaseType.item;

        /**
         * Items to allow
         */
        public List<class_1792> filterItems;

        /**
         * Items with given item tags to allow
         */
        public List<class_2960> filterTags;

        public class_2960 addItemSound = class_3417.field_14667.comp_3319();

        public class_2960 removeItemSound = class_3417.field_14770.comp_3319();

        public boolean hopperDropperSupport = true;

        public int maxStackSize = 1;
    }

    public enum ShowcaseType {
        item,
        block,
        dynamic // block when possible, item otherwise
    }

    public static class Config extends ObjectArrayList<ShowcaseMeta> {
    }

    private static class ShowcaseItemElement extends ItemDisplayElement {
        public ShowcaseItemElement(class_1799 itemStack) {
            setItemReal(itemStack);
        }

        @Override
        public void setItem(class_1799 stack) {

        }

        public void setItemReal(class_1799 stack) {
            this.dataTracker.set(DisplayTrackedData.Item.ITEM, stack, true);
        }
    }
}
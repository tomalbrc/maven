package de.tomalbrc.filament.util;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import java.nio.file.Path;

public class Constants {
    public static final String MOD_ID = "filament";
    public static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir();

    public static final class_2960 ITEM_GROUP_ID = class_2960.method_60655("filament", "item");
    public static final class_2960 BLOCK_GROUP_ID = class_2960.method_60655("filament", "block");
    public static final class_2960 DECORATION_GROUP_ID = class_2960.method_60655("filament", "decoration");
}

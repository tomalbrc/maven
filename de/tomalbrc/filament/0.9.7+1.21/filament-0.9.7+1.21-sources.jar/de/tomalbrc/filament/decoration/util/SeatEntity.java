package de.tomalbrc.filament.decoration.util;

import eu.pb4.polymer.core.api.entity.PolymerEntity;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_3222;

public class SeatEntity extends class_1297 implements PolymerEntity {
    private class_2350 direction = class_2350.field_11036;

    public SeatEntity(class_1299 type, class_1937 world) {
        super(type, world);
        this.method_5648(true);
    }

    @Override
    public void modifyRawTrackedData(List<class_2945.class_7834<?>> data, class_3222 player, boolean initial) {
        data.add(class_2945.class_7834.method_46360(class_1531.field_7107, (byte)(class_1531.field_30444 | class_1531.field_30452)));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.FLAGS, (byte)0));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.SILENT, true));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.NO_GRAVITY, true));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.FLAGS, (byte) (1 << EntityTrackedData.INVISIBLE_FLAG_INDEX)));
    }

    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!this.method_5782()) {
            this.method_31472();
        }
    }

    @Override
    public class_1299<?> getPolymerEntityType(class_3222 player) {
        return class_1299.field_6131;
    }


    @Override
    public class_243 method_24829(class_1309 passenger) {
        return class_243.method_24955(this.method_23312()).method_43206(this.direction, 1);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
    }

    @Override
    public void method_5749(class_2487 compoundTag) {}

    @Override
    public void method_5652(class_2487 compoundTag) {}
}
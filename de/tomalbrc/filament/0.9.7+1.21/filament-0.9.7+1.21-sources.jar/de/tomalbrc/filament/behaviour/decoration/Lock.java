package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

/**
 * Lock behaviour for decoration
 */
public class Lock implements DecorationBehaviour<Lock.LockConfig> {
    public LockConfig lockConfig;
    public boolean unlocked = false;
    public String command = null;

    public Lock(LockConfig lockConfig) {
        this.lockConfig = lockConfig;
    }

    @Override
    @NotNull
    public LockConfig getConfig() {
        return this.lockConfig;
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (this.unlocked) return class_1269.field_5811;

        class_1792 key = this.lockConfig.key == null ? null : class_7923.field_41178.method_10223(this.lockConfig.key);
        class_1799 mainHandItem = player.method_5998(class_1268.field_5808);
        boolean hasHandItem = !mainHandItem.method_7960();
        boolean holdsKeyAndIsValid = hasHandItem && key != null && mainHandItem.method_31574(key);
        boolean noItemNoKey = !hasHandItem && (key == null);
        if (holdsKeyAndIsValid || noItemNoKey) {
            if (this.lockConfig.consumeKey && hasHandItem) {
                mainHandItem.method_7934(1);
            }

            // TODO: FIX LOCK ANIMATION
            //if (this.lock.unlockAnimation != null && !lock.unlockAnimation.isEmpty() && decorationBlockEntity instanceof AjDecorationBlockEntity ajDecorationEntity) {
            //    decorationBlockEntity.play(lock.unlockAnimation);
            //}

            this.unlocked = true;

            boolean validCommand = this.command != null && !this.command.isEmpty();
            boolean validLockCommand = this.lockConfig.command != null && !this.lockConfig.command.isEmpty();
            if ((validCommand || validLockCommand) && player.method_5682() != null) {
                player.method_5682().method_3734().method_44252(player.method_5671(), validCommand ? this.command : this.lockConfig.command);
            }

            if (this.lockConfig.discard) {
                decorationBlockEntity.destroyStructure(false);
            }
        }

        return this.unlocked ? class_1269.field_21466 : class_1269.field_5811;
    }

    @Override
    public void read(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {
        if (compoundTag.method_10545("Lock")) {
            class_2487 lock = compoundTag.method_10562("Lock");

            if (compoundTag.method_10545("Command")) this.command = lock.method_10558("Command");

            if (compoundTag.method_10545("Unlocked")) this.unlocked = lock.method_10577("Unlocked");
        }
    }

    @Override
    public void write(class_2487 compoundTag, class_7225.class_7874 provider, DecorationBlockEntity blockEntity) {
        class_2487 lockTag = new class_2487();

        if (this.command != null && !this.command.isEmpty()) lockTag.method_10582("Command", this.command);

        lockTag.method_10556("Unlocked", this.unlocked);

        compoundTag.method_10566("Lock", lockTag);
    }

    public static class LockConfig {

        /**
         * The identifier of the key required to unlock.
         */
        public class_2960 key = null;

        /**
         * Determines whether the key should be consumed upon unlocking.
         */
        public boolean consumeKey = false;

        /**
         * Specifies whether the lock util should be discarded after unlocking.
         */
        public boolean discard = false;

        /**
         * Name of the animation to play upon successful unlocking (if applicable).
         */
        public String unlockAnimation = null;

        /**
         * Command to execute when the lock is successfully unlocked (if specified).
         * The command can be overwritten using NBT, the path for the command is Lock.Command in the block entities' NBT
         * `formats modify @e[entitySpecifier] Lock.Command set value "say hello"`
         */
        public String command = null;
    }
}
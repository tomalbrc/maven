package de.tomalbrc.filament.cosmetic;

import Z;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3532;

public class CosmeticHolder extends ElementHolder {
    private final class_1309 entity;
    private final DisplayElement displayElement;

    private double prevX = 0;
    private double prevZ = 0;

    private float bodyYaw;

    public CosmeticHolder(class_1309 entity, class_1799 itemStack) {
        super();

        this.entity = entity;

        this.displayElement = new ItemDisplayElement(itemStack);

        Cosmetic.Config cosmeticData = CosmeticUtil.getCosmeticData(itemStack);
        if (cosmeticData != null) {
            this.displayElement.setTranslation(cosmeticData.translation);
            this.displayElement.setScale(cosmeticData.scale);
        }

        this.displayElement.setTeleportDuration(1);

        this.addElement(this.displayElement);
    }

    @Override
    public void onTick() {
        super.onTick();

        this.tickMovement(this.entity);
        this.displayElement.setYaw(this.bodyYaw);

        this.prevX = this.entity.method_23317();
        this.prevZ = this.entity.method_23321();
    }

    private void tickMovement(final class_1309 player) {
        float yaw = this.entity.method_36454();
        double i = player.method_23317() - this.prevX;
        double d = player.method_23321() - this.prevZ;
        float f = (float)(i * i + d * d);
        float g = this.bodyYaw;
        if (f > 0.0025f) {
            // Using internal Mojang math utils here
            float l = (float) class_3532.method_15349(d, i) * class_3532.field_29848 - 90.0F;
            float m = class_3532.method_15379(class_3532.method_15393(yaw) - l);
            if (95.f < m && m < 265.f) {
                g = l - 180.f;
            } else {
                g = l;
            }
        }

        this.turnBody(g, yaw);
    }

    public void turnBody(float bodyRotation, float yaw) {
        float f = class_3532.method_15393(bodyRotation - this.bodyYaw);
        this.bodyYaw += f * 0.3F;
        float g = class_3532.method_15393(yaw - this.bodyYaw);
        if (g < -75.0F) {
            g = -75.0F;
        }

        if (g >= 75.0F) {
            g = 75.0F;
        }

        this.bodyYaw = yaw - g;
        if (g * g > 2500.0F) {
            this.bodyYaw += g * 0.2F;
        }
    }

    @Override
    protected void notifyElementsOfPositionUpdate(class_243 newPos, class_243 delta) {
    }
    @Override
    protected void updateInitialPosition() {
        if (this.entity instanceof class_3222 serverPlayer) this.startWatching(serverPlayer);
    }

    @Override
    public boolean startWatching(class_3244 player) {
        var ret = super.startWatching(player);

        player.method_14364(VirtualEntityUtils.createRidePacket(this.entity.method_5628(), this.displayElement.getEntityIds()));

        return ret;
    }
}

package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5151;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

/**
 * Cosmetics; either head or chestplate slot, can be Blockbenchmodel for chestplate slot or simple item model for either
 */
public class Cosmetic implements ItemBehaviour<Cosmetic.Config> {
    private final Config config;

    public Cosmetic(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Cosmetic.Config getConfig() {
        return this.config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        if (item instanceof class_5151 equipable) {
            return equipable.method_48576(item, level, player, interactionHand);
        }

        return ItemBehaviour.super.use(item, level, player, interactionHand);
    }

    @Override
    public class_1304 getEquipmentSlot() {
        return this.config.slot;
    }

    public static class Config {
        /**
         * The equipment slot for the cosmetic (head, chest).
         */
        public class_1304 slot;

        /**
         * The resource location of the animated model for the cosmetic.
         */
        public class_2960 model;

        /**
         * The name of the animation to autoplay. The animation should be loopable
         */
        public String autoplay;

        /**
         * Scale of the chest cosmetic
         */
        public Vector3f scale = new Vector3f(1);

        /**
         * Translation of the chest cosmetic
         */
        public Vector3f translation = new Vector3f();
    }
}

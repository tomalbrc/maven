package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.class_3258;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3258.class)
public class FilePackResourcesMixin {
    @Inject(method = "listResources", at = @At(value = "INVOKE", target = "Ljava/util/Enumeration;hasMoreElements()Z"))
    private void filament$removeExcessSlashes(class_3264 packType, String string, String string2, class_3262.class_7664 resourceOutput, CallbackInfo ci, @Local(ordinal = 3) LocalRef<String> string4) {
        if (string4.get().endsWith("//")) {
            string4.set(string4.get().substring(0, string4.get().length()-2));
        }
    }
}
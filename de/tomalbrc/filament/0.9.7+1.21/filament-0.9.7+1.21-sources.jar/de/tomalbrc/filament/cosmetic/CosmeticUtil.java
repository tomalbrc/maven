package de.tomalbrc.filament.cosmetic;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.item.Cosmetic;
import de.tomalbrc.filament.item.SimpleItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class CosmeticUtil {
    public static boolean isCosmetic(class_1799 itemStack) {
        return itemStack.method_7909() instanceof SimpleItem simpleItem && getCosmeticData(simpleItem) != null;
    }

    public static Cosmetic.Config getCosmeticData(class_1799 itemStack) {
        return getCosmeticData(itemStack.method_7909());
    }

    public static Cosmetic.Config getCosmeticData(class_1792 item) {
        Cosmetic.Config cosmeticData = null;
        if (item instanceof SimpleItem simpleItem && simpleItem.has(Behaviours.COSMETIC)) {
            cosmeticData = simpleItem.get(Behaviours.COSMETIC).getConfig();
        }
        return cosmeticData;
    }
}

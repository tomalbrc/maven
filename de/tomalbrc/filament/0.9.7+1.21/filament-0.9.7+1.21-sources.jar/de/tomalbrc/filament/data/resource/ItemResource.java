package de.tomalbrc.filament.data.resource;

import java.util.Map;
import net.minecraft.class_2960;

public record ItemResource(Map<String, class_2960> models,
                           Map<String, class_2960> textures,
                           Map<String, class_2960> vanilla) {

    public boolean couldGenerate() {
        return this.textures != null && this.textures.containsKey("default");
    }
}

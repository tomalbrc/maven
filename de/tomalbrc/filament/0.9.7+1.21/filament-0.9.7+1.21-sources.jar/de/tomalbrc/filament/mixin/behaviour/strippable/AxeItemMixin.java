package de.tomalbrc.filament.mixin.behaviour.strippable;

import de.tomalbrc.filament.registry.StrippableRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Optional;
import net.minecraft.class_1743;
import net.minecraft.class_2680;

@Mixin(class_1743.class)
public class AxeItemMixin {
    @Inject(method = "getStripped", locals = LocalCapture.CAPTURE_FAILSOFT, at = @At("RETURN"), cancellable = true)
    private void filament$onGetStripped(class_2680 blockState, CallbackInfoReturnable<Optional<class_2680>> cir) {
        if (StrippableRegistry.has(blockState.method_26204())) {
            var ns = StrippableRegistry.get(blockState.method_26204()).method_34725(blockState);
            cir.setReturnValue(Optional.of(ns));
        }
    }
}

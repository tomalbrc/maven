package de.tomalbrc.filament;

import com.mojang.logging.LogUtils;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.command.DyeCommand;
import de.tomalbrc.filament.command.HatCommand;
import de.tomalbrc.filament.command.PickCommand;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.registry.*;
import de.tomalbrc.filament.util.*;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.slf4j.Logger;

public class Filament implements ModInitializer {
    public static final Logger LOGGER = LogUtils.getLogger();

    @Override
    public void onInitialize() {
        PolymerResourcePackUtils.markAsRequired();
        Behaviours.init();
        EntityRegistry.register();

        if (FilamentConfig.getInstance().commands) {
            CommandRegistrationCallback.EVENT.register((dispatcher, context, selection) -> {
                HatCommand.register(dispatcher);
                DyeCommand.register(dispatcher);
                PickCommand.register(dispatcher);
            });
        }

        if (FilamentConfig.getInstance().emissive_shader) {
            FilamentShaderUtil.registerCallback();
        }

        PolymerBlockUtils.BREAKING_PROGRESS_UPDATE.register(VirtualDestroyStage::updateState);
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (player instanceof class_3222 serverPlayer) {
                ((VirtualDestroyStage.ServerGamePacketListenerExtF) serverPlayer.field_13987).filament$getVirtualDestroyStage().setState(-1);
            }
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.method_8608() && hand == class_1268.field_5808) {
                class_2338 pos = hitResult.method_17777();
                class_2680 blockState = world.method_8320(pos);
                if (DecorationRegistry.isDecoration(blockState) && world.method_8321(pos) instanceof DecorationBlockEntity decorationBlockEntity) {
                    return decorationBlockEntity.decorationInteract((class_3222) player, hand, hitResult.method_17784());
                }
            }

            return class_1269.field_5811;
        });

        FilamentReloadUtil.registerEarlyReloadListener(new FilamentAssetReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ModelRegistry.AjModelReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new BlockRegistry.BlockDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new DecorationRegistry.DecorationDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ItemRegistry.ItemDataReloadListener());

        FilamentRPUtil.registerCallback();

        VirtualDestroyStage.destroy(null);

        for (BlockModelType value : BlockModelType.values()) {
            Filament.LOGGER.info("Blocks left for "+value.name()+":\t"+PolymerBlockResourceUtils.getBlocksLeft(value));
        }
    }
}

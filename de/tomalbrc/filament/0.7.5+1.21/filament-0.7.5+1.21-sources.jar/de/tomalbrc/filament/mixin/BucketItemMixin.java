package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.util.FakeItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1755;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2428;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1755.class)
public abstract class BucketItemMixin implements FakeItem {
    @Shadow public abstract class_1271<class_1799> use(class_1937 level, class_1657 player, class_1268 interactionHand);

    @Shadow @Final private class_3611 content;

    @Shadow protected abstract void playEmptySound(@Nullable class_1657 player, class_1936 levelAccessor, class_2338 blockPos);

    @Inject(cancellable = true, method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;", ordinal = 0), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void filament$preventBucketInteraction(class_1937 level, class_1657 player, class_1268 interactionHand, CallbackInfoReturnable<class_1271<class_1799>> cir, @Local class_2680 blockState, @Local class_1799 itemStack) {
        if (blockState.method_26204() instanceof SimpleBlock && !blockState.method_28498(class_2741.field_12508))
            cir.setReturnValue(class_1271.method_22431(itemStack));
    }


    @Override
    public class_1269 useOn(class_1838 useOnContext) {
        var bs = useOnContext.method_8045().method_8320(useOnContext.method_8037());
        if (bs.method_26204() instanceof SimpleBlock simpleBlock && simpleBlock.getPolymerBlockState(bs, (class_3222) useOnContext.method_8036()).method_26204() instanceof class_2428) {
            class_3611 c = content;
            var res = this.use(useOnContext.method_8045(), useOnContext.method_8036(), useOnContext.method_20287()).method_5467();
            if (res.method_23665()) {
                if (this.content == class_3612.field_15906) {
                    playEmptySound(null, useOnContext.method_8045(), useOnContext.method_8037());
                } else {
                    simpleBlock.method_32351().ifPresent((soundEvent) -> {
                        useOnContext.method_8045().method_8396(null, useOnContext.method_8037(), soundEvent, class_3419.field_15245, 1.0F, 1.0F);
                    });
                }
            }
            return res;
        }
        return class_1269.field_5811;
    }
}

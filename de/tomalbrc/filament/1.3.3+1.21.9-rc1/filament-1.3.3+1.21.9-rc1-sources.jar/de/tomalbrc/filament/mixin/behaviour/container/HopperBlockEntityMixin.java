package de.tomalbrc.filament.mixin.behaviour.container;

import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2614;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2614.class)
public class HopperBlockEntityMixin {
    @Inject(method = "getBlockContainer", at = @At(value = "HEAD"), cancellable = true)
    private static void filament$customContainerSupport(class_1937 level, class_2338 blockPos, class_2680 blockState, CallbackInfoReturnable<class_1263> cir) {
        if (blockState.method_26204() instanceof ComplexDecorationBlock complexDecorationBlock && complexDecorationBlock.getDecorationData().isContainer()) {
            DecorationBlockEntity blockEntity = (DecorationBlockEntity) level.method_8321(blockPos);
            if (blockEntity != null && (blockEntity = blockEntity.getMainBlockEntity()) != null) {
                var containerLike = blockEntity.getDecorationData().getFirstContainer(blockEntity);
                if (containerLike != null && containerLike.hopperDropperSupport()) {
                    cir.setReturnValue(containerLike.container());
                }
            }
        }
    }
}

package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import eu.pb4.polymer.resourcepack.api.AssetPaths;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.extras.api.format.model.ModelAsset;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_10714;
import net.minecraft.class_1304;
import net.minecraft.class_2960;
import net.minecraft.class_8051;
import net.minecraft.class_9334;

/**
 * Trident behaviour
 */
public class GenerateTrimModels implements ItemBehaviour<GenerateTrimModels.Config>, ItemPredicateModelProvider {
    private final Config config;

    public GenerateTrimModels(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public GenerateTrimModels.Config getConfig() {
        return this.config;
    }

    private class_1304 slot(Data<?> data) {
        if (data.components().method_57832(class_9334.field_54196)) {
            return Objects.requireNonNull(data.components().method_58694(class_9334.field_54196)).comp_3174();
        }

        return null;
    }

    @Override
    public void generate(Data<?> data) {
        var slot = slot(data);
        String armorType = null;
        String namespace = null;
        if (slot != null && config.typePrefix == null) {
            for (class_8051 type : class_8051.values()) {
                if (type.method_48399() == slot) {
                    namespace = class_2960.field_33381;
                    armorType = "trims/items/" + type.method_48400() + "_trim_";
                    break;
                }
            }
        } else if (config.typePrefix != null) {
            // support non wearable items like axes
            if (config.typePrefix.contains(":")) {
                var r = class_2960.method_60654(config.typePrefix);
                armorType = r.method_12832();
                namespace = r.method_12836();
            }
            else {
                armorType = config.typePrefix;
            }
        }

        var itemResource = data.itemResource();
        if (armorType != null && itemResource != null) {
            ItemAssetGenerator.createItemModels(data.id(), itemResource);

            final Object2ObjectArrayMap<class_2960, byte[]> map = new Object2ObjectArrayMap<>();
            var list = new ArrayList<class_2960>();
            list.addAll(config.customMaterials);
            list.addAll(config.materials);

            // TODO: trim_material registry not available at the point the rp is generated?
            // Filament.SERVER.registries().compositeAccess().getOrThrow(Registries.TRIM_MATERIAL).value().entrySet().forEach((resourceKeyTrimMaterialEntry -> {
            //                    var trimMaterialReference = resourceKeyTrimMaterialEntry.getValue();
            //                    var assetInfo = trimMaterialReference.assets().assetId(Objects.requireNonNull(eq).assetId().orElseThrow());

            for (class_2960 suffix : list) {
                var layer1 = class_2960.method_60655(namespace == null ? suffix.method_12836() : namespace, String.format("%s%s", armorType, suffix.method_12832()));
                var name = data.id().method_12832() + class_10714.field_56322 + suffix.method_12832();
                ModelAsset.Builder modelAsset = ModelAsset.builder();

                modelAsset.parent(itemResource.parent());

                var layer0 = itemResource.textures().get("default");
                modelAsset.texture("layer0", layer0.get("layer0").toString());
                modelAsset.texture("layer1", layer1.toString());

                var model = class_2960.method_60655(data.id().method_12836(), name);
                var models = itemResource.getModels();
                if (models != null)
                    models.put(suffix.method_12832(), model);

                map.put(model, modelAsset.build().toBytes());
            }

            PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(resourcePackBuilder -> {
                map.forEach((model, modelAsset) -> resourcePackBuilder.addData(AssetPaths.itemModel(model), modelAsset));

                ItemAssetGenerator.createTrimModels(
                        resourcePackBuilder, data.id(),
                        Objects.requireNonNull(data.itemResource()),
                        data.components().method_57832(class_9334.field_49644) || data.vanillaItem().method_57347().method_57832(class_9334.field_49644)
                );
            });
        }
    }

    @Override
    public List<String> requiredModels() {
        return List.of("default");
    }

    @Override
    public boolean canCreateItemModels() {
        return true;
    }

    public static class Config {
        public String typePrefix = null;
        public List<class_2960> customMaterials = List.of();
        public List<class_2960> materials = List.of(
                class_2960.method_60656("quartz"),
                class_2960.method_60656("iron"),
                class_2960.method_60656("netherite"),
                class_2960.method_60656("redstone"),
                class_2960.method_60656("copper"),
                class_2960.method_60656("gold"),
                class_2960.method_60656("emerald"),
                class_2960.method_60656("diamond"),
                class_2960.method_60656("lapis"),
                class_2960.method_60656("amethyst"),
                class_2960.method_60656("resin")
        );
    }
}
package de.tomalbrc.filament.api.behaviour;

import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.holder.FilamentDecorationHolder;
import net.minecraft.class_10225;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_9323;
import net.minecraft.class_9473;

@SuppressWarnings("unused")
public interface DecorationBehaviour<T> extends Behaviour<T> {
    default void init(DecorationBlockEntity blockEntity) {
    }

    default FilamentDecorationHolder createHolder(DecorationBlockEntity blockEntity) {
        return null;
    }

    default void onHolderAttach(DecorationBlockEntity blockEntity, FilamentDecorationHolder holder) {
    }

    default class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        return class_1269.field_5811;
    }

    default void read(class_11368 output, DecorationBlockEntity blockEntity) {
    }

    default void write(class_11372 input, DecorationBlockEntity blockEntity) {
    }

    default void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
    }

    default void modifyDrop(DecorationBlockEntity decorationBlockEntity, class_1799 itemStack) {
    }

    // Allows to change the visual item stack
    default class_1799 visualItemStack(DecorationBlockEntity decorationBlockEntity, class_1799 adjusted, class_2680 blockState) {
        return adjusted;
    }

    default class_2680 updateShape(DecorationBlockEntity decorationBlockEntity, class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        return blockState;
    }

    default class_1799 getCloneItemStack(class_1799 stack, class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        return stack;
    }

    default void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9473 dataComponentGetter) {}

    default void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {}

    default void removeComponentsFromTag(DecorationBlockEntity decorationBlockEntity, class_11372 valueOutput) {}

    default void postBreak(DecorationBlockEntity decorationBlockEntity, class_2338 blockPos, class_1657 player) {

    }
}
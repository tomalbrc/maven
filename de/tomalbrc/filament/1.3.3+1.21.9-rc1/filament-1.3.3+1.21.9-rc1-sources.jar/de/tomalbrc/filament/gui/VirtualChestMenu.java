package de.tomalbrc.filament.gui;

import eu.pb4.sgui.api.gui.SlotGuiInterface;
import eu.pb4.sgui.virtual.inventory.VirtualScreenHandler;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import org.jetbrains.annotations.NotNull;

public class VirtualChestMenu extends VirtualScreenHandler {
    private final SlotGuiInterface gui;
    private final class_1263 container;

    public VirtualChestMenu(class_3917<?> type, int syncId, SlotGuiInterface gui, class_1657 player, class_1263 container) {
        super(type, syncId, gui, player);
        this.gui = gui;
        this.container = container;

        gui.beforeOpen();
        gui.onOpen();
        if (gui instanceof PaginatedContainerGui paginatedContainerGui) {
            paginatedContainerGui.setScreenHandler(this);
        }

        container.method_5435(player);
    }

    @Override
    public void method_37420() {

    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int i) {
        return this.gui.quickMove(i);
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return container.method_5443(player);
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        this.container.method_5432(player);
    }
}
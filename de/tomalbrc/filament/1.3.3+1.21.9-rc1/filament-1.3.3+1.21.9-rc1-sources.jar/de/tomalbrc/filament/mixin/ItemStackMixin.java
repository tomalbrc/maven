package de.tomalbrc.filament.mixin;

import com.mojang.serialization.DataResult;
import de.tomalbrc.filament.item.FilamentItem;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public class ItemStackMixin {
    @Inject(method = "validateStrict", at = @At("HEAD"))
    private static void filament$val(class_1799 itemStack, CallbackInfoReturnable<DataResult<class_1799>> cir) {
        if (itemStack.method_7909() instanceof FilamentItem filamentItem) {
            filamentItem.verifyComponentsAfterLoad(itemStack);
        }
    }
}

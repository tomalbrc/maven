package de.tomalbrc.filament.mixin.decoration;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.decoration.util.BlockEntityWithElementHolder;
import de.tomalbrc.filament.registry.OxidizableRegistry;
import de.tomalbrc.filament.registry.StrippableRegistry;
import de.tomalbrc.filament.registry.WaxableRegistry;
import net.minecraft.class_11352;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3738;
import net.minecraft.class_8942;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2818.class)
public abstract class LevelChunkMixin {
    @Inject(
            method = "setBlockEntity",
            at = @At("TAIL")
    )
    private void filament$filamentDecorationInit(class_2586 blockEntity, CallbackInfo ci) {
        if (blockEntity instanceof BlockEntityWithElementHolder blockEntityWithElementHolder) {
            Filament.SERVER.method_63588(new class_3738(0, () -> blockEntityWithElementHolder.attach((class_2818)(Object) this)));
        }
    }

    @Inject(
            method = "setBlockEntity",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/entity/BlockEntity;setRemoved()V")
    )
    private void filament$filamentDecorationCopyData(class_2586 blockEntity, CallbackInfo ci, @Local(ordinal = 1) class_2586 blockEntity2) {
        if (blockEntity2 instanceof DecorationBlockEntity old && old.replaceable() && blockEntity instanceof DecorationBlockEntity fresh) {
            if (filament$replace(old.getBlock(), fresh.getBlock())) {
                class_2487 compoundTag = old.method_38244(Filament.SERVER.method_30611());

                try (class_8942.class_11340 scopedCollector = new class_8942.class_11340(blockEntity.method_71402(), Filament.LOGGER)) {
                    fresh.method_11014(class_11352.method_71417(scopedCollector, Filament.SERVER.method_30611(), compoundTag));
                    fresh.method_5431();
                } catch (Throwable throwable) {
                    Filament.LOGGER.error("Failed to copy data for decoration {} for block {} at position {} to new decoration {}", old.method_11017(), old.method_11016(), old.method_11010(), fresh.method_11017(), throwable);
                }
            }
        }
    }

    @WrapOperation(method = "setBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/chunk/LevelChunk;removeBlockEntity(Lnet/minecraft/core/BlockPos;)V"))
    private void filament$avoidRemovalOxidation(class_2818 instance, class_2338 blockPos, Operation<Void> original, @Local(ordinal = 0, argsOnly = true) class_2680 blockState, @Local(ordinal = 1) class_2680 blockStateOld) {
        var oxiDeco = !blockStateOld.method_26215() && blockStateOld.method_26204() instanceof DecorationBlock && blockState.method_26204() instanceof DecorationBlock && filament$replace(blockStateOld.method_26204(), blockState.method_26204());
        if (!oxiDeco) {
            original.call(instance, blockPos);
        }
    }

    @WrapOperation(method = "setBlockState", at = @At(value = "INVOKE", target = "Lorg/slf4j/Logger;warn(Ljava/lang/String;[Ljava/lang/Object;)V", remap = false))
    private void filament$avoidRemovalOxidationWarn(Logger instance, String s, Object[] objects, Operation<Void> original, @Local(ordinal = 0, argsOnly = true) class_2680 blockState, @Local(ordinal = 1) class_2680 blockStateOld, @Local(argsOnly = true) class_2338 blockPos) {
        var oxiDeco = !blockStateOld.method_26215() && blockStateOld.method_26204() instanceof DecorationBlock && blockState.method_26204() instanceof DecorationBlock && filament$replace(blockStateOld.method_26204(), blockState.method_26204());
        if (!oxiDeco) {
            original.call(instance, s, objects);
        }
    }

    @Unique
    private boolean filament$replace(class_2248 old, class_2248 fresh) {
        return OxidizableRegistry.sameOxidizable(fresh, old) || StrippableRegistry.get(old) == fresh || WaxableRegistry.getPrevious(fresh) == old;
    }
}

package de.tomalbrc.filament.mixin.accessor;

import net.minecraft.class_2370;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2370.class)
public interface MappedRegistryAccessor<T> {
    @Accessor
    class_2370.class_10105<T> getAllTags();
}

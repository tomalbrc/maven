package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.util.ExecuteUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

public class ExecuteAttackItem implements ItemBehaviour<ExecuteAttackItem.Config> {
    private final Config config;

    public ExecuteAttackItem(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ExecuteAttackItem.Config getConfig() {
        return config;
    }

    public void runCommandItem(class_3222 serverPlayer, class_1792 item, class_1268 hand) {
        var cmds = commands();
        if (cmds != null) {
            if (config.console) {
                ExecuteUtil.asConsole(serverPlayer, null, cmds.toArray(new String[0]));
            } else {
                ExecuteUtil.asPlayer(serverPlayer, null, cmds.toArray(new String[0]));
            }

            serverPlayer.method_7259(class_3468.field_15372.method_14956(item));

            if (this.config.sound != null) {
                var sound = this.config.sound;
                serverPlayer.method_51469().method_43129(null, serverPlayer, class_7923.field_41172.method_63535(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                serverPlayer.method_5998(hand).method_7934(1);
            }
        }
    }

    @Override
    public void hurtEnemy(class_1799 itemStack, class_1309 livingEntity, class_1309 livingEntity2) {
        if (config.onEntityAttack && livingEntity2 instanceof class_3222 player) {
            runCommandItem(player, itemStack.method_7909(), class_1268.field_5808);
        }
    }

    private List<String> commands() {
        return config.commands == null ? this.config.command == null ? null : List.of(this.config.command) : config.commands;
    }

    public static class Config {
        public boolean consumes;

        public String command;
        public List<String> commands;

        public class_2960 sound;

        public boolean onEntityAttack = true;
        public boolean console = false;
    }
}

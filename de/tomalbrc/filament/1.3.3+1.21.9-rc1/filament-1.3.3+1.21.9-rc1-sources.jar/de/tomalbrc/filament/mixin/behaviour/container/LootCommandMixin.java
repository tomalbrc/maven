package de.tomalbrc.filament.mixin.behaviour.container;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import net.minecraft.class_1263;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3039;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3039.class)
public class LootCommandMixin {
    @Inject(method = "getContainer", at = @At(value = "INVOKE", target = "Lcom/mojang/brigadier/exceptions/Dynamic3CommandExceptionType;create(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/brigadier/exceptions/CommandSyntaxException;", shift = At.Shift.BEFORE, remap = false), cancellable = true)
    private static void filament$getFilamentContainer(class_2168 commandSourceStack, class_2338 blockPos, CallbackInfoReturnable<class_1263> cir, @Local class_2586 blockEntity) {
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            var containerLike = decorationBlockEntity.getDecorationData().getFirstContainer(decorationBlockEntity);
            if (containerLike != null) {
                var container = containerLike.container();
                if (container != null)
                    cir.setReturnValue(container);
            }
        }
    }
}

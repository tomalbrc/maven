package de.tomalbrc.filament.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.ItemPredicateModelProvider;
import de.tomalbrc.filament.data.AbstractBlockData;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.data.resource.BlockResource;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.data.resource.ResourceProvider;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_9334;

public class RPUtil {
    public static void create(BehaviourHolder behaviourHolder, Data<?> data) {
        ResourceProvider resource = data.itemResource();
        if (data instanceof AbstractBlockData<?> blockData) {
            if (data.itemResource() == null && blockData.blockResource() != null) resource = blockData.blockResource();

            if (blockData.properties().virtual || blockData instanceof DecorationData)
                createBlockItemAssets(blockData.id(), blockData.blockResource());

            createBlockModels(blockData.id(), blockData.blockResource());
        }

        if (resource != null && !data.components().method_57832(class_9334.field_54199) && data.itemModel() == null && (resource.getModels() != null || resource.couldGenerate())) {
            if (behaviourHolder.getBehaviours() != null && !behaviourHolder.getBehaviours().isEmpty()) {
                for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> entry : behaviourHolder.getBehaviours()) {
                    if (entry.getValue() instanceof ItemPredicateModelProvider modelProvider && modelProvider.hasRequiredModels(data)) {
                        if (resource instanceof ItemResource ir && !modelProvider.canCreateItemModels()) {
                            ItemAssetGenerator.createItemModels(data.id(), ir);
                        }

                        modelProvider.generate(data);
                        return;
                    }
                }
            }

            if (resource instanceof ItemResource ir) {
                ItemAssetGenerator.createItemModels(data.id(), ir);
            }

            ResourceProvider finalItemResources = resource;
            PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(resourcePackBuilder ->
                    ItemAssetGenerator.createDefault(
                            resourcePackBuilder,
                            data.id(),
                            finalItemResources,
                            data.components().method_57832(class_9334.field_49644) || data.vanillaItem().method_57347().method_57832(class_9334.field_49644)
                    )
            );
        }
    }

    // Item assets for virtual blocks that use item displays (NOT DECORATIONS!)
    public static void createBlockItemAssets(class_2960 id, BlockResource blockResource) {
        if (blockResource != null) PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(resourcePackBuilder ->
                ItemAssetGenerator.createDefault(
                        resourcePackBuilder,
                        id.method_45138("block/"),
                        blockResource,
                        false
                )
        );
    }

    private static void createBlockModels(class_2960 id, BlockResource blockResource) {
        if (blockResource != null && blockResource.couldGenerate()) {
            int index = 1;
            Map<Map<String, class_2960>, class_2960> localCache = new Object2ObjectOpenHashMap<>();

            for (Map.Entry<String, BlockResource.TextureBlockModel> entry : blockResource.textures().entrySet()) {
                var model = id.method_45138("block/").method_48331("_" + index);
                if (localCache.containsKey(entry.getValue().textures())) {
                    model = localCache.get(entry.getValue().textures());
                } else {
                    localCache.put(entry.getValue().textures(), model);

                    final var modelId = model;
                    PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(builder -> {
                        JsonObject object = new JsonObject();
                        object.add("parent", new JsonPrimitive(blockResource.parent().method_12836().equals(class_2960.field_33381) ? blockResource.parent().method_12832() : blockResource.parent().toString()));

                        JsonObject textures = new JsonObject();
                        for (Map.Entry<String, class_2960> texturesMapEntry : entry.getValue().textures().entrySet()) {
                            textures.add(texturesMapEntry.getKey(), new JsonPrimitive(texturesMapEntry.getValue().method_12836().equals(class_2960.field_33381) ? texturesMapEntry.getValue().method_12832() : texturesMapEntry.getValue().toString()));
                        }
                        object.add("textures", textures);

                        builder.addData("assets/" + modelId.method_12836() + "/models/" + modelId.method_12832() + ".json", Json.GSON.toJson(object).getBytes(StandardCharsets.UTF_8));
                    });
                }

                blockResource.addModel(entry.getKey(), PolymerBlockModel.of(model, entry.getValue().x(), entry.getValue().y(), entry.getValue().uvLock(), entry.getValue().weight()));
                index++;
            }
        }
    }
}

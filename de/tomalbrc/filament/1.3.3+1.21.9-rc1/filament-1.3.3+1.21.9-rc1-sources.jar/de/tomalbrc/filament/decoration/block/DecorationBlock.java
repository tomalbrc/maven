package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.api.behaviour.*;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.VirtualDestroyStage;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import org.jetbrains.annotations.NotNull;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;

public abstract class DecorationBlock extends SimpleBlock implements PolymerBlock, BlockWithElementHolder, class_3737, VirtualDestroyStage.Marker {
    final protected class_2960 decorationId;
    final protected DecorationData data;
    final protected Map<BlockData.BlockStateMeta, String> cmdMap = new Reference2ObjectOpenHashMap<>();

    public DecorationBlock(class_2251 properties, DecorationData data) {
        super(properties, data);
        this.decorationId = data.id();
        this.data = data;
    }

    public void postRegister() {
        this.stateMap = this.data.createStandardStateMap();
        if (data.blockResource() != null) {
            for (Map.Entry<class_2680, BlockData.BlockStateMeta> stateMapEntry : this.stateMap.entrySet()) {
                for (Map.Entry<String, class_2960> blockResourceModelsEntry : this.blockData.blockResource().getModels().entrySet()) {
                    boolean same = blockResourceModelsEntry.getValue().equals(stateMapEntry.getValue().polymerBlockModel().model());
                    if (same) {
                        this.cmdMap.put(stateMapEntry.getValue(), blockResourceModelsEntry.getKey());
                    }
                }
            }
        }
        this.stateDefinitionEx.method_11662().forEach(class_2680::method_26200);
    }

    public DecorationData getDecorationData() {
        return this.data;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state, PacketContext packetContext) {
        DecorationData decorationData = getDecorationData();
        if (decorationData != null) {
            boolean passthrough = !decorationData.hasBlocks();

            var newState = state;
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
                if (behaviour.getValue() instanceof BlockBehaviour<?> blockBehaviour) {
                    newState = blockBehaviour.modifyPolymerBlockState(state, newState);
                }
            }

            var customBlock = decorationData.block(state);
            class_2680 blockState = customBlock == null ? passthrough ? class_2246.field_10124.method_9564() : class_2246.field_10499.method_9564() : customBlock;
            boolean waterlogged = newState.method_28498(class_2741.field_12508) && newState.method_11654(class_2741.field_12508);
            if (passthrough && waterlogged) {
                return class_2246.field_10382.method_9564();
            } else if (blockState.method_28498(class_2741.field_12508)) {
                blockState = blockState.method_11657(class_2741.field_12508, waterlogged);
            }

            return blockState;
        }

        return super.getPolymerBlockState(state, packetContext);
    }

    @Override
    public void method_55124(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
        if (!blockState.method_26215()) {
            this.removeDecoration(level, blockPos, null);
        }
    }

    @Override
    @NotNull
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2680 returnVal = super.method_9576(level, blockPos, blockState, player);
        this.removeDecoration(level, blockPos, player);
        return returnVal;
    }

    protected void removeDecoration(class_1937 level, class_2338 blockPos, class_1657 player) {
        class_2586 blockEntity = level.method_8321(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            if (player != null) {
                for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : decorationBlockEntity.getBehaviours()) {
                    if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                        decorationBehaviour.postBreak(decorationBlockEntity, blockPos, player);
                    }
                }
            }

            decorationBlockEntity.destroyStructure(player == null || !player.method_56992());
        } else {
            level.method_22352(blockPos, false);
        }
    }

    @Override
    @NotNull
    public class_265 method_9549(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        if (!getDecorationData().hasBlocks()) {
            return class_259.method_1073();
        } else {
            return super.method_9549(blockState, blockGetter, blockPos, collisionContext);
        }
    }

    public float getVisualRotationYInDegrees(class_2680 blockState) {
        if (blockState.method_26204() instanceof DecorationBlock decorationBlock) {
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : decorationBlock.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationRotationProvider rotationProvider) {
                    return rotationProvider.getVisualRotationYInDegrees(blockState);
                }
            }
        }

        return 0;
    }

    abstract public class_1799 visualItemStack(class_4538 levelReader, class_2338 blockPos, class_2680 blockState);


    public void postBreak(DecorationBlockEntity decorationBlockEntity, class_2338 blockPos, class_1657 player) {

    }
}

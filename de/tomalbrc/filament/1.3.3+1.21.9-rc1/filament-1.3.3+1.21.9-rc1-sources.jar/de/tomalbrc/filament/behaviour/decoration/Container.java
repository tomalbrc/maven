package de.tomalbrc.filament.behaviour.decoration;

import de.tomalbrc.filament.api.behaviour.ContainerLike;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.FilamentContainer;
import de.tomalbrc.filament.util.TextUtil;
import de.tomalbrc.filament.util.Util;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_4838;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_747;
import net.minecraft.class_9288;
import net.minecraft.class_9297;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.class_9473;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * Decoration containers, such as chests, or just drawers etc.
 */
public class Container implements DecorationBehaviour<Container.Config>, ContainerLike {
    public FilamentContainer container;
    public class_5321<class_52> lootTable;
    public long lootTableSeed;

    private final Config config;

    public Container(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Container.Config getConfig() {
        return config;
    }

    @Override
    public void init(DecorationBlockEntity blockEntity) {
        this.container = new FilamentContainer(blockEntity, config.size, config.purge);

        var item = blockEntity.getItem();
        if (item.method_57826(class_9334.field_49622)) {
            Objects.requireNonNull(blockEntity.getItem().method_58694(class_9334.field_49622)).method_57492(container.field_5828);
        }

        if (config.openAnimation != null) {
            container.setOpenCallback(() -> blockEntity.getOrCreateHolder().playAnimation(config.openAnimation, 2));
        }
        if (config.closeAnimation != null) {
            container.setCloseCallback(() -> blockEntity.getOrCreateHolder().playAnimation(config.closeAnimation, 2));
        }
    }

    @Override
    public void write(class_11372 output, DecorationBlockEntity decorationBlockEntity) {
        if (!container.method_54872(output))
            class_1262.method_5426(output.method_71461("Container"), this.container.field_5828);
    }

    @Override
    public void read(class_11368 input, DecorationBlockEntity decorationBlockEntity) {
        if (!container.method_54871(input))
            input.method_71420("Container").ifPresent(x -> class_1262.method_5429(x, container.field_5828));
    }

    @Override
    public class_1269 interact(class_3222 player, class_1268 hand, class_243 location, DecorationBlockEntity decorationBlockEntity) {
        if (!player.method_21823()) {
            class_2561 containerName = customName() != null && showCustomName() ? customName() : TextUtil.formatText(config.name);

            player.method_17355(new class_747((id, inventory, p) -> Util.createMenu(container, id, inventory, p), containerName));

            if (config.angerPiglins) class_4838.method_24733(player.method_51469(), player, true);

            decorationBlockEntity.method_5431();

            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }

    @Override
    public void destroy(DecorationBlockEntity decorationBlockEntity, boolean dropItem) {
        container.setValid(false);
        if (!config.canPickup) {
            class_1264.method_5451(decorationBlockEntity.method_10997(), decorationBlockEntity.method_11016(), container);
        }
    }

    @Override
    public void modifyDrop(DecorationBlockEntity blockEntity, class_1799 itemStack) {
        if (config.canPickup) {
            itemStack.method_57379(class_9334.field_49622, class_9288.method_57493(container.method_54454()));
        }
    }

    @Override
    public void applyImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9473 dataComponentGetter) {
        dataComponentGetter.method_58695(class_9334.field_49622, class_9288.field_49334).method_57492(this.container.field_5828);

        class_9297 seededContainerLoot = dataComponentGetter.method_58694(class_9334.field_49626);
        if (seededContainerLoot != null) {
            this.lootTable = seededContainerLoot.comp_2414();
            this.lootTableSeed = seededContainerLoot.comp_2415();
        }
    }

    @Override
    public void collectImplicitComponents(DecorationBlockEntity decorationBlockEntity, class_9323.class_9324 builder) {
        builder.method_57840(class_9334.field_49622, class_9288.method_57493(this.container.field_5828));

        if (this.lootTable != null) {
            builder.method_57840(class_9334.field_49626, new class_9297(this.lootTable, this.lootTableSeed));
        }
    }

    public static class_3917<?> getMenuType(int size) {
        return switch (size) {
            case 9 -> class_3917.field_18664;
            case 2 * 9 -> class_3917.field_18665;
            case 3 * 9 -> class_3917.field_17326;
            case 4 * 9 -> class_3917.field_18666;
            case 5 * 9 -> class_3917.field_18667;
            case 6 * 9 -> class_3917.field_17327;
            case 5 -> class_3917.field_17337;
            default -> null;
        };
    }

    public static class_3917<?> estimateMenuType(int size) {
        if (size <= 5) {
            return class_3917.field_17337;
        }

        int rows = (size + 8) / 9;
        return switch (Math.min(rows, 6)) {
            case 1 -> class_3917.field_18664;
            case 2 -> class_3917.field_18665;
            case 3 -> class_3917.field_17326;
            case 4 -> class_3917.field_18666;
            case 5 -> class_3917.field_18667;
            default -> class_3917.field_17327;
        };
    }

    @Override
    public class_2561 customName() {
        return container.getBlockEntity().method_58693().method_58694(class_9334.field_49631);
    }

    @Override
    public net.minecraft.class_1263 container() {
        return container;
    }

    @Override
    public boolean showCustomName() {
        return config.showCustomName;
    }

    @Override
    public boolean hopperDropperSupport() {
        return config.hopperDropperSupport;
    }

    @Override
    public void removeComponentsFromTag(DecorationBlockEntity decorationBlockEntity, class_11372 valueOutput) {
        valueOutput.method_71478("LootTable");
        valueOutput.method_71478("LootTableSeed");
    }

    @Override
    public void setLootTable(@Nullable class_5321<class_52> resourceKey) {
        lootTable = resourceKey;
    }

    @Override
    public @Nullable class_5321<class_52> getLootTable() {
        return lootTable;
    }

    @Override
    public void setLootTableSeed(long l) {
        lootTableSeed = l;
    }

    @Override
    public long getLootTableSeed() {
        return lootTableSeed;
    }

    public static class Config {
        /**
         * The name displayed in the container UI
         */
        public String name = "Container";

        /**
         * The size of the container, has to be 5 slots or a multiple of 9, up to 6 rows of 9 slots.
         */
        public int size = 9;

        /**
         * Indicates whether the container's contents should be cleared when no player is viewing the inventory.
         */
        public boolean purge = false;

        /**
         * The name of the animation to play when the container is opened (if applicable).
         */
        public String openAnimation = null;

        /**
         * The name of the animation to play when the container is closed (if applicable).
         */
        public String closeAnimation = null;

        /**
         * Flag to indicate whether the container can be picked up like shulker boxes.
         */
        public boolean canPickup = false;

        /**
         * Support hopper and dropper blocks
         */
        public boolean hopperDropperSupport = true;

        public boolean showCustomName = true;

        public boolean angerPiglins = true;
    }
}

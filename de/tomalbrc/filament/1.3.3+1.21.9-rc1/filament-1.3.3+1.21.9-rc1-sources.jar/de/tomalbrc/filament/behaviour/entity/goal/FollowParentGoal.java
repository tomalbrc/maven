package de.tomalbrc.filament.behaviour.entity.goal;

import de.tomalbrc.filament.api.behaviour.EntityBehaviour;
import de.tomalbrc.filament.entity.FilamentMob;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1352;
import net.minecraft.class_1429;

/**
 * Follow parent
 */
public class FollowParentGoal implements EntityBehaviour<FollowParentGoal.Config> {
    private final FollowParentGoal.Config config;

    public FollowParentGoal(Config config) {
        this.config = config;
    }

    @Override
    public void registerGoals(FilamentMob mob) {
        EntityBehaviour.super.registerGoals(mob);

        mob.getGoalSelector().method_6277(config.priority, new FollowParentGoalImpl(mob, config.speedModifier));
    }

    @Override
    @NotNull
    public Config getConfig() {
        return this.config;
    }

    public static class Config {
        int priority;
        float speedModifier = 1.f;
    }

    public static class FollowParentGoalImpl extends class_1352 {
        private final FilamentMob mob;
        @Nullable
        private class_1429 parent;
        private final double speedModifier;
        private int timeToRecalcPath;

        public FollowParentGoalImpl(FilamentMob mob, double d) {
            this.mob = mob;
            this.speedModifier = d;
        }

        public boolean method_6264() {
            if (this.mob.method_5618() >= 0) {
                return false;
            } else {
                List<? extends class_1429> list = this.mob.method_73183().method_8390(class_1429.class, this.mob.method_5829().method_1009(8.0F, 4.0F, 8.0F), x -> x.method_5864() == mob.method_5864());
                class_1429 animal = null;
                double d = Double.MAX_VALUE;

                for(class_1429 animal2 : list) {
                    if (animal2.method_5618() >= 0) {
                        double e = this.mob.method_5858(animal2);
                        if (!(e > d)) {
                            d = e;
                            animal = animal2;
                        }
                    }
                }

                if (animal == null) {
                    return false;
                } else if (d < (double)9.0F) {
                    return false;
                } else {
                    this.parent = animal;
                    return true;
                }
            }
        }

        public boolean method_6266() {
            if (this.mob.method_5618() >= 0) {
                return false;
            } else if (!this.parent.method_5805()) {
                return false;
            } else {
                double d = this.mob.method_5858(this.parent);
                return !(d < (double)9.0F) && !(d > (double)256.0F);
            }
        }

        public void method_6269() {
            this.timeToRecalcPath = 0;
        }

        public void method_6270() {
            this.parent = null;
        }

        public void method_6268() {
            if (--this.timeToRecalcPath <= 0) {
                this.timeToRecalcPath = this.method_38847(10);
                this.mob.method_5942().method_6335(this.parent, this.speedModifier);
            }
        }
    }
}

package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_10225;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

public class ComplexDecorationBlock extends DecorationBlock implements class_2343 {
    public ComplexDecorationBlock(class_2251 properties, DecorationData decorationData) {
        super(properties, decorationData);
    }

    @Override
    public class_1799 visualItemStack(class_4538 levelReader, class_2338 blockPos, class_2680 blockState) {
        var item = ((DecorationBlockEntity) Objects.requireNonNull(levelReader.method_8321(blockPos))).visualItemStack(blockState);

        if (stateMap != null && cmdMap != null) {
            var val = stateMap.get(behaviourModifiedBlockState(blockState, blockState));
            if (val != null && cmdMap.containsKey(val)) {
                item.method_57379(class_9334.field_54199, data.id().method_45138("block/"));
                item.method_57379(class_9334.field_49637, new class_9280(List.of(), List.of(), List.of(cmdMap.get(val)), List.of()));
            }
        }

        return item;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new DecorationBlockEntity(blockPos, blockState);
    }

    @Override
    @NotNull
    public class_1799 method_9574(class_4538 levelReader, class_2338 blockPos, class_2680 blockState, boolean includeData) {
        class_1799 stack;
        class_2586 blockEntity = levelReader.method_8321(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            stack = decorationBlockEntity.getMainBlockEntity().getItem();
            for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : decorationBlockEntity.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                    stack = decorationBehaviour.getCloneItemStack(stack, levelReader, blockPos, blockState, includeData);
                }
            }
        } else {
            stack = super.method_9574(levelReader, blockPos, blockState, includeData);
        }
        return stack;
    }

    @Override
    public @NotNull class_2680 method_9559(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        blockState = super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);

        if (levelReader.method_8321(blockPos) instanceof DecorationBlockEntity blockEntity) {
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : blockEntity.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                    decorationBehaviour.updateShape(blockEntity, blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
                }
            }
        }

        return blockState;
    }
}

package de.tomalbrc.filament.registry;

import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class StrippableRegistry {
    private static final Map<class_2248, Pair<class_2960, class_2960>> strippables = new Reference2ObjectArrayMap<>();

    public static class_2248 get(class_2248 block) {
        if (!has(block))
            return null;

        return class_7923.field_41175.method_63535(strippables.get(block).getFirst());
    }

    public static class_2960 getLootTable(class_2248 block) {
        return strippables.get(block).getSecond();
    }

    public static boolean has(class_2248 block) {
        return strippables.containsKey(block);
    }

    public static void add(class_2248 block, class_2960 replacement, class_2960 lootTable) {
        strippables.putIfAbsent(block, Pair.of(replacement, lootTable));
    }
}

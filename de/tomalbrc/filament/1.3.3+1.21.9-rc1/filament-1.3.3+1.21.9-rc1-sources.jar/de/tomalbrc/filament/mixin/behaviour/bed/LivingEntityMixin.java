package de.tomalbrc.filament.mixin.behaviour.bed;

import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Shadow public abstract Optional<class_2338> getSleepingPos();

    @Inject(method = "checkBedExists", at = @At(value = "HEAD"), cancellable = true)
    private void filament$checkBedExists(CallbackInfoReturnable<Boolean> cir) {
        var value = this.getSleepingPos().map((blockPos) -> this.method_73183().method_8320(blockPos).method_26204() instanceof DecorationBlock decorationBlock && decorationBlock.getDecorationData().behaviour().has(Behaviours.BED)).orElse(false);
        if (value == Boolean.TRUE) {
            cir.setReturnValue(true);
        }
    }
}

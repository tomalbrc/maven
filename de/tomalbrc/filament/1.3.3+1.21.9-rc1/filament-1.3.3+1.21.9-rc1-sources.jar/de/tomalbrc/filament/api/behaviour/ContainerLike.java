package de.tomalbrc.filament.api.behaviour;

import net.minecraft.class_1263;
import net.minecraft.class_2561;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;

public interface ContainerLike {
    class_2561 customName();

    @Nullable
    class_1263 container();

    boolean showCustomName();

    boolean hopperDropperSupport();

    void setLootTable(@Nullable class_5321<class_52> resourceKey);

    @Nullable class_5321<class_52> getLootTable();

    void setLootTableSeed(long l);

    long getLootTableSeed();
}

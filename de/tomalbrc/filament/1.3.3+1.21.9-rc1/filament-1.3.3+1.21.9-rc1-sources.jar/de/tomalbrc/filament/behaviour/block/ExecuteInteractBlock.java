package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.util.ExecuteUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_7923;

public class ExecuteInteractBlock implements BlockBehaviour<ExecuteInteractBlock.Config> {
    private final Config config;

    public ExecuteInteractBlock(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ExecuteInteractBlock.Config getConfig() {
        return config;
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (player instanceof class_3222 serverPlayer) {
            runCommandBlock(serverPlayer, blockPos);
            return class_1269.field_52422;
        }
        return BlockBehaviour.super.useWithoutItem(blockState, level, blockPos, player, blockHitResult);
    }

    @Override
    public @Nullable class_1269 useItemOn(class_1799 itemStack, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult) {
        if (player instanceof class_3222 serverPlayer) {
            runCommandBlock(serverPlayer, blockPos);
            return class_1269.field_52422;
        }
        return BlockBehaviour.super.useItemOn(itemStack, blockState, level, blockPos, player, interactionHand, blockHitResult);
    }

    public void runCommandBlock(class_3222 user, class_2338 blockPos) {
        var cmds = commands();
        if (cmds != null) {
            var pos = config.atBlock ? blockPos.method_46558() : null;
            if (getConfig().console) {
                ExecuteUtil.asConsole(user, pos, cmds.toArray(new String[0]));
            }
            else {
                ExecuteUtil.asPlayer(user, pos, cmds.toArray(new String[0]));
            }

            if (this.config.sound != null) {
                var sound = this.config.sound;
                user.method_51469().method_43129(null, user, class_7923.field_41172.method_63535(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                user.method_51469().method_8651(blockPos, config.dropBlock, user);
            }
        }
    }

    private List<String> commands() {
        return config.commands == null ? this.config.command == null ? null : List.of(this.config.command) : config.commands;
    }

    public static class Config {
        public boolean consumes;

        public String command;
        public List<String> commands;

        public boolean atBlock = false;

        public boolean dropBlock = false;

        public class_2960 sound;
        public boolean console;
    }
}

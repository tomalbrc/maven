package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.mixin.behaviour.strippable.AxeItemAccessor;
import de.tomalbrc.filament.registry.StrippableRegistry;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5712;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_6088;

public class Stripper implements ItemBehaviour<Stripper.Config> {
    private final Config config;

    public Stripper(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Stripper.Config getConfig() {
        return config;
    }

    @Override
    public class_1269 useOn(class_1838 useOnContext) {
        class_1937 level = useOnContext.method_8045();
        class_2338 blockPos = useOnContext.method_8037();
        class_1657 player = useOnContext.method_8036();

        class_2680 optional = this.getNewBlockState(level, blockPos, level.method_8320(blockPos));
        if (optional == null) {
            return class_1269.field_5811;
        } else {
            class_1799 itemStack = useOnContext.method_8041();
            if (player instanceof class_3222) {
                class_174.field_24478.method_23889((class_3222)player, blockPos, itemStack);
            }

            level.method_8652(blockPos, optional, class_2248.field_31030 | class_2248.field_31028 | class_2248.field_31027);
            level.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(player, optional));
            if (player != null) {
                itemStack.method_71012(1, player, useOnContext.method_20287());
            }

            return class_1269.field_5812;
        }
    }

    private class_2680 getNewBlockState(class_1937 level, class_2338 blockPos, class_2680 blockState) {
        var replacementBlock = AxeItemAccessor.getSTRIPPABLES().get(blockState.method_26204());
        if (replacementBlock == null && StrippableRegistry.has(blockState.method_26204())) {
            replacementBlock = StrippableRegistry.get(blockState.method_26204());
        }

        if (replacementBlock != null) {
            level.method_8396(null, blockPos, class_3414.method_47908(config.sound), class_3419.field_15245, 1.0F, 1.0F);
            return replacementBlock.method_34725(blockState);
        } else {
            Optional<class_2680> opt = class_5955.method_34735(blockState);
            if (opt.isPresent()) {
                level.method_8396(null, blockPos, class_3417.field_29541, class_3419.field_15245, 1.0F, 1.0F);
                level.method_8444(null, class_6088.field_31158, blockPos, 0);
                return opt.get();
            } else {
                opt = Optional.ofNullable(class_5953.field_29561.get().get(blockState.method_26204())).map((block) -> block.method_34725(blockState));
                if (opt.isPresent()) {
                    level.method_8396(null, blockPos, class_3417.field_29542, class_3419.field_15245, 1.0F, 1.0F);
                    level.method_8444(null, class_6088.field_31157, blockPos, 0);
                    return opt.get();
                } else {
                    return null;
                }
            }
        }
    }

    public static class Config {
        public class_2960 sound = class_3417.field_14675.comp_3319();
    }
}

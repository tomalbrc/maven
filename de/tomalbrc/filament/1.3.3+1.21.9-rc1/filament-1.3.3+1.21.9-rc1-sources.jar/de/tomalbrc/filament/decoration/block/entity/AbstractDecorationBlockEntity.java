package de.tomalbrc.filament.decoration.block.entity;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.datafixer.DataFix;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.registry.OxidizableRegistry;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public abstract class AbstractDecorationBlockEntity extends class_2586 {
    public static final String MAIN = "Main";
    public static final String VERSION = "V";
    public static final String ITEM = "Item";
    public static final String DIRECTION = "Direction";

    protected class_2338 main;
    protected int version = DataFix.VERSION;

    protected class_2350 direction = class_2350.field_11036;

    public int rotation;

    public AbstractDecorationBlockEntity(class_2338 pos, class_2680 state) {
        super(DecorationRegistry.getBlockEntityType(state), pos, state);
    }

    public boolean isMain() {
        return this.main != null && this.main.equals(class_2338.field_10980);
    }

    public void setMain(class_2338 main) {
        this.main = main;
    }

    public DecorationBlockEntity getMainBlockEntity() {
        assert this.field_11863 != null;
        return (DecorationBlockEntity)this.field_11863.method_8321(new class_2338(this.field_11867).method_10059(this.main));
    }

    public class_2338 mainPosition() {
        return new class_2338(this.field_11867).method_10059(this.main);
    }

    @Override
    protected void method_11014(class_11368 input) {
        super.method_11014(input);

        this.version = input.method_71439(VERSION).orElse(2);
        input.method_71426(MAIN, class_2338.field_25064).ifPresent(main -> this.main = main);

        if (!this.isMain())
            return;

        this.direction = class_2350.method_10143(input.method_71424(DIRECTION, class_2350.field_11036.method_10146()));
    }

    @Override
    protected void method_11007(class_11372 output) {
        super.method_11007(output);

        if (this.main == null) this.main = class_2338.field_10980;

        output.method_71468(MAIN, class_2338.field_25064, this.main);
        output.method_71465(VERSION, this.version);

        if (this.isMain()) {
            output.method_71465(DIRECTION, this.direction.method_10146());
        }
    }

    abstract protected void destroyBlocks(class_1799 particleItem);
    abstract protected void destroyStructure(boolean dropItems);

    public class_2350 getDirection() {
        return this.direction;
    }

    public void setDirection(class_2350 direction) {
        this.direction = direction;
    }

    public class_1799 getItem() {
        var item = method_11010().method_26204().method_8389().method_7854();
        item.method_57365(method_58693());
        return item;
    }

    public float getVisualRotationYInDegrees() {
        return ((DecorationBlock)this.method_11010().method_26204()).getVisualRotationYInDegrees(this.method_11010());
    }
}
package de.tomalbrc.filament.item;

import de.tomalbrc.filament.behaviour.item.Shoot;
import de.tomalbrc.filament.mixin.accessor.AbstractArrowAccessor;
import eu.pb4.polymer.core.api.entity.PolymerEntity;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.elements.ItemDisplayElement;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2752;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3966;
import net.minecraft.class_7833;

public class BaseProjectileEntity extends class_1665 implements PolymerEntity {
    protected class_1799 projectileStack = class_1802.field_8831.method_7854();
    protected class_1799 pickupStack;
    private boolean dealtDamage;
    protected final ElementHolder holder = new ElementHolder() {
        @Override
        protected void notifyElementsOfPositionUpdate(class_243 newPos, class_243 delta) {
        }

        @Override
        protected void startWatchingExtraPackets(class_3244 player, Consumer<class_2596<class_2602>> packetConsumer) {
            packetConsumer.accept(new class_2752(BaseProjectileEntity.this));
        }
    };

    protected ItemDisplayElement mainDisplayElement = new ItemDisplayElement();
    protected final InteractionElement interactionElement = new InteractionElement(); // InteractionElement.redirect(this);
    protected final InteractionElement interactionElement2 = new InteractionElement(); // InteractionElement.redirect(this);

    public Shoot.Config config;

    protected void createMainDisplayElement() {
        this.mainDisplayElement.setItem(this.projectileStack);

        if (!this.holder.getElements().contains(this.mainDisplayElement)) {
            this.holder.addElement(this.mainDisplayElement);
            VirtualEntityUtils.addVirtualPassenger(this, this.mainDisplayElement.getEntityId());
        }

        this.mainDisplayElement.setLeftRotation(class_7833.field_40718.rotationDegrees(180));
        this.mainDisplayElement.setRightRotation(new Quaternionf().rotateY((float) Math.toRadians(method_36454())).mul(config.rotation).normalize());
        this.mainDisplayElement.setTranslation(new Vector3f(0.f, 0.15f, 0.f).add(config.translation));
        this.mainDisplayElement.setScale(config.scale);
    }

    public BaseProjectileEntity(class_1299<? extends class_1665> entityType, class_1937 world) {
        super(entityType, world); // use empty for now, if the future should use the pickupItem of AbstractArrow added in 1.20.3

        EntityAttachment.of(this.holder, this);

        this.interactionElement.setSize(0.5f, 0.25f);
        this.interactionElement2.setSize(0.5f, -0.25f);

        this.holder.addElement(this.interactionElement);
        this.holder.addElement(this.interactionElement2);

        VirtualEntityUtils.addVirtualPassenger(this, this.interactionElement.getEntityId());
        VirtualEntityUtils.addVirtualPassenger(this, this.interactionElement2.getEntityId());
    }

    public ItemDisplayElement getDisplayElement() {
        return this.mainDisplayElement;
    }

    public void setProjectileStack(class_1799 projectileStack) {
        this.projectileStack = projectileStack;
        this.createMainDisplayElement();
    }

    public void setPickupStack(class_1799 itemStack) {
        this.pickupStack = itemStack;
    }

    @Override
    public void method_5773() {
        if (this.field_7576 > 4) {
            this.dealtDamage = true;
        }

        super.method_5773();
    }

    @Nullable
    @Override
    protected class_3966 method_7434(class_243 currentPosition, class_243 nextPosition) {
        return this.dealtDamage ? null : super.method_7434(currentPosition, nextPosition);
    }

    @Override
    public class_1299<?> getPolymerEntityType(PacketContext packetContext) {
        return class_1299.field_6131;
    }

    @Override
    public void modifyRawTrackedData(List<class_2945.class_7834<?>> data, class_3222 player, boolean initial) {
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.FLAGS, (byte) (1 << EntityTrackedData.INVISIBLE_FLAG_INDEX)));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.NO_GRAVITY, true));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.SILENT, true));
        data.add(class_2945.class_7834.method_46360(class_1531.field_7107, (byte) (class_1531.field_30452 | class_1531.field_30444)));
    }

    @Override
    @NotNull
    protected class_1799 method_7445() {
        return this.pickupStack == null ? this.projectileStack : this.pickupStack.method_7972();
    }

    @Override
    protected @NotNull class_1799 method_57314() {
        return class_1799.field_8037;
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        if (entityHitResult.method_17782() instanceof class_1309 target) {
            this.dealtDamage = true;
            class_1297 owner = this.method_24921();
            var damageSource = this.method_48923().method_48799(this, owner);

            double damage = ((AbstractArrowAccessor)this).getBaseDamage();
            if (target.method_64397((class_3218) method_73183(), damageSource, (float) damage)) {
                if (target.method_5864() != class_1299.field_6091 && this.method_24921() instanceof class_1309 livingOwner) {
                    class_1890.method_60619((class_3218) target.method_73183(), livingOwner, damageSource, this.method_59958());
                    this.method_7450(target);
                }
            }
        }

        this.method_18799(this.method_18798().method_18805(-0.01, -0.1, -0.01));
        this.method_5783(class_3417.field_15213, 1.0F, 1.0F);
    }

    @Override
    protected boolean method_34713(class_1657 player) {
        // todo: animate projectile towards player and scale down a bit
        return super.method_34713(player) || this.method_7441() && this.method_34714(player) && player.method_31548().method_7394(this.method_7445());
    }

    @Override
    @NotNull
    protected class_3414 method_7440() {
        return class_3417.field_15104;
    }

    @Override
    public void method_5694(class_1657 player) {
        if (this.method_34714(player) || this.method_24921() == null) {
            super.method_5694(player);
        }
    }

    @Override
    public void method_5749(class_11368 input) {
        super.method_5749(input);

        this.projectileStack = input.method_71426("Item", class_1799.field_24671).orElse(class_1799.field_8037);
        this.pickupStack = input.method_71426("PickupItem", class_1799.field_24671).orElse(class_1799.field_8037);
        this.createMainDisplayElement();

        this.dealtDamage = input.method_71433("DealtDamage", true);
    }

    @Override
    public void method_5652(class_11372 output) {
        super.method_5652(output);

        if (this.projectileStack != null && !this.projectileStack.method_7960()) output.method_71468("Item", class_1799.field_24671, this.projectileStack);
        if (this.pickupStack != null && !this.pickupStack.method_7960()) output.method_71468("PickupItem", class_1799.field_24671, this.pickupStack);

        output.method_71472("DealtDamage", this.dealtDamage);
    }

    @Override
    public void method_7446() {
        if (this.field_7572 != class_1666.field_7593) {
            super.method_7446();
        }
    }
}
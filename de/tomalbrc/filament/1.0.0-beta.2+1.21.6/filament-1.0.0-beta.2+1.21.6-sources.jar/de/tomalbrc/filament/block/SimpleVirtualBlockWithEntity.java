package de.tomalbrc.filament.block;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.BlockBehaviourWithEntity;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.properties.BlockProperties;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;

public class SimpleVirtualBlockWithEntity extends SimpleVirtualBlock implements class_2343 {
    public SimpleVirtualBlockWithEntity(class_2251 properties, BlockData<BlockProperties> data) {
        super(properties, data);
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof BlockBehaviourWithEntity<?> behaviourWithEntity) {
                var res = behaviourWithEntity.newBlockEntity(blockPos, blockState);
                if (res != null)
                    return res;
            }
        }

        return null;
    }

    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 blockState, class_2591<T> blockEntityType) {
        if (level.field_9236)
            return null;

        for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
            if (behaviour.getValue() instanceof BlockBehaviourWithEntity<?> behaviourWithEntity) {
                var res = behaviourWithEntity.getTicker(level, blockState, blockEntityType);
                if (res != null)
                    return res;
            }
        }

        return null;
    }
}

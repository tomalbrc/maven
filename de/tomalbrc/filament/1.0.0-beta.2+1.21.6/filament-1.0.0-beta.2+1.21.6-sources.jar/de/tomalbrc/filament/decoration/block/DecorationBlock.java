package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.DecorationRotationProvider;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.VirtualDestroyStage;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import org.jetbrains.annotations.NotNull;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;

public abstract class DecorationBlock extends SimpleBlock implements PolymerBlock, BlockWithElementHolder, class_3737, VirtualDestroyStage.Marker {
    final protected class_2960 decorationId;
    DecorationData data;

    public DecorationBlock(class_2251 properties, DecorationData data) {
        super(properties, data);
        this.decorationId = data.id();
        this.data = data;

        this.stateDefinitionEx.method_11662().forEach(class_2680::method_26200);
        this.field_10647.method_11662().forEach(class_2680::method_26200);
    }

    @Override
    protected void initCaches() {

    }

    public void postRegister() {
        this.stateDefinitionEx.method_11662().forEach(class_2680::method_26200);
    }

    public DecorationData getDecorationData() {
        return this.data;
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state, PacketContext packetContext) {
        if (getDecorationData() != null) {
            DecorationData decorationData = getDecorationData();
            boolean passthrough = !decorationData.hasBlocks();

            var newState = state;
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
                if (behaviour.getValue() instanceof BlockBehaviour<?> blockBehaviour) {
                    newState = blockBehaviour.modifyPolymerBlockState(state, newState);
                }
            }

            class_2680 blockState = passthrough ? class_2246.field_10124.method_9564() : decorationData.block();
            boolean waterlogged = newState.method_28498(class_2741.field_12508) && newState.method_11654(class_2741.field_12508);
            if (passthrough && waterlogged) {
                return class_2246.field_10382.method_9564();
            } else if (blockState.method_28498(class_2741.field_12508)) {
                blockState = blockState.method_11657(class_2741.field_12508, waterlogged);
            }

            return blockState;
        }

        return super.getPolymerBlockState(state, packetContext);
    }

    @Override
    public void method_55124(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
        if (!blockState.method_26215()) {
            this.removeDecoration(level, blockPos, null);
        }
    }

    @Override
    @NotNull
    public class_2680 method_9576(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        class_2680 returnVal = super.method_9576(level, blockPos, blockState, player);
        this.removeDecoration(level, blockPos, player);
        return returnVal;
    }

    protected void removeDecoration(class_1937 level, class_2338 blockPos, class_1657 player) {
        class_2586 blockEntity = level.method_8321(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            decorationBlockEntity.destroyStructure(player == null || !player.method_68878());
        } else {
            level.method_22352(blockPos, false);
        }
    }

    @Override
    @NotNull
    public class_265 method_9549(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        if (!getDecorationData().hasBlocks()) {
            return class_259.method_1073();
        } else {
            return super.method_9549(blockState, blockGetter, blockPos, collisionContext);
        }
    }

    public float getVisualRotationYInDegrees(class_2680 blockState) {
        float rotation = 0;
        if (blockState.method_26204() instanceof DecorationBlock decorationBlock) {
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : decorationBlock.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationRotationProvider rotationProvider) {
                    return rotationProvider.getVisualRotationYInDegrees(blockState);
                }
            }
        }

        return 0;
    }

    abstract public class_1799 visualItemStack(class_4538 levelReader, class_2338 blockPos, class_2680 blockState);
}

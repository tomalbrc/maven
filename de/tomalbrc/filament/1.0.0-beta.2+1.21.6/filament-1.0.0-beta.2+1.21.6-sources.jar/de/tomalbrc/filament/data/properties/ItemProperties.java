package de.tomalbrc.filament.data.properties;

import eu.pb4.placeholders.api.TextParserUtils;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_2561;

// For shared properties that make sense for both, item, blocks *and* decoration
public class ItemProperties {
    public static final ItemProperties EMPTY = new ItemProperties();

    public int durability = Integer.MIN_VALUE;
    public int stackSize = 64;
    public List<String> lore;
    public boolean fireResistant;
    public boolean copyComponents;

    public void appendHoverText(Consumer<class_2561> tooltip) {
        if (this.lore != null)
            this.lore.forEach(line -> tooltip.accept(TextParserUtils.formatNodesSafe(line).toText()));
    }

    public class_1792.class_1793 toItemProperties() {
        class_1792.class_1793 props = new class_1792.class_1793();
        props.method_7889(stackSize);

        if (durability != Integer.MIN_VALUE)
            props.method_7895(durability);

        if (fireResistant)
            props.method_24359();

        return props;
    }
}

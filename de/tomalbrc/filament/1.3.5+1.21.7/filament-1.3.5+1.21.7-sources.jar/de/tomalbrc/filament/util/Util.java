package de.tomalbrc.filament.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.filament.data.Data;
import de.tomalbrc.filament.gui.PaginatedContainerGui;
import de.tomalbrc.filament.gui.VirtualChestMenu;
import de.tomalbrc.filament.item.FilamentItem;
import de.tomalbrc.filament.util.mixin.RegistryUnfreezer;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.core.impl.interfaces.PolymerIdList;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3300;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import net.minecraft.class_8013;
import net.minecraft.class_8805;
import net.minecraft.class_9334;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static net.minecraft.class_9334.field_54199;

public class Util {
    public static final class_8013 SEGMENTED_ANGLE8 = new class_8013(3); // 3 bits precision = 8

    public static class_2960 id(String s) {
        return class_2960.method_60655(Constants.MOD_ID, s);
    }

    public static Optional<Integer> validateAndConvertHexColor(String hexColor) {
        var res = class_8805.field_46234.decode(JsonOps.INSTANCE, new JsonPrimitive(hexColor));
        if (res.isSuccess()) {
            return Optional.of(res.getOrThrow().getFirst().comp_1971());
        }
        return Optional.empty();
    }

    public static void spawnAtLocation(class_1937 level, class_243 pos, class_1799 itemStack) {
        if (!itemStack.method_7960() && !level.method_8608()) {
            class_1542 itemEntity = new class_1542(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), itemStack);
            itemEntity.method_6988();
            level.method_8649(itemEntity);
        }
    }

    public static void loadDatapackContents(class_3300 resourceManager) {
        ((RegistryUnfreezer) class_7923.field_41175).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_41178).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_41181).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_41177).filament$unfreeze();
        ((RegistryUnfreezer) class_7923.field_44687).filament$unfreeze();

        for (SimpleSynchronousResourceReloadListener listener : FilamentReloadUtil.getReloadListeners()) {
            listener.method_14491(resourceManager);
        }

        ((RegistryUnfreezer) class_7923.field_41175).filament$freeze();
        ((RegistryUnfreezer) class_7923.field_41178).filament$freeze();
        ((RegistryUnfreezer) class_7923.field_41181).filament$freeze();
        ((RegistryUnfreezer) class_7923.field_41177).filament$freeze();
        ((RegistryUnfreezer) class_7923.field_44687).filament$freeze();

        ((PolymerIdList<?>) class_2248.field_10651).polymer$reorderEntries();
        ((PolymerIdList<?>) class_3611.field_15904).polymer$reorderEntries();
    }

    public static void damageAndBreak(int i, class_1799 itemStack, class_1309 livingEntity, class_1304 slot) {
        int newDamage = itemStack.method_7919() + i;
        itemStack.method_7974(newDamage);

        if (newDamage >= itemStack.method_7936()) {
            class_1792 item = itemStack.method_7909();
            itemStack.method_7934(1);
            livingEntity.method_20235(item, slot);
        }
    }

    public static void handleComponentsCustom(JsonElement element, Data<?> data) {
        List<class_2960> comps = List.of(
                Objects.requireNonNull(class_7923.field_49658.method_10221(class_9334.field_52175)),
                Objects.requireNonNull(class_7923.field_49658.method_10221(class_9334.field_49633)),
                Objects.requireNonNull(class_7923.field_49658.method_10221(class_9334.field_49607)),
                Objects.requireNonNull(class_7923.field_49658.method_10221(class_9334.field_49612)),
                Objects.requireNonNull(class_7923.field_49658.method_10221(class_9334.field_49619))
        );

        if (element.getAsJsonObject().has("components")) {
            JsonObject comp = element.getAsJsonObject().get("components").getAsJsonObject();
            for (String key : comp.keySet()) {
                comps.stream().filter(x -> x.toString().equals(key) || x.method_12832().equals(key)).findAny().ifPresent(compId -> {
                    data.putAdditional(class_7923.field_49658.method_63535(compId), comp.get(key));
                });
            }
        }
    }

    public static class_1799 filamentItemStack(class_1799 itemStack, class_1836 tooltipType, PacketContext packetContext, FilamentItem filamentItem) {
        class_1799 stack = PolymerItemUtils.createItemStack(itemStack, tooltipType, packetContext);

        class_2960 dataComponentModel = null;
        if (filamentItem.getData() != null && filamentItem.getData().components().method_57832(field_54199)) {
            dataComponentModel = filamentItem.getData().components().method_58694(field_54199);
        } else if (filamentItem.getData() != null) {
            if (filamentItem.getData().itemModel() != null) {
                dataComponentModel = filamentItem.getData().itemModel();
            } else {
                dataComponentModel = filamentItem.getData().preferredResource() == null ? filamentItem.getData().vanillaItem().method_57347().method_58694(field_54199) : null;
            }
        }
        if (dataComponentModel != null) stack.method_57379(field_54199, dataComponentModel);

        filamentItem.getDelegate().modifyPolymerItemStack(filamentItem.getModelMap(), itemStack, stack, tooltipType, packetContext.getRegistryWrapperLookup(), packetContext.getPlayer());

        return stack;
    }

    public static class_1703 createMenu(class_1263 container, int id, class_1661 inventory, class_1657 player) {
        return createMenu(container, id, inventory, player, false);
    }

    public static class_1703 createMenu(class_1263 container, int id, class_1661 inventory, class_1657 player, boolean forceCustom) {
        class_3917<?> menuType = forceCustom ? null : de.tomalbrc.filament.behaviour.decoration.Container.getMenuType(container.method_5439());

        if (menuType == null) {
            var est = de.tomalbrc.filament.behaviour.decoration.Container.estimateMenuType(container.method_5439());
            return new VirtualChestMenu(est, id, new PaginatedContainerGui(est, (class_3222) player, false, container), player, container);
        }

        return new class_1707(menuType, id, inventory, container, container.method_5439() / 9) {
            @Override
            public void method_61634(class_1263 container, int i, int j) {
                boolean doCheck = FilamentContainer.isPickUpContainer(container);
                for (int y = 0; y < this.method_17388(); ++y) {
                    for (int x = 0; x < 9; ++x) {
                        this.method_7621(new class_1735(container, x + y * 9, i + x * 18, j + y * 18) {
                            @Override
                            public boolean method_7680(class_1799 itemStack) {
                                if (doCheck) {
                                    return itemStack.method_7909().method_31568();
                                }
                                return super.method_7680(itemStack);
                            }
                        });
                    }
                }

            }
        };
    }
}
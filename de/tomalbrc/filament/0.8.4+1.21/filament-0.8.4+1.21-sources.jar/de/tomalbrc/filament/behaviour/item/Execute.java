package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

public class Execute implements ItemBehaviour<Execute.ExecuteConfig> {
    private final ExecuteConfig config;

    public Execute(ExecuteConfig config) {
        this.config = config;
    }

    @Override
    @NotNull
    public ExecuteConfig getConfig() {
        return config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 user, class_1268 hand) {
        if (this.config.command != null) {
            user.method_5682().method_3734().method_44252(user.method_5671(), this.config.command);

            user.method_7259(class_3468.field_15372.method_14956(item));

            if (this.config.sound != null) {
                var sound = this.config.sound;
                level.method_43129(null, user, class_7923.field_41172.method_10223(sound), class_3419.field_15254, 1.0F, 1.0F);
            }

            if (this.config.consumes) {
                user.method_5998(hand).method_7934(1);
            }
            return class_1271.method_22428(user.method_5998(hand));
        }

        return ItemBehaviour.super.use(item, level, user, hand);
    }

    public static class ExecuteConfig {
        public boolean consumes;

        public String command;

        public class_2960 sound;
    }
}

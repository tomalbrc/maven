package de.tomalbrc.filament.decoration.block.entity;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.registry.DecorationRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public abstract class AbstractDecorationBlockEntity extends class_2586 {
    public static final String MAIN = "Main";
    public static final String VERSION = "V";
    public static final String ITEM = "Item";
    public static final String PASSTHROUGH = "Passthrough";
    public static final String ROTATION = "Rotation";
    public static final String DIRECTION = "Direction";

    protected class_2338 main;
    protected int version = 1;

    protected int rotation;

    protected class_2350 direction = class_2350.field_11036;

    protected class_1799 itemStack;

    private boolean passthrough = false;

    public AbstractDecorationBlockEntity(class_2338 pos, class_2680 state) {
        super(DecorationRegistry.getBlockEntityType(state), pos, state);
    }

    public boolean isMain() {
        return this.main != null && this.main.equals(class_2338.field_10980);
    }

    public void setMain(class_2338 main) {
        this.main = main;
    }

    public DecorationBlockEntity getMainBlockEntity() {
        assert this.field_11863 != null;
        return (DecorationBlockEntity)this.field_11863.method_8321(new class_2338(this.field_11867).method_10059(this.main));
    }

    @Override
    protected void method_11014(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11014(compoundTag, provider);

        if (!compoundTag.method_10545(VERSION)) {
            this.version = 1; // upgrade old format
            if (compoundTag.method_10545(MAIN)) this.main = class_2512.method_10691(compoundTag, MAIN).get().method_10059(this.field_11867);
        }
        else {
            this.version = compoundTag.method_10550(VERSION);
            if (compoundTag.method_10545(MAIN)) this.main = class_2512.method_10691(compoundTag, MAIN).get();
        }

        if (compoundTag.method_10545(ITEM)) {
            this.itemStack = class_1799.method_57359(provider, compoundTag.method_10562(ITEM));
        }

        if (this.itemStack == null || this.itemStack.method_7960()) {
            this.itemStack = class_7923.field_41178.method_10223(((DecorationBlock)this.method_11010().method_26204()).getDecorationData().id()).method_7854();
        }

        if (compoundTag.method_10545(PASSTHROUGH)) {
            this.passthrough = compoundTag.method_10577(PASSTHROUGH);
            this.setCollision(!this.passthrough);
        }

        if (!this.isMain())
            return;

        if (compoundTag.method_10545(ROTATION))
            this.rotation = compoundTag.method_10550(ROTATION);
        if (compoundTag.method_10545(DIRECTION))
            this.direction = class_2350.method_10143(compoundTag.method_10550(DIRECTION));
    }

    @Override
    protected void method_11007(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11007(compoundTag, provider);

        if (this.itemStack == null) this.itemStack = class_7923.field_41178.method_10223(this.method_11010().method_41520().method_40230().get().method_29177()).method_7854();

        if (this.itemStack == null) {
            Filament.LOGGER.error("No item for decoration! Removing decoration block entity at " + this.method_11016().method_23854());
            this.field_11863.method_22352(this.method_11016(), false);
            this.method_11012();
            return;
        }

        if (this.itemStack != null)
            compoundTag.method_10566(ITEM, this.itemStack.method_57358(provider));

        if (this.main == null) this.main = class_2338.field_10980;

        compoundTag.method_10566(MAIN, class_2512.method_10692(this.main));
        compoundTag.method_10569(VERSION, this.version);
        compoundTag.method_10556(PASSTHROUGH, this.passthrough);

        if (this.isMain()) {
            compoundTag.method_10569(ROTATION, this.rotation);
            compoundTag.method_10569(DIRECTION, this.direction.method_10146());
        }
    }

    abstract protected void destroyBlocks();
    abstract protected void destroyStructure(boolean dropItems);
    abstract protected void setCollisionStructure(boolean collisionStructure);

    protected void setCollision(boolean collision) {
        this.method_11010().method_11657(DecorationBlock.PASSTHROUGH, !collision);
    }

    public class_2350 getDirection() {
        return this.direction;
    }

    public void setDirection(class_2350 direction) {
        this.direction = direction;
    }

    public class_1799 getItem() {
        return this.itemStack;
    }

    public void setItem(class_1799 itemStack) {
        this.itemStack = itemStack;
    }

    public float getVisualRotationYInDegrees() {
        class_2350 direction = this.getDirection();
        int i = direction.method_10166().method_10178() ? 90 * direction.method_10171().method_10181() : 0;
        return (float) class_3532.method_15392(180 + direction.method_10161() * 90 + rotation * 45 + i);
    }

    public void setRotation(int rotation) {
        this.rotation = rotation;
    }

    public int getRotation() {
        return this.rotation;
    }
}
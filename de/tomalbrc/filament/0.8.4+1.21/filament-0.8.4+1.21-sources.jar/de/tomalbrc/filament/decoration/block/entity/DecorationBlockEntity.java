package de.tomalbrc.filament.decoration.block.entity;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.behaviour.Behaviour;
import de.tomalbrc.filament.api.behaviour.BehaviourType;
import de.tomalbrc.filament.api.behaviour.DecorationBehaviour;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.behaviour.BehaviourMap;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.holder.DecorationHolder;
import de.tomalbrc.filament.decoration.util.BlockEntityWithElementHolder;
import de.tomalbrc.filament.registry.DecorationRegistry;
import de.tomalbrc.filament.util.FilamentConfig;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.ChunkAttachment;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7225;

public class DecorationBlockEntity extends AbstractDecorationBlockEntity implements BlockEntityWithElementHolder, BehaviourHolder {
    private final BehaviourMap behaviours = new BehaviourMap();

    @Nullable
    private ElementHolder decorationHolder;

    public BehaviourMap getBehaviours() {
        return this.behaviours;
    }
    public DecorationBlockEntity(class_2338 pos, class_2680 state) {
        super(pos, state);
    }

    @Override
    protected void method_11014(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11014(compoundTag, provider);

        if (this.isMain()) this.loadMain(compoundTag, provider);
    }

    @Override
    public void method_31662(class_1937 level) {
        super.method_31662(level);
        if (isMain() && level != null && this.decorationHolder == null) {
            if (this.behaviours.isEmpty() && this.getDecorationData().behaviourConfig() != null && !this.getDecorationData().behaviourConfig().isEmpty())
                this.initBehaviours(this.getDecorationData().behaviourConfig());
            this.getOrCreateHolder();
        }
    }

    public void loadMain(class_2487 compoundTag, class_7225.class_7874 provider) {
        DecorationData decorationData = this.getDecorationData();
        if (decorationData == null) {
            this.itemStack.method_7922();
            Filament.LOGGER.error("No decoration formats for " + this.itemStack.method_7922() + "!");
        } else if (this.decorationHolder == null) {
            this.setupBehaviour(decorationData);
        }

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : this.behaviours) {
            if (entry.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                decorationBehaviour.read(compoundTag, provider, this);
            }
        }
    }

    @Override
    protected void method_11007(class_2487 compoundTag, class_7225.class_7874 provider) {
        super.method_11007(compoundTag, provider);

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : behaviours) {
            if (entry.getValue() instanceof DecorationBehaviour<?> decorationBehaviour)
                decorationBehaviour.write(compoundTag, provider, this);
        }
    }

    @Override
    public ElementHolder getOrCreateHolder() {
        if (this.decorationHolder != null)
            return this.decorationHolder;

        ElementHolder altHolder = null;
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> entry : this.behaviours) {
            if (entry.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                altHolder = decorationBehaviour.createHolder(this);
                if (altHolder != null) {
                    break;
                }
            }
        }

        if (altHolder == null)
            altHolder = new DecorationHolder(this);

        this.decorationHolder = altHolder;

        return this.decorationHolder;
    }

    @Override
    @Nullable
    public ElementHolder getDecorationHolder() {
        return this.decorationHolder;
    }

    public void setDecorationHolder(@Nullable ElementHolder holder) {
        this.decorationHolder = holder;
    }

    @Override
    public void attach(class_2818 chunk) {
        if (this.isMain() && this.itemStack != null) {
            ElementHolder elementHolder = this.getOrCreateHolder();
            if (elementHolder.getAttachment() == null) {
                new ChunkAttachment(elementHolder, chunk, this.method_11016().method_46558(), !(this.getDecorationHolder() instanceof DecorationHolder));
            }
        }

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviourEntry : this.behaviours) {
            if (behaviourEntry.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                decorationBehaviour.onElementAttach(this, this.decorationHolder);
            }
        }
    }

    @Override
    public void attach(class_3218 level) {
        this.attach((class_2818)level.method_22350(this.method_11016()));
    }

    public void setupBehaviour(DecorationData decorationData) {
        // When placed, decorationId is not yet set?
        if (this.isMain() && this.behaviours.isEmpty() && decorationData.behaviourConfig() != null) {
            this.initBehaviours(decorationData.behaviourConfig());
        }
    }

    @Override
    public void initBehaviours(BehaviourConfigMap behaviourConfigMap) {
        BehaviourHolder.super.initBehaviours(behaviourConfigMap);

        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.behaviours) {
            if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                decorationBehaviour.init(this);
            }
        }
    }

    public class_1269 interact(class_1657 player, class_1268 interactionHand, class_243 location) {
        return this.decorationInteract((class_3222) player, interactionHand, location);
    }

    public class_1269 decorationInteract(class_3222 player, class_1268 interactionHand, class_243 location) {
        if (FilamentConfig.getInstance().preventAdventureModeDecorationInteraction && player.field_13974.method_14257() == class_1934.field_9216)
            return class_1269.field_5811;

        if (!this.isMain()) {
            return this.getMainBlockEntity().decorationInteract(player, interactionHand, location);
        }

        DecorationData decorationData = this.getDecorationData();
        if (decorationData == null) {
            Filament.LOGGER.warn("Can't interact with decoration: Missing decoration data! Location: " + location.toString());
            return class_1269.field_5814;
        }

        class_1269 res = class_1269.field_5811;
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : behaviours) {
            if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                res = decorationBehaviour.interact(player, interactionHand, location, this);
                if (res.method_23665())
                    break;
            }
        }

        return res;
    }

    @Override
    protected void destroyBlocks() {
        class_2680 decorationBlockState = this.method_11010();
        if (DecorationRegistry.isDecoration(decorationBlockState) && this.getDecorationData() != null) {
            if (this.getDecorationData().hasBlocks()) {
                Util.forEachRotated(this.getDecorationData().blocks(), this.method_11016(), this.getVisualRotationYInDegrees(), blockPos -> {
                    if (this.method_10997() != null && DecorationRegistry.isDecoration(this.method_10997().method_8320(blockPos))) {
                        if (this.getDecorationData().properties().showBreakParticles)
                            Util.showBreakParticle((class_3218) this.field_11863, blockPos, this.getDecorationData().properties().useItemParticles ? this.getItem() : this.getDecorationData().properties().blockBase.method_8389().method_7854(), (float) blockPos.method_46558().method_10216(), (float) blockPos.method_46558().method_10214(), (float) blockPos.method_46558().method_10215());
                        this.method_10997().method_8650(blockPos, false);
                    }
                });
            } else {
                assert this.field_11863 != null;

                class_2338 blockPos = this.method_11016();

                if (this.getDecorationData().properties().showBreakParticles)
                    Util.showBreakParticle((class_3218) this.field_11863, blockPos, this.getDecorationData().properties().useItemParticles ? this.getItem() : this.getDecorationData().properties().blockBase.method_8389().method_7854(), (float) blockPos.method_46558().method_10216(), (float) blockPos.method_46558().method_10214(), (float) blockPos.method_46558().method_10215());

                class_3414 breakSound = this.getDecorationData().properties().blockBase.method_9564().method_26231().method_10595();
                this.field_11863.method_8396(null, this.method_11016(),  breakSound, class_3419.field_15245, 1.0F, 1.0F);
                this.field_11863.method_22352(this.method_11016(), true);
            }
        }
    }

    @Override
    public void destroyStructure(boolean dropItem) {
        if (!this.isMain()) {
            if (this.method_10997() != null && this.main != null && this.method_10997().method_8321(this.method_11016().method_10059(this.main)) instanceof DecorationBlockEntity mainBlockEntity) {
                mainBlockEntity.destroyStructure(dropItem);
            }
            return;
        }

        if (!this.getDecorationData().properties().drops) {
            dropItem = false;
        }

        class_1799 thisItemStack = this.getItem();
        for (Map.Entry<BehaviourType<?, ?>, Behaviour<?>> behaviour : this.behaviours) {
            if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                if (dropItem)
                    decorationBehaviour.modifyDrop(this, thisItemStack);
                decorationBehaviour.destroy(this, dropItem);
            }
        }

        if (dropItem) {
            Util.spawnAtLocation(this.method_10997(), this.method_11016().method_46558(), thisItemStack);
        }

        this.removeHolder(this.decorationHolder);

        this.destroyBlocks();
    }

    private void removeHolder(ElementHolder holder) {
        if (holder != null && holder.getAttachment() != null)
            holder.getAttachment().destroy();
    }

    @Override
    protected void setCollisionStructure(boolean collisionStructure) {
        if (this.getDecorationData() != null && this.getDecorationData().blocks() != null) {
            Util.forEachRotated(this.getDecorationData().blocks(), this.method_11016(), this.getVisualRotationYInDegrees(), blockPos -> {
                class_2680 blockState = this.method_11010();

                if (DecorationRegistry.isDecoration(blockState)) {
                    blockState.method_11657(DecorationBlock.PASSTHROUGH, !collisionStructure);
                }
            });
        }
    }

    public DecorationData getDecorationData() {
        return ((DecorationBlock)this.method_11010().method_26204()).getDecorationData();
    }
}

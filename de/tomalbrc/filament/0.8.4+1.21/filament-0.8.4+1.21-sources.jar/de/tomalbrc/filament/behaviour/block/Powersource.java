package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.jetbrains.annotations.NotNull;

/**
 * Block behaviour for redstone power source
 */
public class Powersource implements BlockBehaviour<Powersource.PowersourceConfig> {
    private final PowersourceConfig config;

    public Powersource(PowersourceConfig config) {
        this.config = config;
    }

    @Override
    public int getSignal(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_2350 direction) {
        return config.value;
    }

    @Override
    @NotNull
    public PowersourceConfig getConfig() {
        return this.config;
    }

    public static class PowersourceConfig {
        /**
         * The redstone power value
         */
        public int value = 15;
    }
}

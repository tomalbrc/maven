package de.tomalbrc.filament.mixin;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4466;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

// For crops
@Mixin(class_4466.class_4474.class)
public abstract class BeeMixin {
    @Inject(locals = LocalCapture.CAPTURE_FAILSOFT, method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z", ordinal = 0))
    void filament$beeAddCustom(CallbackInfo ci, int i, class_2338 blockPos, class_2680 blockState, class_2248 block, LocalRef<class_2680> blockState2) {
        //blockState2.set(Blocks.STONE.defaultBlockState());
    }
}

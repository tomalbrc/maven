package de.tomalbrc.filament.mixin.trim;

import de.tomalbrc.filament.trim.FilamentTrimPatterns;
import net.minecraft.class_2370;
import net.minecraft.class_2385;
import net.minecraft.class_3300;
import net.minecraft.class_6903;
import net.minecraft.class_7655;
import net.minecraft.class_7924;
import net.minecraft.class_8056;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7655.class)
public class RegistryDataLoaderMixin {
    @Inject(at = @At(value = "TAIL"), method = "method_56514")
    private static void filament$bootstrap(class_3300 resourceManager, class_7655.class_9158 loader, class_6903.class_7863 registryInfoLookup, CallbackInfo ci) {
        if (loader.comp_2246() instanceof class_2370 mappedRegistry) {
            if (mappedRegistry.method_30517() == class_7924.field_42082) {
                FilamentTrimPatterns.bootstrap((class_2385<class_8056>) mappedRegistry);
            }
        }
    }
}

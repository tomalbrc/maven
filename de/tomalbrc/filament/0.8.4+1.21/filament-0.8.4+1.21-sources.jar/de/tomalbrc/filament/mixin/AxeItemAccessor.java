package de.tomalbrc.filament.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1743;
import net.minecraft.class_2248;

@Mixin(class_1743.class)
public interface AxeItemAccessor {
    @Accessor
    static Map<class_2248, class_2248> getSTRIPPABLES() {
        throw new UnsupportedOperationException();
    }
}

package de.tomalbrc.filament.block;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.item.SimpleItem;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_3222;
import net.minecraft.class_5151;

public class SimpleBlockItem extends SimpleItem implements PolymerItem, class_5151, BehaviourHolder {

    private final PolymerModelData itemModelData;

    private final BlockData blockData;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties, data.properties(), data.vanillaItem());
        this.blockData = data;
        boolean hasItemModels = data.itemResource() != null && data.itemResource().models() != null;
        this.itemModelData = PolymerResourcePackUtils.requestModel(
                data.vanillaItem(),
                hasItemModels ? data.itemResource().models().get("default") : data.blockResource().models().entrySet().iterator().next().getValue());

        this.initBehaviours(data.behaviourConfig());
    }

    public BlockData getBlockData() {
        return this.blockData;
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, class_3222 player) {
        return this.itemModelData.item();
    }

    @Override
    public int getPolymerCustomModelData(class_1799 itemStack, class_3222 player) {
        return this.itemModelData.value();
    }
}
package de.tomalbrc.filament.data.properties;

import java.util.Map;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

public class BlockStateMappedProperty<T> {
    private T value;
    private Map<String, T> valueMap;

    public BlockStateMappedProperty(T value) {
        this.value = value;
    }

    public BlockStateMappedProperty(Map<String, T> valueMap) {
        this.valueMap = valueMap;
    }

    public T getValue(class_2680 blockState) {
        if (this.isMap()) {
            for (Map.Entry<String, T> entry : valueMap.entrySet()) {
                String[] props = entry.getKey().split(",");
                for (String propWithValue : props) {
                    String[] pair = propWithValue.split("=");
                    assert pair.length == 2;
                    boolean missmatch = false;
                    for (class_2769<?> property : blockState.method_28501()) {
                        if (property.method_11899().equals(pair[0])) {
                            if (!blockState.method_11654(property).toString().equals(pair[1])) {
                                missmatch = true;
                            }
                        }
                    }

                    if (!missmatch) {
                        return entry.getValue();
                    }
                }
            }
        }

        return this.value;
    }

    public T getOrDefault(class_2680 key, T def) {
        var val = this.getValue(key);
        return val == null ? def : val;
    }

    public boolean isMap() {
        return this.valueMap != null && !this.valueMap.isEmpty();
    }

    public T getRawValue() {
        return this.value;
    }
}

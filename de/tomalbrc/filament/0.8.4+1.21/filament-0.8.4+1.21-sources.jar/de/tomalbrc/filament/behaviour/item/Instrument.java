package de.tomalbrc.filament.behaviour.item;

import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5712;
import org.jetbrains.annotations.NotNull;

public class Instrument implements ItemBehaviour<Instrument.InstrumentConfig> {
    private final InstrumentConfig config;

    public Instrument(InstrumentConfig config) {
        this.config = config;
    }

    @Override
    @NotNull
    public InstrumentConfig getConfig() {
        return this.config;
    }

    @Override
    public class_1271<class_1799> use(class_1792 item, class_1937 level, class_1657 player, class_1268 interactionHand) {
        class_1799 itemStack = player.method_5998(interactionHand);

        player.method_6019(interactionHand);
        play(level, player, config);
        if (config.useDuration > 0) player.method_7357().method_7906(item, config.useDuration);

        player.method_7259(class_3468.field_15372.method_14956(item));

        return class_1271.method_22428(itemStack);
    }

    private static void play(class_1937 level, class_1657 player, Instrument.InstrumentConfig instrument) {
        float f = instrument.range / 25.0F;
        level.method_43129(null, player, class_3414.method_47908(instrument.sound), class_3419.field_15247, f, 1.0F);
        level.method_32888(class_5712.field_39415, player.method_19538(), class_5712.class_7397.method_43285(player));
    }

    public static class InstrumentConfig {
        public class_2960 sound = null;

        public int range = 0;

        public int useDuration = 0;
    }
}

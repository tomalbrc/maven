package de.tomalbrc.filament.mixin.trim;

import com.llamalad7.mixinextras.sugar.Local;
import de.tomalbrc.filament.trim.FilamentTrimPatterns;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_9129;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net/minecraft/world/item/ItemStack$1")
public abstract class ItemStackPacketCodecMixin {
    @Inject(method = "encode(Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/world/item/ItemStack;)V", at = @At("HEAD"))
    private void filament$modifyChainmail(class_9129 registryFriendlyByteBuf, class_1799 itemStack, CallbackInfo ci, @Local(argsOnly = true) class_9129 buf) {
        if (FilamentTrimPatterns.overwriteChainMail()) {
            class_3222 player = PolymerUtils.getPlayerContext();
            boolean isPolymerStack = itemStack.method_7909() instanceof PolymerItem;
            if (player != null && !isPolymerStack && itemStack.method_7909() instanceof class_1738 armorItem && armorItem.method_7686().method_55838(class_1740.field_7887))
                FilamentTrimPatterns.apply(player.method_56673(), itemStack);
        }
    }
}
package de.tomalbrc.filament.behaviour.block;

import com.google.gson.JsonParseException;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.data.BlockData;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2760;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import net.minecraft.class_9904;

public class Trapdoor implements BlockBehaviour<Trapdoor.Config>, class_3737 {
    private final Config config;

    public Trapdoor(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Config getConfig() {
        return this.config;
    }

    @Override
    public class_2680 rotate(class_2680 blockState, class_2470 rotation) {
        return blockState.method_11657(class_2741.field_12481, rotation.method_10503(blockState.method_11654(class_2741.field_12481)));
    }

    @Override
    public class_2680 mirror(class_2680 blockState, class_2415 mirror) {
        return blockState.method_26186(mirror.method_10345(blockState.method_11654(class_2741.field_12481)));
    }

    @Override
    public Optional<Boolean> isPathfindable(class_2680 blockState, class_10 pathComputationType) {
        return switch (pathComputationType) {
            case field_50, field_51 -> Optional.of(blockState.method_11654(class_2741.field_12537));
            case field_48 -> Optional.of(blockState.method_11654(class_2741.field_12508));
        };
    }

    @Override
    public class_1269 useWithoutItem(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (!this.config.canOpenByHand) {
            return class_1269.field_5811;
        }
        this.toggle(blockState, level, blockPos, player);
        return class_1269.field_52422;
    }

    @Override
    public void onExplosionHit(class_2680 blockState, class_3218 level, class_2338 blockPos, class_1927 explosion, BiConsumer<class_1799, class_2338> biConsumer) {
        if (explosion.method_60274() && this.config.canOpenByWindCharge && !blockState.method_11654(class_2741.field_12484)) {
            this.toggle(blockState, level, blockPos, null);
        }
    }

    private void toggle(class_2680 blockState, class_1937 level, class_2338 blockPos, @Nullable class_1657 player) {
        class_2680 blockState2 = blockState.method_28493(class_2741.field_12537);
        level.method_8652(blockPos, blockState2, 2);
        if (blockState2.method_11654(class_2741.field_12508)) {
            level.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        this.playSound(player, level, blockPos, blockState2.method_11654(class_2741.field_12537));
    }

    protected void playSound(@Nullable class_1657 player, class_1937 level, class_2338 blockPos, boolean open) {
        level.method_8396(player, blockPos, open ? this.config.openSound : this.config.closeSound, class_3419.field_15245, 1.0f, level.method_8409().method_43057() * 0.1f + 0.9f);
        level.method_33596(player, open ? class_5712.field_28168 : class_5712.field_28169, blockPos);
    }

    @Override
    public void neighborChanged(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, class_9904 orientation, boolean bl) {
        if (level.field_9236) {
            return;
        }
        boolean bl2 = level.method_49803(blockPos);
        if (bl2 != blockState.method_11654(class_2741.field_12484)) {
            if (blockState.method_11654(class_2741.field_12537) != bl2) {
                blockState = blockState.method_11657(class_2741.field_12537, bl2);
                this.playSound(null, level, blockPos, bl2);
            }
            level.method_8652(blockPos, blockState.method_11657(class_2741.field_12484, bl2), 2);
            if (blockState.method_11654(class_2741.field_12508)) {
                level.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
            }
        }
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 self, class_1750 blockPlaceContext) {
        class_2680 blockState = self.method_26204().method_9564();
        class_3610 fluidState = blockPlaceContext.method_8045().method_8316(blockPlaceContext.method_8037());
        class_2350 direction = blockPlaceContext.method_8038();
        blockState = blockPlaceContext.method_7717() || !direction.method_10166().method_10179() ? blockState.method_11657(class_2741.field_12481, blockPlaceContext.method_8042().method_10153()).method_11657(class_2741.field_12518, direction == class_2350.field_11036 ? class_2760.field_12617 : class_2760.field_12619) : blockState.method_11657(class_2741.field_12481, direction).method_11657(class_2741.field_12518, blockPlaceContext.method_17698().field_1351 - (double)blockPlaceContext.method_8037().method_10264() > 0.5 ? class_2760.field_12619 : class_2760.field_12617);
        if (blockPlaceContext.method_8045().method_49803(blockPlaceContext.method_8037())) {
            blockState = blockState.method_11657(class_2741.field_12537, true).method_11657(class_2741.field_12484, true);
        }
        return blockState.method_11657(class_2741.field_12508, fluidState.method_15772() == class_3612.field_15910);
    }

    @Override
    public boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2741.field_12481, class_2741.field_12537, class_2741.field_12518, class_2741.field_12484, class_2741.field_12508);
        return true;
    }

    @Override
    public class_3610 getFluidState(class_2680 blockState) {
        if (blockState.method_11654(class_2741.field_12508)) {
            return class_3612.field_15910.method_15729(false);
        }
        return null;
    }

    @Override
    public class_2680 updateShape(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        if (blockState.method_11654(class_2741.field_12508)) {
            scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
        }
        return BlockBehaviour.super.updateShape(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
    }

    @Override
    public class_2680 modifyDefaultState(class_2680 blockState) {
        return blockState.method_11657(class_2741.field_12484, false).method_11657(class_2741.field_12508, false).method_11657(class_2741.field_12481, class_2350.field_11043).method_11657(class_2741.field_12537, false).method_11657(class_2741.field_12518, class_2760.field_12617);
    }

    @Override
    public boolean modifyStateMap(Map<class_2680, BlockData.BlockStateMeta> map, BlockData data) {
        for (Map.Entry<String, PolymerBlockModel> entry : data.blockResource().models().entrySet()) {
            PolymerBlockModel blockModel = entry.getValue();

            class_2259.class_7211 parsed;
            String str = String.format("%s[%s]", data.id(), entry.getKey());
            try {
                parsed = class_2259.method_41957(class_7923.field_41175, str, false);
            } catch (CommandSyntaxException e) {
                throw new JsonParseException("Invalid BlockState value: " + str);
            }

            map.put(parsed.comp_622(), BlockData.BlockStateMeta.of(dryState(parsed, blockModel), blockModel));
            map.put(parsed.comp_622().method_11657(class_2741.field_12508, true), BlockData.BlockStateMeta.of(wetState(parsed, blockModel), blockModel));
        }

        return true;
    }

    private class_2680 dryState(class_2259.class_7211 parsed, PolymerBlockModel blockModel) {
        class_2680 requestedState = null;
        if (parsed.comp_622().method_11654(class_2741.field_12518) == class_2760.field_12619 && !parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.TOP_TRAPDOOR, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12518) == class_2760.field_12617 && !parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.BOTTOM_TRAPDOOR, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11043 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.NORTH_TRAPDOOR, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11034 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.EAST_TRAPDOOR, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11035 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.SOUTH_TRAPDOOR, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11039 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.WEST_TRAPDOOR, blockModel);
        }

        return requestedState;
    }

    private class_2680 wetState(class_2259.class_7211 parsed, PolymerBlockModel blockModel) {
        class_2680 requestedState = null;
        if (parsed.comp_622().method_11654(class_2741.field_12518) == class_2760.field_12619 && !parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.TOP_TRAPDOOR_WATERLOGGED, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12518) == class_2760.field_12617 && !parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.BOTTOM_TRAPDOOR_WATERLOGGED, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11043 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.NORTH_TRAPDOOR_WATERLOGGED, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11034 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.EAST_TRAPDOOR_WATERLOGGED, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11035 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.SOUTH_TRAPDOOR_WATERLOGGED, blockModel);
        } else if (parsed.comp_622().method_11654(class_2741.field_12481) == class_2350.field_11039 && parsed.comp_622().method_11654(class_2741.field_12537)) {
            requestedState = PolymerBlockResourceUtils.requestBlock(BlockModelType.WEST_TRAPDOOR_WATERLOGGED, blockModel);
        }

        return requestedState;
    }

    @Override
    public class_2680 getCustomPolymerBlockState(Map<class_2680, BlockData.BlockStateMeta> stateMap, class_2680 blockState) {
        blockState = blockState.method_11657(class_2741.field_12484, false);
        return stateMap.get(blockState).blockState();
    }

    public static class Config {
        public boolean canOpenByWindCharge = true;
        public boolean canOpenByHand = true;
        public class_3414 openSound = class_3417.field_14932;
        public class_3414 closeSound = class_3417.field_15080;
    }
}
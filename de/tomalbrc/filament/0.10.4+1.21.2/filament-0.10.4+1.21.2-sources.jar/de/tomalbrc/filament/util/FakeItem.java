package de.tomalbrc.filament.util;

import net.minecraft.class_1269;
import net.minecraft.class_1838;

public interface FakeItem {

    class_1269 filament$useOn(class_1838 useOnContext);
}

package de.tomalbrc.filament.block;

import de.tomalbrc.filament.behaviour.BehaviourHolder;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.item.SimpleItem;
import eu.pb4.polymer.core.api.item.PolymerItem;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

public class SimpleBlockItem extends SimpleItem implements PolymerItem, BehaviourHolder {
    private final BlockData blockData;

    public SimpleBlockItem(class_1793 properties, class_2248 block, BlockData data) {
        super(block, properties, data.properties(), data.vanillaItem());
        this.blockData = data;
        this.initBehaviours(data.behaviour());
    }

    @Override
    protected Map<String, class_2960> getModelMap() {
        return this.blockData.itemResource() == null ? Map.of() : Objects.requireNonNull(this.blockData.itemResource()).models();
    }

    @Override
    protected class_2960 getModel() {
        boolean hasItemModels = this.blockData.itemResource() != null && Objects.requireNonNull(this.blockData.itemResource()).models() != null;
        return hasItemModels ? Objects.requireNonNull(this.blockData.itemResource()).models().get("default") : removeItemPrefix(this.blockData.blockResource().models().entrySet().iterator().next().getValue().model());
    }

    private static class_2960 removeItemPrefix(class_2960 resourceLocation) {
        var path = resourceLocation.method_12832();
        return class_2960.method_60655(resourceLocation.method_12836(), path.startsWith("item/") ? path.substring("item/".length()) : path);
    }
}
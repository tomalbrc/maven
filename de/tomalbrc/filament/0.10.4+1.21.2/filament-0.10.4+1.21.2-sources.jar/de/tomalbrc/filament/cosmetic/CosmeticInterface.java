package de.tomalbrc.filament.cosmetic;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public interface CosmeticInterface {
    void filament$addHolder(class_1309 livingEntity, class_1792 item, class_1799 itemStack, String slot);

    void filament$destroyHolder(String slot);
}

package de.tomalbrc.filament.data.properties;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings({"FieldCanBeLocal", "FieldMayBeFinal"})
public class BlockProperties extends ItemProperties {
    public static final BlockProperties EMPTY = new BlockProperties();

    @NotNull
    public class_2248 blockBase = class_2246.field_10340;
    public boolean requiresTool = true;
    public float explosionResistance = Float.MIN_VALUE;
    public float destroyTime = Float.MIN_VALUE;
    public BlockStateMappedProperty<Boolean> redstoneConductor = null;

    public BlockStateMappedProperty<Integer> lightEmission = null;

    public boolean transparent = false;
    public boolean allowsSpawning = false;
    public boolean replaceable = false;
    public boolean collision = true;

    public boolean solid = true;

    public class_3619 pushReaction = class_3619.field_15974;

    public class_4970.class_2251 toBlockProperties() {
        class_4970.class_2251 props = class_4970.class_2251.method_9637();
        props.method_9626(this.blockBase.method_9564().method_26231());

        if (this.destroyTime != Float.MIN_VALUE) props.method_36557(this.destroyTime);
        if (this.explosionResistance != Float.MIN_VALUE) props.method_36558(this.explosionResistance);
        else if (this.destroyTime != Float.MIN_VALUE) props.method_36558(this.destroyTime);
        if (this.mayBeLightSource()) props.method_9631((state) -> this.lightEmission.getOrDefault(state, 0));
        if (this.mayBeRedstoneConductor()) props.method_26236((blockState, blockGetter, blockPos) -> this.redstoneConductor.getOrDefault(blockState, false));
        if (this.requiresTool) props.method_29292();
        if (this.replaceable) props.method_51371();
        if (this.transparent) props.method_22488();
        if (!this.collision) props.method_9634();

        if (this.solid) props.method_51369();
        else props.method_51370();

        props.method_26235((blockState,blockGetter,blockPos,entityType) -> this.allowsSpawning);
        props.method_50012(this.pushReaction);

        return props;
    }

    public boolean mayBeRedstoneConductor() {
        return this.redstoneConductor != null && (this.redstoneConductor.isMap() || (this.redstoneConductor.getRawValue() != null && this.redstoneConductor.getRawValue()));
    }

    public boolean mayBeLightSource() {
        return this.lightEmission != null && (this.lightEmission.isMap() || (this.lightEmission.getRawValue() != null && this.lightEmission.getRawValue() > 0));
    }
}

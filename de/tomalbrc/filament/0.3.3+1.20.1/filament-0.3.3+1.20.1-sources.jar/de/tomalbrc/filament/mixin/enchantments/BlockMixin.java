package de.tomalbrc.filament.mixin.enchantments;

import de.tomalbrc.filament.util.FilamentConfig;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import de.tomalbrc.filament.registry.filament.EnchantmentRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1277;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3956;

// For enchantments
@Mixin(class_2248.class)
public class BlockMixin {
    @Inject(at = @At("RETURN"),
            method = "getDrops(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)Ljava/util/List;",
            cancellable = true)
    private static void dropLoot(class_2680 state, class_3218 level, class_2338 pos, class_2586 blockEntity, class_1297 entity, class_1799 tool, CallbackInfoReturnable<List<class_1799>> ci) {
        if (!FilamentConfig.getInstance().enchantments) {
            return;
        }

        if (class_1890.method_8225(EnchantmentRegistry.INFERNAL_TOUCH, tool) != 0) {
            if (entity instanceof class_1657) {
                List<class_1799> newDropList = new ObjectArrayList<>();
                ci.getReturnValue().forEach(x ->
                        newDropList.add(level.method_8433().method_8132(class_3956.field_17546, new class_1277(x), level)
                                .map(smeltingRecipe -> smeltingRecipe.method_8110(level.method_30349()))
                                .filter(itemStack -> !itemStack.method_7960())
                                .map(itemStack -> {
                                    class_1799 copy = itemStack.method_7972();
                                    copy.method_7939(x.method_7947() * itemStack.method_7947());
                                    return copy;
                                })
                                .orElse(x))
                );
                ci.setReturnValue(newDropList);
            }
        }

        if (class_1890.method_8225(EnchantmentRegistry.MAGNETIZED, tool) != 0) {
            if (entity instanceof class_1657 playerEntity) {
                List<class_1799> newDropList = new ObjectArrayList<>(ci.getReturnValue());
                newDropList.removeIf(playerEntity::method_7270);
                ci.setReturnValue(newDropList);
            }
        }
    }
}
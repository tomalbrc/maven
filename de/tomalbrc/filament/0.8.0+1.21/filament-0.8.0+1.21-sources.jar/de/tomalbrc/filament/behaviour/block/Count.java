package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;

public class Count implements BlockBehaviour<Count.CountConfig> {
    public static final class_2758 COUNT = class_2758.method_11867("count", 1,16);

    private final CountConfig config;

    public Count(CountConfig config) {
        this.config = config;
    }

    @Override
    @NotNull
    public CountConfig getConfig() {
        return this.config;
    }

    @Override
    public boolean createBlockStateDefinition(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(COUNT);
        return true;
    }

    @Override
    public Optional<Boolean> canBeReplaced(class_2680 blockState, class_1750 blockPlaceContext) {
        return Optional.of(!blockPlaceContext.method_8046() && blockPlaceContext.method_8041().method_7909() == blockState.method_26204().method_8389() && blockState.method_11654(COUNT) < config.max);
    }

    @Override
    public class_2680 getStateForPlacement(class_2680 self, class_1750 blockPlaceContext) {
        class_2680 blockState = blockPlaceContext.method_8045().method_8320(blockPlaceContext.method_8037());
        if (blockState.method_27852(self.method_26204())) {
            class_2680 newState = blockState.method_28493(COUNT);
            if (newState.method_11654(COUNT) > this.config.max)
                return newState.method_11657(COUNT, this.config.max);
        }

        return self;
    }

    public static class CountConfig {
        public int max = 4;
    }
}

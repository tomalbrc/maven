package de.tomalbrc.filament.behaviour.block;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.util.annotation.RegistryRef;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.FaceAttachedHorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.redstone.ExperimentalRedstoneUtils;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

import static net.minecraft.world.level.block.FaceAttachedHorizontalDirectionalBlock.FACE;

public class Button implements BlockBehaviour<Button.Config> {
    private final Config config;

    public Button(Config config) {
        this.config = config;
    }

    @Override
    @NotNull
    public Button.Config getConfig() {
        return this.config;
    }

    @Override
    public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (state.getValue(ButtonBlock.POWERED)) {
            return InteractionResult.CONSUME;
        } else {
            this.press(state, level, pos, player);
            return InteractionResult.SUCCESS;
        }
    }

    @Override
    public void onExplosionHit(BlockState state, ServerLevel level, BlockPos pos, Explosion explosion, BiConsumer<ItemStack, BlockPos> dropConsumer) {
        if (explosion.canTriggerBlocks() && !(Boolean)state.getValue(ButtonBlock.POWERED)) {
            this.press(state, level, pos, null);
        }
    }

    public void press(BlockState state, Level level, BlockPos pos, @Nullable Player player) {
        level.setBlock(pos, state.setValue(ButtonBlock.POWERED, true), Block.UPDATE_ALL);
        this.updateNeighbours(state, level, pos);
        level.scheduleTick(pos, state.getBlock(), this.config.ticksToStayPressed.getValue(state));
        this.playSound(level, pos, true);
        level.gameEvent(player, GameEvent.BLOCK_ACTIVATE, pos);
    }

    protected void playSound(LevelAccessor level, BlockPos pos, boolean on) {
        level.playSound(null, pos, this.getSound(on), SoundSource.BLOCKS);
    }

    protected SoundEvent getSound(boolean on) {
        return on ? SoundEvent.createVariableRangeEvent(this.config.clickOnSound) : SoundEvent.createVariableRangeEvent(this.config.clickOffSound);
    }

    @Override
    public void affectNeighborsAfterRemoval(BlockState state, ServerLevel level, BlockPos pos, boolean movedByPiston) {
        if (!movedByPiston && state.getValue(ButtonBlock.POWERED)) {
            this.updateNeighbours(state, level, pos);
        }
    }

    @Override
    public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(ButtonBlock.POWERED) ? this.config.powerlevel.getValue(state) : 0;
    }

    @Override
    public int getDirectSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(ButtonBlock.POWERED) && Lever.getConnectedDirection(state) == direction ? this.config.powerlevel.getValue(state) : 0;
    }

    @Override
    public boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(ButtonBlock.POWERED)) {
            this.pressCheck(state, level, pos);
        }
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity, InsideBlockEffectApplier effectApplier) {
        if (!level.isClientSide() && this.config.canBeActivatedByArrows.getValue(state) && !(Boolean)state.getValue(ButtonBlock.POWERED)) {
            this.pressCheck(state, level, pos);
        }
    }

    protected void pressCheck(BlockState state, Level level, BlockPos pos) {
        AbstractArrow abstractArrow = this.config.canBeActivatedByArrows.getValue(state) ? level.getEntitiesOfClass(AbstractArrow.class, state.getShape(level, pos).bounds().move(pos)).stream().findFirst().orElse(null) : null;
        boolean hasArrowInside = abstractArrow != null;
        boolean isPowered = state.getValue(ButtonBlock.POWERED);
        if (hasArrowInside != isPowered) {
            level.setBlock(pos, state.setValue(ButtonBlock.POWERED, hasArrowInside), Block.UPDATE_ALL);
            this.updateNeighbours(state, level, pos);
            this.playSound(level, pos, hasArrowInside);
            level.gameEvent(abstractArrow, hasArrowInside ? GameEvent.BLOCK_ACTIVATE : GameEvent.BLOCK_DEACTIVATE, pos);
        }

        if (hasArrowInside) {
            level.scheduleTick(pos, state.getBlock(), this.config.ticksToStayPressed.getValue(state));
        }
    }

    private void updateNeighbours(BlockState state, Level level, BlockPos pos) {
        Direction direction = Lever.getConnectedDirection(state).getOpposite();
        Orientation orientation = ExperimentalRedstoneUtils.initialOrientation(level, direction, direction.getAxis().isHorizontal() ? Direction.UP : state.getValue(ButtonBlock.FACING));
        level.updateNeighborsAt(pos, state.getBlock(), orientation);
        level.updateNeighborsAt(pos.relative(direction), state.getBlock(), orientation);
    }

    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ButtonBlock.FACING, ButtonBlock.POWERED, FACE);
    }

    @Override
    public BlockState modifyDefaultState(BlockState blockState) {
        return blockState.setValue(ButtonBlock.FACING, Direction.NORTH).setValue(ButtonBlock.POWERED, false).setValue(FACE, AttachFace.WALL);
    }

    @Override
    public BlockState getStateForPlacement(BlockState blockState, BlockPlaceContext context) {
        for (Direction direction : context.getNearestLookingDirections()) {
            BlockState state = direction.getAxis() == Direction.Axis.Y ? blockState.getBlock().defaultBlockState().setValue(FACE, direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR).setValue(ButtonBlock.FACING, context.getHorizontalDirection()) : blockState.getBlock().defaultBlockState().setValue(FACE, AttachFace.WALL).setValue(ButtonBlock.FACING, direction.getOpposite());
            if (!state.canSurvive(context.getLevel(), context.getClickedPos())) continue;
            return state;
        }
        return null;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return FaceAttachedHorizontalDirectionalBlock.canAttach(level, pos, getConnectedDirection(state).getOpposite());
    }

    static Direction getConnectedDirection(BlockState state) {
        return switch (state.getValue(FACE)) {
            case CEILING -> Direction.DOWN;
            case FLOOR -> Direction.UP;
            default -> state.getValue(ButtonBlock.FACING);
        };
    }

    public static class Config {
        public BlockStateMappedProperty<Integer> powerlevel = BlockStateMappedProperty.of(15);
        public BlockStateMappedProperty<Integer> ticksToStayPressed = BlockStateMappedProperty.of(20);
        public BlockStateMappedProperty<Boolean> canBeActivatedByArrows = BlockStateMappedProperty.of(true);

        public @RegistryRef("sound_event")
        Identifier clickOnSound = SoundEvents.WOODEN_BUTTON_CLICK_ON.location();

        public @RegistryRef("sound_event")
        Identifier clickOffSound = SoundEvents.WOODEN_BUTTON_CLICK_OFF.location();
    }
}
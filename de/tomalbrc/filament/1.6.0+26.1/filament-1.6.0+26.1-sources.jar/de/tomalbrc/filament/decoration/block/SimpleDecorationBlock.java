package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.holder.DecorationHolder;
import de.tomalbrc.filament.util.BlockUtil;
import de.tomalbrc.filament.util.DecorationUtil;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.storage.loot.LootParams;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

import java.util.List;

public class SimpleDecorationBlock extends DecorationBlock implements BlockWithElementHolder {
    public SimpleDecorationBlock(Properties properties, DecorationData data) {
        super(properties, data);
    }

    @Nullable
    public ElementHolder createElementHolder(ServerLevel world, BlockPos blockPos, BlockState initialBlockState) {
        DecorationHolder holder = new DecorationHolder(() -> visualItemStack(world, blockPos, initialBlockState));
        DecorationUtil.setupElements(holder, this.getDecorationData(), Direction.UP, this.getVisualRotationYInDegrees(initialBlockState), this.visualItemStack(world, blockPos, initialBlockState), null);
        return holder;
    }

    @Override
    @NotNull
    public BlockState playerWillDestroy(@NonNull Level level, @NonNull BlockPos blockPos, @NonNull BlockState blockState, @NonNull Player player) {
        BlockState returnVal = super.playerWillDestroy(level, blockPos, blockState, player);
        if (!player.hasInfiniteMaterials()) this.playerDestroy(level, player, blockPos, blockState, null, player.getMainHandItem());
        return returnVal;
    }

    @Override
    public ItemStack visualItemStack(LevelReader levelReader, BlockPos blockPos, BlockState blockState) {
        var item = BuiltInRegistries.ITEM.getValue(this.data.id()).getDefaultInstance();

        if (stateMap != null && cmdMap != null) {
            BlockData.BlockStateMeta val = stateMap.get(behaviourModifiedBlockState(blockState, blockState));
            if (val == null && blockState.hasProperty(BlockUtil.ROTATION)) {
                val = stateMap.get(behaviourModifiedBlockState(blockState, blockState).setValue(BlockUtil.ROTATION, 0));
            }

            if (val == null && blockState.hasProperty(BlockUtil.ROTATION) && blockState.hasProperty(BlockStateProperties.WATERLOGGED)) {
                val = stateMap.get(behaviourModifiedBlockState(blockState, blockState).setValue(BlockUtil.ROTATION, 0).setValue(BlockStateProperties.WATERLOGGED, false));
            }

            if (val != null && cmdMap.containsKey(val)) {
                item.set(DataComponents.ITEM_MODEL, data.id().withPrefix("block/"));
                item.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(List.of(), List.of(), List.of(cmdMap.get(val)), List.of()));
            }
        }

        return item;
    }

    @Override
    @NotNull
    public List<ItemStack> getDrops(@NonNull BlockState blockState, LootParams.@NonNull Builder builder) {
        if (this.getDecorationData().properties().drops) {
            List<ItemStack> list = ObjectArrayList.of(BuiltInRegistries.ITEM.getValue(this.decorationId).getDefaultInstance());
            list.addAll(super.getDrops(blockState, builder));
            return list;
        } else {
            return super.getDrops(blockState, builder);
        }
    }

    @Override
    protected void spawnDestroyParticles(@NonNull Level level, @NonNull Player player, @NonNull BlockPos blockPos, @NonNull BlockState blockState) {
        if (level.isClientSide()) return;

        BlockUtil.playBreakSound(level, blockPos, blockState);

        if (data.properties().showBreakParticles())
            DecorationUtil.showBreakParticle((ServerLevel) level, data.properties().useItemParticles ? BuiltInRegistries.ITEM.getValue(this.decorationId).getDefaultInstance() : this.getDecorationData().properties().blockBase().asItem().getDefaultInstance(), (float) blockPos.getCenter().x(), (float) blockPos.getCenter().y(), (float) blockPos.getCenter().z());
    }
}

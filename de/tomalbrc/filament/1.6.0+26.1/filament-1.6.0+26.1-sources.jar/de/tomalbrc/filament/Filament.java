package de.tomalbrc.filament;

import com.mojang.logging.LogUtils;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.Fire;
import de.tomalbrc.filament.command.FilamentCommand;
import de.tomalbrc.filament.data.ItemGroupData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.recipe.Workstations;
import de.tomalbrc.filament.registry.*;
import de.tomalbrc.filament.util.*;
import de.tomalbrc.filament.util.resource.FilamentAssetReloadListener;
import de.tomalbrc.filament.util.resource.FilamentTemplateReloadListener;
import de.tomalbrc.filament.util.resource.WorkstationReloadListener;
import de.tomalbrc.filamentweb.EditorServer;
import de.tomalbrc.filamentweb.FilamentEditorConfig;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockResourceUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.BlockPos;
import net.minecraft.core.LayeredRegistryAccess;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.RegistryLayer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.Objects;

public class Filament implements ModInitializer {
    public static final Logger LOGGER = LogUtils.getLogger();
    public static LayeredRegistryAccess<RegistryLayer> REGISTRY_ACCESS;
    public static MinecraftServer SERVER;

    //public static MinecraftServerAudiences ADVENTURE;

    //public static MinecraftServerAudiences adventure() {
    //    return ADVENTURE;
    //}

    @Override
    public void onInitialize() {
        if (FilamentConfig.getInstance().addCustomMenuAssets)
            PolymerResourcePackUtils.addModAssets(Constants.MOD_ID);

        if (FilamentConfig.getInstance().resourcepackRequired)
            PolymerResourcePackUtils.markAsRequired();

        FilamentComponents.register();
        Behaviours.register();
        SkinUtil.registerEventHandler();
        Translations.registerEventHandler();
        EntityRegistry.register();

        nexoHint();

        if (FilamentConfig.getInstance().commands) {
            FilamentCommand.register();
        }

        VirtualDestroyStage.init();
        AsyncBlockTicker.init();
        Workstations.init();
        Fire.addRemap();
        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(Fire::init);
        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(RPUtil::addExtraAssets);

        if (FilamentEditorConfig.getInstance().enabled) {
            EditorServer.init();
        }

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClientSide() && hand == InteractionHand.MAIN_HAND) {
                BlockPos pos = hitResult.getBlockPos();
                BlockState blockState = world.getBlockState(pos);
                if (DecorationRegistry.isDecoration(blockState) && world.getBlockEntity(pos) instanceof DecorationBlockEntity decorationBlockEntity) {
                    return decorationBlockEntity.decorationInteract((ServerPlayer) player, hand, hitResult.getLocation());
                }
            }

            return InteractionResult.PASS;
        });

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            //ADVENTURE = MinecraftServerAudiences.of(server);
            SERVER = server;
        });

        ServerTickEvents.END_SERVER_TICK.register(AsyncBlockTicker::tick);
        ServerChunkEvents.CHUNK_UNLOAD.register(AsyncBlockTicker::remove);
        //ServerLifecycleEvents.SERVER_STOPPING.register(minecraftServer -> {
        //    if (ADVENTURE != null) ADVENTURE.close();
        //});
        ItemGroupRegistry.register(new ItemGroupData(Constants.ITEM_GROUP_ID, Identifier.withDefaultNamespace("diamond"), TextUtil.formatText("<c:blue>Filament Items")));
        ItemGroupRegistry.register(new ItemGroupData(Constants.BLOCK_GROUP_ID, Identifier.withDefaultNamespace("furnace"), TextUtil.formatText("<c:blue>Filament Blocks")));
        ItemGroupRegistry.register(new ItemGroupData(Constants.DECORATION_GROUP_ID, Identifier.withDefaultNamespace("lantern"), TextUtil.formatText("<c:blue>Filament Decorations")));

        FilamentReloadUtil.registerEarlyReloadListener(new FilamentAssetReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new FilamentTemplateReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new WorkstationReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ModelRegistry.AjModelReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ItemRegistry.ItemDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new BlockRegistry.BlockDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new DecorationRegistry.DecorationDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new EntityRegistry.EntityDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new ItemGroupRegistry.ItemGroupDataReloadListener());
        FilamentReloadUtil.registerEarlyReloadListener(new BiomeModifications.BiomeModificationsDataReloadListener());

        if (FilamentConfig.getInstance().debug) {
            LOGGER.info("Available Polymer block model types:");
            logModelTypes();

            ServerLifecycleEvents.SERVER_STARTED.register(_ -> {
                LOGGER.info("Available Polymer block model types after server start:");
                logModelTypes();
            });
        }
    }

    private static void nexoHint() {
        var nexoDir = FabricLoader.getInstance().getGameDir().resolve("nexo");
        var nexoDirFile = nexoDir.toFile();
        if (!FabricLoader.getInstance().isModLoaded("filament-nexo") && nexoDirFile.exists() && nexoDirFile.isDirectory() && nexoDirFile.listFiles() != null && Arrays.stream(Objects.requireNonNull(nexoDirFile.listFiles())).anyMatch(x -> !FilenameUtils.getBaseName(x.getPath()).startsWith("."))) {
            throw new RuntimeException("Found nexo folder with packs, please install filament-nexo (https://modrinth.com/mod/filament-nexo) or remove the nexo directory in your game directory!");
        }
    }

    private void logModelTypes() {
        for (var blockModelType : BlockModelType.values()) {
            LOGGER.info("\t{} = {}", blockModelType.name(), PolymerBlockResourceUtils.getBlocksLeft(blockModelType));
        }
    }
}

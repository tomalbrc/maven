package de.tomalbrc.filamentweb;

import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.data.ItemData;
import de.tomalbrc.filament.util.annotation.AssetRef;
import de.tomalbrc.filamentweb.asset.ResourceStore;
import de.tomalbrc.filamentweb.service.*;
import de.tomalbrc.filamentweb.util.Mc2Glb;
import de.tomalbrc.filamentweb.util.WebLogAppender;
import eu.pb4.polymer.resourcepack.api.AssetPaths;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import jakarta.servlet.DispatcherType;
import jakarta.websocket.server.ServerEndpointConfig;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.resources.Identifier;
import org.eclipse.jetty.ee10.servlet.ResourceServlet;
import org.eclipse.jetty.ee10.servlet.ServletContextHandler;
import org.eclipse.jetty.ee10.servlet.ServletHolder;
import org.eclipse.jetty.ee10.websocket.jakarta.server.config.JakartaWebSocketServletContainerInitializer;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.util.resource.ResourceFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public class EditorServer implements Runnable {
    private static final ScheduledExecutorService EXECUTOR = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "Filament-Web-Scheduler");
        t.setDaemon(true);
        return t;
    });

    private static ResourcePackBuilder RP_BUILDER;
    private static EditorServer INSTANCE;
    public static Mc2Glb CONVERTER;

    private final Server server;

    public static ResourcePackBuilder resourcePackBuilder() {
        return RP_BUILDER;
    }

    public static Map<AssetRef.Type, Set<String>> RP_ASSETS = new ConcurrentHashMap<>();

    public EditorServer() throws Exception {
        server = new Server();
        ServerConnector connector = new ServerConnector(server);
        connector.setPort(FilamentEditorConfig.getInstance().bindPort);
        connector.setHost(FilamentEditorConfig.getInstance().bindIp);
        server.addConnector(connector);

        ContextHandlerCollection handlers = new ContextHandlerCollection();
        server.setHandler(handlers);

        addResourceHandler(handlers);
        addRestHandler(handlers);
    }

    private void addResourceHandler(ContextHandlerCollection contextHandlerCollection) throws Exception {
        ServletContextHandler handler = new ServletContextHandler(ServletContextHandler.SESSIONS);
        handler.setContextPath("/");

        var webRoot = ResourceFactory.of(handler).newClassLoaderResource("docs");
        if (webRoot == null) {
            throw new IllegalStateException("docs not found on the classpath");
        }
        handler.setBaseResource(webRoot);

        AuthFilter auth = new AuthFilter();

        handler.addServlet(new ServletHolder(new ResourceServlet()), "/docs/*");
        handler.addServlet(new ServletHolder(new ActionServlet()), "/action/*");
        handler.addServlet(new ServletHolder(new LoginServlet(auth)), "/login");
        handler.addServlet(new ServletHolder(new LogoutServlet()), "/logout");
        handler.addServlet(new ServletHolder(new AssetEditorServlet()), "/");

        handler.addFilter(AuthFilter.class, "/*", EnumSet.of(DispatcherType.REQUEST));

        JakartaWebSocketServletContainerInitializer.configure(handler, (_, container) -> {
            container.addEndpoint(
                    ServerEndpointConfig.Builder
                            .create(LogEndpoint.class, "/ws/log")
                            .configurator(new LogEndpoint.Configurator())
                            .build()
            );
        });

        contextHandlerCollection.addHandler(handler);
    }

    private void addRestHandler(ContextHandlerCollection handlers) {
        ServletContextHandler apiHandler = new ServletContextHandler(ServletContextHandler.SESSIONS);
        apiHandler.setContextPath("/rest");
        handlers.addHandler(apiHandler);

        apiHandler.addServlet(new ServletHolder(new FileListServlet()), "/files");
        apiHandler.addServlet(new ServletHolder(new ReadFileServlet()), "/file");
        apiHandler.addServlet(new ServletHolder(new FragmentServlet()), "/fragment");
    }

    public void start() throws Exception {
        server.start();
    }

    public void join() throws InterruptedException {
        server.join();
    }

    public void stop() throws Exception {
        server.stop();
    }

    public static void runServer() {
        if (INSTANCE != null || RP_BUILDER == null || Filament.SERVER == null) {
            return;
        }

        try {
            // todo: handle non-existing files.
            Function<Identifier, InputStream> modelProvider = identifier -> {
                var path = AssetPaths.model(identifier) + ".json";
                var data = resourcePackBuilder().getDataOrSource(path);
                if (data == null) Filament.LOGGER.warn("Resourcepack model at {} does not exist!", path);
                return data == null ? null : new ByteArrayInputStream(data);
            };
            Function<Identifier, InputStream> textureProvider = identifier -> {
                var path = AssetPaths.texture(identifier) + ".png";
                var data = resourcePackBuilder().getDataOrSource(path);
                if (data == null) Filament.LOGGER.warn("Resourcepack texture at {} does not exist!", path);

                return data == null ? null : new ByteArrayInputStream(data);
            };

            CONVERTER = new Mc2Glb(modelProvider, textureProvider);
            ResourceStore.DEFAULT_MODEL = CONVERTER.toGlb(Identifier.withDefaultNamespace("block/stone"));

        } catch (Exception e) {
            Filament.LOGGER.error("Could not start editor server!", e);
            return;
        }

        try {
            EditorServer server = new EditorServer();
            var thread = new Thread(server, "Filament-Editor-Server");
            thread.setDaemon(true);
            thread.start();
            Filament.LOGGER.info("Started Filament Editor server!");
            INSTANCE = server;
        } catch (Exception e) {
            Filament.LOGGER.error("Failed to start editor server", e);
        }
    }

    @Override
    public void run() {
        try {
            start();
            join();
        } catch (Exception e) {
            Filament.LOGGER.error("Failed to start editor server", e);
        }
    }

    public static void init() {
        PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(EditorServer::init);
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            WebLogAppender.install();
            if (EditorServer.resourcePackBuilder() != null)
                EditorServer.runServer();
        });

        EXECUTOR.scheduleAtFixedRate(
                () -> LogEndpoint.broadcast("ping"),
                10,
                5,
                TimeUnit.SECONDS
        );

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (INSTANCE != null) {
                try {
                    INSTANCE.stop();
                } catch (Exception e) {
                    Filament.LOGGER.error("Error shutting down web server", e);
                }
            }

            EXECUTOR.shutdown();
        });

        FilamentRegistrationEvents.ITEM.register((data, item) -> {
            ResourceStore.registerResourceFromPath(data, ItemData.class);
        });
        FilamentRegistrationEvents.BLOCK.register((data, item, block) -> {
            ResourceStore.registerResourceFromPath(data, BlockData.class);
        });
        FilamentRegistrationEvents.DECORATION.register((data, item, block) -> {
            ResourceStore.registerResourceFromPath(data, DecorationData.class);
        });
        // TODO: Entity support!
    }

    public static void init(ResourcePackBuilder builder) {
        builder.addResourceConverter((x, data) -> {
            var parts = x.split("/");

            // assets/<namespace>/<type>/
            if (parts.length > 3 && "assets".equals(parts[0])) {
                String namespace = parts[1];
                String subpath = String.join("/", Arrays.copyOfRange(parts, 2, parts.length));

                for (AssetRef.Type type : AssetRef.Type.values()) {
                    if (subpath.startsWith(type.prefix()) && subpath.endsWith(type.suffix())) {
                        String stripped = subpath.substring(type.prefix().length());

                        int dot = stripped.lastIndexOf('.');
                        if (dot != -1) {
                            stripped = stripped.substring(0, dot);
                        }

                        String identifier = namespace + ":" + stripped;
                        RP_ASSETS.computeIfAbsent(type, k -> new HashSet<>()).add(identifier);
                    }
                }
            }

            return data;
        });

        RP_BUILDER = builder;
        EditorServer.runServer();
    }
}
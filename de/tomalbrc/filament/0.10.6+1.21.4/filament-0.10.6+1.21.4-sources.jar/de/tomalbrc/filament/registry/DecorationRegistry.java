package de.tomalbrc.filament.registry;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourUtil;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.decoration.Container;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.data.resource.ItemResource;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.generator.ItemAssetGenerator;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Util;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_9282;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import net.minecraft.class_9336;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.function.Function;

public class DecorationRegistry {
    private static final Reference2ObjectOpenHashMap<class_2960, DecorationData> decorations = new Reference2ObjectOpenHashMap<>();
    private static final Reference2ObjectOpenHashMap<class_2960, class_2248> decorationBlocks = new Reference2ObjectOpenHashMap<>();
    private static final Reference2ObjectOpenHashMap<class_2248, class_2591<DecorationBlockEntity>> decorationBlockEntities = new Reference2ObjectOpenHashMap<>();
    public static int REGISTERED_BLOCK_ENTITIES = 0;
    public static int REGISTERED_DECORATIONS = 0;

    public static void register(InputStream inputStream) throws IOException {
        JsonElement element = JsonParser.parseReader(new InputStreamReader(inputStream));
        DecorationData data = Json.GSON.fromJson(element, DecorationData.class);

        Util.handleComponentsCustom(element, data);

        register(data);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static public void register(DecorationData data) {
        for (Map.Entry<class_2960, DecorationData> entry : decorations.entrySet()) {
            if (entry.getKey().equals(data.id())) return;
        }

        decorations.put(data.id(), data);

        class_4970.class_2251 blockProperties = data.properties().toBlockProperties();

        var block = BlockRegistry.registerBlock(BlockRegistry.key(data.id()), getBlockCreator(data), blockProperties);
        decorationBlocks.put(data.id(), block);

        class_1792.class_1793 properties = data.properties().toItemProperties();
        for (class_9336 component : data.components()) {
            properties.method_57349(component.comp_2443(), component.comp_2444());
        }

        if (data.isContainer()) {
            Container.ContainerConfig container = data.behaviour().get(Behaviours.CONTAINER);
            if (container.canPickup)
                properties.method_57349(class_9334.field_49622, class_9288.field_49334);
        }

        if (data.vanillaItem() == class_1802.field_18138 || data.vanillaItem() == class_1802.field_8450) {
            properties.method_57349(class_9334.field_49644, new class_9282(0xdaad6d, false));
        }

        var item = ItemRegistry.registerItem(ItemRegistry.key(data.id()), (newProps) -> new DecorationItem(block, data, newProps), properties, data.group() != null ? data.group() : Constants.DECORATION_GROUP_ID);
        BehaviourUtil.postInitItem(item, item, data.behaviour());

        var resourceProvider = data.itemResource() == null ? new ItemResource(Map.of("default", data.model()), null, null) : data.itemResource();
        if (resourceProvider != null && data.itemModel() == null && resourceProvider.getModels() != null) {
            PolymerResourcePackUtils.RESOURCE_PACK_AFTER_INITIAL_CREATION_EVENT.register(resourcePackBuilder ->
                    ItemAssetGenerator.create(resourcePackBuilder, data.id(), resourceProvider)
            );
        }

        REGISTERED_DECORATIONS++;
    }

    @NotNull
    private static Function<class_4970.class_2251, class_2248> getBlockCreator(DecorationData data) {
        Function<class_4970.class_2251, class_2248> gen;
        if (!data.isSimple()) {
            gen = (x) -> {
                var block = new ComplexDecorationBlock(x.method_50012(class_3619.field_15972), data.id());

                class_2591<DecorationBlockEntity> DECORATION_BLOCK_ENTITY = FabricBlockEntityTypeBuilder.create(DecorationBlockEntity::new, block).build();
                EntityRegistry.registerBlockEntity(EntityRegistry.key(data.id()), DECORATION_BLOCK_ENTITY);

                decorationBlockEntities.put(block, DECORATION_BLOCK_ENTITY);
                REGISTERED_BLOCK_ENTITIES++;

                return block;
            };
        } else {
            gen = (x) -> new SimpleDecorationBlock(x, data.id());
        }
        return gen;
    }

    public static DecorationData getDecorationDefinition(class_2960 resourceLocation) {
        return decorations.get(resourceLocation);
    }

    public static boolean isDecoration(class_2680 blockState) {
        return blockState.method_26204() instanceof DecorationBlock;
    }

    public static DecorationBlock getDecorationBlock(class_2960 resourceLocation) {
        return (DecorationBlock) decorationBlocks.get(resourceLocation);
    }

    public static class_2591<DecorationBlockEntity> getBlockEntityType(class_2680 blockState) {
        return decorationBlockEntities.get(blockState.method_26204());
    }


    public static class DecorationDataReloadListener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return class_2960.method_60655(Constants.MOD_ID, "decorations");
        }

        @Override
        public void method_14491(class_3300 resourceManager) {
            var resources = resourceManager.method_14488("filament/decoration", path -> path.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
                try (var reader = new InputStreamReader(entry.getValue().method_14482())) {
                    DecorationData data = Json.GSON.fromJson(reader, DecorationData.class);
                    DecorationRegistry.register(data);
                } catch (IOException | IllegalStateException e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"{}\".", entry.getKey());
                }
            }
        }
    }
}

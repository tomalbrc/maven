package de.tomalbrc.filament.mixin.behaviour.oxidizable;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import de.tomalbrc.filament.behaviour.Behaviours;
import de.tomalbrc.filament.behaviour.block.Oxidizable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChangeOverTimeBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(ChangeOverTimeBlock.class)
public interface ChangeOverTimeBlockMixin {
    @WrapOperation(method = "lambda$getNextState$1", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"))
    private static BlockState filament$oxidizableState(ServerLevel instance, BlockPos pos, Operation<BlockState> original) {
        var state = original.call(instance, pos);
        if (state.getBlock().isFilamentBlock()) {
            Oxidizable oxidizable;
            if ((oxidizable = state.getBlock().get(Behaviours.OXIDIZABLE)) != null) {
                return switch (oxidizable.getConfig().weatherState) {
                    case UNAFFECTED -> Blocks.COPPER_BLOCK.weathering().unaffected().defaultBlockState();
                    case EXPOSED -> Blocks.COPPER_BLOCK.weathering().exposed().defaultBlockState();
                    case WEATHERED -> Blocks.COPPER_BLOCK.weathering().weathered().defaultBlockState();
                    case OXIDIZED -> Blocks.COPPER_BLOCK.weathering().oxidized().defaultBlockState();
                };
            }
        }

        return state;
    }
}

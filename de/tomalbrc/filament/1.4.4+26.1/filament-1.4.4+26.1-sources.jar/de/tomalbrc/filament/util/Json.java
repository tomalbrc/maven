package de.tomalbrc.filament.util;

import com.google.common.reflect.TypeToken;
import com.google.gson.*;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import de.tomalbrc.bil.json.SimpleCodecDeserializer;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.behaviour.BehaviourConfigMap;
import de.tomalbrc.filament.behaviour.BehaviourList;
import de.tomalbrc.filament.behaviour.decoration.Showcase;
import de.tomalbrc.filament.data.properties.BlockStateMappedProperty;
import de.tomalbrc.filament.data.properties.RangedValue;
import de.tomalbrc.filament.data.properties.RangedVector3f;
import de.tomalbrc.filament.data.resource.BlockResource;
import eu.pb4.polymer.blocks.api.BlockModelType;
import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.WeatheringCopper;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.PushReaction;
import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.jspecify.annotations.NonNull;
import org.yaml.snakeyaml.Yaml;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Json {
    public static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
            .registerTypeHierarchyAdapter(BlockState.class, new BlockStateDeserializer())
            .registerTypeHierarchyAdapter(Vector3f.class, new SimpleCodecDeserializer<>(ExtraCodecs.VECTOR3F))
            .registerTypeHierarchyAdapter(Vector2f.class, new SimpleCodecDeserializer<>(ExtraCodecs.VECTOR2F))
            .registerTypeHierarchyAdapter(Quaternionf.class, new QuaternionfDeserializer())
            .registerTypeAdapter(Identifier.class, new SimpleCodecDeserializer<>(Identifier.CODEC))
            .registerTypeHierarchyAdapter(Component.class, new ComponentDeserializer())
            .registerTypeHierarchyAdapter(DataComponentMap.class, new DataComponentsDeserializer())
            .registerTypeHierarchyAdapter(Display.BillboardConstraints.class, new SimpleCodecDeserializer<>(Display.BillboardConstraints.CODEC))
            .registerTypeHierarchyAdapter(EquipmentSlot.class, new SimpleCodecDeserializer<>(EquipmentSlot.CODEC))
            .registerTypeHierarchyAdapter(BlockModelType.class, new BlockModelTypeDeserializer())
            .registerTypeHierarchyAdapter(Difficulty.class, new SimpleCodecDeserializer<>(Difficulty.CODEC))
            .registerTypeHierarchyAdapter(MobCategory.class, new SimpleCodecDeserializer<>(MobCategory.CODEC))
            .registerTypeHierarchyAdapter(ItemDisplayContext.class, new SimpleCodecDeserializer<>(ItemDisplayContext.CODEC))
            .registerTypeHierarchyAdapter(PushReaction.class, new LowercaseEnumDeserializer<>(PushReaction.class))
            .registerTypeHierarchyAdapter(WeatheringCopper.WeatherState.class, new SimpleCodecDeserializer<>(WeatheringCopper.WeatherState.CODEC))
            .registerTypeHierarchyAdapter(RangedValue.class, new SimpleCodecDeserializer<>(RangedValue.CODEC))
            .registerTypeHierarchyAdapter(RangedVector3f.class, new SimpleCodecDeserializer<>(RangedVector3f.CODEC))
            .registerTypeHierarchyAdapter(Block.class, new RegistryDeserializer<>(BuiltInRegistries.BLOCK))
            .registerTypeHierarchyAdapter(Item.class, new RegistryDeserializer<>(BuiltInRegistries.ITEM))
            .registerTypeHierarchyAdapter(SoundEvent.class, new RegistryDeserializer<>(BuiltInRegistries.SOUND_EVENT))
            .registerTypeHierarchyAdapter(BehaviourConfigMap.class, new BehaviourConfigMap.Deserializer())
            .registerTypeHierarchyAdapter(BehaviourList.class, new BehaviourList.Deserializer())
            .registerTypeHierarchyAdapter(BlockStateMappedProperty.class, new BlockStateMappedPropertyDeserializer<>())
            .registerTypeHierarchyAdapter(PolymerBlockModel.class, new PolymerBlockModelDeserializer())
            .registerTypeHierarchyAdapter(BlockResource.TextureBlockModel.class, new TextureBlockModelDeserializer())
            // special case to support old format
            // TODO: allow behaviours to specify codec/deserializer
            .registerTypeHierarchyAdapter(Showcase.Config.class, new Showcase.Config.ConfigDeserializer())
            .create();

    public static List<InputStream> yamlToJson(InputStream inputStream) {
        Yaml yaml = new Yaml();
        var documents = yaml.loadAll(inputStream);
        List<InputStream> list = new ObjectArrayList<>();
        for (Object document : documents) {
            if (document instanceof Map) {
                @SuppressWarnings("unchecked")
                var documentMap = (Map<String, Object>) document;
                document = Json.camelToSnakeCase(documentMap);
            }
            String jsonString = Json.GSON.toJson(document);
            InputStream stream = new ByteArrayInputStream(jsonString.getBytes(StandardCharsets.UTF_8));
            list.add(stream);
        }
        return list;
    }

    public static InputStream camelToSnakeCase(InputStream inputStream) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
        var json = JsonParser.parseReader(new InputStreamReader(inputStream));
        InputStream stream;
        if (json.isJsonObject()) {
            Type mapType = new TypeToken<Map<String, Object>>() {}.getType();
            Map<String, Object> document = gson.fromJson(json, mapType);
            if (document != null) {
                document = Json.camelToSnakeCase(document);
            }
            stream = new ByteArrayInputStream(gson.toJson(document).getBytes(StandardCharsets.UTF_8));
        } else {
            stream = new ByteArrayInputStream(gson.toJson(json).getBytes(StandardCharsets.UTF_8));
        }

        return stream;
    }

    public static Map<String, Object> camelToSnakeCase(Map<String, Object> map) {
        Map<String, Object> result = new HashMap<>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = camelToSnakeCaseKey(entry.getKey());
            Object value = entry.getValue();
            if (value instanceof Map<?, ?> map1) {
                @SuppressWarnings("unchecked")
                Map<String, Object> nestedMap = (Map<String, Object>) map1;
                value = camelToSnakeCase(nestedMap);
            }
            result.put(key, value);
        }
        return result;
    }

    @NotNull
    private static String camelToSnakeCaseKey(String key) {
        StringBuilder snakeCase = new StringBuilder();
        for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);
            if (Character.isUpperCase(c) && i > 0) {
                snakeCase.append('_');
            }
            snakeCase.append(Character.toLowerCase(c));
        }
        return snakeCase.toString();
    }

    public static class BlockStateMappedPropertyDeserializer<T> implements JsonDeserializer<BlockStateMappedProperty<T>>, JsonSerializer<BlockStateMappedProperty<T>> {
        @Override
        public BlockStateMappedProperty<T> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonPrimitive()) {
                JsonPrimitive primitive = json.getAsJsonPrimitive();
                Type propertyType = ((ParameterizedType) typeOfT).getActualTypeArguments()[0];
                T t = context.deserialize(primitive, propertyType);
                return new BlockStateMappedProperty<>(t);
            } else if (json.isJsonObject()) {
                ParameterizedType mapType = getParameterizedType((ParameterizedType) typeOfT);
                Map<String, T> map = context.deserialize(json, mapType);
                return new BlockStateMappedProperty<>(map);
            }

            throw new JsonParseException("Invalid format for MappedProperty");
        }

        @Override
        public JsonElement serialize(BlockStateMappedProperty<T> src, Type typeOfSrc, JsonSerializationContext context) {
            try {
                for (Field field : src.getClass().getDeclaredFields()) {
                    field.setAccessible(true);
                    Object val = field.get(src);
                    if (val instanceof Map) {
                        return context.serialize(val);
                    } else if (val != null) {
                        return context.serialize(val);
                    }
                }
            } catch (Exception ignored) {
            }
            return new JsonObject();
        }

        @NotNull
        private static ParameterizedType getParameterizedType(ParameterizedType typeOfT) {
            Type propertyType = typeOfT.getActualTypeArguments()[0];
            return new ParameterizedType() {
                @Override
                public Type @NotNull [] getActualTypeArguments() {
                    return new Type[]{String.class, propertyType};
                }

                @Override
                @NotNull
                public Type getRawType() {
                    return Map.class;
                }

                @Override
                public Type getOwnerType() {
                    return null;
                }
            };
        }
    }

    public static class BlockStateDeserializer implements JsonDeserializer<BlockState>, JsonSerializer<BlockState> {
        @Override
        public BlockState deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String name = json.getAsString().toLowerCase();

            BlockStateParser.BlockResult parsed;
            try {
                parsed = BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK, name, false);
            } catch (CommandSyntaxException e) {
                throw new JsonParseException("Invalid BlockState value: " + name);
            }

            return parsed.blockState();
        }

        @Override
        @SuppressWarnings({"rawtypes", "unchecked"})
        public JsonElement serialize(BlockState src, Type typeOfSrc, JsonSerializationContext context) {
            StringBuilder builder = new StringBuilder();
            builder.append(BuiltInRegistries.BLOCK.getKey(src.getBlock()));
            if (src.getValues().findAny().isPresent()) {
                builder.append('[');
                boolean first = true;
                for (var val : src.getValues().toList()) {
                    if (!first) {
                        builder.append(',');
                    }
                    first = false;
                    Property property = val.property();
                    builder.append(property.getName())
                            .append('=')
                            .append(property.getName(val.value()));
                }
                builder.append(']');
            }
            return new JsonPrimitive(builder.toString());
        }
    }

    public static class BlockModelTypeDeserializer implements JsonDeserializer<BlockModelType>, JsonSerializer<BlockModelType> {
        private static final Map<String, BlockModelType> LOOKUP = new HashMap<>();

        static {
            for (BlockModelType type : BlockModelType.values()) {
                String newName = type.name();

                var s = "SCULK_SENSOR_";
                if (newName.startsWith(s)) {
                    var sensorBlock = newName.replace(s, "");
                    LOOKUP.put(("SCULK_SENSOR_BLOCK_" + sensorBlock).toLowerCase(), type);
                }

                LOOKUP.put(newName.toLowerCase(), type);
                LOOKUP.put((newName + "_BLOCK").toLowerCase(), type);

                handlePositionalSwaps(newName, type);

                if (newName.endsWith("_ACTIVE")) {
                    String base = newName.replace("_ACTIVE", "");
                    LOOKUP.put(("ACTIVE_" + base).toLowerCase(), type);
                    LOOKUP.put(("ACTIVE_" + base + "_BLOCK").toLowerCase(), type);
                }
            }

            manualMap("TRANSPARENT_BLOCK", "LEAVES");
            manualMap("TRANSPARENT_BLOCK_WATERLOGGED", "LEAVES_WATERLOGGED");
            manualMap("BIOME_TRANSPARENT_BLOCK", "BIOME_COLORED_LEAVES");
            manualMap("BIOME_TRANSPARENT_BLOCK_WATERLOGGED", "BIOME_COLORED_LEAVES_WATERLOGGED");

            manualMap("TOP_SLAB", "STAB_TOP");
            manualMap("TOP_SLAB_WATERLOGGED", "SLAB_TOP_WATERLOGGED");
        }

        private static void handlePositionalSwaps(String newName, BlockModelType type) {
            String[] parts = newName.split("_");
            if (parts.length >= 2) {
                String prefix = parts[0];
                if (prefix.equals("DOOR") || prefix.equals("SHELF") || prefix.equals("TRAPDOOR") || prefix.equals("GATE") || prefix.equals("SCAFFOLDING")) {
                    String remainder = newName.substring(prefix.length() + 1);
                    LOOKUP.put((remainder + "_" + prefix).toLowerCase(), type);
                    LOOKUP.put((remainder + "_" + prefix + "_GATE").toLowerCase(), type);
                }
            }
        }

        private static void manualMap(String oldJsonName, String newEnumName) {
            try {
                LOOKUP.put(oldJsonName.toLowerCase(), BlockModelType.valueOf(newEnumName));
            } catch (IllegalArgumentException ignored) {

            }
        }

        @Override
        public BlockModelType deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String value = json.getAsString().toLowerCase();

            BlockModelType type = LOOKUP.get(value);
            if (type != null) {
                return type;
            }

            try {
                return BlockModelType.valueOf(value.toUpperCase());
            } catch (IllegalArgumentException e) {
                throw new JsonParseException("Unsupported BlockModelType: " + value);
            }
        }

        @Override
        public JsonElement serialize(BlockModelType src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.name().toLowerCase());
        }
    }

    public static class LowercaseEnumDeserializer<T extends Enum<T>> implements JsonDeserializer<T>, JsonSerializer<T> {

        private final Class<T> enumClass;

        public LowercaseEnumDeserializer(Class<T> enumClass) {
            this.enumClass = enumClass;
        }

        @Override
        public T deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            String value = json.getAsString().toLowerCase();
            for (T constant : enumClass.getEnumConstants()) {
                if (constant.name().equalsIgnoreCase(value)) {
                    return constant;
                }
            }

            throw new JsonParseException("Invalid " + enumClass.getSimpleName() + " value: " + value);
        }

        @Override
        public JsonElement serialize(T src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.name().toLowerCase());
        }
    }

    public static class PolymerBlockModelDeserializer implements JsonDeserializer<PolymerBlockModel>, JsonSerializer<PolymerBlockModel> {
        @Override
        public PolymerBlockModel deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonPrimitive()) {
                JsonPrimitive primitive = json.getAsJsonPrimitive();
                if (primitive.isString()) {
                    return PolymerBlockModel.of(Identifier.tryParse(primitive.getAsString()));
                }
            } else if (json.isJsonObject()) {
                JsonObject object = json.getAsJsonObject();
                Identifier model = Identifier.parse(object.get("model").getAsString());
                int x = object.has("x") ? object.get("x").getAsInt() : 0;
                int y = object.has("y") ? object.get("y").getAsInt() : 0;
                boolean uvLock = object.has("uvLock") && object.get("uvLock").getAsBoolean();
                int weight = object.has("weight") ? object.get("weight").getAsInt() : 1;
                return PolymerBlockModel.of(model, x, y, uvLock, weight);
            }

            throw new JsonParseException("Invalid PolymerBlockModel value: " + json);
        }

        @Override
        public JsonElement serialize(PolymerBlockModel src, Type typeOfSrc, JsonSerializationContext context) {
            JsonObject object = new JsonObject();
            try {
                object.addProperty("model", src.model().toString());
                if (src.x() != 0) object.addProperty("x", src.x());
                if (src.y() != 0) object.addProperty("y", src.y());
                if (src.uvLock()) object.addProperty("uvLock", true);
                if (src.weight() != 1) object.addProperty("weight", src.weight());

                if (object.size() == 1)
                    return new JsonPrimitive(object.get("model").getAsString());
            } catch (Exception e) {
                return new JsonPrimitive(src.toString());
            }
            return object;
        }
    }

    public static class TextureBlockModelDeserializer implements JsonDeserializer<BlockResource.TextureBlockModel>, JsonSerializer<BlockResource.TextureBlockModel> {
        @Override
        public BlockResource.TextureBlockModel deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonObject()) {
                JsonObject object = json.getAsJsonObject();

                Map<String, Identifier> map;
                Type mapType = new TypeToken<Map<String, Identifier>>() {}.getType();
                if (object.has("textures")) {
                    map = context.deserialize(object.get("textures").getAsJsonObject(), mapType);
                } else {
                    map = context.deserialize(object, mapType);
                }

                int x = object.has("x") ? object.get("x").getAsInt() : 0;
                int y = object.has("y") ? object.get("y").getAsInt() : 0;
                boolean uvLock = object.has("uvLock") && object.get("uvLock").getAsBoolean();
                int weight = object.has("weight") ? object.get("weight").getAsInt() : 1;
                return new BlockResource.TextureBlockModel(map, x, y, uvLock, weight);
            }

            throw new JsonParseException("Invalid TextureBlockModel value: " + json);
        }

        @Override
        public JsonElement serialize(BlockResource.TextureBlockModel src, Type typeOfSrc, JsonSerializationContext context) {
            JsonObject object = new JsonObject();
            try {
                object.add("textures", context.serialize(src.textures()));
                if (src.x() != 0) object.addProperty("x", src.x());
                if (src.y() != 0) object.addProperty("y", src.y());
                if (src.uvLock()) object.addProperty("uvLock", true);
                if (src.weight() != 1) object.addProperty("weight", src.weight());
            } catch (Exception ignored) {
            }
            return object;
        }
    }

    public static class QuaternionfDeserializer implements JsonDeserializer<Quaternionf>, JsonSerializer<Quaternionf> {
        @Override
        public Quaternionf deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonArray jsonArray = jsonElement.getAsJsonArray();

            if (jsonArray.size() < 3) {
                throw new JsonParseException("Array size should be at least 3 for euler angle deserialization.");
            }

            float x = jsonArray.get(0).getAsFloat();
            float y = jsonArray.get(1).getAsFloat();
            float z = jsonArray.get(2).getAsFloat();

            return new Quaternionf().rotateXYZ(x * Mth.DEG_TO_RAD, y * Mth.DEG_TO_RAD, z * Mth.DEG_TO_RAD);
        }

        @Override
        public JsonElement serialize(Quaternionf src, Type typeOfSrc, JsonSerializationContext context) {
            JsonArray array = new JsonArray();
            Vector3f euler = src.getEulerAnglesXYZ(new Vector3f());
            array.add(euler.x * Mth.RAD_TO_DEG);
            array.add(euler.y * Mth.RAD_TO_DEG);
            array.add(euler.z * Mth.RAD_TO_DEG);
            return array;
        }
    }

    private record RegistryDeserializer<T>(Registry<T> registry) implements JsonDeserializer<T>, JsonSerializer<T> {
        @Override
        public T deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            return this.registry.getValue(Identifier.parse(element.getAsString()));
        }

        @Override
        public JsonElement serialize(T src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(this.registry.getKey(src).toString());
        }
    }

    private record ComponentDeserializer() implements JsonDeserializer<Component>, JsonSerializer<Component> {
        @Override
        public Component deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
            return TextUtil.formatText(element.getAsString());
        }

        @Override
        public JsonElement serialize(Component src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.getString());
        }
    }

    public static class DataComponentsDeserializer implements JsonDeserializer<DataComponentMap>, JsonSerializer<DataComponentMap> {
        @Override
        public DataComponentMap deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            RegistryOps.RegistryInfoLookup registryInfoLookup = createContext(RegistryAccess.fromRegistryOfRegistries(BuiltInRegistries.REGISTRY));
            DataResult<Pair<DataComponentMap, JsonElement>> result = DataComponentMap.CODEC.decode(RegistryOps.create(JsonOps.INSTANCE, registryInfoLookup), jsonElement);

            if (result.resultOrPartial().isEmpty()) {
                Filament.LOGGER.error("Skipping broken components; could not load: {}", jsonElement.toString());
                Filament.LOGGER.error("Minecraft error message: {}", result.error().orElseThrow().message());
                return null;
            } else if (result.error().isPresent()) {
                Filament.LOGGER.warn("Could not load some components: {}", jsonElement.toString());
                Filament.LOGGER.warn("Minecraft error message: {}", result.error().orElseThrow().message());
            }

            return result.resultOrPartial().get().getFirst();
        }

        @Override
        public JsonElement serialize(DataComponentMap src, Type typeOfSrc, JsonSerializationContext context) {
            RegistryOps.RegistryInfoLookup registryInfoLookup = createContext(RegistryAccess.fromRegistryOfRegistries(BuiltInRegistries.REGISTRY));
            return DataComponentMap.CODEC.encodeStart(RegistryOps.create(JsonOps.INSTANCE, registryInfoLookup), src).getOrThrow();
        }

        public static RegistryOps.RegistryInfoLookup createContext(RegistryAccess registryAccess) {
            final Map<ResourceKey<? extends Registry<?>>, RegistryOps.RegistryInfo<?>> map = new HashMap<>();
            registryAccess.registries().forEach((registryEntry) -> map.put(registryEntry.key(), createInfoForContextRegistry(registryEntry.value())));
            return new RegistryOps.RegistryInfoLookup() {
                @NotNull
                @SuppressWarnings("unchecked")
                public <T> Optional<RegistryOps.RegistryInfo<T>> lookup(@NonNull ResourceKey<? extends Registry<? extends T>> resourceKey) {
                    return Optional.ofNullable((RegistryOps.RegistryInfo<T>) map.get(resourceKey));
                }
            };
        }

        public static <T> RegistryOps.RegistryInfo<T> createInfoForContextRegistry(Registry<T> registry) {
            return new RegistryOps.RegistryInfo<>(registry, registry, registry.registryLifecycle());
        }
    }
}
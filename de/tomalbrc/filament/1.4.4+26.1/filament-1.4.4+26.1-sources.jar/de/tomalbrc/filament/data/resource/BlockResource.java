package de.tomalbrc.filament.data.resource;

import eu.pb4.polymer.blocks.api.PolymerBlockModel;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.resources.Identifier;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

public class BlockResource implements ResourceProvider {
    private Map<String, PolymerBlockModel> models = new Object2ObjectArrayMap<>();
    private Identifier parent;
    private Map<String, TextureBlockModel> textures;

    public BlockResource(Map<String, PolymerBlockModel> models) {
        this(models, null, null);
    }

    public BlockResource(Map<String, PolymerBlockModel> models, Identifier parent, Map<String, TextureBlockModel> textures) {
        this.models = models;
        this.parent = parent;
        this.textures = textures;
    }

    public Identifier parent() {
        if (parent == null)
            parent = Identifier.withDefaultNamespace("block/cube_all");
        return parent;
    }

    public Map<String, TextureBlockModel> textures() {
        return textures;
    }

    public boolean couldGenerate() {
        return (models == null || models.isEmpty()) && textures != null;
    }

    @Override
    public Map<String, Identifier> getModels() {
        if (this.models == null || this.models.isEmpty()) return Collections.emptyMap();

        var map = new Object2ObjectOpenHashMap<String, Identifier>(this.models.size());

        for (var entry : this.models.entrySet()) {
            String rawKey = entry.getKey();
            String processedKey = rawKey;

            if (rawKey.indexOf(',') != -1) {
                String[] parts = rawKey.split(",");
                Arrays.sort(parts);
                processedKey = String.join(",", parts);
            }

            map.put(processedKey, entry.getValue().model());
        }
        return map;
    }

    public Map<String, PolymerBlockModel> models() {
        return this.models;
    }

    public void addModel(String key, PolymerBlockModel blockModel) {
        if (this.models == null) this.models = new Object2ObjectArrayMap<>();
        this.models.put(key, blockModel);
    }

    public record TextureBlockModel(Map<String, Identifier> textures, int x, int y, boolean uvLock, int weight) {}
}
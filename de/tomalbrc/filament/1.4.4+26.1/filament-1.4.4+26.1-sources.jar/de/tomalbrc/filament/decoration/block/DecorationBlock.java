package de.tomalbrc.filament.decoration.block;

import de.tomalbrc.filament.api.behaviour.*;
import de.tomalbrc.filament.block.SimpleBlock;
import de.tomalbrc.filament.data.BlockData;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.VirtualDestroyStage;
import eu.pb4.common.protection.api.CommonProtection;
import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.virtualentity.api.BlockWithElementHolder;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.fabric.api.networking.v1.context.PacketContext;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

import java.util.Map;
import java.util.function.BiConsumer;

public abstract class DecorationBlock extends SimpleBlock implements PolymerBlock, BlockWithElementHolder, SimpleWaterloggedBlock, VirtualDestroyStage.Marker {
    final protected Identifier decorationId;
    final protected DecorationData data;
    final protected Map<BlockData.BlockStateMeta, String> cmdMap = new Reference2ObjectOpenHashMap<>();

    public DecorationBlock(Properties properties, DecorationData data) {
        super(properties, data);
        this.decorationId = data.id();
        this.data = data;
    }

    public void postRegister() {
        this.stateMap = this.data.createStandardStateMap();
        var resource = blockData.blockResource();
        if (resource != null) {
            for (Map.Entry<BlockState, BlockData.BlockStateMeta> stateMapEntry : this.stateMap.entrySet()) {
                for (Map.Entry<String, Identifier> blockResourceModelsEntry : resource.getModels().entrySet()) {
                    boolean same = blockResourceModelsEntry.getValue().equals(stateMapEntry.getValue().polymerBlockModel().model());
                    if (same) {
                        this.cmdMap.put(stateMapEntry.getValue(), blockResourceModelsEntry.getKey());
                    }
                }
            }
        }
        this.stateDefinitionEx.getPossibleStates().forEach(BlockState::initCache);
    }

    public DecorationData getDecorationData() {
        return this.data;
    }

    @Override
    public BlockState getPolymerBlockState(BlockState state, PacketContext packetContext) {
        DecorationData decorationData = getDecorationData();
        if (decorationData != null) {
            boolean passthrough = !decorationData.hasBlocks();

            var newState = state;
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : this.getBehaviours()) {
                if (behaviour.getValue() instanceof BlockBehaviour<?> blockBehaviour) {
                    newState = blockBehaviour.modifyPolymerBlockState(state, newState);
                }
            }

            var customBlock = decorationData.block(state);
            BlockState blockState = customBlock == null ? passthrough ? Blocks.AIR.defaultBlockState() : Blocks.BARRIER.defaultBlockState() : customBlock;
            boolean waterlogged = newState.hasProperty(BlockStateProperties.WATERLOGGED) && newState.getValue(BlockStateProperties.WATERLOGGED);
            if (passthrough && waterlogged) {
                return Blocks.WATER.defaultBlockState();
            } else if (blockState.hasProperty(BlockStateProperties.WATERLOGGED)) {
                blockState = blockState.setValue(BlockStateProperties.WATERLOGGED, waterlogged);
            }

            return blockState;
        }

        return super.getPolymerBlockState(state, packetContext);
    }

    @Override
    public void onExplosionHit(@NonNull BlockState blockState, @NonNull ServerLevel level, @NonNull BlockPos blockPos, Explosion explosion, @NonNull BiConsumer<ItemStack, BlockPos> biConsumer) {
        if (explosion.getDirectSourceEntity() instanceof Player player && !CommonProtection.canExplodeBlock(level, blockPos, explosion, player.nameAndId(), player))
            return;

        if ((explosion.getBlockInteraction() == Explosion.BlockInteraction.DESTROY || explosion.getBlockInteraction() == Explosion.BlockInteraction.DESTROY_WITH_DECAY) && !blockState.isAir()) {
            this.removeDecoration(level, blockPos, null);
            this.wasExploded(level, blockPos, explosion);
        }
    }

    @Override
    @NotNull
    public BlockState playerWillDestroy(@NonNull Level level, @NonNull BlockPos blockPos, @NonNull BlockState blockState, @NonNull Player player) {
        BlockState returnVal = super.playerWillDestroy(level, blockPos, blockState, player);
        this.removeDecoration(level, blockPos, player);
        return returnVal;
    }

    protected void removeDecoration(Level level, BlockPos blockPos, Player player) {
        BlockEntity blockEntity = level.getBlockEntity(blockPos);
        if (blockEntity instanceof DecorationBlockEntity decorationBlockEntity) {
            if (player != null) {
                for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : decorationBlockEntity.getBehaviours()) {
                    if (behaviour.getValue() instanceof DecorationBehaviour<?> decorationBehaviour) {
                        decorationBehaviour.postBreak(decorationBlockEntity, blockPos, player);
                    }
                }
            }

            decorationBlockEntity.destroyStructure(player == null || !player.hasInfiniteMaterials());
        } else {
            level.destroyBlock(blockPos, false);
        }
    }

    @Override
    @NotNull
    public VoxelShape getCollisionShape(@NonNull BlockState blockState, @NonNull BlockGetter blockGetter, @NonNull BlockPos blockPos, @NonNull CollisionContext collisionContext) {
        if (!getDecorationData().hasBlocks()) {
            return Shapes.empty();
        } else {
            return super.getCollisionShape(blockState, blockGetter, blockPos, collisionContext);
        }
    }

    public float getVisualRotationYInDegrees(BlockState blockState) {
        if (blockState.getBlock() instanceof DecorationBlock decorationBlock) {
            for (Map.Entry<BehaviourType<? extends Behaviour<?>, ?>, Behaviour<?>> behaviour : decorationBlock.getBehaviours()) {
                if (behaviour.getValue() instanceof DecorationRotationProvider rotationProvider) {
                    return rotationProvider.getVisualRotationYInDegrees(blockState);
                }
            }
        }

        return 0;
    }

    abstract public ItemStack visualItemStack(LevelReader levelReader, BlockPos blockPos, BlockState blockState);
}

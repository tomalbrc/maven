package de.tomalbrc.filament.behaviour;

import de.tomalbrc.filament.api.behaviour.BlockBehaviour;
import de.tomalbrc.filament.api.behaviour.ItemBehaviour;
import de.tomalbrc.filament.block.SimpleBlock;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

public class BehaviourUtil {
    public static void postInitItem(Item item, BehaviourHolder behaviourHolder, BehaviourConfigMap configMap) {
        if (configMap == null || item == null)
            return;

        for (var e : behaviourHolder.getBehaviours()) {
            if (e.getValue() instanceof ItemBehaviour<?> itemBehaviour) {
                itemBehaviour.init(item, behaviourHolder);
            }
        }
    }

    @Deprecated
    public static void postInitBlock(Item blockItem, Block block, BehaviourHolder behaviourHolder, BehaviourConfigMap configMap) {
        if (configMap == null)
            return;

        for (var e : behaviourHolder.getBehaviours()) {
            if (e.getValue() instanceof BlockBehaviour<?> blockBehaviour) {
                blockBehaviour.init(blockItem, block, behaviourHolder);
            }
        }
    }

    public static void postInitBlock(SimpleBlock block, BehaviourConfigMap configMap) {
        if (configMap == null)
            return;

        for (var e : block.getBehaviours()) {
            if (e.getValue() instanceof BlockBehaviour<?> blockBehaviour) {
                blockBehaviour.init(block.asItem(), block, block);
            }
        }
    }
}

package de.tomalbrc.filament.registry;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import de.tomalbrc.filament.Filament;
import de.tomalbrc.filament.api.event.FilamentRegistrationEvents;
import de.tomalbrc.filament.data.DecorationData;
import de.tomalbrc.filament.datafixer.config.DecorationDataFix;
import de.tomalbrc.filament.decoration.DecorationItem;
import de.tomalbrc.filament.decoration.block.ComplexDecorationBlock;
import de.tomalbrc.filament.decoration.block.DecorationBlock;
import de.tomalbrc.filament.decoration.block.SimpleDecorationBlock;
import de.tomalbrc.filament.decoration.block.entity.DecorationBlockEntity;
import de.tomalbrc.filament.util.Constants;
import de.tomalbrc.filament.util.FilamentSynchronousResourceReloadListener;
import de.tomalbrc.filament.util.Json;
import de.tomalbrc.filament.util.Util;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.PushReaction;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Map;
import java.util.function.Function;

public class DecorationRegistry {
    private static final Reference2ObjectOpenHashMap<Identifier, DecorationData> decorations = new Reference2ObjectOpenHashMap<>();
    private static final Reference2ObjectOpenHashMap<Identifier, Block> decorationBlocks = new Reference2ObjectOpenHashMap<>();
    private static final Reference2ObjectOpenHashMap<Block, BlockEntityType<DecorationBlockEntity>> decorationBlockEntities = new Reference2ObjectOpenHashMap<>();
    public static int REGISTERED_BLOCK_ENTITIES = 0;
    public static int REGISTERED_DECORATIONS = 0;

    public static void register(Path filepath, InputStream inputStream) throws IOException {
        JsonElement element = JsonParser.parseReader(new InputStreamReader(inputStream));

        try {
            DecorationData data = Json.GSON.fromJson(element, DecorationData.class);
            data.filepath = filepath;
            // backwards compatibility
            DecorationDataFix.fixup(element, data);
            Util.handleComponentsCustom(element, data);

            register(data);
        } catch (Exception e) {
            Filament.LOGGER.error("Could not load file! Error: {}", String.valueOf(e.fillInStackTrace()));
            Filament.LOGGER.info("Path: {}", filepath);
            Filament.LOGGER.info("File: \n{}", element.toString());
        }
    }

    public static void register(InputStream inputStream) throws IOException {
        register(null, inputStream);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static public void register(DecorationData data) {
        for (Map.Entry<Identifier, DecorationData> entry : decorations.entrySet()) {
            if (entry.getKey().equals(data.id())) {
                var block = BuiltInRegistries.BLOCK.getValue(data.id());
                if (block.isFilamentBlock() && block.asItem().isFilamentItem()) {
                    block.asItem().asFilamentItem().initBehaviours(data.behaviour());
                    block.asFilamentBlock().initBehaviours(data.behaviour());
                    BlockRegistry.postRegistration(block.asItem().asFilamentItem(), block.asFilamentBlock(), data);
                }
                return;
            }
        }

        decorations.put(data.id(), data);

        BlockBehaviour.Properties blockProperties = data.properties().toBlockProperties();
        DecorationBlock block = BlockRegistry.registerBlock(BlockRegistry.key(data.id()), getBlockCreator(data), blockProperties, data.blockTags());
        decorationBlocks.put(data.id(), block);

        Item.Properties properties = data.properties().toItemProperties();
        if (data.properties().copyComponents == Boolean.TRUE) {
            for (TypedDataComponent component : data.vanillaItem().components()) {
                properties.component(component.type(), component.value());
            }
        }
        for (TypedDataComponent component : data.components()) {
            properties.component(component.type(), component.value());
        }

        if (data.isContainer()) {
            properties.component(DataComponents.CONTAINER, ItemContainerContents.EMPTY);
        }

        if (data.vanillaItem() == Items.LEATHER_HORSE_ARMOR || data.vanillaItem() == Items.FIREWORK_STAR) {
            properties.component(DataComponents.DYED_COLOR, new DyedItemColor(0xdaad6d));
        }

        var item = ItemRegistry.registerItem(ItemRegistry.key(data.id()), (newProps) -> new DecorationItem(block, data, newProps), properties, data.group() != null ? data.group() : Constants.DECORATION_GROUP_ID, data.itemTags());
        BlockRegistry.postRegistration(item, block, data);

        FilamentRegistrationEvents.DECORATION.invoker().registered(data, item, block);
    }

    @NotNull
    private static Function<BlockBehaviour.Properties, DecorationBlock> getBlockCreator(DecorationData data) {
        Function<BlockBehaviour.Properties, DecorationBlock> gen;
        if (data.requiresEntityBlock()) {
            gen = (x) -> {
                var block = new ComplexDecorationBlock(x.pushReaction(PushReaction.BLOCK), data);

                BlockEntityType<DecorationBlockEntity> DECORATION_BLOCK_ENTITY = FabricBlockEntityTypeBuilder.create(DecorationBlockEntity::new, block).build();
                EntityRegistry.registerBlockEntity(EntityRegistry.key(data.id()), DECORATION_BLOCK_ENTITY);

                decorationBlockEntities.put(block, DECORATION_BLOCK_ENTITY);
                REGISTERED_BLOCK_ENTITIES++;
                REGISTERED_DECORATIONS++;

                return block;
            };
        } else {
            gen = (x) -> {
                REGISTERED_DECORATIONS++;
                return new SimpleDecorationBlock(x, data);
            };
        }
        return gen;
    }

    public static DecorationData getDecorationData(Identifier Identifier) {
        return decorations.get(Identifier);
    }

    public static boolean isDecoration(BlockState blockState) {
        return blockState.getBlock() instanceof DecorationBlock;
    }

    public static DecorationBlock getDecorationBlock(Identifier Identifier) {
        return (DecorationBlock) decorationBlocks.get(Identifier);
    }

    public static BlockEntityType<DecorationBlockEntity> getBlockEntityType(BlockState blockState) {
        return decorationBlockEntities.get(blockState.getBlock());
    }


    public static class DecorationDataReloadListener implements FilamentSynchronousResourceReloadListener {
        @Override
        public Identifier getFabricId() {
            return Identifier.fromNamespaceAndPath(Constants.MOD_ID, "decorations");
        }

        @Override
        public void onResourceManagerReload(ResourceManager resourceManager) {
            load("filament/decoration", null, resourceManager, (id, inputStream) -> {
                try {
                    DecorationRegistry.register(obtainPath(id, resourceManager), inputStream);
                } catch (Exception e) {
                    Filament.LOGGER.error("Failed to load decoration resource \"{}\".", id);
                }
            });
        }
    }
}

package de.tomalbrc.bil.core.holder.wrapper;

import de.tomalbrc.bil.core.element.PerPlayerItemDisplayElement;
import de.tomalbrc.bil.core.model.Node;
import de.tomalbrc.bil.core.model.Pose;
import eu.pb4.polymer.virtualentity.api.tracker.DisplayTrackedData;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class ItemBone extends Bone<PerPlayerItemDisplayElement> {
    protected final class_1799 item;
    protected boolean invisible;

    protected ItemBone(PerPlayerItemDisplayElement element, Node node, Pose defaultPose, BoneTag tag) {
        super(element, node, defaultPose, tag);
        this.item = element.getItem();
    }

    public static ItemBone of(PerPlayerItemDisplayElement element, Node node, Pose defaultPose, BoneTag tag) {
        return new ItemBone(element, node, defaultPose, tag);
    }

    public static ItemBone of(PerPlayerItemDisplayElement element, @NotNull Node node, Pose defaultPose) {
        Node current = node;
        boolean head = false;
        while (current != null) {
            if (current.headTag()) {
                head = true;
                break;
            }
            current = current.parent();
        }

        return new ItemBone(element, node, defaultPose, head ? BoneTag.HEAD : BoneTag.NONE);
    }

    public void setInvisible(boolean invisible) {
        if (this.invisible == invisible) {
            return;
        }

        this.invisible = invisible;
        if (invisible) {
            this.setTrackedItem(class_1799.field_8037);
        } else {
            this.setTrackedItem(this.item);
        }
    }

    public void updateColor(int color) {
        this.item.method_57379(class_9334.field_49644, new class_9282(color));

        if (!this.invisible) {
            this.setTrackedItem(this.item);
        }
    }

    public void updateModel(class_2960 model) {
        this.item.method_57379(class_9334.field_54199, model);

        if (!this.invisible) {
            this.setTrackedItem(this.item);
        }
    }

    protected void setTrackedItem(class_1799 item) {
        this.element().getDataTracker().set(DisplayTrackedData.Item.ITEM, item, true);
    }
}

package de.tomalbrc.bil.mixin.packet;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.api.AnimatedEntityHolder;
import net.minecraft.class_1297;
import net.minecraft.class_2663;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2663.class)
public class ClientboundEntityEventPacketMixin {
    @Mutable
    @Shadow
    @Final
    private int entityId;

    @Inject(method = "<init>(Lnet/minecraft/world/entity/Entity;B)V", at = @At("RETURN"))
    private void bil$modifyEventPacket(class_1297 entity, byte b, CallbackInfo ci) {
        AnimatedEntityHolder holder = AnimatedEntity.getHolder(entity);
        if (holder != null) {
            this.entityId = holder.getEntityEventId();
        }
    }
}

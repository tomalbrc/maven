package de.tomalbrc.bil.file.loader;

import com.google.gson.JsonParseException;
import de.tomalbrc.bil.core.model.Model;
import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import net.minecraft.class_2960;

public interface ModelLoader {
    static String normalizedModelId(String id) {
        id = id.trim().replace(" ", "_");
        id = id.replace("-", "_");
        id = id.replace("\\", "/");
        return id.toLowerCase();
    }

    Model load(InputStream input, @NotNull String path) throws JsonParseException;

    Model loadResource(class_2960 resourceLocation) throws IllegalArgumentException, JsonParseException;
}

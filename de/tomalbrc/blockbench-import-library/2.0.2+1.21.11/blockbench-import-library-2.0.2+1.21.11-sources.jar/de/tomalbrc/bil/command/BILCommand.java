package de.tomalbrc.bil.command;

import com.mojang.brigadier.CommandDispatcher;
import de.tomalbrc.bil.util.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class BILCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        var builder = class_2170.method_9247("bil").requires(Permissions.require("bil.command", 4));
        builder.then(ModelCommand.register());
        dispatcher.register(builder);
    }
}

package de.tomalbrc.bil.util;

import de.tomalbrc.bil.mixin.accessor.LivingEntityAccessor;
import java.util.List;
import net.minecraft.class_2394;
import net.minecraft.class_2940;

public class Constants {
    public static final class_2940<List<class_2394>> DATA_EFFECT_PARTICLES = LivingEntityAccessor.getDATA_EFFECT_PARTICLES();
    public static final int DAMAGE_TINT_COLOR = 0xFF7E7E;
}

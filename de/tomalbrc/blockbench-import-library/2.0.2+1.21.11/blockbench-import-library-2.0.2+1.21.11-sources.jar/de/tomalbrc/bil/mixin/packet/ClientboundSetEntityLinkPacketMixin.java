package de.tomalbrc.bil.mixin.packet;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.api.AnimatedEntityHolder;
import net.minecraft.class_1297;
import net.minecraft.class_2740;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2740.class)
public class ClientboundSetEntityLinkPacketMixin {
    @Mutable
    @Shadow
    @Final
    private int sourceId;

    @Inject(method = "<init>(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;)V", at = @At("RETURN"))
    private void bil$modifyLeashPacket(class_1297 leashed, @Nullable class_1297 leashHolder, CallbackInfo ci) {
        AnimatedEntityHolder holder = AnimatedEntity.getHolder(leashed);
        if (holder != null) {
            this.sourceId = holder.getLeashedId();
        }
    }
}

package de.tomalbrc.bil.core.model;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_241;

/**
 * Intermediate/internal model representation
 */
public record Model(Object2ObjectOpenHashMap<UUID, Node> nodeMap,
                    Reference2ObjectOpenHashMap<UUID, Pose> defaultPose,

                    Reference2ObjectOpenHashMap<UUID, Variant> variants,
                    Object2ObjectOpenHashMap<String, Animation> animations,
                    @Nullable class_241 size) {
}

package de.tomalbrc.bil.core.holder.entity.living;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.util.Utils;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3244;
import net.minecraft.class_4048;
import net.minecraft.class_8042;

/**
 * Extension of {@link LivingEntityHolder} that allows for custom passenger riding offsets.
 * <p>
 * This will use {@link class_1297#method_17682} + {@link class_1297#getMyRidingOffset} as the ride height.
 * <p>
 * It works by adding an extra zero bounding boxed {@link InteractionElement} to the parent entity,
 * which is used as the vehicle. This will add a very minor overhead on the client.
 */
public class LivingEntityHolderWithRideOffset<T extends class_1309 & AnimatedEntity> extends LivingEntityHolder<T> {
    private static final class_4048 ZERO = class_4048.method_18385(0, 0);
    protected final InteractionElement rideInteraction;

    public LivingEntityHolderWithRideOffset(T parent, Model model) {
        super(parent, model);

        this.rideInteraction = new InteractionElement();
        this.rideInteraction.setInvisible(true);
        this.addElement(this.rideInteraction);
    }

    protected float getRideOffset() {
        return (float) (this.parent.method_17682() + this.parent.method_52538(this.parent).method_10214());
    }

    @Override
    protected void startWatchingExtraPackets(class_3244 player, Consumer<class_2596<class_2602>> consumer) {
        super.startWatchingExtraPackets(player, consumer);

        for (var packet : Utils.updateClientInteraction(this.rideInteraction, ZERO, this.getRideOffset())) {
            consumer.accept((class_2596<class_2602>) packet);
        }
    }

    @Override
    protected void addDirectPassengers(IntList passengers) {
        super.addDirectPassengers(passengers);
        passengers.add(this.rideInteraction.getEntityId());
    }

    @Override
    public void onDimensionsUpdated(class_4048 dimensions) {
        super.onDimensionsUpdated(dimensions);
        this.sendPacket(new class_8042(Utils.updateClientInteraction(this.rideInteraction, ZERO, this.getRideOffset())));
    }

    @Override
    public int getVehicleId() {
        return this.rideInteraction.getEntityId();
    }
}

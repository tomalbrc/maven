package de.tomalbrc.bil.mixin.packet;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.api.AnimatedEntityHolder;
import net.minecraft.class_1297;
import net.minecraft.class_2616;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.minecraft.class_2616.field_33299;
import static net.minecraft.class_2616.field_33300;

@Mixin(class_2616.class)
public class ClientboundAnimatePacketMixin {
    @Mutable
    @Shadow
    @Final
    private int id;

    @Inject(method = "<init>(Lnet/minecraft/world/entity/Entity;I)V", at = @At("RETURN"))
    private void bil$modifyAnimatePacket(class_1297 entity, int action, CallbackInfo ci) {
        AnimatedEntityHolder holder = AnimatedEntity.getHolder(entity);
        if (holder != null) {
            this.id = switch (action) {
                // Return the entity id for handling critical hit particles.
                case field_33299, field_33300 -> holder.getCritParticleId();
                // Return invalid entity id to prevent the client from incorrectly type casting.
                default -> -1;
            };
        }
    }
}

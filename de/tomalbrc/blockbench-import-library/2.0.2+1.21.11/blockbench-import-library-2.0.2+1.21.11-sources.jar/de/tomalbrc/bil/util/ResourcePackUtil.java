package de.tomalbrc.bil.util;

import eu.pb4.polymer.resourcepack.api.ResourcePackBuilder;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2960;


public class ResourcePackUtil {
    private static ConcurrentHashMap<class_2960, byte[]> data = new ConcurrentHashMap<>();

    public static byte[] add(class_2960 location, byte[] bytes) {
        return data.put(location, bytes);
    }

    public static void addAdditional(ResourcePackBuilder resourcePackBuilder) {
        for (var entry : data.entrySet()) {
            resourcePackBuilder.addData(entry.getKey().method_12832(), entry.getValue());
        }
    }
}

package de.tomalbrc.bil.util;

import de.tomalbrc.bil.core.holder.base.AbstractElementHolder;
import net.minecraft.class_3898;

public interface IChunkMap {
    static void scheduleAsyncTick(AbstractElementHolder holder) {
        IChunkMap chunkMap = (IChunkMap) holder.getLevel().method_14178().field_17254;
        chunkMap.bil$scheduleAsyncTick(holder);
    }

    static void blockUntilAsyncTickFinished(class_3898 map) {
        IChunkMap chunkMap = (IChunkMap) map;
        chunkMap.bil$blockUntilAsyncTickFinished();
    }

    void bil$scheduleAsyncTick(AbstractElementHolder holder);

    void bil$blockUntilAsyncTickFinished();
}

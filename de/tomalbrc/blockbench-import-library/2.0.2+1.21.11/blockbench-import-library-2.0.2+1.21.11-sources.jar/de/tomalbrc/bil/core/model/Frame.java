package de.tomalbrc.bil.core.model;

import com.mojang.brigadier.CommandDispatcher;
import de.tomalbrc.bil.BIL;
import de.tomalbrc.bil.core.holder.base.AbstractAnimationHolder;
import de.tomalbrc.bil.util.command.ParsedCommand;
import eu.pb4.polymer.virtualentity.api.attachment.HolderAttachment;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_12096;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2767;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_6880;

public record Frame(
        float time,
        Reference2ObjectOpenHashMap<UUID, Pose> poses,

        @Nullable Variant variant,
        @Nullable Commands commands,
        @Nullable class_3414 soundEffect,
        @Nullable Particle particleEffect
) {
    private static boolean satisfiesConditions(ParsedCommand[] conditions, CommandDispatcher<class_2168> dispatcher, class_2168 source) {
        if (conditions != null) {
            for (ParsedCommand condition : conditions) {
                if (condition.execute(dispatcher, source) <= 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean requiresUpdates() {
        return this.variant != null || this.commands != null || this.soundEffect != null;
    }

    public void runEffects(class_3222 serverPlayer, AbstractAnimationHolder holder) {
        CommandDispatcher<class_2168> dispatcher = BIL.SERVER.method_3734().method_9235();
        class_2168 source = holder.createCommandSourceStack().method_9206(class_12096.field_63208).method_9217();

        if (this.soundEffect != null) {
            class_1297 entity = source.method_9228();
            if (entity != null) {
                entity.method_43077(this.soundEffect);
            } else {
                HolderAttachment attachment = holder.getAttachment();
                if (attachment != null) {
                    var soundPacket = new class_2767(class_6880.method_40223(this.soundEffect), holder.getSoundSource(), source.method_9222().field_1352, source.method_9222().field_1351, source.method_9222().field_1350, 1.f, 1.f, attachment.getWorld().method_8409().method_43055());
                    if (serverPlayer == null) {
                        holder.sendPacket(soundPacket);
                    } else {
                        serverPlayer.field_13987.method_14364(soundPacket);
                    }
                }
            }
        }

        if (this.variant != null) {
            if (satisfiesConditions(this.variant.conditions, dispatcher, source)) {
                holder.getVariantController().setVariant(this.variant.uuid);
            }
        }

        if (this.commands != null && this.commands.commands.length > 0) {
            if (satisfiesConditions(this.commands.conditions, dispatcher, source)) {
                for (ParsedCommand command : this.commands.commands) {
                    command.execute(dispatcher, source);
                }
            }
        }
    }

    public record Variant(
            UUID uuid,
            @Nullable ParsedCommand[] conditions
    ) {
    }

    public record Commands(
            ParsedCommand[] commands,
            @Nullable ParsedCommand[] conditions
    ) {
    }

    public record Particle(
            String effect,
            String locator,
            ParsedCommand[] script,
            String file
    ) {
    }
}
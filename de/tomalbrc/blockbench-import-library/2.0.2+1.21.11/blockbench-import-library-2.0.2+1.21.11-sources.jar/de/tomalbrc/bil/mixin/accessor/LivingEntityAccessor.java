package de.tomalbrc.bil.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_2394;
import net.minecraft.class_2940;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
    @Accessor
    static class_2940<List<class_2394>> getDATA_EFFECT_PARTICLES() {
        throw new UnsupportedOperationException();
    }
}

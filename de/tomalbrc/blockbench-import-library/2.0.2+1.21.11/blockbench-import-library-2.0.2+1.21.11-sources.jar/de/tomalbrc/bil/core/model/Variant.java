package de.tomalbrc.bil.core.model;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import java.util.UUID;
import net.minecraft.class_2960;

public record Variant(
        String name,
        UUID uuid,
        Reference2ObjectOpenHashMap<UUID, class_2960> models,
        ReferenceOpenHashSet<UUID> affectedBones,
        boolean affectedBonesIsAWhitelist
) {
    public boolean isAffected(UUID boneUuid) {
        return this.affectedBonesIsAWhitelist == this.affectedBones.contains(boneUuid);
    }
}


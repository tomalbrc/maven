package de.tomalbrc.bil.core.extra;

import de.tomalbrc.bil.core.holder.base.AbstractAnimationHolder;
import de.tomalbrc.bil.core.holder.entity.EntityHolder;
import de.tomalbrc.bil.core.holder.wrapper.Locator;
import de.tomalbrc.bil.core.model.Pose;
import eu.pb4.polymer.virtualentity.api.VirtualEntityUtils;
import eu.pb4.polymer.virtualentity.api.elements.GenericEntityElement;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import org.joml.Vector3f;
import org.joml.Vector3fc;

/**
 * Listener for locators, updates a single GenericEntityElement
 */
public class ElementUpdateListener implements Locator.LocatorListener {
    protected final GenericEntityElement element;

    public ElementUpdateListener(GenericEntityElement element) {
        this.element = element;
    }

    @Override
    public void update(class_3222 serverPlayer, AbstractAnimationHolder holder, Pose pose) {
        if (this.element.isSendingPositionUpdates()) {
            if (holder instanceof EntityHolder<?> entityHolder) {
                this.updateEntityBasedHolder(entityHolder, pose);
            } else {
                this.updateNonEntityBasedHolder(holder, pose);
            }
        }
    }

    private void updateEntityBasedHolder(EntityHolder<?> holder, Pose pose) {
        class_1297 parent = holder.getParent();
        float scale = holder.getScale();
        float yRot = parent.method_36454();
        float angle = yRot * class_3532.field_29847;

        Vector3f offset = pose.translation();
        if (scale != 1F) {
            offset.mul(scale);
        }
        offset.rotateY(-angle);

        class_243 pos = holder.getPos().method_1031(offset.x, offset.y, offset.z);
        holder.sendPacket(VirtualEntityUtils.createMovePacket(
                this.element.getEntityId(),
                pos,
                pos,
                true,
                yRot,
                0F
        ));
    }

    private void updateNonEntityBasedHolder(AbstractAnimationHolder holder, Pose pose) {
        float scale = holder.getScale();
        Vector3fc offset = scale != 1F
                ? pose.translation().mul(scale)
                : pose.readOnlyTranslation();

        class_243 pos = holder.getPos().method_1031(offset.x(), offset.y(), offset.z());
        holder.sendPacket(VirtualEntityUtils.createMovePacket(
                this.element.getEntityId(),
                pos,
                pos,
                false,
                0F,
                0F
        ));
    }
}
package de.tomalbrc.bil.core.element;

import eu.pb4.polymer.virtualentity.api.elements.GenericEntityElement;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import eu.pb4.polymer.virtualentity.mixin.SlimeEntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_3222;

public class CollisionElement extends GenericEntityElement {
    private InteractionHandler handler = InteractionHandler.EMPTY;

    public CollisionElement(InteractionHandler handler) {
        this.dataTracker.set(EntityTrackedData.SILENT, true);
        this.dataTracker.set(EntityTrackedData.NO_GRAVITY, true);
        this.dataTracker.set(EntityTrackedData.FLAGS, (byte) ((1 << EntityTrackedData.INVISIBLE_FLAG_INDEX)));
        this.setHandler(handler);
    }

    public static CollisionElement createWithRedirect(class_1297 redirectedEntity) {
        return new CollisionElement(InteractionHandler.redirect(redirectedEntity));
    }

    public void setHandler(InteractionHandler handler) {
        this.handler = handler;
    }

    @Override
    public InteractionHandler getInteractionHandler(class_3222 player) {
        return this.handler;
    }

    @Override
    protected final class_1299<? extends class_1297> getEntityType() {
        return class_1299.field_6069;
    }

    public int getSize() {
        return this.dataTracker.get(SlimeEntityAccessor.getID_SIZE());
    }

    public void setSize(int size) {
        this.dataTracker.set(SlimeEntityAccessor.getID_SIZE(), size);
    }
}
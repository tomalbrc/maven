package de.tomalbrc.bil.util.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import de.tomalbrc.bil.BIL;
import net.minecraft.class_12096;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_5244;
import org.jetbrains.annotations.Nullable;

public class ParsedCommand {
    private final String command;
    @Nullable
    private ParseResults<class_2168> parsed;
    private boolean isInvalid;

    protected ParsedCommand(String command) {
        this.command = command;
    }

    public int execute(CommandDispatcher<class_2168> dispatcher, class_2168 source) {
        if (this.parsed == null) {
            var parsingSource = new class_2168(
                    class_2165.field_17395, class_243.field_1353, class_241.field_1340, source.method_9225(), class_12096.field_63208, "", class_5244.field_39003, source.method_9211(), null
            );
            this.parsed = dispatcher.parse(this.command, parsingSource);

            if (class_2170.method_23917(this.parsed) != null) {
                BIL.LOGGER.error("Unable to parse command: {}", this.command);
                this.isInvalid = true;
            }
        }

        if (!this.isInvalid) {
            try {
                return dispatcher.execute(class_2170.method_45018(this.parsed, (s) -> source));
            } catch (Throwable ignored) {
            }
        }
        return 0;
    }
}

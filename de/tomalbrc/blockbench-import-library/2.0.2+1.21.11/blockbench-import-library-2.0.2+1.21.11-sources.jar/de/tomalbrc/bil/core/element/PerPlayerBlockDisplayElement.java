package de.tomalbrc.bil.core.element;

import eu.pb4.polymer.virtualentity.api.elements.BlockDisplayElement;
import eu.pb4.polymer.virtualentity.api.tracker.DataTrackerLike;
import eu.pb4.polymer.virtualentity.api.tracker.SimpleDataTracker;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class PerPlayerBlockDisplayElement extends BlockDisplayElement implements PerPlayerTransformableElement {
    final Map<class_3222, Data> playerDataTracker = new ConcurrentHashMap<>();

    public PerPlayerBlockDisplayElement(class_2680 blockState) {
        super(blockState);
    }

    @Override
    public void startWatching(class_3222 player, Consumer<class_2596<class_2602>> packetConsumer) {
        this.playerDataTracker.put(player, new Data());
        super.startWatching(player, packetConsumer);
    }

    @Override
    public void stopWatching(class_3222 player, Consumer<class_2596<class_2602>> packetConsumer) {
        this.playerDataTracker.remove(player);
        super.stopWatching(player, packetConsumer);
    }

    @Override
    public Map<class_3222, Data> playerDataTrackers() {
        return playerDataTracker;
    }

    @Override
    protected void sendTrackerUpdates() {
        sendTrackerUpdatesPerPlayer();
    }

    @Override
    public DataTrackerLike createDataTracker() {
        return new SimpleDataTracker(this.getEntityType());
    }
}

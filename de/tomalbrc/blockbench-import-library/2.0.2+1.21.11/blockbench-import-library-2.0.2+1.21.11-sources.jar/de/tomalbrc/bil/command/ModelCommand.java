package de.tomalbrc.bil.command;

import com.google.gson.JsonParseException;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import de.tomalbrc.bil.BIL;
import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.api.AnimatedEntityHolder;
import de.tomalbrc.bil.api.VariantController;
import de.tomalbrc.bil.core.extra.ModelEntity;
import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.core.model.Variant;
import de.tomalbrc.bil.file.loader.AjBlueprintLoader;
import de.tomalbrc.bil.file.loader.AjModelLoader;
import de.tomalbrc.bil.file.loader.BbModelLoader;
import de.tomalbrc.bil.util.Utils;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import java.util.Collection;
import java.util.HexFormat;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class ModelCommand {
    private static final String TARGETS = "targets";
    private static final String ANIMATION = "animation";

    public static ArgumentBuilder<class_2168, ?> register() {
        var builder = class_2170.method_9247("model").requires(Permissions.require("bil.command.model", 2));

        // Create model command
        builder.then(modelCreator());

        // Manipulate model command
        builder.then(class_2170.method_9244(TARGETS, class_2186.method_9306())
                .then(scaleManipulator())
                .then(colorManipulator())
                .then(variantManipulator())
                .then(animationManipulator())
        );

        return builder;
    }

    private static int manipulateModels(class_2168 source, Collection<? extends class_1297> targets, Consumer<AnimatedEntityHolder> consumer) {
        int count = 0;
        for (class_1297 target : targets) {
            AnimatedEntityHolder holder = AnimatedEntity.getHolder(target);
            if (holder != null) {
                consumer.accept(holder);
                count++;
            }
        }

        if (count <= 0) {
            source.method_9213(class_2561.method_43470("No models found!"));
        }

        return count;
    }

    private static int spawnModel(class_2168 source, String path) throws CommandSyntaxException {
        class_2960 resource = class_2960.method_60654(path);
        if (path.endsWith(".ajmodel")) {
            return substituteModelLoader(source, path, "ajmodel", newResource -> new AjModelLoader().loadResource(newResource));
        } else if (path.endsWith(".ajblueprint")) {
            return substituteModelLoader(source, path, "ajblueprint", newResource -> new AjBlueprintLoader().loadResource(newResource));
        }

        return spawnModel(source, () -> new BbModelLoader().loadResource(resource), path);
    }

    private static int substituteModelLoader(class_2168 source, String path, String suffix, Function<class_2960, Model> function) throws CommandSyntaxException {
        var newPath = path.replace("." + suffix, "");
        var newResource = class_2960.method_60654(newPath);
        return spawnModel(source, () -> function.apply(newResource), newPath);
    }

    private static int spawnModel(class_2168 source, Supplier<Model> supplier, String path) throws CommandSyntaxException {
        class_3218 level = source.method_9225();
        class_243 pos = source.method_9222();
        class_241 rot = source.method_9210();

        try {
            Model model = supplier.get();
            ModelEntity entity = new ModelEntity(level, model);
            entity.method_66246(pos, rot.field_1342, rot.field_1343);

            level.method_8649(entity);
            source.method_9226(() -> class_2561.method_43470("Successfully spawned model!"), false);
        } catch (JsonParseException ex) {
            BIL.LOGGER.error("{} is not a valid model file!", path, ex);
            throw Utils.buildCommandException(ex.getMessage() + "\nCheck the server console for more information.");
        } catch (Throwable throwable) {
            throw Utils.buildCommandException("Failed to load model!\n" + throwable.getMessage());
        }

        return Command.SINGLE_SUCCESS;
    }

    private static ArgumentBuilder<class_2168, ?> modelCreator() {
        var builder = class_2170.method_9247("create");

        builder.then(class_2170.method_9244("model", StringArgumentType.greedyString())
                .executes(context -> spawnModel(
                        context.getSource(),
                        StringArgumentType.getString(context, "model")
                ))
        );

        return builder;
    }

    private static ArgumentBuilder<class_2168, ?> scaleManipulator() {
        var builder = class_2170.method_9247("scale");

        builder.then(class_2170.method_9244("scale", FloatArgumentType.floatArg(0.01f))
                .executes(context -> {
                    float scale = FloatArgumentType.getFloat(context, "scale");
                    return manipulateModels(
                            context.getSource(),
                            class_2186.method_9317(context, TARGETS),
                            holder -> holder.setScale(scale)
                    );
                })
        );

        return builder;
    }

    private static ArgumentBuilder<class_2168, ?> colorManipulator() {
        var builder = class_2170.method_9247("color");

        builder.then(class_2170.method_9244("color", StringArgumentType.word())
                .executes(context -> {
                    int color = convertHexCode(StringArgumentType.getString(context, "color"));
                    return manipulateModels(
                            context.getSource(),
                            class_2186.method_9317(context, TARGETS),
                            holder -> holder.setColor(color)
                    );
                })
        );

        return builder;
    }

    private static ArgumentBuilder<class_2168, ?> variantManipulator() {
        var builder = class_2170.method_9247("variant");

        builder.then(class_2170.method_9244("variant", StringArgumentType.word())
                .suggests(availableVariants())
                .executes(context -> {
                    String variant = StringArgumentType.getString(context, "variant");
                    return manipulateModels(
                            context.getSource(),
                            class_2186.method_9317(context, TARGETS),
                            holder -> {
                                VariantController controller = holder.getVariantController();
                                if (variant.equals("default")) {
                                    controller.setDefaultVariant();
                                } else {
                                    controller.setVariant(variant);
                                }
                            }
                    );
                })
        );

        return builder;
    }

    private static ArgumentBuilder<class_2168, ?> animationManipulator() {
        var builder = class_2170.method_9247("animation");

        builder.then(class_2170.method_9244(ANIMATION, StringArgumentType.word())
                .suggests(availableAnimations())
                .executes(context -> {
                    String animation = StringArgumentType.getString(context, ANIMATION);
                    return manipulateModels(
                            context.getSource(),
                            class_2186.method_9317(context, TARGETS),
                            (holder) -> holder.getAnimator().playAnimation(animation)
                    );
                })
                .then(class_2170.method_9247("play")
                        .executes(context -> {
                            String animation = StringArgumentType.getString(context, ANIMATION);
                            return manipulateModels(
                                    context.getSource(),
                                    class_2186.method_9317(context, TARGETS),
                                    (holder) -> holder.getAnimator().playAnimation(animation)
                            );
                        })
                        .then(class_2170.method_9244("priority", IntegerArgumentType.integer())
                                .executes(context -> {
                                    String animation = StringArgumentType.getString(context, ANIMATION);
                                    int priority = IntegerArgumentType.getInteger(context, "priority");
                                    return manipulateModels(
                                            context.getSource(),
                                            class_2186.method_9317(context, TARGETS),
                                            (holder) -> holder.getAnimator().playAnimation(animation, priority)
                                    );
                                })
                        )
                )
                .then(class_2170.method_9247("set-frame")
                        .then(class_2170.method_9244("frame", IntegerArgumentType.integer())
                                .executes(context -> {
                                    String animation = StringArgumentType.getString(context, ANIMATION);
                                    int frame = IntegerArgumentType.getInteger(context, "frame");
                                    return manipulateModels(
                                            context.getSource(),
                                            class_2186.method_9317(context, TARGETS),
                                            holder -> holder.getAnimator().setAnimationFrame(animation, frame)
                                    );
                                })
                        )
                )
                .then(class_2170.method_9247("pause")
                        .executes(context -> {
                            String animation = StringArgumentType.getString(context, ANIMATION);
                            return manipulateModels(
                                    context.getSource(),
                                    class_2186.method_9317(context, TARGETS),
                                    holder -> holder.getAnimator().pauseAnimation(animation)
                            );
                        })
                )
                .then(class_2170.method_9247("stop")
                        .executes(context -> {
                            String animation = StringArgumentType.getString(context, ANIMATION);
                            return manipulateModels(
                                    context.getSource(),
                                    class_2186.method_9317(context, TARGETS),
                                    holder -> holder.getAnimator().stopAnimation(animation)
                            );
                        })
                )
        );

        return builder;
    }

    private static SuggestionProvider<class_2168> availableAnimations() {
        return (ctx, builder) -> {
            forEachModel(ctx, model -> {
                for (String animation : model.animations().keySet()) {
                    builder.suggest(animation);
                }
            });
            return builder.buildFuture();
        };
    }

    private static SuggestionProvider<class_2168> availableVariants() {
        return (ctx, builder) -> {
            builder.suggest("default");
            forEachModel(ctx, model -> {
                for (Variant variant : model.variants().values()) {
                    builder.suggest(variant.name());
                }
            });
            return builder.buildFuture();
        };
    }

    private static void forEachModel(CommandContext<class_2168> ctx, Consumer<Model> consumer) throws CommandSyntaxException {
        // Make sure to only call this when we have the target context already.
        for (class_1297 entity : class_2186.method_9317(ctx, TARGETS)) {
            AnimatedEntityHolder holder = AnimatedEntity.getHolder(entity);
            if (holder != null) {
                consumer.accept(holder.getModel());
            }
        }
    }

    private static int convertHexCode(String hexCode) throws CommandSyntaxException {
        try {
            return HexFormat.fromHexDigits(hexCode);
        } catch (Throwable throwable) {
            throw Utils.buildCommandException("Invalid color: " + throwable.getMessage());
        }
    }
}

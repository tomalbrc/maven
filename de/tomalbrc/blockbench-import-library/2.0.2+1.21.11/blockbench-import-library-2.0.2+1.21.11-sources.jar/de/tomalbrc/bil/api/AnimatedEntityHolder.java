package de.tomalbrc.bil.api;

import eu.pb4.polymer.virtualentity.api.elements.DisplayElement;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2940;
import net.minecraft.class_4048;

@SuppressWarnings("unused")
public interface AnimatedEntityHolder extends AnimatedHolder {
    /**
     * Notifies the holder that the synchronized data has been updated.
     * <p>
     * Holder implementations can use this to update their element data.
     */
    void onSyncedDataUpdated(class_2940<?> key, Object value);

    /**
     * Notifies the holder that the dimensions of the parent entity have been updated.
     * <p>
     * Holder implementations can use this to update their element data.
     */
    void onDimensionsUpdated(class_4048 dimensions);

    /**
     * Returns an array of entity ids used for displaying the intermediate.
     */
    int[] getDisplayIds();

    /**
     * Returns the entity id of the vehicle of the display entities.
     */
    int getDisplayVehicleId();

    /**
     * Returns the entity id of the vehicle used for mounting mobs and players.
     */
    int getVehicleId();

    /**
     * Returns the entity id that should be used for leashing mobs.
     * <p>
     * If the entity id is not from a {@link class_1308} (clientside), the leash will not be rendered.
     */
    int getLeashedId();

    /**
     * Returns the entity id that should be used for handling entity events clientside.
     * <p>
     * Entity events are responsible certain entity particles, added by the client.
     * If for example the entity id is not from a {@link class_1309} on the client, death particles will not work.
     */
    int getEntityEventId();

    /**
     * Returns the entity id that should be used for handling critical hit particles.
     * <p>
     * If available, it is recommended to use the id of an element of approximately the same size as the intermediate.
     */
    int getCritParticleId();

    /**
     * Adds a display element to the holder.
     * This is needed to tell the holder to mount the display as a passenger on the display vehicle.
     */
    boolean addAdditionalDisplay(DisplayElement element);

    /**
     * Removes an additional display element from the holder.
     */
    boolean removeAdditionalDisplay(DisplayElement element);

    /**
     * Whether to modify the ride packet to inject the holders' additional display entities
     */
    default boolean modifyRidePacket() {
        return true;
    }
}

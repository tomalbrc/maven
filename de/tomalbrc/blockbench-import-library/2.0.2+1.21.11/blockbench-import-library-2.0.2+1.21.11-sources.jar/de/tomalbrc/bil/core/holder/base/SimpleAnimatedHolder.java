package de.tomalbrc.bil.core.holder.base;

import de.tomalbrc.bil.core.model.Model;
import net.minecraft.class_12096;
import net.minecraft.class_2168;
import net.minecraft.class_241;
import net.minecraft.class_2561;

public class SimpleAnimatedHolder extends AbstractAnimationHolder {
    public SimpleAnimatedHolder(Model model) {
        super(model);
    }

    @Override
    public class_2168 createCommandSourceStack() {
        String name = String.format("SimpleAnimatedHolder[%.1f, %.1f, %.1f]", this.getPos().field_1352, this.getPos().field_1351, this.getPos().field_1350);
        return new class_2168(
                this.getLevel().method_8503(),
                this.getPos(),
                class_241.field_1340,
                this.getLevel(),
                class_12096.field_63208,
                name,
                class_2561.method_43470(name),
                this.getLevel().method_8503(),
                null
        );
    }
}

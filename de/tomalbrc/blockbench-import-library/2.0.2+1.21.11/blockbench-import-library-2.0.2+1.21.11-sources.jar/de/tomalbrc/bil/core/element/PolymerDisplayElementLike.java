package de.tomalbrc.bil.core.element;

import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.tracker.DataTrackerLike;
import net.minecraft.class_4048;
import net.minecraft.class_8104;
import net.minecraft.class_8113;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("unused")
public interface PolymerDisplayElementLike extends PolymerGenericElementLike {
    @Nullable ElementHolder getHolder();
    DataTrackerLike getDataTracker();
    DataTrackerLike createDataTracker();
    int getEntityId();

    class_8113.class_8114 getBillboardMode();
    void setBillboardMode(class_8113.class_8114 billboardMode);
    @Nullable class_8104 getBrightness();
    void setBrightness(@Nullable class_8104 brightness);

    float getViewRange();
    void setViewRange(float viewRange);
    float getShadowRadius();
    void setShadowRadius(float shadowRadius);

    float getShadowStrength();

    void setShadowStrength(float shadowStrength);

    float getDisplayWidth();
    float getDisplayHeight();
    void setDisplayWidth(float width);
    void setDisplayHeight(float height);
    void setDisplaySize(float width, float height);
    void setDisplaySize(class_4048 dimensions);
    int getGlowColorOverride();
    void setGlowColorOverride(int glowColorOverride);
}

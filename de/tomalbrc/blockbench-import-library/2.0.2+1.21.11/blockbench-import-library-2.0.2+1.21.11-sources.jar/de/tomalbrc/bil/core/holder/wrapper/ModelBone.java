package de.tomalbrc.bil.core.holder.wrapper;

import de.tomalbrc.bil.core.element.PerPlayerItemDisplayElement;
import de.tomalbrc.bil.core.model.Node;
import de.tomalbrc.bil.core.model.Pose;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class ModelBone extends ItemBone {
    private final class_1799 item;

    protected ModelBone(PerPlayerItemDisplayElement element, Node node, Pose defaultPose) {
        super(element, node, defaultPose);
        this.item = element.getItem();
    }

    public static ModelBone of(PerPlayerItemDisplayElement element, @NotNull Node node, Pose defaultPose) {
        return new ModelBone(element, node, defaultPose);
    }

    public void updateModel(class_2960 model) {
        this.item.method_57379(class_9334.field_54199, model);

        if (!this.invisible) {
            this.setTrackedItem(this.item);
        }
    }
}

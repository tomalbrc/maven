package de.tomalbrc.bil.file.bbmodel;

import com.google.gson.annotations.SerializedName;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.joml.Vector3f;

import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_811;
import net.minecraft.class_8113;

@SuppressWarnings("unused")
public class BbElement {
    public String name;
    public boolean rescale;

    @SerializedName("light_emission")
    public int lightEmission = 0;

    public Vector3f from;
    public Vector3f to;
    public Boolean shade;
    public Vector3f rotation;

    public float inflate;
    public Vector3f origin;
    public Vector3f position; // used by locators
    public Object2ObjectOpenHashMap<String, BbFace> faces;
    public ElementType type;
    public UUID uuid;

    // ajblueprint...
    // Yes, camelCase in the json, this is intended
    class_2960 item;
    class_2960 block;
    String text;
    int lineWidth;
    class_811 itemDisplayContext = class_811.field_4315;
    class_8113.class_8123.class_8124 align;
    boolean shadow = false;
    double backgroundAlpha;
    String backgroundColor;

    public class_2960 getItem() {
        return item;
    }

    public class_2960 getBlock() {
        return block;
    }

    public String getText() {
        return text;
    }

    public int getLineWidth() {
        return lineWidth;
    }

    public class_811 getItemDisplayContext() {
        return itemDisplayContext;
    }

    public class_8113.class_8123.class_8124 getAlign() {
        return align;
    }

    public boolean isShadow() {
        return shadow;
    }

    public double getBackgroundAlpha() {
        return backgroundAlpha;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public enum ElementType {
        @SerializedName("cube")
        CUBE_MODEL,
        @SerializedName("locator")
        LOCATOR,
        @SerializedName("animated_java:vanilla_block_display")
        BLOCK_DISPLAY,
        @SerializedName("animated_java:vanilla_item_display")
        ITEM_DISPLAY,
        @SerializedName("animated_java:vanilla_text_display")
        TEXT_DISPLAY
    }
}

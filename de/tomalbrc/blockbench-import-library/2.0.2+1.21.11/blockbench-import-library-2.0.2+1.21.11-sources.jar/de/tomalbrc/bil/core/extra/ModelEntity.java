package de.tomalbrc.bil.core.extra;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.api.AnimatedEntityHolder;
import de.tomalbrc.bil.core.holder.entity.EntityHolder;
import de.tomalbrc.bil.core.holder.entity.simple.SimpleEntityHolder;
import de.tomalbrc.bil.core.holder.wrapper.DisplayWrapper;
import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.core.model.Pose;
import eu.pb4.polymer.virtualentity.api.attachment.EntityAttachment;
import eu.pb4.polymer.virtualentity.api.tracker.InteractionTrackedData;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import net.minecraft.class_11372;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_8150;

public class ModelEntity extends class_8150 implements AnimatedEntity {
    private final EntityHolder<?> holder;

    public ModelEntity(class_1937 level, Model model) {
        super(class_1299.field_42623, level);
        this.holder = new SimpleEntityHolder<>(this, model) {
            @Override
            public void updateElement(class_3222 serverPlayer, DisplayWrapper<?> display, @Nullable Pose pose) {
                display.element().setYaw(this.parent.method_36454());
                display.element().setPitch(this.parent.method_36455());
                super.updateElement(serverPlayer, display, pose);
            }

            @Override
            protected void updateCullingBox() {
                // Do nothing, we want to prevent culling.
            }
        };

        EntityAttachment.ofTicking(this.holder, this);
    }

    @Override
    public AnimatedEntityHolder getHolder() {
        return this.holder;
    }

    @Override
    public boolean method_5786(class_11372 valueOutput) {
        // Don't save this entity.
        return false;
    }

    @Override
    public class_1299<?> getPolymerEntityType(PacketContext context) {
        return class_1299.field_42623;
    }

    @Override
    public void modifyRawTrackedData(List<class_2945.class_7834<?>> data, class_3222 player, boolean initial) {
        data.add(class_2945.class_7834.method_46360(InteractionTrackedData.HEIGHT, 2f));
        data.add(class_2945.class_7834.method_46360(InteractionTrackedData.WIDTH, 2f));
    }
}

package de.tomalbrc.bil.api;

import eu.pb4.polymer.core.api.entity.PolymerEntity;
import eu.pb4.polymer.virtualentity.api.tracker.DisplayTrackedData;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2945;
import net.minecraft.class_3222;

public interface AnimatedEntity extends PolymerEntity {
    @Nullable
    static AnimatedEntityHolder getHolder(Object obj) {
        return obj instanceof AnimatedEntity animatedEntity ? animatedEntity.getHolder() : null;
    }

    AnimatedEntityHolder getHolder();

    default float getShadowRadius() {
        if (this instanceof class_1297 entity) {
            return entity.method_17681() * 0.6f;
        }
        return 0;
    }

    default int getTeleportDuration() {
        return 3;
    }

    @Override
    default class_1299<?> getPolymerEntityType(PacketContext context) {
        return class_1299.field_42460;
    }

    @Override
    default void modifyRawTrackedData(List<class_2945.class_7834<?>> data, class_3222 player, boolean initial) {
        if (this instanceof class_1297 entity) {
            data.add(class_2945.class_7834.method_46360(DisplayTrackedData.WIDTH, entity.method_17681()));
            data.add(class_2945.class_7834.method_46360(DisplayTrackedData.HEIGHT, entity.method_17682()));
        }

        data.add(class_2945.class_7834.method_46360(DisplayTrackedData.SHADOW_RADIUS, this.getShadowRadius()));
        data.add(class_2945.class_7834.method_46360(DisplayTrackedData.TELEPORTATION_DURATION, Math.max(0, this.getTeleportDuration())));

        data.add(class_2945.class_7834.method_46360(EntityTrackedData.SILENT, true));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.NO_GRAVITY, true));
        data.add(class_2945.class_7834.method_46360(EntityTrackedData.NAME_VISIBLE, false));
    }
}

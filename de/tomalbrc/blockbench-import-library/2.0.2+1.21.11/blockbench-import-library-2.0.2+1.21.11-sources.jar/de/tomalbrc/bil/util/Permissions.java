package de.tomalbrc.bil.util;

import java.util.function.Predicate;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public class Permissions {
    public static boolean check(class_3222 player, String node, int defaultCheck) {
        return me.lucko.fabric.api.permissions.v0.Permissions.check(player, node, defaultCheck);
    }

    public static Predicate<class_2168> require(String node, int fallbackLevel) {
        return me.lucko.fabric.api.permissions.v0.Permissions.require(node, fallbackLevel);
    }
}

package de.tomalbrc.bil.json;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Type;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public record RegistryDeserializer<T>(class_2378<@NotNull T> registry) implements JsonDeserializer<T> {
    @Override
    public T deserialize(JsonElement element, Type type, JsonDeserializationContext context) throws JsonParseException {
        return this.registry.method_10223(class_2960.method_60654(element.getAsString())).orElseThrow().comp_349();
    }
}

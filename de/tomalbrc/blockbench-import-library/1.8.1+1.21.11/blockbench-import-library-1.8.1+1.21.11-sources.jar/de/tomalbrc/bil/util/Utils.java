package de.tomalbrc.bil.util;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import de.tomalbrc.bil.mixin.accessor.ServerCommonPacketListenerImplAccessor;
import eu.pb4.polymer.core.impl.networking.PacketPatcher;
import eu.pb4.polymer.networking.api.util.ServerDynamicPacket;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import eu.pb4.polymer.virtualentity.api.tracker.InteractionTrackedData;
import java.util.List;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2739;
import net.minecraft.class_2945;
import net.minecraft.class_3244;
import net.minecraft.class_3532;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_7648;
import net.minecraft.class_8609;

public class Utils {
    public static final class_3244[] EMPTY_CONNECTION_ARRAY = new class_3244[0];

    public static class_2535 getConnection(class_8609 networkHandler) {
        return ((ServerCommonPacketListenerImplAccessor) networkHandler).getConnection();
    }

    public static CommandSyntaxException buildCommandException(String message) {
        return new SimpleCommandExceptionType(class_2561.method_43470(message)).create();
    }

    public static int toSlimeSize(float size) {
        return class_3532.method_15375(size / 2.04F / 0.255F);
    }

    public static boolean getSharedFlag(byte value, int flag) {
        return (value & 1 << flag) != 0;
    }

    public static List<class_2596<? super class_2602>> updateClientInteraction(InteractionElement interaction, class_4048 dimensions) {
        return updateClientInteraction(interaction, dimensions, dimensions.comp_2186());
    }

    public static List<class_2596<? super class_2602>> updateClientInteraction(InteractionElement interaction, class_4048 dimensions, float height) {
        // Updates the dimensions and bounding box of the interaction on the client. Note that the interactions dimensions and bounding box are two different things.
        // - The bounding box is primarily used for detecting player attacks, interactions and rendering the hitbox.
        // - The dimensions are used for certain other properties, such as the passenger riding height or the fire animation.
        return List.of(
                // We update the POSE in this packet, which makes the client refresh the interactions dimensions.
                // We use this to move the passenger riding height of the interaction upwards.
                new class_2739(interaction.getEntityId(), List.of(
                        class_2945.class_7834.method_46360(InteractionTrackedData.HEIGHT, height),
                        class_2945.class_7834.method_46360(InteractionTrackedData.WIDTH, dimensions.comp_2185()),
                        class_2945.class_7834.method_46360(EntityTrackedData.POSE, class_4050.field_18076)
                )),
                // Afterward, we send another packet that only updates the bounding box height back to its original value, without updating its dimensions.
                // This lets us turn the bounding box back into the correct size whilst keeping the raised passenger riding height.
                new class_2739(interaction.getEntityId(), List.of(
                        class_2945.class_7834.method_46360(InteractionTrackedData.HEIGHT, dimensions.comp_2186())
                ))
        );
    }

    /**
     * Vanilla + Polymer copy of {@link class_8609#method_52391(class_2596, class_7648)} but without flushing the connection.
     * <p>
     * we will often have to send a ton of separate packet from a different thread.
     * Even though we always make sure to start and finish this process before player connection flushing gets resumed at the end of the game tick,
     * the normal send method will still flush the connection for every packet, causing a significant downgrade in network performance and ping.
     */
    public static void sendPacketNoFlush(class_8609 networkHandler, class_2596<? extends class_2602> packet) {
        class_2596<?> modifiedPacket = PacketPatcher.replace(networkHandler, packet);
        if (modifiedPacket instanceof ServerDynamicPacket || PacketPatcher.prevent(networkHandler, modifiedPacket)) {
            return;
        }

        try {
            Utils.getConnection(networkHandler).method_52906(modifiedPacket, null, false);
        } catch (Throwable throwable) {
            class_128 report = class_128.method_560(throwable, "Sending packet");
            class_129 category = report.method_562("Packet being sent");
            category.method_577("Packet class", () -> modifiedPacket.getClass().getCanonicalName());
            throw new class_148(report);
        }

        PacketPatcher.sendExtra(networkHandler, packet);
    }
}

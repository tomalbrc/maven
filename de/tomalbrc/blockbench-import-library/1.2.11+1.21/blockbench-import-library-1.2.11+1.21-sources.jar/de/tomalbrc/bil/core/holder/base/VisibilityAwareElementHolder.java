package de.tomalbrc.bil.core.holder.base;

import de.tomalbrc.bil.BIL;
import de.tomalbrc.bil.util.Utils;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VisibilityAwareElementHolder extends ElementHolder {
    protected static final double FOV = 80 * Mth.DEG_TO_RAD;
    protected static final double MAX_DISTANCE_SQR = Mth.square(6 * 16); // no packet update range
    protected static final double MIN_DISTANCE_SQR = Mth.square(2 * 16); // always all packets here
    protected static final double MAX_VISIBILITY_DISTANCE_SQR = Mth.square(6 * 16);

    protected final List<Packet<? super ClientGamePacketListener>> stagedPackets = new ObjectArrayList<>();
    protected final Set<ServerGamePacketListenerImpl> trackedPlayers = new HashSet<>();

    @Override
    public void sendPacket(Packet<? extends ClientGamePacketListener> packet) {
        this.stagedPackets.add((Packet<? super ClientGamePacketListener>) packet);
    }

    @Override
    public void tick() {
        super.tick();

        for (ServerGamePacketListenerImpl player : trackedPlayers) {
            boolean shouldSee = isInRangeAndFov(player);
            boolean isWatching = this.getWatchingPlayers().contains(player);

            if (shouldSee && !isWatching) {
                this.startWatching(player);
            } else if (!shouldSee && isWatching) {
                super.stopWatching(player);
            }
        }
    }

    @Override
    public boolean startWatching(ServerGamePacketListenerImpl player) {
        trackedPlayers.add(player);
        if (!isInRangeAndFov(player)) {
            return false;
        }
        return super.startWatching(player);
    }

    @Override
    public boolean stopWatching(ServerGamePacketListenerImpl player) {
        boolean result = super.stopWatching(player);
        if (result) {
            trackedPlayers.remove(player);
        }
        return result;
    }


    protected boolean isInRangeAndFov(ServerGamePacketListenerImpl player) {
        Vec3 holderPos = this.getPos();
        double distSqr = player.player.distanceToSqr(holderPos);
        if (distSqr > MAX_VISIBILITY_DISTANCE_SQR)
            return false;

        return isInFov(player);
    }

    protected double getFov() {
        return FOV;
    }

    protected double getMaxAnimationDistance() {
        return MAX_DISTANCE_SQR;
    }

    protected double getMinAnimationDistance() {
        return MIN_DISTANCE_SQR;
    }

    protected boolean isInFov(ServerGamePacketListenerImpl player) {
        Vec3 holderPos = this.getPos();
        double dist = player.player.distanceToSqr(holderPos.x, player.player.getY(), holderPos.z);
        boolean inVRange = Math.abs(player.player.getY() - holderPos.y) > Math.sqrt(this.getMaxAnimationDistance());
        if (dist > this.getMaxAnimationDistance() && !inVRange)
            return false;
        else if (dist <= this.getMinAnimationDistance() || inVRange)
            return true;

        Vec3 directionFacing = player.player.getViewVector(1).normalize();
        Vec3 directionToTarget = holderPos.subtract(player.player.position()).normalize();

        Vec3 horizontalFacing = new Vec3(directionFacing.x, 0, directionFacing.z).normalize();
        Vec3 horizontalToTarget = new Vec3(directionToTarget.x, 0, directionToTarget.z).normalize();
        double horizontalAngle = Math.acos(horizontalFacing.dot(horizontalToTarget));
        if (horizontalAngle > this.getFov())
            return false;

        double pitchFacing = Math.asin(directionFacing.y);
        double pitchTarget = Math.asin(directionToTarget.y);
        double verticalAngle = Math.abs(pitchFacing - pitchTarget);
        return verticalAngle <= this.getFov();
    }

    protected List<Packet<? super ClientGamePacketListener>> filterForPlayer(List<Packet<? super ClientGamePacketListener>> packetList, ServerGamePacketListenerImpl packetListener) {
        if (!isInFov(packetListener)) {
            List<Packet<? super ClientGamePacketListener>> filteredList = new ObjectArrayList<>(packetList.size());
            for (var packet : packetList) {
                if (!(packet instanceof ClientboundSetEntityDataPacket))
                    filteredList.add(packet);
            }
            return filteredList;
        }

        return packetList;
    }

    protected void flushPackets(ServerGamePacketListenerImpl[] watchingPlayers) {
        if (this.stagedPackets.isEmpty())
            return;
        for (var player : watchingPlayers) {
            if (player == null) continue;
            var playerPackets = filterForPlayer(this.stagedPackets, player);
            for (var packet : playerPackets) {
                sendPacketDirect(player, (Packet<? extends ClientGamePacketListener>) packet);
            }
        }
        this.stagedPackets.clear();
    }

    public void sendPacketDirect(ServerGamePacketListenerImpl player, Packet<? extends ClientGamePacketListener> packet) {
        if (player != null) {
            if (BIL.SERVER.isSameThread()) {
                player.send(packet);
            } else {
                Utils.sendPacketNoFlush(player, packet);
            }
        }
    }

    @Override
    public void destroy() {
        this.flushPackets(this.getWatchingPlayers().toArray(new ServerGamePacketListenerImpl[0]));
        super.destroy();
    }
}
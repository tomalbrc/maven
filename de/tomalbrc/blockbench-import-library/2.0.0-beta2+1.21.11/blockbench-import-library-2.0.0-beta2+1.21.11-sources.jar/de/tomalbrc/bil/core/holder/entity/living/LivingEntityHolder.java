package de.tomalbrc.bil.core.holder.entity.living;

import de.tomalbrc.bil.api.AnimatedEntity;
import de.tomalbrc.bil.core.element.CollisionElement;
import de.tomalbrc.bil.core.holder.entity.EntityHolder;
import de.tomalbrc.bil.core.holder.wrapper.DisplayWrapper;
import de.tomalbrc.bil.core.model.Model;
import de.tomalbrc.bil.core.model.Node;
import de.tomalbrc.bil.core.model.Pose;
import de.tomalbrc.bil.util.Constants;
import de.tomalbrc.bil.util.Utils;
import eu.pb4.polymer.virtualentity.api.elements.InteractionElement;
import eu.pb4.polymer.virtualentity.api.tracker.EntityTrackedData;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_2394;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2740;
import net.minecraft.class_2752;
import net.minecraft.class_2781;
import net.minecraft.class_2783;
import net.minecraft.class_2940;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_4048;
import net.minecraft.class_5134;
import net.minecraft.class_8042;
import net.minecraft.class_9817;
import net.minecraft.network.protocol.game.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class LivingEntityHolder<T extends class_1309 & AnimatedEntity> extends EntityHolder<T> {
    protected final InteractionElement hitboxInteraction;
    protected final CollisionElement collisionElement;
    protected float deathAngle;
    protected float entityScale = 1F;

    public LivingEntityHolder(T parent, Model model) {
        super(parent, model);

        this.hitboxInteraction = InteractionElement.redirect(parent);
        this.hitboxInteraction.setSendPositionUpdates(false);
        this.addElement(this.hitboxInteraction);

        this.collisionElement = CollisionElement.createWithRedirect(parent);
        this.collisionElement.setSendPositionUpdates(false);
        this.addElement(this.collisionElement);
    }

    @Override
    protected void onAsyncTick() {
        if (this.parent.field_6213 > 0) {
            this.deathAngle = Math.min((float) Math.sqrt((this.parent.field_6213) / 20.0F * 1.6F), 1.f);
        }

        super.onAsyncTick();
    }

    @Override
    public void updateElement(class_3222 serverPlayer, DisplayWrapper<?> displayWrapper, @Nullable Pose pose) {
        displayWrapper.element().setYaw(this.parent.field_6283);
        super.updateElement(serverPlayer, displayWrapper, pose);
    }

    @Override
    protected void applyPose(class_3222 serverPlayer, Pose pose, DisplayWrapper<?> displayWrapper) {
        Vector3f translation = pose.translation();
        boolean isHead = displayWrapper.node().tag() == Node.NodeTag.HEAD;
        boolean isDead = this.parent.field_6213 > 0;

        if (isHead || isDead) {
            Quaternionf bodyRotation = new Quaternionf();
            if (isDead) {
                bodyRotation.rotateZ(-this.deathAngle * class_3532.field_29845);
                translation.rotate(bodyRotation);
            }

            if (isHead) {
                bodyRotation.rotateY(class_3532.field_29847 * -class_3532.method_17821(0.5f, this.parent.field_6259 - this.parent.field_6220, this.parent.field_6241 - this.parent.field_6283));
                bodyRotation.rotateX(class_3532.field_29847 * class_3532.method_16439(0.5f, this.parent.field_6004, this.parent.method_36455()));
            }

            displayWrapper.element().setLeftRotation(serverPlayer, bodyRotation.mul(pose.readOnlyLeftRotation()));
        } else {
            displayWrapper.element().setLeftRotation(serverPlayer, pose.readOnlyLeftRotation());
        }

        if (this.entityScale != 1F) {
            translation.mul(this.entityScale);
            displayWrapper.element().setScale(serverPlayer, pose.scale().mul(this.entityScale));
        } else {
            displayWrapper.element().setScale(serverPlayer, pose.readOnlyScale());
        }

        displayWrapper.element().setTranslation(serverPlayer, translation.sub(0, this.dimensions.comp_2186() - 0.01f, 0));
        displayWrapper.element().setRightRotation(serverPlayer, pose.readOnlyRightRotation());

        displayWrapper.element().startInterpolationIfDirty(serverPlayer);
    }

    @Override
    protected void startWatchingExtraPackets(class_3244 player, Consumer<class_2596<@NotNull class_2602>> consumer) {
        super.startWatchingExtraPackets(player, consumer);

        for (var packet : Utils.updateClientInteraction(this.hitboxInteraction, this.dimensions)) {
            // noinspection unchecked
            consumer.accept((class_2596<@NotNull class_2602>) packet);
        }

        if (this.parent.method_6094()) {
            consumer.accept(new class_2783(this.collisionElement.getEntityId(), new class_1293(class_1294.field_5923, -1, 0, false, false), false));
        }

        if (this.parent instanceof class_9817 leashable && leashable.method_60955() != null && leashable.method_60952() != null) {
            consumer.accept(new class_2740(this.parent, leashable.method_60952()));
        }

        consumer.accept(new class_2752(this.parent));
    }

    @Override
    protected void addDirectPassengers(IntList passengers) {
        super.addDirectPassengers(passengers);
        passengers.add(this.hitboxInteraction.getEntityId());
        passengers.add(this.collisionElement.getEntityId());
    }

    @Override
    public int getDisplayVehicleId() {
        return this.hitboxInteraction.getEntityId();
    }

    @Override
    public int getVehicleId() {
        return this.hitboxInteraction.getEntityId();
    }

    @Override
    public int getCritParticleId() {
        return this.hitboxInteraction.getEntityId();
    }

    @Override
    public int getLeashedId() {
        return this.collisionElement.getEntityId();
    }

    @Override
    public int getEntityEventId() {
        return this.collisionElement.getEntityId();
    }

    @Override
    protected void updateCullingBox() {
        float scale = this.getScale();
        float width = scale * (this.dimensions.comp_2185() * 2);
        float height = -this.dimensions.comp_2186() - 1;

        for (int i = 0; i < this.bones.length; i++) {
            this.bones[i].element().setDisplaySize(width, height);
        }
    }

    @Override
    public void onDimensionsUpdated(class_4048 dimensions) {
        this.updateEntityScale(this.scale);
        super.onDimensionsUpdated(dimensions);

        var size = Utils.toSlimeSize(Math.min(dimensions.comp_2185(), dimensions.comp_2186()));
        if (size <= 0) {
            var attributeInstance = new class_1324(class_5134.field_47760, (instance) -> {});
            attributeInstance.method_6192(0.01);
            var attributesPacket = new class_2781(this.collisionElement.getEntityId(), List.of(attributeInstance));
            this.sendPacket(attributesPacket);
            size = 1;
        }

        this.collisionElement.setSize(size);
        this.sendPacket(new class_8042(Utils.updateClientInteraction(this.hitboxInteraction, dimensions)));
    }

    @Override
    public void onSyncedDataUpdated(class_2940<?> key, Object object) {
        super.onSyncedDataUpdated(key, object);
        if (key.equals(Constants.DATA_EFFECT_PARTICLES)) {
            // noinspection unchecked
            this.collisionElement.getDataTracker().set(Constants.DATA_EFFECT_PARTICLES, (List<class_2394>) object);
        }

        if (key.equals(EntityTrackedData.NAME_VISIBLE)) {
            this.hitboxInteraction.setCustomNameVisible((boolean) object);
        }

        if (key.equals(EntityTrackedData.CUSTOM_NAME)) {
            // noinspection unchecked
            this.hitboxInteraction.getDataTracker().set(EntityTrackedData.CUSTOM_NAME, (Optional<class_2561>) object);
        }
    }

    @Override
    protected void updateOnFire(boolean displayFire) {
        this.hitboxInteraction.setOnFire(displayFire);
        super.updateOnFire(displayFire);
    }

    @Override
    protected void updateInvisibility(boolean isInvisible) {
        this.hitboxInteraction.setInvisible(isInvisible);
        super.updateInvisibility(isInvisible);
    }

    @Override
    public float getScale() {
        return this.entityScale;
    }

    @Override
    public void setScale(float scale) {
        this.updateEntityScale(scale);
        super.setScale(scale);
    }

    protected void updateEntityScale(float scalar) {
        this.entityScale = this.parent.method_55693() * scalar;
    }

    @Override
    public class_3419 getSoundSource() {
        return class_3419.field_15254;
    }
}

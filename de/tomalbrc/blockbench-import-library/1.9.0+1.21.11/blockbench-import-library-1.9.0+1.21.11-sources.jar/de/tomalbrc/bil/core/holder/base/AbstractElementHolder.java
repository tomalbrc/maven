package de.tomalbrc.bil.core.holder.base;

import de.tomalbrc.bil.util.IChunkMap;
import de.tomalbrc.bil.util.Utils;
import eu.pb4.polymer.virtualentity.api.ElementHolder;
import eu.pb4.polymer.virtualentity.api.attachment.HolderAttachment;
import eu.pb4.polymer.virtualentity.api.elements.VirtualElement;
import net.minecraft.class_3218;
import net.minecraft.class_3244;
import org.jetbrains.annotations.Nullable;

/**
 * Base class for all holder that handles Polymer's ElementHolder specific logic.
 * <p>
 * This class mainly exists to split off ElementHolder logic from the element logic.
 */
public abstract class AbstractElementHolder extends ElementHolder {
    protected class_3244[] watchingPlayers;
    protected boolean isDataLoaded;

    @Deprecated(forRemoval = true)
    protected AbstractElementHolder(class_3218 unused) {
        this();
    }

    protected AbstractElementHolder() {
        super();
        this.watchingPlayers = Utils.EMPTY_CONNECTION_ARRAY;
    }

    abstract protected void onAsyncTick();

    abstract protected void onDataLoaded();

    abstract protected boolean shouldSkipTick();

    @Override
    public boolean startWatching(class_3244 player) {
        if (!this.isDataLoaded) {
            this.isDataLoaded = true;
            this.onDataLoaded();
        }

        var result = super.startWatching(player);
        this.watchingPlayers = this.getWatchingPlayers().toArray(Utils.EMPTY_CONNECTION_ARRAY);
        return result;
    }

    @Override
    public boolean stopWatching(class_3244 player) {
        boolean result = super.stopWatching(player);
        this.watchingPlayers = this.getWatchingPlayers().toArray(Utils.EMPTY_CONNECTION_ARRAY);
        return result;
    }

    @Override
    public final void tick() {
        if (this.getAttachment() == null || this.shouldSkipTick()) {
            return;
        }

        this.onTick();

        this.updatePosition();

        // Schedule an async tick for this holder.
        IChunkMap.scheduleAsyncTick(this);
    }

    public final void asyncTick() {
        this.onAsyncTick();

        for (VirtualElement element : this.getElements()) {
            element.tick();
        }
    }

    public @Nullable class_3218 getLevel() {
        return this.getAttachment() != null ? this.getAttachment().getWorld() : null;
    }
}

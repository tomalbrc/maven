package de.tomalbrc.bil.core.element;

import de.tomalbrc.bil.mixin.accessor.SimpleDataTrackerAccessor;
import de.tomalbrc.bil.util.Utils;
import eu.pb4.polymer.virtualentity.api.tracker.DataTrackerLike;
import eu.pb4.polymer.virtualentity.api.tracker.DisplayTrackedData;
import eu.pb4.polymer.virtualentity.api.tracker.SimpleDataTracker;
import org.apache.commons.lang3.tuple.Triple;
import org.joml.*;

import java.util.List;
import java.util.Map;
import net.minecraft.class_243;
import net.minecraft.class_2739;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_4590;
import net.minecraft.class_7837;

@SuppressWarnings("unused")
public interface PerPlayerTransformableElement extends PolymerDisplayElementLike {
    Map<class_3222, Data> playerDataTrackers();

    default void addDataTracker(class_3222 serverPlayer) {
        playerDataTrackers().get(serverPlayer).setDataTracker(copyEntries((SimpleDataTracker) getDataTracker(), (SimpleDataTracker) createDataTracker()));
    }

    default void resetDataTracker(class_3222 serverPlayer) {
        var map = this.playerDataTrackers().get(serverPlayer);
        if (map != null)
            map.setDataTracker(null);
    }

    default DataTrackerLike dataTrackerOrDefault(class_3222 serverPlayer) {
        if (serverPlayer == null) {
            return getDataTracker();
        }

        var playerData = this.playerDataTrackers().get(serverPlayer);
        if (playerData == null || playerData.getDataTracker() == null) {
            return getDataTracker();
        }
        return playerData.getDataTracker();
    }

    default void setTransformation(class_3222 serverPlayer, class_4590 transformation) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.TRANSLATION, transformation.method_35865());
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.LEFT_ROTATION, transformation.method_22937());
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.SCALE, transformation.method_35866());
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.RIGHT_ROTATION, transformation.method_35867());
    }

    default void setTransformation(class_3222 serverPlayer, Matrix4f matrix) {
        float f = 1.0F / matrix.m33();
        Triple<Quaternionf, Vector3f, Quaternionf> triple = class_7837.method_46412((new Matrix3f(matrix)).scale(f));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.TRANSLATION, matrix.getTranslation(new Vector3f()));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.LEFT_ROTATION, new Quaternionf(triple.getLeft()));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.SCALE, new Vector3f(triple.getMiddle()));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.RIGHT_ROTATION, new Quaternionf(triple.getRight()));
    }

    default void setTransformation(class_3222 serverPlayer, Matrix4x3f matrix) {
        Triple<Quaternionf, Vector3f, Quaternionf> triple = class_7837.method_46412((new Matrix3f()).set(matrix));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.TRANSLATION, matrix.getTranslation(new Vector3f()));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.LEFT_ROTATION, new Quaternionf(triple.getLeft()));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.SCALE, new Vector3f(triple.getMiddle()));
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.RIGHT_ROTATION, new Quaternionf(triple.getRight()));
    }

    default boolean isTransformationDirty(class_3222 serverPlayer) {
        var dataTracker = dataTrackerOrDefault(serverPlayer);
        return dataTracker.isDirty(DisplayTrackedData.TRANSLATION) || dataTracker.isDirty(DisplayTrackedData.LEFT_ROTATION) || dataTracker.isDirty(DisplayTrackedData.SCALE) || dataTracker.isDirty(DisplayTrackedData.RIGHT_ROTATION);
    }

    default void setTranslation(class_3222 serverPlayer, Vector3fc vector3f) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.TRANSLATION, new Vector3f(vector3f));
    }

    default Vector3fc getTranslation(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.TRANSLATION);
    }

    default void setScale(class_3222 serverPlayer, Vector3fc vector3f) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.SCALE, new Vector3f(vector3f));
    }

    default Vector3fc getScale(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.SCALE);
    }

    default void setLeftRotation(class_3222 serverPlayer, Quaternionfc quaternion) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.LEFT_ROTATION, new Quaternionf(quaternion));
    }

    default Quaternionfc getLeftRotation(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.LEFT_ROTATION);
    }

    default void setRightRotation(class_3222 serverPlayer, Quaternionfc quaternion) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.RIGHT_ROTATION, new Quaternionf(quaternion));
    }

    default Quaternionfc getRightRotation(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.RIGHT_ROTATION);
    }

    default Integer getInterpolationDuration(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.INTERPOLATION_DURATION);
    }

    default void setInterpolationDuration(class_3222 serverPlayer, int interpolationDuration) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.INTERPOLATION_DURATION, interpolationDuration);
    }

    default Integer getTeleportDuration(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.TELEPORTATION_DURATION);
    }

    default void setTeleportDuration(class_3222 serverPlayer, int interpolationDuration) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.TELEPORTATION_DURATION, interpolationDuration);
    }

    default Integer getStartInterpolation(class_3222 serverPlayer) {
        return this.dataTrackerOrDefault(serverPlayer).get(DisplayTrackedData.START_INTERPOLATION);
    }

    default void startInterpolation(class_3222 serverPlayer) {
        this.dataTrackerOrDefault(serverPlayer).setDirty(DisplayTrackedData.START_INTERPOLATION, true);
    }

    default void setStartInterpolation(class_3222 serverPlayer, int startInterpolation) {
        this.dataTrackerOrDefault(serverPlayer).set(DisplayTrackedData.START_INTERPOLATION, startInterpolation, true);
    }

    default void startInterpolationIfDirty(class_3222 serverPlayer) {
        if (this.isTransformationDirty(serverPlayer)) {
            this.startInterpolation(serverPlayer);
        }
    }

    default void sendTrackerIfDirty(class_3244 serverPlayer, List<class_2945.class_7834<?>> list) {
        if (list != null && serverPlayer != null) {
            serverPlayer.method_14364(new class_2739(getEntityId(), list));
        }
    }

    default void sendTrackerUpdatesPerPlayer() {
        var holder = getHolder();
        if (holder == null)
            return;

        var defaultDirty = this.getDataTracker().getDirtyEntries();
        var arr = holder.getWatchingPlayers().toArray(Utils.EMPTY_CONNECTION_ARRAY);
        for (class_3244 watchingPlayer : arr) {
            if (watchingPlayer != null) {
                var data = this.playerDataTrackers().get(watchingPlayer.field_14140);
                if (data != null && data.dataTracker != null) {
                    sendTrackerIfDirty(watchingPlayer, data.dataTracker.getDirtyEntries());
                } else {
                    sendTrackerIfDirty(watchingPlayer, defaultDirty);
                }
            }
        }
    }

    class Data {
        SimpleDataTracker dataTracker;
        float yRot;
        float xRot;
        class_243 pos;

        public Data() {}

        public Data(float yRot, float xRot, class_243 pos) {
            this.dataTracker = null;
            this.yRot = yRot;
            this.xRot = xRot;
            this.pos = pos;
        }


        public class_243 getPos() {
            return pos;
        }

        public float getxRot() {
            return xRot;
        }

        public float getyRot() {
            return yRot;
        }

        public SimpleDataTracker getDataTracker() {
            return dataTracker;
        }

        public class_243 pos() {
            return pos;
        }

        public void setDataTracker(SimpleDataTracker dataTracker) {
            this.dataTracker = dataTracker;
        }

        public void setYaw(float yRot) {
            this.yRot = yRot;
        }

        public void setPitch(float xRot) {
            this.xRot = xRot;
        }

        public void setPos(class_243 pos) {
            this.pos = pos;
        }
    }

    static SimpleDataTracker copyEntries(SimpleDataTracker from, SimpleDataTracker to) {
        for (SimpleDataTracker.Entry entry : ((SimpleDataTrackerAccessor)from).getEntries()) {
            if (!entry.isUnchanged())
                to.set(entry.getData(), entry.get());
        }
        return to;
    }
}

package de.tomalbrc.bil.json;

import com.google.gson.GsonBuilder;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.joml.Matrix4f;
import org.joml.Vector2i;
import org.joml.Vector3f;

import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5699;
import net.minecraft.class_7923;

public class JSON {
    public static final Codec<Vector2i> VECTOR2I = Codec.either(
                    Codec.INT.listOf()
                            .comapFlatMap(l -> class_156.method_33141(l, 2).map(x -> new Vector2i(x.get(0), x.get(1))),
                                    v -> List.of(v.x(), v.y())),
                    RecordCodecBuilder.<Vector2i>create(i -> i.group(
                            Codec.INT.fieldOf("width").forGetter(Vector2i::x),
                            Codec.INT.fieldOf("height").forGetter(Vector2i::y)
                    ).apply(i, Vector2i::new))
            )
            .xmap(
                    e -> e.map(Function.identity(), Function.identity()),
                    Either::left
            );

    public static final GsonBuilder GENERIC_BUILDER = new GsonBuilder()
            // Reference equality
            .registerTypeAdapter(UUID.class, new CachedUuidDeserializer())
            // Custom deserializers
            .registerTypeAdapter(Matrix4f.class, new SimpleCodecDeserializer<>(class_5699.field_42268))
            .registerTypeAdapter(Vector3f.class, new SimpleCodecDeserializer<>(class_5699.field_40723))
            .registerTypeAdapter(Vector2i.class, new SimpleCodecDeserializer<>(VECTOR2I))
            .registerTypeAdapter(class_2960.class, new SimpleCodecDeserializer<>(class_2960.field_25139))
            .registerTypeAdapter(class_1792.class, new RegistryDeserializer<>(class_7923.field_41178))
            .registerTypeAdapter(class_3414.class, new RegistryDeserializer<>(class_7923.field_41172));
}

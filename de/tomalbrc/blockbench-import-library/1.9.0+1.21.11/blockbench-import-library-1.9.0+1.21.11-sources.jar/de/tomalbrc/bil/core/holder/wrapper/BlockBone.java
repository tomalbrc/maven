package de.tomalbrc.bil.core.holder.wrapper;

import de.tomalbrc.bil.core.element.PerPlayerBlockDisplayElement;
import de.tomalbrc.bil.core.model.Node;
import de.tomalbrc.bil.core.model.Pose;
import eu.pb4.polymer.virtualentity.api.tracker.DisplayTrackedData;
import org.jetbrains.annotations.NotNull;

import java.util.EnumSet;
import net.minecraft.class_2246;
import net.minecraft.class_2680;

public class BlockBone extends Bone<PerPlayerBlockDisplayElement> {
    private class_2680 blockState;
    private boolean invisible;

    protected BlockBone(PerPlayerBlockDisplayElement element, Node node, Pose defaultPose, BoneTag tag) {
        super(element, node, defaultPose, tag);
        this.blockState = element.getBlockState();
    }

    public static BlockBone of(PerPlayerBlockDisplayElement element, Node node, Pose defaultPose, BoneTag tag) {
        return new BlockBone(element, node, defaultPose, tag);
    }

    public static BlockBone of(PerPlayerBlockDisplayElement element, @NotNull Node node, Pose defaultPose) {
        Node current = node;
        boolean head = false;
        while (current != null) {
            if (current.headTag()) {
                head = true;
                break;
            }
            current = current.parent();
        }

        return new BlockBone(element, node, defaultPose, head ? BoneTag.HEAD : BoneTag.NONE);
    }

    public void setInvisible(boolean invisible) {
        if (this.invisible == invisible) {
            return;
        }

        this.invisible = invisible;
        if (invisible) {
            this.setTrackedBlock(class_2246.field_10124.method_9564());
        } else {
            this.setTrackedBlock(this.blockState);
        }
    }

    public void updateBlockState(class_2680 model) {
        this.blockState = model;

        if (!this.invisible) {
            this.setTrackedBlock(this.blockState);
        }
    }

    private void setTrackedBlock(class_2680 block) {
        this.element().getDataTracker().set(DisplayTrackedData.Block.BLOCK_STATE, block, true);
    }
}

package de.tomalbrc.polymersquasher.impl;

import de.tomalbrc.polymersquasher.PolymerSquasher;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

public class Util {
    public static final Path PACK = FabricLoader.getInstance().getGameDir().resolve("polymer/pack");
    public static final Path MIN_FILE = FabricLoader.getInstance().getGameDir().resolve("polymer/resource_pack.min.zip");

    public static boolean runPackSquash(Path outputPath) {
        try {
            PolymerSquasher.LOGGER.info("Running packsquash... This might take a while!");
            PackSquashRunner.run(outputPath, FabricLoader.getInstance().getGameDir().resolve(ModConfig.getInstance().packsquash), FabricLoader.getInstance().getGameDir().resolve(ModConfig.getInstance().packsquashConfig));
        } catch (IOException | InterruptedException e) {
            PolymerSquasher.LOGGER.warn("PackSquash failed", e);
            e.printStackTrace();
            return false;
        }

        return true;
    }

    /**
     * Returns true if changes to the rp were made
     */
    public static boolean writeToDirectory(Map<String, byte[]> fileMap, List<BiFunction<String, byte[], byte[]>> converters) {
        boolean dirty = false;
        try {
            for (Map.Entry<String, byte[]> entry : fileMap.entrySet()) {
                String relativePath = entry.getKey();
                byte[] data = entry.getValue();

                if (relativePath.isBlank()) {
                    var s = new String(data);
                    PolymerSquasher.LOGGER.info("Found empty file path! {}", s);
                    continue;
                }

                Path fullPath = PACK.resolve(relativePath);
                if (relativePath.endsWith("/")) {
                    PolymerSquasher.LOGGER.info("This should not happen!");
                    Files.createDirectories(fullPath);
                } else {
                    Files.createDirectories(fullPath.getParent());

                    if (data != null) {
                        for (var conv : converters) {
                            data = conv.apply(relativePath, data);
                            if (data == null) break;
                        }

                        if (fullPath.toFile().exists()) {
                            var e = FileHashes.addExists(relativePath, data);
                            if (e)
                                continue;
                        }

                        if (data != null) {
                            Files.write(fullPath, data);
                            dirty = true;
                        }
                    }
                }
            }
        } catch (IOException e) {
            PolymerSquasher.LOGGER.warn("Failed to write to directory!", e);
            e.printStackTrace();
            return false;
        }

        return dirty;
    }
}

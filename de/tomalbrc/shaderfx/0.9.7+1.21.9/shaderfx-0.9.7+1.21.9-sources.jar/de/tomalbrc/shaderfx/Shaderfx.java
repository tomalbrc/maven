package de.tomalbrc.shaderfx;

import com.google.common.collect.ImmutableList;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import de.tomalbrc.shaderfx.api.FileUtil;
import de.tomalbrc.shaderfx.api.ShaderEffect;
import de.tomalbrc.shaderfx.api.ShaderEffects;
import de.tomalbrc.shaderfx.api.ShaderUtil;
import eu.pb4.polymer.resourcepack.api.PackResource;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.resourcepack.extras.api.format.font.BitmapProvider;
import eu.pb4.polymer.resourcepack.extras.api.format.font.FontAsset;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.kyori.adventure.platform.modcommon.MinecraftServerAudiences;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.minecraft.class_11199;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.class_8042;
import org.jetbrains.annotations.NotNull;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Shaderfx implements ModInitializer {
    public static final String MODID = "shaderfx";
    public static boolean ADD_LOCAL = false;

    public static boolean convertAnimoji = true;
    private static boolean addedAssets = false;

    public static void enableAnimojiConversion() {
        convertAnimoji = true;
    }

    public static void enableAssets() {
        if (addedAssets)
            return;

        addedAssets = true;

        PolymerResourcePackUtils.addModAssets(MODID);

        PolymerResourcePackUtils.RESOURCE_PACK_CREATION_EVENT.register(builder -> {
            builder.addResourceConverter((path, resource) -> {
                if (convertAnimoji & path.matches(".*/textures/font/.*_animoji[0-9]*\\.png")) {
                    try {
                        Pattern p = Pattern.compile("_animoji([0-9]*)\\.png$");
                        Matcher m = p.matcher(path);
                        int fps = 5;
                        if (m.find() && !m.group(1).isBlank()) {
                            fps = Integer.parseInt(m.group(1));
                        }

                        BufferedImage image = ImageIO.read(new ByteArrayInputStream(resource.readAllBytes()));
                        image = ShaderUtil.addAnimatedEmojiMarker(image, fps);
                        var out = new ByteArrayOutputStream();
                        ImageIO.write(image, "PNG", out);
                        return PackResource.of(out.toByteArray());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                } else if (path.matches("assets/shaderfx/textures/font/transition-.*\\.png")) {
                    try {
                        BufferedImage image = ShaderUtil.tintEdges(ImageIO.read(new ByteArrayInputStream(resource.readAllBytes())), ShaderEffects.IMAGE_TRANSITION.asFullscreenColor());
                        var out = new ByteArrayOutputStream();
                        ImageIO.write(image, "PNG", out);
                        return PackResource.of(out.toByteArray());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                return resource;
            });

            String fragmentShader = FileUtil.loadCore("rendertype_text.fsh");
            StringBuilder importList = new StringBuilder();
            for (class_2960 location : ShaderEffects.IMPORTS) {
                importList.append(String.format("#moj_import <%s>\n", location));
            }
            fragmentShader = fragmentShader.replace("//%IMPORTS%", importList);

            List<String> chars = new ArrayList<>();
            StringBuilder stringBuilder = new StringBuilder();

            StringBuilder shaderCases = new StringBuilder();
            var img = createFullscreenFontImage(stringBuilder, shaderCases);
            var imgLocal = createLocalEffectFontImage();
            fragmentShader = fragmentShader.replace("//%CASES%", shaderCases);

            chars.add(stringBuilder.toString());

            FontAsset.Builder fontAsset = FontAsset.builder();
            String formatted = String.format("font/%s.png", ShaderEffects.FONT.comp_4590().method_12832());
            fontAsset.add(new BitmapProvider(class_2960.method_60655(MODID, formatted), chars, 0));

            FontAsset.Builder fontAssetLocal = FontAsset.builder();
            String formatted2 = String.format("font/%s_local.png", ShaderEffects.FONT.comp_4590().method_12832());
            fontAssetLocal.add(new BitmapProvider(class_2960.method_60655(MODID, formatted2), chars, 0));

            var out = new ByteArrayOutputStream();
            var outLocal = new ByteArrayOutputStream();
            try {
                ImageIO.write(img, "PNG", out);
                ImageIO.write(imgLocal, "PNG", outLocal);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            builder.addData(String.format("assets/%s/font/%s.json", ShaderEffects.FONT.comp_4590().method_12836(), ShaderEffects.FONT.comp_4590().method_12832()), fontAsset.build().toBytes());
            if (ADD_LOCAL) builder.addData(String.format("assets/%s/font/%s_local.json", ShaderEffects.FONT.comp_4590().method_12836(), ShaderEffects.FONT.comp_4590().method_12832()), fontAssetLocal.build().toBytes());
            builder.addData(String.format("assets/%s/textures/font/%s.png", ShaderEffects.FONT.comp_4590().method_12836(), ShaderEffects.FONT.comp_4590().method_12832()), out.toByteArray());
            if (ADD_LOCAL) builder.addData(String.format("assets/%s/textures/font/%s_local.png", ShaderEffects.FONT.comp_4590().method_12836(), ShaderEffects.FONT.comp_4590().method_12832()), outLocal.toByteArray());
            builder.addData("assets/minecraft/shaders/core/rendertype_text.fsh", fragmentShader.getBytes(StandardCharsets.UTF_8));
        });
    }

    private static @NotNull BufferedImage createFullscreenFontImage(StringBuilder stringBuilder, StringBuilder shaderCases) {
        var img = new BufferedImage(ShaderEffects.EFFECTS.size(), 1, BufferedImage.TYPE_INT_ARGB);
        for (Map.Entry<class_2960, ShaderEffect> entry : ShaderEffects.EFFECTS.entrySet()) {
            var effect = entry.getValue();
            stringBuilder.append(effect.asChar());
            img.setRGB(effect.id() - 1, 0, effect.asFullscreenColor());

            shaderCases.append(FileUtil.wrapCase(effect.snippet(), effect.id()));
        }
        return img;
    }

    private static @NotNull BufferedImage createLocalEffectFontImage() {
        var img = new BufferedImage(ShaderEffects.EFFECTS.size(), 1, BufferedImage.TYPE_INT_ARGB);
        for (Map.Entry<class_2960, ShaderEffect> entry : ShaderEffects.EFFECTS.entrySet()) {
            var effect = entry.getValue();
            img.setRGB(effect.id() - 1, 0, effect.asLocalEffectColor());
        }
        return img;
    }

    public static MinecraftServerAudiences ADVENTURE;

    public static MinecraftServerAudiences adventure() {
        if (ADVENTURE == null) {
            throw new IllegalStateException("Tried to access Adventure without a running server!");
        }
        return ADVENTURE;
    }

    @Override
    public void onInitialize() {
        ShaderEffects.addImport(class_2960.method_60656("shaderfx_utils.glsl"));
        ShaderEffects.addImport(class_2960.method_60656("spikes.glsl"));
        ShaderEffects.addImport(class_2960.method_60656("fractal1.glsl"));
        ShaderEffects.addImport(class_2960.method_60656("fractal2.glsl"));

        ServerLifecycleEvents.SERVER_STARTING.register(server -> ADVENTURE = MinecraftServerAudiences.of(server));

        final SuggestionProvider<class_2168> SUGGESTER = (commandContext, suggestionsBuilder) -> class_2172.method_9264(ShaderEffects.EFFECTS.keySet().stream().map(class_2960::toString), suggestionsBuilder);
        CommandRegistrationCallback.EVENT.register((dispatcher, commandBuildContext, commandSelection) -> {
            dispatcher.register(commandFullscreen(SUGGESTER));
            dispatcher.register(commandLocal(SUGGESTER));
            dispatcher.register(commandCustom());
        });
    }

    private static LiteralArgumentBuilder<class_2168> commandFullscreen(SuggestionProvider<class_2168> suggestionProvider) {
        return class_2170.method_9247("shaderfx").requires(x -> x.method_9259(2)).then(class_2170.method_9247("run").then(class_2170.method_9244("id", class_2232.method_9441()).suggests(suggestionProvider).then(class_2170.method_9244("player", class_2186.method_9305()).then(class_2170.method_9244("color", class_11199.method_70758()).then(class_2170.method_9244("fadeIn", IntegerArgumentType.integer(0)).then(class_2170.method_9244("stay", IntegerArgumentType.integer(0)).then(class_2170.method_9244("fadeOut", IntegerArgumentType.integer(0)).executes(x -> {
            int color = class_11199.method_70760(x, "color");
            class_2960 id = class_2232.method_9443(x, "id");
            class_3222 player = class_2186.method_9315(x, "player");

            int fadeIn = IntegerArgumentType.getInteger(x, "fadeIn");
            int stay = IntegerArgumentType.getInteger(x, "stay");
            int fadeOut = IntegerArgumentType.getInteger(x, "fadeOut");

            var titlePacket = new class_5904(ShaderEffects.effectComponent(id, color));
            var timesPacket = new class_5905(fadeIn, stay, fadeOut);
            player.field_13987.method_14364(new class_8042(ImmutableList.of(timesPacket, titlePacket)));

            return Command.SINGLE_SUCCESS;
        })))).executes(x -> {
            int color = class_11199.method_70760(x, "color");
            class_2960 id = class_2232.method_9443(x, "id");
            class_3222 player = class_2186.method_9315(x, "player");

            var titlePacket = new class_5904(ShaderEffects.effectComponent(id, color));
            player.field_13987.method_14364(titlePacket);

            return Command.SINGLE_SUCCESS;
        })).executes(x -> {
            class_2960 id = class_2232.method_9443(x, "id");
            class_3222 player = class_2186.method_9315(x, "player");

            var titlePacket = new class_5904(ShaderEffects.effectComponent(id));
            player.field_13987.method_14364(titlePacket);

            return Command.SINGLE_SUCCESS;
        }))));
    }


    private static LiteralArgumentBuilder<class_2168> commandLocal(SuggestionProvider<class_2168> suggestionProvider) {
        return class_2170.method_9247("shaderfx:local").requires(x -> x.method_9259(2)).then(class_2170.method_9247("run").then(class_2170.method_9244("id", class_2232.method_9441()).suggests(suggestionProvider).then(class_2170.method_9244("player", class_2186.method_9305()).then(class_2170.method_9244("color", class_11199.method_70758()).then(class_2170.method_9244("fadeIn", IntegerArgumentType.integer(0)).then(class_2170.method_9244("stay", IntegerArgumentType.integer(0)).then(class_2170.method_9244("fadeOut", IntegerArgumentType.integer(0)).executes(x -> {
            int color = class_11199.method_70760(x, "color");
            class_2960 id = class_2232.method_9443(x, "id");
            class_3222 player = class_2186.method_9315(x, "player");

            int fadeIn = IntegerArgumentType.getInteger(x, "fadeIn");
            int stay = IntegerArgumentType.getInteger(x, "stay");
            int fadeOut = IntegerArgumentType.getInteger(x, "fadeOut");

            var titlePacket = new class_5904(ShaderEffects.effectComponentLocal(id, color));
            var timesPacket = new class_5905(fadeIn, stay, fadeOut);
            player.field_13987.method_14364(new class_8042(ImmutableList.of(timesPacket, titlePacket)));

            return Command.SINGLE_SUCCESS;
        })))).executes(x -> {
            int color = class_11199.method_70760(x, "color");
            class_2960 id = class_2232.method_9443(x, "id");
            class_3222 player = class_2186.method_9315(x, "player");

            var titlePacket = new class_5904(ShaderEffects.effectComponentLocal(id, color));
            player.field_13987.method_14364(titlePacket);

            return Command.SINGLE_SUCCESS;
        })).executes(x -> {
            class_2960 id = class_2232.method_9443(x, "id");
            class_3222 player = class_2186.method_9315(x, "player");

            var titlePacket = new class_5904(ShaderEffects.effectComponentLocal(id));
            player.field_13987.method_14364(titlePacket);

            return Command.SINGLE_SUCCESS;
        }))));
    }

    private static LiteralArgumentBuilder<class_2168> commandCustom() {
        return class_2170.method_9247("shaderfx:custom").requires(x -> x.method_9259(2)).then(class_2170.method_9247("run").then(class_2170.method_9244("text", StringArgumentType.string()).then(class_2170.method_9244("player", class_2186.method_9305()).then(class_2170.method_9244("fadeIn", IntegerArgumentType.integer(0)).then(class_2170.method_9244("stay", IntegerArgumentType.integer(0)).then(class_2170.method_9244("fadeOut", IntegerArgumentType.integer(0)).executes(x -> {
            class_3222 player = class_2186.method_9315(x, "player");

            int fadeIn = IntegerArgumentType.getInteger(x, "fadeIn");
            int stay = IntegerArgumentType.getInteger(x, "stay");
            int fadeOut = IntegerArgumentType.getInteger(x, "fadeOut");

            var titlePacket = new class_5904(Shaderfx.adventure().asNative(MiniMessage.miniMessage().deserialize(StringArgumentType.getString(x, "text"))));
            var timesPacket = new class_5905(fadeIn, stay, fadeOut);
            player.field_13987.method_14364(new class_8042(ImmutableList.of(timesPacket, titlePacket)));

            return Command.SINGLE_SUCCESS;
        })))).executes(x -> {
            class_3222 player = class_2186.method_9315(x, "player");

            var titlePacket = new class_5904(Shaderfx.adventure().asNative(MiniMessage.miniMessage().deserialize(StringArgumentType.getString(x, "text"))));
            player.field_13987.method_14364(titlePacket);

            return Command.SINGLE_SUCCESS;
        })).executes(x -> {
            class_3222 player = class_2186.method_9315(x, "player");

            var titlePacket = new class_5904(Shaderfx.adventure().asNative(MiniMessage.miniMessage().deserialize(StringArgumentType.getString(x, "text"))));
            player.field_13987.method_14364(titlePacket);

            return Command.SINGLE_SUCCESS;
        })));
    }
}

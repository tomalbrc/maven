package de.tomalbrc.shaderfx.api;

import net.minecraft.class_2960;
import net.minecraft.class_9848;

public class ShaderEffect {
    final class_2960 location;
    final int id;
    final String snippet;

    public ShaderEffect(class_2960 location, int id, String snippet) {
        this.location = location;
        this.id = id;
        this.snippet = snippet;
    }

    public class_2960 location() {
        return location;
    }

    public int id() {
        return this.id;
    }

    public String asChar() {
        return String.valueOf((char) (0xE100 + id()));
    }

    public int asFullscreenColor() {
        return class_9848.method_61324(251, 0, 0, id());
    }

    public int asLocalEffectColor() {
        return class_9848.method_61324(253, 0, 0, id());
    }

    public String snippet() {
        return this.snippet;
    }
}

package de.tomalbrc.shaderfx.api;

import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5250;

import static de.tomalbrc.shaderfx.Shaderfx.MODID;
import static de.tomalbrc.shaderfx.api.FileUtil.loadSnippet;

public class ShaderEffects {
    public static final class_11719.class_11721 FONT = new class_11719.class_11721(class_2960.method_60655(MODID, "fx"));
    public static final class_11719.class_11721 FONT_LOCAL = new class_11719.class_11721(class_2960.method_60655(MODID, "fx_local"));
    public static final Map<class_2960, ShaderEffect> EFFECTS = new Object2ObjectArrayMap<>();

    public static final List<class_2960> IMPORTS = new ArrayList<>();

    public static void addImport(class_2960 mojimport) {
        IMPORTS.add(mojimport);
    }

    public static class_5250 effectComponent(class_2960 effectId, int color) {
        return class_2561.method_43470(EFFECTS.get(effectId).asChar()).method_27696(class_2583.field_24360.method_27704(FONT).method_36139(color).method_65302(0));
    }

    public static class_5250 effectComponentLocal(class_2960 effectId, int color) {
        return class_2561.method_43470(EFFECTS.get(effectId).asChar()).method_27696(class_2583.field_24360.method_27704(FONT_LOCAL).method_36139(color).method_65302(0));
    }

    public static class_5250 effectComponentLocal(class_2960 effectId) {
        return effectComponentLocal(effectId, 0xFF_FF_FF);
    }

    public static class_5250 effectComponent(class_2960 effectId) {
        return effectComponent(effectId, 0xFF_FF_FF);
    }

    public static ShaderEffect effect(class_2960 resourceLocation) {
        return EFFECTS.get(resourceLocation);
    }

    public static ShaderEffect register(class_2960 id, String snippet, boolean addFont) {
        ShaderEffect effect = new ShaderEffect(id, EFFECTS.size() + 1, snippet);
        EFFECTS.put(id, effect);
        return effect;
    }

    public static ShaderEffect register(class_2960 id, String snippet) {
        return register(id, snippet, true);
    }

    public static final ShaderEffect CIRCLE = ShaderEffects.register(class_2960.method_60655(MODID, "circle"), loadSnippet("circle.glsl"));
    public static final ShaderEffect FADE = ShaderEffects.register(class_2960.method_60655(MODID, "fade"), "color = vec4(vertexColor.rgb, vertexColor.a);");
    public static final ShaderEffect DIRECTIONAL_GRID = ShaderEffects.register(class_2960.method_60655(MODID, "directional_grid"), loadSnippet("dir_grid_impl.glsl"));
    public static final ShaderEffect NOISE_GRID = ShaderEffects.register(class_2960.method_60655(MODID, "noise_grid"), "ivec2 grid = ivec2(gl_FragCoord.xy / 32) * 32; color = (abs(hash(grid.x ^ hash(grid.y)) % 0x100) + 10 < int(vertexColor.a * (length(grid / ScreenSize.xy - 0.5) * 2 + 1) * 0x100)) ? vec4(vertexColor.rgb, 1) : vec4(0);");
    public static final ShaderEffect FRACTAL1 = ShaderEffects.register(class_2960.method_60655(MODID, "fractal1"), "color = fractal1();");
    public static final ShaderEffect FRACTAL2 = ShaderEffects.register(class_2960.method_60655(MODID, "fractal2"), "color = fractal2();");
    public static final ShaderEffect APERTURE = ShaderEffects.register(class_2960.method_60655(MODID, "aperture"), loadSnippet("rot_impl.glsl"), false);
    public static final ShaderEffect SPIKE = ShaderEffects.register(class_2960.method_60655(MODID, "spike"), "color = spikes(vertexColor, centerUV, 0.09);");
    public static final ShaderEffect VIGNETTE = ShaderEffects.register(class_2960.method_60655(MODID, "vignette"), "color = vec4(vertexColor.rgb, clamp(length(centerUV * vec2(0.8, 0.5 / (1 - vertexColor.a))) - 0.6, 0, 1));");
    public static final ShaderEffect IMAGE_TRANSITION = ShaderEffects.register(class_2960.method_60655(MODID, "image_transition"), "float mask = texture(Sampler0, centerUV-0.5*vec2(1,-1)).r; color = vec4(vertexColor.rgb, step(mask, vertexColor.a));", false);
}
